SoundID Description                             MIDI filename
1       Start communicating with other AIBO     AS01_Start_AC.mid
2       Enter Media link mode(1)                AS02_Start_ML1.mid
3       Enter Media link mode(2)                AS03_Start_ML2.mid
4       Enter Media link mode(3)                AS04_Start_ML3.mid
5       Restore AIBO to autonomous/station mode AS05_End_ML.mid
6       Raise hand "hello"                      AS06_Hello.mid
7       Wave hand "bye"                         AS07_Bye.mid
8       Pretend sleeping                        AS08_Sleep.mid
9       Short nod                               AS09_Nod_Short.mid
10      Long nod                                AS10_Nod_Long.mid
11      Excited                                 AS11_Expect.mid
12      Yes                                     AS12_Yes.mid
13      No                                      AS13_No.mid
14      Question                                AS14_Question.mid
15      Happy                                   AS15_Joy.mid
16      Very happy                              AS16_Happy.mid
17      Dislike                                 AS17_Disgust.mid
18      Surprised                               AS18_Surprise.mid
19      Sad                                     AS19_Sad.mid
20      Relieved                                AS20_Relief.mid
21      Appeal                                  AS21_Appeal.mid
22      Various characteristic actions          AS22_Action.mid
23      Dance                                   AS23_Dance.mid
24      Song (1)                                AS24_Song1.mid
25      Song (2)                                AS25_Song2.mid
26      Favorite dance                          AS26_Fav_Dance.mid
27      Fear                                    AS27_Fear.mid
28      Bow                                     AS28_Greet.mid
29      Pose                                    AS29_Pose.mid
30      Banzai!                                 AS30_Cheer.mid
31      Attention                               AS31_Look.mid
32      Shy                                     AS32_Abash.mid
33      Charming                                AS33_Charm.mid
34      Inform its character                    AS34_Type_Check.mid
35      Inform receiving a call                 AS35_Call.mid
