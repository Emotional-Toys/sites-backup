//-------------------------------------------
//  Tracking 2
//-------------------------------------------

SET:Power:1
POSE:AIBO:slp_slp

:100
MOVE:HEAD:C-TRACKING	//Color tracking
WAIT
