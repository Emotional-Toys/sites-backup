//------------------------------------------
//  PLAY SOUND
//------------------------------------------

SET:Power:1
POSE:AIBO:slp_slp

:100

PLAY:SOUND:hppy_sit:50    //Joy
PLAY:AIBO:Happy_sit
WAIT

PLAY:SOUND:ang1_xxa:50    //Anger
PLAY:AIBO:Angry_sitc
WAIT

PLAY:SOUND:sad1_xxa:50    //Sorrow
PLAY:AIBO:Sad_sit
WAIT

PLAY:SOUND:joy1_xxa:50    //It is pleasant.
PLAY:AIBO:Joy1_std
WAIT

PLAY:SOUND:biku1ddx:50    //It is surprised.
PLAY:AIBO:Biku_std
WAIT

PLAY:SOUND:sup1_xxa:50    //Surprise
PLAY:AIBO:Biku_sit
WAIT

PLAY:SOUND:yes_tta:50    //Consent
PLAY:AIBO:Yes_sit
WAIT

