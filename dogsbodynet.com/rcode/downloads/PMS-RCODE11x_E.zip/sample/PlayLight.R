//------------------------------------------
//  PLAY Light
//------------------------------------------

SET:Power:1

:100

PLAY:LIGHT:hppy1eye:0�@   //joy
PLAY:AIBO:Happy_sit
WAIT
QUIT:LIGHT

PLAY:LIGHT:ang1_eye:0    //anger
PLAY:AIBO:Angry_sitc
WAIT
QUIT:LIGHT

PLAY:LIGHT:sos1_eye:0    //help is necessary.
PLAY:AIBO:Swing1_std_R
WAIT
QUIT:LIGHT

PLAY:LIGHT:joy1_eye:0    //It is pleasant.
PLAY:AIBO:Joy1_std
WAIT
QUIT:LIGHT

PLAY:LIGHT:sup1_eye:0    //Surprise.
PLAY:AIBO:Biku_sit
WAIT
QUIT:LIGHT
