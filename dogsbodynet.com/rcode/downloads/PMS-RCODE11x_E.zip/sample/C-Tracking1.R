//-------------------------------------------
//  Tracking 1
//-------------------------------------------

SET:Power:1
POSE:AIBO:slp_slp

SET:COLOR:PINK
MOVE:HEAD:C-TRACKING:1000
