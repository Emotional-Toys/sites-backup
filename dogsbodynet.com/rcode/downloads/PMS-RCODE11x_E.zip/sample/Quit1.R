//------------------------------------------
//  QUIT 1
//------------------------------------------

SET:Power:1
POSE:AIBO:slp_slp
WAIT
MOVE:HEAD:HOME
WAIT
MOVE:HEAD:ABS:0:90:0:5000
WAIT:1000
QUIT:HEAD
