//------------------------------------------
//  PLAY AIBO
//------------------------------------------

SET:Power:1
POSE:AIBO:slp_slp

:100

PLAY:AIBO:Akubi_sit
WAIT

PLAY:AIBO:BadB_sit
WAIT

PLAY:AIBO:Banzai_sit_C
WAIT

PLAY:AIBO:Bata_slp
WAIT

PLAY:AIBO:Biku_sit
WAIT

PLAY:AIBO:Bound_sit
WAIT

PLAY:AIBO:Cry_slp
WAIT

PLAY:AIBO:Fear_sit3
WAIT

PLAY:AIBO:Find_slp_C
WAIT

PLAY:AIBO:Gari_slp
WAIT

PLAY:AIBO:GetupB_fall_std
WAIT

PLAY:AIBO:JitaKyoro_fall
WAIT

PLAY:AIBO:Joy1_std
WAIT

PLAY:AIBO:Kyoro_sit_R
WAIT

PLAY:AIBO:Look_slp
WAIT

PLAY:AIBO:Ltouch_sit
WAIT
