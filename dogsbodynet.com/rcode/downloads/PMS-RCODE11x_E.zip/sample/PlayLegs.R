//------------------------------------------
//  The movement of LEGS
//------------------------------------------

SET:Power:1
POSE:AIBO:slp_slp

:100

PLAY:LEGS:Brise_slp
WAIT

PLAY:LEGS:Hand_slpb
WAIT

PLAY:LEGS:KickL_std
WAIT

PLAY:LEGS:LtouchL_sit
WAIT

PLAY:LEGS:OteL1_sit
WAIT

PLAY:LEGS:sit_sit
WAIT

PLAY:LEGS:slp_slp
WAIT

PLAY:LEGS:StouchL_sit
WAIT

PLAY:LEGS:Waku_slpb3
WAIT
