//------------------------------------------
//  POSE Legs
//------------------------------------------

SET:Power:1
POSE:AIBO:slp_slp

:100
PLAY:SOUND:trk4_xxx:50   //Start sound
POSE:LEGS:oSitting
WAIT

PLAY:SOUND:trk4_xxx:50	//Start sound
POSE:LEGS:oSit_Otel
WAIT

PLAY:SOUND:trk4_xxx:50	//Start sound
POSE:LEGS:oStanding
WAIT

PLAY:SOUND:trk4_xxx:50	//Start sound
POSE:LEGS:oSleeping
WAIT

PLAY:SOUND:trk4_xxx:50	//Start sound
POSE:LEGS:oSlp_Otel
WAIT

PLAY:SOUND:trk4_xxx:50	//Start sound
POSE:LEGS:oStation
WAIT
