//------------------------------------------
//  PLAY TAIL
//------------------------------------------

SET:Power:1

:100

PLAY:TAIL:Akubi_slpb3
WAIT

PLAY:TAIL:Dere_sitb
WAIT

PLAY:TAIL:No2_sta
WAIT

PLAY:TAIL:oSittingAngry1
WAIT

PLAY:TAIL:oSleepingAngry1
WAIT

PLAY:TAIL:oStandingAngry1
WAIT

PLAY:TAIL:oStationAngry1
WAIT

PLAY:TAIL:sit_sit
WAIT

PLAY:TAIL:slp_slp
WAIT

PLAY:TAIL:sta_sta
WAIT

PLAY:TAIL:Stail_sit
WAIT

PLAY:TAIL:stajoy1_sta
WAIT

PLAY:TAIL:std_home
WAIT

PLAY:TAIL:Tail_sitb2
WAIT
