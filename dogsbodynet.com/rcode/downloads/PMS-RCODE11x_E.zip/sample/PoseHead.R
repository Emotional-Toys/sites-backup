//------------------------------------------
//  POSE & HEAD
//------------------------------------------

SET:Power:1

:100
PLAY:SOUND:trk4_xxx:50  	//Start sound
POSE:HEAD:oHome 
WAIT:5000

PLAY:SOUND:trk4_xxx:50 		//Start sound
POSE:HEAD:oLow  
WAIT:5000

PLAY:SOUND:trk4_xxx:50		//Start sound
POSE:HEAD:oP0T30
WAIT:5000

PLAY:SOUND:trk4_xxx:50		//Start sound
POSE:HEAD:oSleeping
WAIT:5000

PLAY:SOUND:trk4_xxx:50		//Start sound
POSE:HEAD:oStanding
WAIT:5000

PLAY:SOUND:trk4_xxx:50		//Start sound
POSE:HEAD:oSitting
WAIT:5000

PLAY:SOUND:trk4_xxx:50		//Start sound
POSE:HEAD:oStation
WAIT
