//------------------------------------------
//  The movement of the head.
//------------------------------------------

SET:Power:1

:100

PLAY:HEAD:Akubi_sitb
WAIT

PLAY:HEAD:Dere_sitb
WAIT

PLAY:HEAD:Down_sit
WAIT

PLAY:HEAD:Kyoro_sitb2
WAIT

PLAY:HEAD:LookL_stay_pan+5
WAIT

PLAY:HEAD:low_home
WAIT

PLAY:HEAD:No_sta
WAIT

PLAY:HEAD:sta_sta
WAIT

PLAY:HEAD:p0t30_p-30t30
WAIT

PLAY:HEAD:Paku_sitb2
WAIT

PLAY:HEAD:sit_sit
WAIT

PLAY:HEAD:slp_slp
WAIT

PLAY:HEAD:Up_sit
WAIT
