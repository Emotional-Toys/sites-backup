
////////////////////////////////////////////////////////////////////
//                                                                //
//  DogsLife Rest Mode Module                                     //
//  Copyright (C) 2001-2002 by DogsBody & Ratchet Software        //
//  All Rights Reserved                                           //
//                                                                //
//  This is free software and MAY NOT be sold under any           //
//  circumstances, seperately or bundled.                         //
//                                                                //
////////////////////////////////////////////////////////////////////


//
// Handle if hungry, too hot, on charger, picked up, etc...
//
:G_RESTMODE

PRINT:"Restmode.  Batt_Rest=%d  Body_Temp=%d  Batt_Temp=%d":Batt_Rest:Body_Temp:Batt_Temp

IF Posture1 == POSTURE_WALK THEN
  PLAY ACTION STAND
  WAIT
  CLR SENSORS
  RND bored_timer 30 60
  RND maxtime2 1 3	// Look around timer
ENDIF

:1456	// HUNGREY?
IF_1ST Batt_Rest < 25 1467
IF_1ST Body_Temp > 45 1463
IF_1ST Batt_Temp > 45 1463

SWITCH Posture1
  CASE:POSTURE_PICKUP GO 1461	// Picked up?
  CASE:POSTURE_CHARGE1 GO 1461	// On charger? (babypos)
  CASE:POSTURE_CHARGE2 GO 1461	// On charger? (normal)
CALL G_SEE_BALL?
  CASE:GO_SEEBALL RET:GO_SEEBALL
CALL G_RANDOM2
  CASE:1 RET:GO_DOWNPOS
RET:GO_SITPOS

:1461	// STATIONPOS
CALL G_STATIONPOS

:1462	// loop
GO 1456

:1463	// TOO_HOT
PLAY ACTION LIE
WAIT

:1464	// WAIT_10_SEC
PLAY ACTION+ panting
WAIT 10000
PRINT Batt_Rest=%d Batt_Rest
PRINT Batt_Temp=%d Batt_Temp
PRINT Body_Temp=%d Body_Temp
CALL G_STATION_SHUTDOWN
WAIT 1
IF_1ST Batt_Rest < 25 1462
IF_1ST Body_Temp <= 40
IF_AND Batt_Temp <= 40 1462
GO 1464

:1467	// HUNGRY
PLAY ACTION+ hungry_empty
WAIT
PLAY ACTION CHGPOS.STATR.NORMAL
WAIT
PLAY ACTION PALONE.AUTO.TAILH

:1468	// WAIT_5_SEC
WAIT 5000
PRINT Batt_Rest=%d Batt_Rest
PRINT Batt_Temp=%d Batt_Temp
PRINT Body_Temp=%d Body_Temp
CALL G_STATION_SHUTDOWN

WAIT 1
IF_1ST Batt_Rest < 25 1468
PLAY ACTION PALONE.AUTO.TAILSTOP
WAIT
GO 1456



