
////////////////////////////////////////////////////////////////////
//                                                                //
//  DogsLife Sleep Position Behavior Module                       //
//  Copyright (C) 2001-2002 by DogsBody & Ratchet Software        //
//  All Rights Reserved                                           //
//                                                                //
//  This is free software and MAY NOT be sold under any           //
//  circumstances, seperately or bundled.                         //
//                                                                //
////////////////////////////////////////////////////////////////////


//
//  Behavior when laying down...
//
:G_SLEEPPOS
CALL G_INIT_SLEEPPOS

:SLEEP_LOOP	// INIT_TIMERS
CALL G_UPDATE_PAUSEBAR
SET Clock 0
RND maxtime1 3 10	// 3 to 10 seconds
RND maxtime2 0 2	// 0 to 2 seconds
RND maxtime3 5 10	// 5 to 10 seconds
SET tailwag 0
SET tilt Head_Tilt
SET pan Head_Pan
IF_1ST mood_happy > 3 2291

:2257	// NEED2REST?
CALL G_NEED2REST
  CASE:1 GO 2290
WAIT 50
CALL G_REST_TIMER
CALL G_SEE_BALL?
  CASE:GO_IDLE GO 2262
  CASE:GO_IGNORE GO 2262
CALL G_STAND4BALL
  CASE:2 RET:GO_SEEBALL
  CASE:3 RET:GO_STANDPOS
  CASE:4 RET:GO_RESTPOS

:2262	// ATTENTION?
CALL G_SLEEP_ATTENTION
  CASE:1 GO 2289 // look timer
  CASE:2 GO 2288 // praise
  CASE:3 GO 2287 // petted
  CASE:4 GO 2284 // scolded

// Call voice command customization routine...
IF sitonly > 0 THEN
  CALL G_CUSTOM_SLEEP_VOICECMD
    CASE:GO_SITPOS   RET:GO_SITPOS
    CASE:GO_STANDPOS GO 2264
    CASE:GO_WALK     GO 2264
    CASE:GO_SEEBALL  GO 2264
    CASE:GO_IGNORE   GO 2264
ELSE
  CALL G_CUSTOM_SLEEP_VOICECMD
    CASE:GO_SITPOS   RET:GO_SITPOS
    CASE:GO_STANDPOS RET:GO_STANDPOS
    CASE:GO_WALK     RET:GO_WALK
    CASE:GO_SEEBALL  RET:GO_SEEBALL
    CASE:GO_IGNORE   GO 2264
ENDIF

// If not overridden, do normal voice command processing...
CALL G_SLEEP_VOICE_HANDLER
  CASE:1 GO 2265
  CASE:3 RET:GO_WALK
  CASE:4 RET:GO_SITPOS
  CASE:5 RET:GO_SEEBALL
  CASE:6 RET:GO_STANDPOS
  CASE:7 RET:GO_RESTPOS

:2264	// loop
ADD change_thres 2
GO SLEEP_LOOP

:2265	// NOSE_SENSE?
CALL G_SLEEP_NOSE_SENSE
CALL G_BORED_TIMER
  CASE:1 GO 2257

// Go process pending voice command...
IF_1ST AP_Voice_Cmd > 0 
IF_AND AP_Voice_Level >= MIN_VOICE_LEVEL 2262

// Should we go walking?  10% of the time, yes (if not too tired)...
RND rndnum 0 100
IF (sitonly == 0) && (rndnum<=10) && (mood_tired<=5) && (bored_count<1) THEN
  RET:GO_WALK
ENDIF

// Should we sit?
IF rndnum <= 20 THEN // 20% of the time, yes...
  SET sleepsit 1
  RET:GO_SITPOS
ENDIF

// Change sleep position?
IF_1ST rndnum < change_thres SLEEP_CHANGEPOS

IF rndnum < 90 THEN
  RND rndnum 0 100
  // If upset, cry...
  IF (mood_sad>5) && (rndnum<(mood_sad-5)*10) THEN
    CALL:G_SAD
    GO SLEEP_LOOP
  ENDIF

  // Bored skit?
  IF (rndnum > 33) && (bored_count < 3) THEN
    CALL G_SLEEP_BORED
    CALL G_BEHAVIOR_BORED
    ADD change_thres 2
    GO SLEEP_LOOP
  ENDIF

  // Happy skit?
  IF (rndnum > 66) && (bored_count >= 3) && (mood_happy > 5) THEN
    CALL G_SLEEP_HAPPY
    ADD change_thres 2
    GO SLEEP_LOOP
  ENDIF

  // Tailsong skit?
  IF (rndnum > 66) && (bored_count >= 3) && (mood_happy > 2) THEN
    CALL G_SLEEP_TAILSONG
    ADD change_thres 2
    GO SLEEP_LOOP
  ENDIF
ENDIF

// Do little "calm" act while in sleep position...
CALL G_SLEEP_CALM
ADD change_thres 2
GO SLEEP_LOOP

:SLEEP_CHANGEPOS
CALL G_SLEEP_CHANGEPOS
ADD change_thres 2
GO SLEEP_LOOP

:2284	// SCOLD
CALL G_SCOLD_REST

:2285	// RESET_BORED
RND bored_count 5 10
CALL G_CLEAR_SENSORS
ADD change_thres 2
GO SLEEP_LOOP

:2287	// SLEEP_PETTED
CALL G_SLEEP_PETTED
GO 2285

:2288	// PRAISE
CALL G_PRAISE_REST
GO 2285

:2289	// LOOK_TIMER
CALL G_LOOK_TIMER
GO 2265

:2290	// STOP_TAILWAG1
CALL G_STOP_TAILWAG
RET:GO_RESTPOS

:2291	// START_TAILWAG
PLAY ACTION TAILWAG_VERT1
SET tailwag 1
GO 2257



////////////////////////////////////////////////////////////////////
// INIT_SLEEPPOS
:G_INIT_SLEEPPOS
PRINT SLEEPPOS
SET sleepstate 0	// 0=pos,1=wide,2=flat
SET change_thres 40	// Change threshold
SET nosecount 0	// # of nose triggers
SET back_count 0	// # b2b back pets

WAIT 1
SET init_wait Wait

PLAY ACTION LIE
CALL G_WAIT
CALL G_CLEAR_SENSORS

WAIT 1
IF_1ST sleepsit > 0
IF_AND bored_count < 3 1247
IF_1ST sleepsit > 0 1246
RND bored_count 3 10

:1246	// DONE
SET sleepsit 0
SET tiltadj Head_Tilt	// See how out-of-whack head tilt is
RET 1

:1247	// SIT2SLEEP
RND bored_count 3 5
SET sleepsit 0
SET tiltadj Head_Tilt	// See how out-of-whack head tilt is
RET 1


////////////////////////////////////////////////////////////////////
//
//  Process user praise/scolding while in sleep position...
//
:G_SLEEP_ATTENTION
CALL G_ATTENTION_HANDLER
  CASE:2 RET 2	// praise
  CASE:3 RET 3	// pet
  CASE:4 RET 4	// scold
  CASE:5 RET 5	// voice
CALL G_TAIL_TWEAKED
  CASE:2 RET 2	// praise
  CASE:3 RET 4	// scold
  CASE:4 RET 5	// voice
WAIT 1
IF_1ST RFLeg_ON <> 0 1947

:1939	// LF_FOOT_ON?
IF_1ST LFLeg_ON <> 0 1946

:1940	// CHECK_RFEET?
IF_1ST sleepstate = 0 1943	// Rear feet on floor
IF_1ST RRLeg_3 < 30
IF_AND RRLeg_ON > 0 1945

:1942	// LR_FOOT_ON?
IF_1ST LRLeg_3 < 30
IF_AND LRLeg_ON > 0 1944

:1943	// DECIDE
IF_1ST pet = 0 1948
RET 3	// pet

:1944	// LR_FOOT_ON
ADD pet 64
SET LRLeg_ON 0
SET back_count 0
GO 1943

:1945	// RR_FOOT_ON
ADD pet 32
SET RRLeg_ON 0
SET back_count 0
GO 1942

:1946	// LF_FOOT_ON
ADD pet 16
SET LFLeg_ON 0
SET back_count 0
GO 1940

:1947	// RF_FOOT_ON
ADD pet 8
SET RFLeg_ON 0
SET back_count 0
GO 1939

:1948	// none
RET 1

////////////////////////////////////////////////////////////////////
// SLEEP_BORED  (Do something when bored in sleep position)
:G_SLEEP_BORED

:1954	// SLEEPSTATE?
SWITCH sleepstate
  CASE:0 GO 1986	// SleepPos
  CASE:1 GO 1975	// SleepWide
  CASE:2 GO 1963	// SleepFlat
SET rndbase 250
SET rndcount 2
SET lastact1 last_boredact
SET lastact2 last_boredact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1962
  CASE:2 GO 1958
RET 1

:1958	// SELECT_BELLY
IF_1ST rndnum = 250 1961
PLAY ACTION HOWL_BELLY2
SET last_boredact rndnum

:4119	// WAIT_BELLY
WAIT
RET 1

:1961	// bhowl1
PLAY ACTION HOWL_BELLY1
SET last_boredact rndnum
GO 4119

:1962	// SLEEP_PICKPOS
CALL G_SLEEP_PICKPOS
GO 1954

:1963	// SLEEPFLAT
SET rndbase 200
SET rndcount 8
SET lastact1 last_boredact
SET lastact2 last_boredact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1962
  CASE:3 RET 1
SWITCH rndnum
  CASE:200 PLAY ACTION ANYONE_THERE1
  CASE:201 PLAY ACTION ANYONE_THERE2
  CASE:202 PLAY ACTION ANYONE_THERE3
  CASE:203 PLAY ACTION ANYONE_THERE4
  CASE:204 PLAY ACTION BORED_SLEEP1
  CASE:205 PLAY ACTION HOWL_SLEEP1
  CASE:206 PLAY ACTION HOWL_SLEEP2
  CASE:ELSE PLAY ACTION PET_ME
SET last_boredact rndnum
WAIT
RET 1

:1975	// SLEEPWIDE
SET rndbase 150
SET rndcount 7
SET lastact1 last_boredact
SET lastact2 last_boredact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1962
  CASE:3 RET 1
SWITCH rndnum
  CASE:150 PLAY ACTION BORED_SLEEP5
  CASE:151 PLAY ACTION BORED_SLEEP6
  CASE:152 PLAY ACTION BORED_SLEEP7
  CASE:153 PLAY ACTION BORED_SLEEP8
  CASE:154 PLAY ACTION BORED_SLEEP9
  CASE:155 PLAY ACTION BORED_SLEEP10
  CASE:ELSE PLAY ACTION TWITCHY
SET last_boredact rndnum
WAIT
RET 1

:1986	// SLEEPPOS
SET rndbase 100
SET rndcount 9
SET lastact1 last_boredact
SET lastact2 last_boredact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1962
  CASE:3 RET 1
SWITCH rndnum
  CASE:100 PLAY ACTION BORED_SLEEP2
  CASE:101 PLAY ACTION BORED_SLEEP3
  CASE:102 PLAY ACTION BORED_SLEEP4
  CASE:103 PLAY ACTION NOBI1
  CASE:104 PLAY ACTION NOBI2
  CASE:105 PLAY ACTION NOBI3
  CASE:106 PLAY ACTION WANT_ATTENTION_SLEEP1
  CASE:107 PLAY ACTION WANT_ATTENTION_SLEEP2
  CASE:ELSE PLAY ACTION IMPATIENT_SLEEP
SET last_boredact rndnum
WAIT
RET 1

////////////////////////////////////////////////////////////////////
// SLEEP_CALM  (Do something when calm in sleep position)
:G_SLEEP_CALM

:2001	// SLEEPSTATE?
SWITCH sleepstate
  CASE:0 GO 2036	// SleepPos
  CASE:1 GO 2023	// SleepWide
  CASE:2 GO 2019	// SleepFlat
SET rndbase 700
SET rndcount 10
SET lastact1 last_calmact
SET lastact2 last_calmact2
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 2018
  CASE:2 GO 2005
RET 1

:2005	// SELECT_BELLY
SWITCH rndnum
  CASE:700 PLAY ACTION CONFUSED1
  CASE:701 PLAY ACTION CONFUSED2
  CASE:702 PLAY ACTION OHWELL
  CASE:703 PLAY ACTION BOTH_EAR_TWITCH4
  CASE:704 PLAY ACTION BOTH_EAR_TWITCH5
  CASE:705 PLAY ACTION WAVE_LEFT_BELLY1
  CASE:706 PLAY ACTION WAVE_LEFT_BELLY2
  CASE:707 PLAY ACTION WAVE_RIGHT_BELLY1
  CASE:708 PLAY ACTION WAVE_RIGHT_BELLY2
  CASE:ELSE PLAY ACTION THINKING_BELLY
WAIT
SET last_calmact2 last_calmact
SET last_calmact rndnum
RET 1

:2018	// SLEEP_PICKPOS
CALL G_SLEEP_PICKPOS
GO 2001

:2019	// SLEEPFLAT
RND rndnum 650 650
IF_1ST rndnum = last_calmact 2018
IF_1ST rndnum = last_calmact2 2018
PLAY ACTION LOOKAROUND_SLEEP1
WAIT
SET last_calmact2 last_calmact
SET last_calmact rndnum
RET 1

:2023	// SLEEPWIDE
SET rndbase 600
SET rndcount 9
SET lastact1 last_calmact
SET lastact2 last_calmact2
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 2018
  CASE:3 RET 1
SWITCH rndnum
  CASE:600 PLAY ACTION PLAY_VIOLIN
  CASE:601 PLAY ACTION TAP_REARRIGHT
  CASE:602 PLAY ACTION SMOKING
  CASE:603 PLAY ACTION SNEEZE
  CASE:604 PLAY ACTION CUTE_BOXING
  CASE:605 PLAY ACTION SCRATCH_REAR
  CASE:606 PLAY ACTION DRINKING
  CASE:607 PLAY ACTION LOOKAROUND_SLEEP3
  CASE:ELSE PLAY ACTION EATING
WAIT
SET last_calmact2 last_calmact
SET last_calmact rndnum
RET 1

:2036	// SLEEPPOS
SET rndbase 550
SET rndcount 8
SET lastact1 last_calmact
SET lastact2 last_calmact2
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 2018
  CASE:3 RET 1
SWITCH rndnum
  CASE:550 PLAY ACTION HICCUPS_SLEEP
  CASE:551 PLAY ACTION YOGA
  CASE:552 PLAY ACTION CUTE_EXERCISE1
  CASE:553 PLAY ACTION CUTE_EXERCISE2
  CASE:554 PLAY ACTION CUTE_EXERCISE4
  CASE:555 PLAY ACTION SCRATCH_LEFTEAR2
  CASE:556 PLAY ACTION THINKING_SLEEP
  CASE:ELSE PLAY ACTION LOOKAROUND_SLEEP2
WAIT
SET last_calmact2 last_calmact
SET last_calmact rndnum
RET 1

////////////////////////////////////////////////////////////////////
// SLEEP_CHANGEPOS  (Change to new sleep position)
:G_SLEEP_CHANGEPOS
CALL G_SLEEP_PICKPOS
SWITCH sleepstate
  CASE:0 PLAY ACTION LIE
  CASE:1 PLAY ACTION SLEEPWIDE
  CASE:2 PLAY ACTION SLEEPFLAT
  CASE:ELSE PLAY ACTION BELLYPOS
SET change_thres 15
WAIT
CALL G_CLEAR_SENSORS
RET 1

////////////////////////////////////////////////////////////////////
// SLEEP_DANCE  (Perform dance when in lay-down (sleep) position)
:G_SLEEP_DANCE

:2060	// SLEEPSTATE?
SWITCH sleepstate
  CASE:0 GO 2086	// SleepPos
  CASE:1 GO 2077	// SleepWide
  CASE:2 GO 2073	// SleepFlat
SET rndbase 900
SET rndcount 6
SET lastact1 last_danceact
SET lastact2 last_danceact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 2072
  CASE:2 GO 2064
RET 1

:2064	// SELECT_BELLY
SWITCH rndnum
  CASE:900 PLAY ACTION DANCE_BELLY1
  CASE:901 PLAY ACTION DANCE_BELLY2
  CASE:902 PLAY ACTION DANCE_BELLY3
  CASE:903 PLAY ACTION DANCE_BELLY4
  CASE:904 PLAY ACTION DANCE_BELLY5
  CASE:ELSE PLAY ACTION DANCE_BELLY6
SET last_danceact rndnum
WAIT
RET 1

:2072	// SLEEP_PICKPOS
CALL G_SLEEP_PICKPOS
GO 2060

:2073	// RNDNUM_FLAT
RND rndnum 200 200
IF_1ST rndnum = last_danceact 2072
PLAY ACTION DANCE_SLEEP1
SET last_danceact rndnum
WAIT
RET 1

:2077	// SLEEPWIDE
SET rndbase 800
SET rndcount 5
SET lastact1 last_danceact
SET lastact2 last_danceact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 2072
  CASE:3 RET 1
SWITCH rndnum
  CASE:800 PLAY ACTION DANCE_SLEEP5
  CASE:801 PLAY ACTION DANCE_SLEEP6
  CASE:802 PLAY ACTION DANCE_SLEEP7
  CASE:803 PLAY ACTION SONG_SLEEP1
  CASE:ELSE PLAY ACTION SONG_SLEEP2
SET last_danceact rndnum
WAIT
RET 1

:2086	// SLEEPPOS
SET rndbase 750
SET rndcount 3
SET lastact1 last_danceact
SET lastact2 last_danceact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 2072
  CASE:3 RET 1
SWITCH rndnum
  CASE:750 PLAY ACTION DANCE_SLEEP2
  CASE:751 PLAY ACTION DANCE_SLEEP3
  CASE:ELSE PLAY ACTION DANCE_SLEEP4
SET last_danceact rndnum
WAIT
RET 1

////////////////////////////////////////////////////////////////////
// SLEEP_GREET  (Do little greeting.)
:G_SLEEP_GREET
WAIT 1
SET init_wait Wait
CALL G_RANDOM1/3
  CASE:1 GO 2110

:2097	// POSITION?
SWITCH sleepstate
  CASE:0 GO 2107
  CASE:1 GO 2104
CALL G_RANDOM4
  CASE:1 PLAY ACTION WAVE_LEFT_BELLY1
  CASE:2 PLAY ACTION WAVE_LEFT_BELLY2
  CASE:3 PLAY ACTION WAVE_RIGHT_BELLY1
  CASE:4 PLAY ACTION WAVE_RIGHT_BELLY2
SET sleepstate 3

:2100	// WAIT
CALL G_WAIT_AWARE
RET 1

:2104	// RANDOM2(2)
CALL G_RANDOM2
  CASE:1 PLAY ACTION SHYWAVE1
  CASE:2 PLAY ACTION SHYWAVE2
SET sleepstate 1
GO 2100

:2107	// RANDOM2
CALL G_RANDOM2
  CASE:1 PLAY ACTION WAVE_LEFT_SLEEP
  CASE:2 PLAY ACTION WAVE_RIGHT_SLEEP
SET sleepstate 0
GO 2100

:2110	// SLEEP_PICKPOS
CALL G_SLEEP_PICKPOS
GO 2097

////////////////////////////////////////////////////////////////////
// SLEEP_HAPPY  (Do something when happy in sleep position)
:G_SLEEP_HAPPY

:2113	// SLEEPSTATE?
SWITCH sleepstate
  CASE:0 GO 2140	// SleepPos
  CASE:1 GO 2130	// SleepWide
  CASE:2 GO 2126	// SleepFlat
SET rndbase 450
SET rndcount 6
SET lastact1 last_happyact
SET lastact2 last_happyact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 2125
  CASE:2 GO 2117
RET 1

:2117	// SELECT_BELLY
SWITCH rndnum
  CASE:450 PLAY ACTION DANCE_BELLY1
  CASE:451 PLAY ACTION DANCE_BELLY2
  CASE:452 PLAY ACTION DANCE_BELLY3
  CASE:453 PLAY ACTION DANCE_BELLY4
  CASE:454 PLAY ACTION DANCE_BELLY5
  CASE:ELSE PLAY ACTION DANCE_BELLY6
SET last_happyact rndnum
WAIT
RET 1

:2125	// SLEEP_PICKPOS
CALL G_SLEEP_PICKPOS
GO 2113

:2126	// SLEEPFLAT
RND rndnum 400 400
IF_1ST rndnum = last_happyact 2125
PLAY ACTION DANCE_SLEEP1
SET last_happyact rndnum
WAIT
RET 1

:2130	// SLEEPWIDE
SET rndbase 350
SET rndcount 6
SET lastact1 last_happyact
SET lastact2 last_happyact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 2125
  CASE:3 RET 1
SWITCH rndnum
  CASE:350 PLAY ACTION DANCE_SLEEP5
  CASE:351 PLAY ACTION DANCE_SLEEP6
  CASE:352 PLAY ACTION DANCE_SLEEP7
  CASE:353 PLAY ACTION LAUGH
  CASE:354 PLAY ACTION SONG_SLEEP1
  CASE:ELSE PLAY ACTION SONG_SLEEP2
SET last_happyact rndnum
WAIT
RET 1

:2140	// SLEEPPOS
SET rndbase 300
SET rndcount 3
SET lastact1 last_happyact
SET lastact2 last_happyact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 2125
  CASE:3 RET 1
SWITCH rndnum
  CASE:300 PLAY ACTION DANCE_SLEEP2
  CASE:302 PLAY ACTION DANCE_SLEEP3
  CASE:ELSE PLAY ACTION DANCE_SLEEP4
SET last_happyact rndnum
WAIT
RET 1

////////////////////////////////////////////////////////////////////
// SLEEP_NOSE_SENSE
:G_SLEEP_NOSE_SENSE
WAIT 1
IF_1ST Wait = 0
IF_AND nosecount < 3 2150
IF_1ST Wait = 1
IF_AND tailwag > 0
IF_AND nosecount < 3 2150
RET 1

:2150	// NOSE_DIST?
IF_1ST Distance < 200
IF_AND Head_Tilt > -5 2151
RET 1

:2151	// INIT
SET init_wait Wait
ADD nosecount 1
CALL G_RANDOM1/3
  CASE:2 RET 1
CALL G_RANDOM2
  CASE:1 PLAY ACTION LOOKAWAY_LEFT_SLEEP1
  CASE:2 PLAY ACTION LOOKAWAY_RIGHT_SLEEP1
SET sleepstate 0
CALL G_WAIT_AWARE
RET 1

////////////////////////////////////////////////////////////////////
// SLEEP_PETTED
:G_SLEEP_PETTED
CALL G_RANDOM3
  CASE:1 GO 2182
  CASE:2 GO 2177

:2160	// LOTS_BACK_PET?
IF_1ST back_count > 4 2174

:2161	// RNDNUM
RND rndnum 0 5
WAIT 1
SET init_wait Wait
IF_1ST rndnum = last_petsong 2161
SWITCH rndnum
  CASE:0 GO 2173
  CASE:1 GO 2172
  CASE:2 GO 2171
  CASE:3 PLAY ACTION BEEN_PETTED18
  CASE:4 PLAY ACTION BEEN_PETTED19
  CASE:ELSE PLAY ACTION BEEN_PETTED20

:2165	// TRACK_PETSONG
SET last_petsong rndnum
CALL G_WAIT

:2167	// INC_HAPPY_MOOD
CALL G_INC_HAPPY_MOOD
CALL G_DEC_MAD_MOOD
CALL G_DEC_SAD_MOOD
RET 1

:2171	// pet17
PLAY ACTION BEEN_PETTED17
SET sleepstate 0
GO 2165

:2172	// pet16
PLAY ACTION BEEN_PETTED16
SET sleepstate 0
GO 2165

:2173	// pet15
PLAY ACTION BEEN_PETTED15
SET sleepstate 0
GO 2165

:2174	// petkick
SET sleepstate 0
SET last_petsong 999
PLAY ACTION+ petting_kick_sleep
CALL G_WAITLAST
SET Back_ON 0
GO 2167

:2177	// petted2
WAIT 1
SET init_wait Wait
PLAY ACTION TUNE_PETTED2

:2178	// WAIT
CALL G_WAIT
IF_1ST mood_happy > 4 2181
CALL G_RANDOM1/3
  CASE:1 GO 2160
GO 2167

:2181	// RANDOM(1)
CALL G_RANDOM1/3
  CASE:1 GO 2167
GO 2160

:2182	// petted1
WAIT 1
SET init_wait Wait
PLAY ACTION TUNE_PETTED1
GO 2178

////////////////////////////////////////////////////////////////////
// SLEEP_PICKPOS  (Pick a new sleep position (but dont change to it))
:G_SLEEP_PICKPOS

:2185	// NEW_STATE
RND rndnum 0 3
IF_1ST rndnum = sleepstate 2185
SET sleepstate rndnum
RET 1

////////////////////////////////////////////////////////////////////
// SLEEP_TAILSONG  (Play a little tune accompanied with tail wagging)
:G_SLEEP_TAILSONG
SET rndbase 500
SET rndcount 6
SET lastact1 last_tailsong
SET lastact2 last_tailsong
CALL G_BEHAVIOR_RNDN
  CASE:2 RET 1
SWITCH rndnum
  CASE:500 PLAY ACTION TAILWAG_SONG1
  CASE:501 PLAY ACTION TAILWAG_SONG2
  CASE:502 PLAY ACTION TAILWAG_SONG3
  CASE:503 PLAY ACTION TAILWAG_SONG4
  CASE:504 PLAY ACTION TAILWAG_SONG5
  CASE:ELSE PLAY ACTION TAILWAG_SONG6
SET last_tailsong rndnum
SET sleepstate 0
WAIT
RET 1

////////////////////////////////////////////////////////////////////
// SLEEP_VOICE_HANDLER  (Voice Processing when laying down)
:G_SLEEP_VOICE_HANDLER
CALL G_STOP_HEAD
SWITCH VoiceCmd
  CASE:HEARD_RHYTHM GO 2222		// Rhythm?
  CASE:VOICE_WALK GO 2245		// Walk
  CASE:VOICE_FINDBALL GO 2233		// Find Ball
  CASE:VOICE_KICKBALL GO 2233		// Kick Ball
  CASE:VOICE_LETSDANCE GO 2231		// Dance
  CASE:VOICE_AREYOUOK GO 2230		// Are you ok?
  CASE:VOICE_GOODNIGHT GO 2229		// Good Night
  CASE:VOICE_GOODBYE GO 2229		// Goodbye
  CASE:VOICE_AIBO GO 2226		// AIBO
  CASE:VOICE_GOODMORNING GO 2226	// Good Morning
  CASE:VOICE_HELLO GO 2226		// Hello
  CASE:VOICE_SAYHELLO GO 2226		// Say Hello
  CASE:VOICE_AREYOUTIRED GO 2225	// Tired?
  CASE:VOICE_LAYDOWN GO 2223		// Lie Down / Play Dead
  CASE:VOICE_ROAR GO 2223		// Roar / Roll Over
  CASE:VOICE_AREYOUHUNGRY GO 2221	// Hungry?
  CASE:VOICE_ROAR GO 2220		// Roar
  CASE:VOICE_MEOW GO 2220		// Meow
  CASE:VOICE_TURNLEFT GO 2219		// Left
  CASE:VOICE_GOFORWARD GO 2218		// Forward
  CASE:VOICE_TURNRIGHT GO 2217		// Right
  CASE:VOICE_GOBACK GO 2216		// Back
  CASE:VOICE_GETUP GO 2215		// Get Up
  CASE:VOICE_STANDUP GO 2215		// Stand Up
  CASE:VOICE_SITDOWN GO 2213		// Sit Down
  CASE:VOICE_SHAKEPAW GO 2211		// Shake
  CASE:VOICE_SHAKE GO 2211		// Shake
  CASE:VOICE_OTHERPAW GO 2209		// Other Paw
  CASE:VOICE_LETSPLAY GO 2208		// Let's Play
  CASE:VOICE_KARATECHOP GO 2207		// Karate Chop
  CASE:VOICE_POSE GO 2206
RET 1	// none

:2206	// SIT_POSE
CALL G_SIT_POSE
RET 4	// sit

:2207	// KARATE_CHOP
CALL G_KARATE_CHOP
RET 4	// sit

:2208	// RPS
CALL G_RPS
RET 4	// sit

:2209	// OTHERPAW_CMD
CALL G_VOICE_HIT
CALL G_SIT_OTHERHAND
RET 4	// sit

:2211	// SHAKEPAW_CMD
CALL G_VOICE_HIT
CALL G_SIT_SHAKEHANDS
RET 4	// sit

:2213	// SIT_DOWN
CALL G_VOICE_HIT
PLAY ACTION SIT
WAIT
RET 4	// sit

:2215	// STAND_UP
CALL G_CHECK_STAYSIT
  CASE:GO_IGNORE RET 4 // sit
CALL G_STAND_UP
RET 6	// stand

:2216	// BACK
CALL G_CHECK_STAYSIT
  CASE:GO_IGNORE RET 4 // sit
CALL G_GO_BACK
RET 6	// stand

:2217	// RIGHT
CALL G_LAZY_GORIGHT
  CASE:1 RET 2	// done
RET 6	// stand

:2218	// FWD
CALL G_CHECK_STAYSIT
  CASE:GO_IGNORE RET 4 // sit
CALL G_GO_FORWARD
RET 6	// stand

:2219	// LEFT
CALL G_LAZY_GOLEFT
  CASE:1 RET 2	// done
RET 6	// stand

:2220	// BARK
CALL G_CHECK_STAYSIT
  CASE:GO_IGNORE RET 4 // sit
CALL G_STAND_BARK
RET 6	// stand

:2221	// HUNGRY?
CALL G_QUERY_HUNGRY
  CASE:1 RET 2	// done
RET 4	// sit

:2222	// SLEEP_RHYTHM
CALL G_SLEEP_RHYTHM
RET 2	// done

:2223	// LAYDOWN
CALL G_VOICE_HIT
IF sitonly == 0 THEN
#ifdef AIBO310
  SET:NoFallDown:1
  PLAY ACTION playdead_sleep
  WAIT
  SET:NoFallDown:0
  PLAY MWCID 2514
  WAIT
  PLAY ACTION SHUDDER
  WAIT
  RET 6 // stand
#else
  PLAY ACTION+ playdead_sleep
  WAIT
#endif
ENDIF
RET 2	// done

:2225	// ARE_YOU_TIRED?
CALL G_QUERY_TIRED
RET 2	// done

:2226	// HELLO?
CALL G_RANDOM1/3
  CASE:1 GO 2229
WAIT 1
SET init_wait Wait
PLAY ACTION HELLO_SLEEP
CALL G_WAIT_AWARE
RET 2	// done

:2229	// SLEEP_GREET
CALL G_SLEEP_GREET
RET 2	// done

:2230	// ARE_YOU_OK?
CALL G_QUERY_MOOD
RET 2	// done

:2231	// LETS_DANCE
CALL G_TWITCH_EARS
CALL G_SLEEP_DANCE
RET 2	// done

:2233	// FIND_BALL
CALL G_VOICE_HIT

// If sitonly, do a quick look around then quit...
IF sitonly > 0 THEN
  CALL G_SOCCER_LOOK4BALL
  RET 2 // done
ENDIF

CALL G_SOCCER_SEARCH4BALL
  CASE:1 RET 7	// rest
  CASE:2 GO 2237

:2235	// STOOD_UP?(2)
IF_1ST searchmove <= 0 2247	// Nope.
PLAY ACTION LIE
WAIT
RET 2	// done

:2237	// TIRED?
IF_1ST mood_tired >= 9 2235	// Nope
IF_1ST searchmove <> 0 2250	// Nope.
SET pan Head_Pan
SET tilt Head_Tilt
SUB tilt tiltadj
SUB tilt 15
WAIT 1
SET init_wait Wait
PLAY ACTION STAND
CALL G_WAIT_AWARE
PLAY ACTION MOVE.HEAD.FAST pan tilt
CALL G_WAIT_AWARE
IF_1ST Pink_Ball <> 0 2250	// Nope
CALL G_SOCCER_SEARCH4BALL
  CASE:1 RET 7	// rest
  CASE:2 RET 5	// ball
RET 2	// done

:2245	// WALK_REQUEST
CALL G_WALK_REQUEST
  CASE:1 RET 3	// walk

:2247	// done
RET 2

:2250	// ball
RET 5


////////////////////////////////////////////////////////////////////
// SLEEP_RHYTHM
:G_SLEEP_RHYTHM
SET rndbase 1850
SET rndcount 4
CALL G_BEHAVIOR_RNDNM
  CASE:3 RET 1	// no valid number available

SWITCH rndnum
  CASE:1850 PLAY ACTION+ dancestep_aibosleep
  CASE:1851 PLAY ACTION+ dancestep_sleep1
  CASE:1852 PLAY ACTION+ dancestep_sleep2
  CASE:ELSE PLAY ACTION+ dancestep_sleep3
WAIT
RET 1


