
////////////////////////////////////////////////////////////////////
//                                                                //
//  DogsLife Stand Position Behavior Module                       //
//  Copyright (C) 2001-2002 by DogsBody & Ratchet Software        //
//  All Rights Reserved                                           //
//                                                                //
//  This is free software and MAY NOT be sold under any           //
//  circumstances, seperately or bundled.                         //
//                                                                //
////////////////////////////////////////////////////////////////////


//
// Behavior when standing still...
//
:G_STANDPOS
CALL G_CHECK_SITONLY
  CASE:GO_DOWNPOS RET:GO_DOWNPOS
  CASE:GO_SITPOS RET:GO_SITPOS

CALL G_INIT_STANDPOS

:STAND_LOOP	// INIT_TIMERS
SET Clock 0
RND maxtime1 3 10	// 3 to 10 seconds
RND maxtime2 0 2	// 0 to 2 seconds
RND maxtime3 5 10	// 5 to 10 seconds
SET tailwag 0
IF_1ST mood_happy > 3 2870

:2845	// NEED2REST?
CALL G_NEED2REST
  CASE:1 GO 2847

IF_1ST mood_tired < MOOD_MAX 2848	// Nope

// If tired & standing, sitdown...
IF Posture1 == POSTURE_STAND THEN
  RND rndnum 0 100
  SET init_wait Wait
  IF rndnum < 50 THEN
    PLAY ACTION SIT
  ELSE
    PLAY ACTION+ sit_quick
  ENDIF
  CALL G_WAIT
ENDIF

:2847	// STOP_TAILWAG2
CALL G_STOP_TAILWAG
RET:GO_RESTPOS

:2848	// REST_TIMER
CALL G_CHECK_SITONLY
  CASE:GO_DOWNPOS RET:GO_DOWNPOS
  CASE:GO_SITPOS RET:GO_SITPOS

CALL G_REST_TIMER
WAIT 50
CALL G_SEE_BALL?
  CASE:GO_IDLE GO 2852
  CASE:GO_IGNORE GO 2852
CALL G_STOP_TAILWAG
RET:GO_SEEBALL

:2852	// ATTENTION?
CALL G_ATTENTION_HANDLER
  CASE:1 GO 2868
  CASE:2 GO 2867
  CASE:3 GO 2866
  CASE:4 GO 2863

// Call voice command customization routine...
:2853
CALL G_CUSTOM_STAND_VOICECMD
  CASE:GO_DOWNPOS RET:GO_DOWNPOS
  CASE:GO_SITPOS RET:GO_SITPOS
  CASE:GO_STANDPOS RET:GO_STANDPOS
  CASE:GO_SEEBALL RET:GO_SEEBALL
  CASE:GO_IGNORE GO 2854

// If not overridden, do normal voice command processing...
CALL G_STAND_VOICE_HANDLER
  CASE:1 GO STAND_LOOP
  CASE:3 RET:GO_WALK
  CASE:4 RET:GO_DOWNPOS
  CASE:5 RET:GO_SITPOS
  CASE:6 RET:GO_SEEBALL
  CASE:7 RET:GO_RESTPOS

:2854	// TIMER1?
CALL G_BORED_TIMER
  CASE:1 GO 2845

// Go process pending voice command...
IF_1ST AP_Voice_Cmd > 0
IF_AND AP_Voice_Level >= MIN_VOICE_LEVEL 2852

//
// 20% remain standing (bored)
// 50% of time start walking.  
// 20% lay down
// 10% sit down
//
RND rndnum 0 100
IF rndnum >= 20 THEN
  IF rndnum < 70 THEN
    RET:GO_WALK
  ENDIF
  IF rndnum < 90 THEN
    RET:GO_DOWNPOS
  ENDIF
  RET:GO_SITPOS
ENDIF

WAIT 1
CALL G_BEHAVIOR_BORED
ADD change_thres 2
GO STAND_LOOP

:2863	// SCOLD
CALL G_SCOLD_REST

:2864	// RESET_BORED
RND bored_count 5 10
CALL G_CLEAR_SENSORS
ADD change_thres 2
GO STAND_LOOP

:2866	// STAND_PETTED
CALL G_STAND_PETTED
GO 2864

:2867	// PRAISE
CALL G_PRAISE_REST
GO 2864

:2868	// TAIL_TWEAKED?
CALL G_TAIL_TWEAKED
  CASE:2 GO 2867
  CASE:3 GO 2863
  CASE:4 GO 2853
CALL G_LOOK_TIMER
GO 2854

:2870	// START_TAILWAG
PLAY ACTION TAILWAG_VERT1
SET tailwag 1
GO 2845



////////////////////////////////////////////////////////////////////
// INIT_STANDPOS
:G_INIT_STANDPOS
RND bored_count 3 10	// # of cycles before bored
SET back_count 0	// # b2b back pets
SET tilt 0
SET pan 0
WAIT 1

// Get into stand position if necessary...
IF Posture1 != POSTURE_STAND THEN
  SET init_wait Wait
  PLAY ACTION STAND
  CALL G_WAIT
ENDIF

CALL G_CLEAR_SENSORS
RET 1


////////////////////////////////////////////////////////////////////
// STAND_BARK
:G_STAND_BARK
CALL G_VOICE_HIT
CALL G_RANDOM2
  CASE:1 PLAY ACTION BARK
  CASE:2 PLAY ACTION BARK2
WAIT
RET 1


////////////////////////////////////////////////////////////////////
// STAND_DANCE
:G_STAND_DANCE
SET rndbase 1600
SET rndcount 5
SET lastact1 last_danceact
SET lastact2 last_danceact
CALL G_BEHAVIOR_RNDN
  CASE:2 RET 1
SWITCH rndnum
  CASE:1600 PLAY ACTION DANCE_STAND3
  CASE:1601 PLAY ACTION DANCE_STAND4
  CASE:1602 PLAY ACTION DANCE_STAND5
  CASE:1603 PLAY ACTION DANCE_STAND6
  CASE:ELSE GO G_STAND_TWISTNSHOUT
SET last_danceact rndnum
WAIT
RET 1

:G_STAND_TWISTNSHOUT
SET:NoFallDown:1
PLAY ACTION twistnshout
WAIT
SET:NoFallDown:0
SET last_danceact rndnum
RET 1


////////////////////////////////////////////////////////////////////
// STAND_GREET
:G_STAND_GREET
WAIT 1
SET init_wait Wait
CALL G_RANDOM4
  CASE:1 PLAY ACTION WAVE_LEFT_STAND1
  CASE:2 PLAY ACTION WAVE_LEFT_STAND2
  CASE:3 PLAY ACTION WAVE_RIGHT_STAND1
  CASE:4 PLAY ACTION WAVE_RIGHT_STAND2
CALL G_WAIT
RET 1


////////////////////////////////////////////////////////////////////
// STAND_HELLO
:G_STAND_HELLO
WAIT 1
SET init_wait Wait
CALL G_RANDOM4
  CASE:1 PLAY ACTION HELLO_STAND1
  CASE:2 PLAY ACTION HELLO_STAND2
  CASE:3 PLAY ACTION HELLO_STAND3
  CASE:4 PLAY ACTION HELLO_STAND4
CALL G_WAIT
RET 1


////////////////////////////////////////////////////////////////////
// STAND_HUH  (Say what?)
:G_STAND_HUH
CALL G_VOICE_HIT
CALL G_RANDOM3
  CASE:1 PLAY ACTION SAYWHAT_LEFT
  CASE:2 PLAY ACTION SAYWHAT_RIGHT
  CASE:3 PLAY ACTION LEANRIGHT
WAIT
RET 1


////////////////////////////////////////////////////////////////////
// STAND_PETTED
:G_STAND_PETTED
CALL G_RANDOM3
  CASE:1 GO 2783
  CASE:2 GO 2778

:2761	// LOTS_BACK_PET?
IF_1ST back_count > 4 2775

:2762	// RNDNUM
WAIT 1
RND rndnum 0 5
SET init_wait Wait
IF_1ST rndnum = last_petsong 2762
SWITCH rndnum
  CASE:0 PLAY ACTION BEEN_PETTED18
  CASE:1 PLAY ACTION BEEN_PETTED19
  CASE:2 PLAY ACTION BEEN_PETTED20
  CASE:3 PLAY ACTION BEEN_PETTED21
  CASE:4 PLAY ACTION BEEN_PETTED22
  CASE:ELSE PLAY ACTION BEEN_PETTED23
SET last_petsong rndnum
CALL G_WAIT

:2768	// INC_HAPPY_MOOD
CALL G_INC_HAPPY_MOOD
CALL G_DEC_MAD_MOOD
CALL G_DEC_SAD_MOOD
RET 1

:2775	// petkick
WAIT 1
SET init_wait Wait
PLAY ACTION+ petting_kick_stand
SET last_petsong 999
CALL G_WAIT
SET Back_ON 0
GO 2768

:2778	// petted2
WAIT 1
SET init_wait Wait
PLAY ACTION TUNE_PETTED2

:2779	// WAIT
CALL G_WAIT
IF_1ST mood_happy > 4 2782
CALL G_RANDOM1/3
  CASE:1 GO 2761
GO 2768

:2782	// RANDOM(1)
CALL G_RANDOM1/3
  CASE:1 GO 2768
GO 2761

:2783	// petted1
WAIT 1
SET init_wait Wait
PLAY ACTION TUNE_PETTED1
GO 2779


////////////////////////////////////////////////////////////////////
// STAND_POSE
:G_STAND_POSE
WAIT 1
SET rndbase 1650
SET rndcount 5
SET lastact1 last_poseact
SET lastact2 last_poseact
SET init_wait Wait
CALL G_BEHAVIOR_RNDN
  CASE:2 RET 1
SWITCH rndnum
  CASE:1650 PLAY ACTION POSE_MADONNA
  CASE:1651 PLAY ACTION POSE_WAVERIGHT
  CASE:1652 PLAY ACTION SMALL_BOW
  CASE:1653 PLAY ACTION SURPRISE_STAND
  CASE:ELSE GO G_STAND_HEADSTAND
CALL G_WAIT
RET 1


:G_STAND_HEADSTAND
SET:NoFallDown:1
PLAY ACTION headstand_stand
CALL G_WAIT
SET:NoFallDown:0
RET 1


////////////////////////////////////////////////////////////////////
// STAND_VOICE_HANDLER  (Voice processing when standing still.)
:G_STAND_VOICE_HANDLER
CALL G_STOP_HEAD
WAIT 1
SWITCH VoiceCmd
  CASE:HEARD_RHYTHM GO 2816
  CASE:VOICE_WALK GO 2833		// Walk
  CASE:VOICE_FINDBALL GO 2831		// Find Ball
  CASE:VOICE_KICKBALL GO 2831		// Kick Ball
  CASE:VOICE_LETSDANCE GO 2829		// Dance
  CASE:VOICE_GETUP GO 2828		// Get Up
  CASE:VOICE_STOP GO 2828		// Stop
  CASE:VOICE_STANDUP GO 2828		// Stand Up
  CASE:VOICE_GOODMORNING GO 2825	// Good Morning
  CASE:VOICE_GOODNIGHT GO 2827		// Good Night
  CASE:VOICE_GOODBYE GO 2827		// Goodbye
  CASE:VOICE_AIBO GO 2825		// AIBO
  CASE:VOICE_HELLO GO 2825		// Hello
  CASE:VOICE_SAYHELLO GO 2825		// Say Hello
  CASE:VOICE_AREYOUOK GO 2824		// Are you ok?
  CASE:VOICE_GOFORWARD GO 2823		// Go Forward
  CASE:VOICE_TURNLEFT GO 2822		// Go Left
  CASE:VOICE_GOBACK GO 2821		// Go Back
  CASE:VOICE_TURNRIGHT GO 2820		// Go Right
  CASE:VOICE_POSE GO 2819		// Pose
  CASE:VOICE_ROAR GO 2818		// Roar
  CASE:VOICE_MEOW GO 2818		// Meow
  CASE:VOICE_AREYOUTIRED GO 2817	// Tired?
  CASE:VOICE_AREYOUHUNGRY GO 2815	// Hungry?
  CASE:VOICE_SHAKEPAW GO 2814		// Shake Paw
  CASE:VOICE_SHAKE GO 2812		// Shake
  CASE:VOICE_OTHERPAW GO 2806		// Other Paw
  CASE:VOICE_KARATECHOP GO 2811		// Karate Chop
  CASE:VOICE_LETSPLAY GO 2808		// Let's Play
  CASE:VOICE_SITDOWN GO 2809		// Sit
  CASE:VOICE_LAYDOWN GO 2800		// Lie Down / Play Dead
  CASE:VOICE_ROAR GO 2800		// Roar / Roll Over
RET 2	// none

:2800	// LAY_DOWN
CALL G_VOICE_HIT
CALL G_RANDOM2
  CASE:1 GO 2805
IF_1ST mood_happy < 3 2805
PLAY ACTION RESIGNATION
WAIT
CALL G_DEC_HAPPY_MOOD
RET 4	// down

:2805	// SLEEPPOS
PLAY ACTION LIE
WAIT
RET 4	// down

:2806	// OTHERPAW_CMD
CALL G_VOICE_HIT
CALL G_SIT_OTHERHAND
RET 5	// sit

:2808	// RPS
CALL G_RPS
RET 5	// sit

:2809	// SIT_DOWN
CALL G_VOICE_HIT
RND rndnum 0 100
IF rndnum < 50 THEN
  PLAY ACTION SIT
ELSE
  PLAY ACTION+ sit_quick
ENDIF
WAIT
RET 5	// sit

:2811	// KARATE_CHOP
CALL G_KARATE_CHOP
RET 5	// sit

:2812	// SHAKEPAW_CMD
CALL G_VOICE_HIT
CALL G_SIT_SHAKEHANDS
RET 5	// sit

:2814	// SHUDDER
CALL G_SHUDDER
  CASE:1 RET 1	// done
GO 2812

:2815	// HUNGRY?
CALL G_QUERY_HUNGRY
  CASE:1 RET 1	// done
RET 5	// sit

:2816	// STAND_RHYTHM
CALL G_STAND_RHYTHM
RET 1	// done

:2817	// TIRED?
CALL G_QUERY_TIRED
RET 1	// done

:2818	// BARK
CALL G_STAND_BARK
RET 1	// done

:2819	// POSE
CALL G_STAND_POSE
RET 1	// done

:2820	// RIGHT
CALL G_GO_RIGHT
RET 1	// done

:2821	// BACK
CALL G_GO_BACK
RET 1	// done

:2822	// LEFT
CALL G_GO_LEFT
RET 1	// done

:2823	// FWD
CALL G_GO_FORWARD
RET 1	// done

:2824	// OK?
CALL G_QUERY_MOOD
RET 1	// done

:2825	// HELLO?
CALL G_RANDOM1/3
  CASE:1 GO 2827
CALL G_STAND_HELLO
RET 1	// done

:2827	// GREET
CALL G_STAND_GREET
RET 1	// done

:2828	// HUH?
CALL G_STAND_HUH
RET 1	// done

:2829	// LETS_DANCE
CALL G_VOICE_HIT
CALL G_STAND_DANCE
RET 1	// done

:2831	// FIND_BALL
CALL G_VOICE_HIT
CALL G_SOCCER_SEARCH4BALL
  CASE:1 RET 7	// rest
  CASE:2 RET 6	// ball
RET 1	// done

:2833	// WALK_REQUEST
CALL G_WALK_REQUEST
  CASE:1 RET 3	// walk
RET 1



////////////////////////////////////////////////////////////////////
// STAND_RHYTHM
:G_STAND_RHYTHM
SET rndbase 1950
SET rndcount 6
CALL G_BEHAVIOR_RNDNM
  CASE:3 RET 1	// no valid number available

:4097	// SELECT_POS
SWITCH rndnum
  CASE:1950 PLAY ACTION+ dancestep_aibostand1
  CASE:1951 PLAY ACTION+ dancestep_aibostand2
  CASE:1952 PLAY ACTION+ dancestep_aibostand3
  CASE:1953 PLAY ACTION+ dancestep_aibostand4
  CASE:1954 PLAY ACTION+ dancestep_stand1
  CASE:ELSE PLAY ACTION+ dancestep_stand2
WAIT
RET 1


