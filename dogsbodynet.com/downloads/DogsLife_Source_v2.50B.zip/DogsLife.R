//|////////////////////////////////////////////////////////////////|//
//|                                                                |//
//| DogsLife - Version 2.50b                                       |//
//| Copyright (C) 2001-2002 by DogsBody & Ratchet Software         |//
//| All Rights Reserved                                            |//
//|                                                                |//
//| The DogsLife behavior software is provided AS IS without       |//
//| any warranty, expressed or implied.   This includes without    |//
//| limitation the fitfulness for a particular purpose or          |//
//| application.   People using the software bear all risk as to   |//
//| its quality and performance.   The user of the software is     |//
//| responsible for any damages whether direct, indirect, special, |//
//| incidental or consequential arising from a failure of this     |//
//| program to operate in any manner desired.                      |//
//|                                                                |//
//| This is free software and MAY NOT be sold under any            |//
//| circumstances, seperately or bundled.                          |//
//|                                                                |//
//|////////////////////////////////////////////////////////////////|//

#define RCODE250
#include "DogsLife.RH"


////////////////////////////////////////////////////////////////////
// Main
:G_Main

CALL G_STARTUP

:MAINLOOP
CASE:GO_RESTPOS  CALL G_RESTMODE
CASE:GO_DOWNPOS  CALL G_SLEEPPOS
CASE:GO_SITPOS   CALL G_SITPOS
CASE:GO_STANDPOS CALL G_STANDPOS
CASE:GO_WALK     CALL G_WALK_ABOUT
CASE:GO_SEEBALL  CALL G_SOCCER
GO MAINLOOP



////////////////////////////////////////////////////////////////////
// ATTENTION_HANDLER  (Process user praise or scolding...)
:G_ATTENTION_HANDLER
SET pet 0
SET praise 0
SET scold 0
WAIT 1

#ifdef AIBO310

/*** 310 specific ***/
IF Tail_R_LONG > 0 THEN			// 310 - Enter sit-only mode
  SET Tail_R_LONG 0
  SET sitonly 1
  CALL G_UPDATE_PAUSEBAR
ENDIF
IF Tail_U_LONG > 0 THEN			// 310 - Exit sit-only mode
  SET Tail_U_LONG 0
  SET sitonly 0
  CALL G_UPDATE_PAUSEBAR
ENDIF
IF Tail_RollR || Tail_RollL THEN	// 310 - Praise
  ADD pet 2
  SET maxtime6 MAXINT			// reset delay scold timer
  SET Tail_RollR 0
  SET Tail_RollL 0
  SET Tail_U_ON 0
  SET Tail_D_ON 0
  SET Tail_R_ON 0
  SET Tail_L_ON 0
  SET back_count 0
  RET 3	// pet
ENDIF

// Gotta be careful with these, since a roll might trigger one of these...
// Therefore, a delayed scold using a timer is implemented here.  If a roll
// doesn't happen within the 1second timeout, the scolding occurs...
IF Tail_U_ON || Tail_D_ON || Tail_R_ON || Tail_L_ON THEN	// 310 - Scold
  SET maxtime6 1
  SET Tail_U_ON 0
  SET Tail_D_ON 0
  SET Tail_R_ON 0
  SET Tail_L_ON 0
  SET back_count 0
ENDIF

IF maxtime6 < 0 THEN			// 310 - Delayed scold
  SET maxtime6 MAXINT
  SET Tail_U_ON 0
  SET Tail_D_ON 0
  SET Tail_R_ON 0
  SET Tail_L_ON 0
  SET back_count 0
  ADD scold 2
  RET 4	// scold
ENDIF

/*** 210/220 specific ***/
#else 
IF Back_LONG > 0 THEN			// 210/220 - Enter sit-only mode
  SET Back_LONG 0
  SET Head_LONG 0
  SET sitonly 1
  CALL G_UPDATE_PAUSEBAR
ENDIF
IF Head_LONG > 0 THEN			// 210/220 - Exit sit-only mode
  SET Back_LONG 0
  SET Head_LONG 0
  SET sitonly 0
  CALL G_UPDATE_PAUSEBAR
ENDIF
IF Back_ON > 0 THEN			// 210/220 - Petted
  ADD pet 2
  SET Back_ON 0
  ADD back_count 1
  RET 3	// pet
ENDIF
IF Jaw_ON > 0 THEN			// 210/220 - Petted
  ADD pet 4
  SET Jaw_ON 0
  SET back_count 0
  RET 3	// pet
ENDIF
#endif

IF Head_Hit > 0 THEN
  ADD scold 1
  SET Head_Hit 0
  SET back_count 0
  RET 4	// scold
ENDIF

IF Head_ON > 0 THEN
  ADD praise 1
  SET Head_ON 0
  SET back_count 0
  RET 2	// praise
ENDIF

CALL G_VOICECMD
  CASE:GO_VOICE GO AH_VOICECMD

IF AP_Rhythm > 0 THEN
  SET VoiceCmd HEARD_RHYTHM
  SET VoiceLevel 3
  SET VoicePitch 3
  SET VoiceHorz 0
  SET VoiceDictID VoiceCmd
  SET AP_Rhythm 0
  GO AH_VOICECMD
ENDIF

IF AP_Tone > 0 THEN
  CALL G_TONECMD
    CASE:1 GO AH_VOICECMD
ENDIF

RET 1

:AH_VOICECMD
SET back_count 0
IF VoiceCmd == VOICE_GOODBOT THEN
  IF VoiceDictID >= 149	THEN			// Good Boy
    IF VoiceDictID <= 150 THEN
      CALL G_INC_BOYGIRL
    ENDIF
  ENDIF
  IF VoiceDictID >= 151	THEN			// Good Girl
    IF VoiceDictID <= 154 THEN
      CALL G_DEC_BOYGIRL
    ENDIF
  ENDIF
  RET 2	// praise
ENDIF

IF VoiceCmd == VOICE2_GOODBOY THEN		// Good Boy (voice2)
  CALL G_INC_BOYGIRL
  RET 2	// praise
ENDIF

IF VoiceCmd == VOICE2_GOODGIRL THEN		// Good Girl (voice2)
  CALL G_DEC_BOYGIRL
  RET 2	// praise
ENDIF

IF VoiceCmd == VOICE_GOFORIT THEN		// Go For It
  SET goforit 60
  RET 2	// praise
ENDIF

IF VoiceCmd == VOICE_BADBOT THEN
  IF VoiceDictID >= 160	THEN			// Bad Boy
    IF VoiceDictID <= 161 THEN
      CALL G_INC_BOYGIRL
    ENDIF
  ENDIF
  IF VoiceDictID >= 162	THEN			// Bad Girl
    IF VoiceDictID <= 165 THEN
      CALL G_DEC_BOYGIRL
    ENDIF
  ENDIF
  RET 4	// scold
ENDIF

IF VoiceCmd == VOICE2_BADBOY THEN		// Bad Boy (voice2)
  CALL G_INC_BOYGIRL
  RET 4	// scold
ENDIF

IF VoiceCmd == VOICE2_BADGIRL THEN		// Bad Girl (voice2)
  CALL G_DEC_BOYGIRL
  RET 4	// scold
ENDIF

SWITCH VoiceCmd 
  CASE:VOICE_AIBO CALL G_DEC_SAD_MOOD		// Aibo or registered name
  CASE:VOICE_ILIKEYOU CALL G_DEC_SAD_MOOD	// I like you
  CASE:VOICE_IAMHERE CALL G_DEC_SAD_MOOD	// I'm here (come here)
  CASE:VOICE_DONTDOTHAT RET 4 // scold		// Don't do that
  CASE:VOICE2_THATSRIGHT RET 2 // praise	// Good Bot (voice2)

IF VoiceCmd == VOICE_TAKEAPICTURE THEN		// Take a picture?
  IF Posture1 != POSTURE_WALK THEN
    CALL G_TAKE_A_PICTURE
  ENDIF
  RET 1	// none
ENDIF

RET 5 // voice


////////////////////////////////////////////////////////////////////
// CLEAR_SENSORS
:G_CLEAR_SENSORS
SET Head_Pat 0
SET Head_Hit 0
SET Head_ON 0
SET Back_ON 0
SET Jaw_ON 0
SET Jaw_LONG 0
SET RFLeg_ON 0
SET LFLeg_ON 0
SET RRLeg_ON 0
SET LRLeg_ON 0
RET 1


////////////////////////////////////////////////////////////////////
// DEC_HAPPY_MOOD  (Decrease happiness level)
:G_DEC_HAPPY_MOOD
SUB mood_happy 1
IF mood_happy > MOOD_MAX THEN
  SET mood_happy MOOD_MAX
ENDIF
IF mood_happy < 0 THEN
  SET mood_happy 0
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// DEC_MAD_MOOD
:G_DEC_MAD_MOOD
SUB mood_mad 1
CALL G_INIT_MOOD_TIMER
IF mood_mad > MOOD_MAX THEN
  SET mood_mad MOOD_MAX
ENDIF
IF mood_mad < 0 THEN
  SET mood_mad 0
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// DEC_SAD_MOOD
:G_DEC_SAD_MOOD
SUB mood_sad 1
CALL G_INIT_MOOD_TIMER
IF mood_sad > MOOD_MAX THEN
  SET mood_sad MOOD_MAX
ENDIF
IF mood_sad < 0 THEN
  SET mood_sad 0
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// DEC_TIRED_MOOD
:G_DEC_TIRED_MOOD
IF mood_tired < 1 THEN
  SET mood_tired 0
  RET 1
ENDIF

SUB mood_tired 1
IF mood_tired < 1 THEN
  CALL G_DEC_ENDURE
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// GO_BACK
:G_GO_BACK
CALL G_VOICE_HIT
IF mood_mad > 5 THEN
  PLAY ACTION MOVE.MOVE.SLOW 180 100
  WAIT
  RET 1
ENDIF

IF mood_happy > 5 THEN
  PLAY ACTION MOVE.MOVE.FAST 180 300
  WAIT
  RET 1
ENDIF

CALL G_RANDOM3
  CASE:1 PLAY ACTION MOVE.MOVE.SLOW 180 200
  CASE:2 PLAY ACTION MOVE.MOVE.NORMAL 180 200
  CASE:3 PLAY ACTION MOVE.MOVE.FAST 180 200
WAIT
RET 1


////////////////////////////////////////////////////////////////////
// GO_FORWARD  (Move forward in response to command.)
:G_GO_FORWARD
CALL G_VOICE_HIT
WAIT 1
SET init_wait Wait

// Stand up if not doing so already...
IF ((Posture1 != POSTURE_STAND) && (Posture1 != POSTURE_WALK)) THEN
  PLAY ACTION STAND
ENDIF

:1158	// LOOK_DOWN
PLAY ACTION MOVE.HEAD.FAST 0 WALKHEADTILT
WAIT
CALL G_WAIT

IF mood_mad > 5 THEN
  PLAY ACTION MOVE.MOVE.SLOW 0 250
  GO GF_WAITLOOP
ENDIF

IF mood_happy > 5 THEN
  PLAY ACTION WALK 0 500
  GO GF_WAITLOOP
ENDIF

CALL G_RANDOM2
  CASE:1 PLAY ACTION MOVE.MOVE.SLOW 0 400
  CASE:2 PLAY ACTION MOVE.MOVE.NORMAL 0 400

:GF_WAITLOOP	// WAIT_FOR_WALK
IF (Distance<TOOCLOSEDIST) || (Distance>CLIFFDIST) THEN
 GO GF_STOPWALK
ENDIF

CALL G_SEE_BALL?
  CASE:GO_SEEBALL GO GF_STOPWALK

IF Wait > 0 THEN
  WAIT 100
  GO GF_WAITLOOP
ENDIF
RET 1

:GF_STOPWALK
PLAY ACTION WALK 0 0
WAIT
RET 1


////////////////////////////////////////////////////////////////////
// GO_LEFT
:G_GO_LEFT
CALL G_VOICE_HIT
RND pan 30 60
IF_1ST mood_tired > 8 1184
IF_1ST mood_mad > 5 1184
IF_1ST mood_happy <= 5 1180
RND temp 0 100
IF_1ST temp < 90 1178
RND pan 90 180

:1178	// LEFT_FAST_MORE
ADD pan 45
PLAY ACTION MOVE.TURN.FAST pan
WAIT
RET 1

:1180	// RANDOM3
CALL G_RANDOM3
  CASE:1 PLAY ACTION MOVE.TURN.SLOW pan
  CASE:2 PLAY ACTION MOVE.TURN.NORMAL pan
  CASE:3 PLAY ACTION MOVE.TURN.FAST pan
WAIT
RET 1

:1184	// LEFT_SLOW_LESS
SUB pan 20
PLAY ACTION MOVE.TURN.SLOW pan
WAIT
RET 1


////////////////////////////////////////////////////////////////////
// GO_RIGHT
:G_GO_RIGHT
CALL G_VOICE_HIT
RND pan -30 -60
IF_1ST mood_tired > 8 1200
IF_1ST mood_mad > 5 1200
IF_1ST mood_happy <= 5 1196
RND temp 0 100
IF_1ST temp < 90 1194
RND pan -90 -180

:1194	// RT_FAST_MORE
ADD pan -45
PLAY ACTION MOVE.TURN.FAST pan
WAIT
RET 1

:1196	// RANDOM3
CALL G_RANDOM3
  CASE:1 PLAY ACTION MOVE.TURN.SLOW pan
  CASE:2 PLAY ACTION MOVE.TURN.NORMAL pan
  CASE:3 PLAY ACTION MOVE.TURN.FAST pan
WAIT
RET 1

:1200	// RT_SLOW_LESS
SUB pan -20
PLAY ACTION MOVE.TURN.SLOW pan
WAIT
RET 1


////////////////////////////////////////////////////////////////////
// HAPPYDANCE  (Do a happy dance)
:G_HAPPYDANCE

:1203	// PICK_ACT
RND temp 0 9
WAIT 1
SET init_wait Wait
IF_1ST temp = last_happydance 1203
IF_1ST temp = last_happydance2 1203
SWITCH temp
  CASE:0 PLAY ACTION CUTE_SMILE1
  CASE:1 PLAY ACTION CUTE_SWING1
  CASE:2 PLAY ACTION CUTE_SWING2
  CASE:3 PLAY ACTION DANCE_STAND1
  CASE:4 PLAY ACTION DANCE_STAND2
  CASE:5 PLAY ACTION LETSPLAY1
  CASE:6 PLAY ACTION LETSPLAY2
  CASE:7 PLAY ACTION DANCE_STAND6
  CASE:8 PLAY ACTION DANCE_STAND3
  CASE:ELSE PLAY ACTION DANCE_STAND5
SET last_happydance2 last_happydance
SET last_happydance temp
CALL G_WAIT_AWARE
RET 1


////////////////////////////////////////////////////////////////////
// INC_HAPPY_MOOD  (Increase happiness level)
:G_INC_HAPPY_MOOD
IF mood_happy > 2 THEN
  CALL G_DEC_SAD_MOOD
ENDIF
ADD mood_happy 1
IF mood_happy > MOOD_MAX THEN
  SET mood_happy MOOD_MAX
ENDIF
IF mood_happy < 0 THEN
  SET mood_happy 0
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// INC_MAD_MOOD
:G_INC_MAD_MOOD
IF mood_mad > 5 THEN
  CALL G_INC_SAD_MOOD
ENDIF
ADD mood_mad 1
CALL G_INIT_MOOD_TIMER
IF mood_mad > MOOD_MAX THEN
  SET mood_mad MOOD_MAX
ENDIF
IF mood_mad < 0 THEN
  SET mood_mad 0
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// INC_SAD_MOOD
:G_INC_SAD_MOOD
ADD mood_sad 1
CALL G_INIT_MOOD_TIMER
IF mood_sad > MOOD_MAX THEN
  SET mood_sad MOOD_MAX
ENDIF
IF mood_sad < 0 THEN
  SET mood_sad 0
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// KARATE_CHOP
:G_KARATE_CHOP
CALL G_VOICE_HIT
SET rndbase 950
SET rndcount 3
SET lastact1 last_karateact
SET lastact2 last_karateact
CALL G_BEHAVIOR_RNDN
  CASE:2 RET 1
SWITCH rndnum
  CASE:950 PLAY ACTION KARATE1
  CASE:951 PLAY ACTION KARATE2
  CASE:ELSE PLAY ACTION KARATE3
SET last_karateact rndnum
WAIT
RET 1


////////////////////////////////////////////////////////////////////
// LAZY_GOLEFT
:G_LAZY_GOLEFT

IF sitonly == 0 THEN
  IF mood_happy > 3 1275
  CALL G_RANDOM1/3
    CASE:1 GO 1275
ENDIF

CALL G_VOICE_HIT
CALL G_RANDOM3
  CASE:1 PLAY ACTION MOVE.HEAD.SLOW 90 0
  CASE:2 PLAY ACTION MOVE.HEAD.NORMAL 90 0
  CASE:3 PLAY ACTION MOVE.HEAD.FAST 90 0
WAIT
RET 1	// done

:1275	// GO_LEFT
CALL G_GO_LEFT
RET 2	// stand


////////////////////////////////////////////////////////////////////
// LAZY_GORIGHT
:G_LAZY_GORIGHT

IF sitonly == 0 THEN
  IF mood_happy > 3 1287
  CALL G_RANDOM1/3
    CASE:1 GO 1287
ENDIF

CALL G_VOICE_HIT
CALL G_RANDOM3
  CASE:1 PLAY ACTION MOVE.HEAD.SLOW -90 0
  CASE:2 PLAY ACTION MOVE.HEAD.NORMAL -90 0
  CASE:3 PLAY ACTION MOVE.HEAD.FAST -90 0
WAIT
RET 1	// done

:1287	// GO_RIGHT
CALL G_GO_RIGHT
RET 2	// stand


////////////////////////////////////////////////////////////////////
// NEED2REST  (See if we need to rest (heat or battery))
:G_NEED2REST
SWITCH Posture1
  CASE:POSTURE_PICKUP RET 1	// rest - Picked up?
  CASE:POSTURE_CHARGE1 RET 1	// rest - On charger?
  CASE:POSTURE_CHARGE2 RET 1	// rest - On charger? 

IF Batt_Rest < 25 THEN
  RET:1 // rest
ENDIF

IF Body_Temp > 45 THEN
  RET:1 // rest
ENDIF

IF Batt_Temp > 45 THEN
  RET:1 // rest
ENDIF

RET:2 // play


////////////////////////////////////////////////////////////////////
// PRAISE
:G_PRAISE
CALL G_DEC_SAD_MOOD

IF_1ST mood_happy < 2 1319
CALL G_RANDOM2
  CASE:1 GO 1319

:1308	// RNDNUM(2)
RND rndnum 100 102
WAIT 1
SET init_wait Wait
IF_1ST rndnum = last_praiseact 1308
IF_1ST rndnum = last_praiseact2 1308
SWITCH rndnum
  CASE:100 PLAY ACTION PRAISED7
  CASE:101 PLAY ACTION PRAISED8
  CASE:ELSE PLAY ACTION PRAISED9

:1312	// TRACK_ACT
SET last_praiseact2 last_praiseact
SET last_praiseact rndnum
CALL G_WAIT
CALL G_INC_HAPPY_MOOD
CALL G_DEC_MAD_MOOD
CALL G_BEHAVIOR_PRAISE
RET 1

:1319	// RNDNUM
RND rndnum 0 5
WAIT 1
SET init_wait Wait
IF_1ST rndnum = last_praiseact 1319
IF_1ST rndnum = last_praiseact2 1319
SWITCH rndnum
  CASE:0 PLAY ACTION PRAISED1
  CASE:1 PLAY ACTION PRAISED2
  CASE:2 PLAY ACTION PRAISED3
  CASE:3 PLAY ACTION PRAISED4
  CASE:4 PLAY ACTION PRAISED5
  CASE:ELSE PLAY ACTION PRAISED6
GO 1312


////////////////////////////////////////////////////////////////////
// PRAISE_REST  (Been praised while not moving.   Get happier.)
:G_PRAISE_REST
CALL G_DEC_SAD_MOOD

IF_1ST mood_happy < 2 1361
IF_1ST mood_happy < 5 1371
IF_1ST mood_happy < 8 1370
CALL G_RANDOM4
  CASE:1 GO 1361
  CASE:2 GO 1355
  CASE:3 GO 1346

:1332	// RNDNUM(4)
RND rndnum 300 305
WAIT 1
SET init_wait Wait
IF_1ST rndnum = last_praiseact 1332
IF_1ST rndnum = last_praiseact2 1332
SWITCH rndnum
  CASE:300 PLAY ACTION HAPPY_ANY7
  CASE:301 PLAY ACTION HAPPY_ANY8
  CASE:302 PLAY ACTION HAPPY_ANY9
  CASE:303 PLAY ACTION HAPPY_ANY10
  CASE:304 PLAY ACTION HAPPY_ANY11
  CASE:ELSE PLAY ACTION HAPPY_ANY12

:1336	// TRACK_ACT
SET last_praiseact2 last_praiseact
SET last_praiseact rndnum
VSAVE boygirl
CALL G_WAIT
CALL G_INC_HAPPY_MOOD
CALL G_DEC_MAD_MOOD
CALL G_BEHAVIOR_PRAISE
RET 1

:1346	// RNDNUM(3)
RND rndnum 200 205
WAIT 1
SET init_wait Wait
IF_1ST rndnum = last_praiseact 1346
IF_1ST rndnum = last_praiseact2 1346
SWITCH rndnum
  CASE:200 PLAY ACTION HAPPY_ANY1
  CASE:201 PLAY ACTION HAPPY_ANY2
  CASE:202 PLAY ACTION HAPPY_ANY3
  CASE:203 PLAY ACTION HAPPY_ANY4
  CASE:204 PLAY ACTION HAPPY_ANY5
  CASE:ELSE PLAY ACTION HAPPY_ANY6
GO 1336

:1355	// RNDNUM(2)
RND rndnum 100 102
WAIT 1
SET init_wait Wait
IF_1ST rndnum = last_praiseact 1355
IF_1ST rndnum = last_praiseact2 1355
SWITCH rndnum
  CASE:100 PLAY ACTION PRAISED7
  CASE:101 PLAY ACTION PRAISED8
  CASE:ELSE PLAY ACTION PRAISED9
GO 1336

:1361	// RNDNUM
RND rndnum 0 5
WAIT 1
SET init_wait Wait
IF_1ST rndnum = last_praiseact 1361
IF_1ST rndnum = last_praiseact2 1361
SWITCH rndnum
  CASE:0 PLAY ACTION PRAISED1
  CASE:1 PLAY ACTION PRAISED2
  CASE:2 PLAY ACTION PRAISED3
  CASE:3 PLAY ACTION PRAISED4
  CASE:4 PLAY ACTION PRAISED5
  CASE:ELSE PLAY ACTION PRAISED6
GO 1336

:1370	// RANDOM3
CALL G_RANDOM3
  CASE:1 GO 1361
  CASE:2 GO 1355
GO 1346

:1371	// RANDOM2
CALL G_RANDOM2
  CASE:1 GO 1361
GO 1355


////////////////////////////////////////////////////////////////////
// QUERY_HUNGRY  (Respond to query about tummy status)
:G_QUERY_HUNGRY

WAIT 1
SET init_wait Wait

IF Batt_Rest >= 50 THEN // not hungry
  CALL G_RANDOM2
    CASE:1 PLAY ACTION NO1
    CASE:2 PLAY ACTION NO2
  CALL G_WAIT_AWARE
  RET 1	// done
ENDIF

CALL G_RANDOM2
  CASE:1 PLAY ACTION YES_OK1
  CASE:2 PLAY ACTION YES_OK2
CALL G_WAIT_AWARE

CALL G_RANDOM2
  CASE:2 RET 1	// done

IF Batt_Rest < 35 THEN
  PLAY ACTION HUNGRY_LOT
ELSE
  PLAY ACTION HUNGRY_LITTLE
ENDIF

CALL G_WAIT_AWARE
RET 2	// sit


////////////////////////////////////////////////////////////////////
// QUERY_MOOD  (Respond if asked "Are you ok?")
:G_QUERY_MOOD
WAIT 1
SET init_wait Wait

// If battery & mood ok, then say YES...
IF (Batt_Rest >= 35) && (mood_mad < 1) && (mood_sad < 1) THEN
  CALL G_RANDOM2
    CASE:1 PLAY ACTION YES_OK1
    CASE:2 PLAY ACTION YES_OK2
  CALL G_WAIT_AWARE
  RET:1
ENDIF

// Say NO...
CALL G_RANDOM2
  CASE:1 PLAY ACTION NO1
  CASE:2 PLAY ACTION NO2
CALL G_WAIT_AWARE

// If hungry, occastionally indicate if hungry...
RND rndnum 0 100
IF rndnum<50 THEN
  RET:1
ENDIF

IF Batt_Rest<35 THEN
  PLAY ACTION HUNGRY_LOT
  CALL G_WAIT
  RET:1
ENDIF

IF mood_mad>4 THEN
  CALL G_TANTRUM
  RET:1
ENDIF

IF mood_sad>4 THEN
  CALL G_SAD
  RET:1
ELSE
  RND maxtime5 2 5	// Set timer to turn off eyes...
  SET Eye_L1 1		// Set sad eyes...
  SET Eye_R1 1
ENDIF
RET:1


////////////////////////////////////////////////////////////////////
// QUERY_TIRED
:G_QUERY_TIRED
WAIT 1
SET init_wait Wait

IF mood_tired>5 THEN
  CALL G_RANDOM2
    CASE:1 PLAY ACTION YES_OK1
    CASE:2 PLAY ACTION YES_OK2
  CALL G_WAIT_AWARE
  RET 1	// done
ENDIF

CALL G_RANDOM2
  CASE:1 PLAY ACTION NO1
  CASE:2 PLAY ACTION NO2
CALL G_WAIT_AWARE
RET 1	// done


////////////////////////////////////////////////////////////////////
//
//  Random 20% chance...
//
:G_RANDOM1/5
RND rndnum 0 100
CSET:rndnum:<:20:1	// Yup
CSET:rndnum:>=:20:2	// Nope
RET:Context


////////////////////////////////////////////////////////////////////
//
//  Random 33% chance...
//
:G_RANDOM1/3
RND rndnum 0 100
CSET:rndnum:<:33:1	// Yup
CSET:rndnum:>=:33:2	// Nope
RET:Context


////////////////////////////////////////////////////////////////////
// RANDOM2  (Random 50% chance)
:G_RANDOM2
RND rndnum 0 100
CSET:rndnum:<:50:1	// Yup
CSET:rndnum:>=:50:2	// Nope
RET:Context


////////////////////////////////////////////////////////////////////
// RANDOM3  (Random 1 in 3)
:G_RANDOM3
RND rndnum 0 100
CSET:rndnum:<:33:1
CSET:rndnum:<:66:2
CSET:rndnum:>=:66:3
RET:Context


////////////////////////////////////////////////////////////////////
// RANDOM4  (Random 1 in 4)
:G_RANDOM4
RND rndnum 0 100
CSET:rndnum:<:25:1
CSET:rndnum:<:50:2
CSET:rndnum:<:75:3
CSET:rndnum:>=:75:4
RET:Context


////////////////////////////////////////////////////////////////////
// RANDOM6  (Random 1 in 6)
:G_RANDOM6
RND rndnum 0 60
CSET:rndnum:<:10:1
CSET:rndnum:<:20:2
CSET:rndnum:<:30:3
CSET:rndnum:<:40:4
CSET:rndnum:<:50:5
CSET:rndnum:>=:50:6
RET:Context


////////////////////////////////////////////////////////////////////
// SAD
:G_SAD
RND rndnum 0 13
SWITCH rndnum
  CASE:0 PLAY ACTION SAD_ANY1
  CASE:1 PLAY ACTION SAD_ANY2
  CASE:2 PLAY ACTION SAD_ANY3
  CASE:3 PLAY ACTION SAD_ANY4
  CASE:4 PLAY ACTION SAD_ANY5
  CASE:5 PLAY ACTION SAD_ANY6
  CASE:6 PLAY ACTION SAD_ANY7
  CASE:7 PLAY ACTION SAD_ANY8
  CASE:8 PLAY ACTION SAD_ANY9
  CASE:9 PLAY ACTION SAD_ANY10
  CASE:10 PLAY ACTION SAD_ANY11
  CASE:11 PLAY ACTION SAD_ANY12
  CASE:12 PLAY ACTION SAD_ANY13
  CASE:ELSE PLAY ACTION SAD_ANY14
CALL G_WAIT
RET 1


////////////////////////////////////////////////////////////////////
// SCOLD
:G_SCOLD

:1496	// MOOD?
IF_1ST mood_mad <= 5 1514
RND rndnum 0 23

:4109	// MAD_RNDNUM
WAIT 1
SET init_wait Wait
IF_1ST rndnum = last_scoldact 1496
IF_1ST rndnum = last_scoldact2 1496
SWITCH rndnum
  CASE:0 PLAY ACTION SCOLDED1
  CASE:1 PLAY ACTION SCOLDED2
  CASE:2 PLAY ACTION SCOLDED3
  CASE:3 PLAY ACTION SCOLDED4
  CASE:4 PLAY ACTION SCOLDED5
  CASE:5 PLAY ACTION SCOLDED6
  CASE:6 PLAY ACTION SCOLDED7
  CASE:7 PLAY ACTION SCOLDED8
  CASE:ELSE PLAY ACTION SCOLDED9
SET last_scoldact2 last_scoldact
SET last_scoldact rndnum
CALL G_WAIT

CALL G_INC_MAD_MOOD
CALL G_DEC_HAPPY_MOOD
CALL G_BEHAVIOR_SCOLD
RET 1

:1514	// CALM_RNDNUM
RND rndnum 0 8
GO 4109


////////////////////////////////////////////////////////////////////
// SCOLD_REST  (Been scolded.  Get madder.)
:G_SCOLD_REST

:1517	// MOOD?
IF_1ST mood_mad <= 5 1555
CALL G_RANDOM1/3
  CASE:1 GO 1551

:1519	// MAD_RNDNUM
RND rndnum 0 23

:4110	// MAD_RNDNUM
WAIT 1
SET init_wait Wait
IF_1ST rndnum = last_scoldact 1517
IF_1ST rndnum = last_scoldact2 1517
IF_1ST rndnum < 10 1541
SWITCH rndnum
  CASE:9 PLAY ACTION MAD_ANY1
  CASE:10 PLAY ACTION MAD_ANY2
  CASE:11 PLAY ACTION MAD_ANY3
  CASE:12 PLAY ACTION MAD_ANY4
  CASE:13 PLAY ACTION MAD_ANY5
  CASE:14 PLAY ACTION MAD_ANY6
  CASE:15 PLAY ACTION MAD_ANY7
  CASE:16 PLAY ACTION MAD_ANY8
  CASE:17 PLAY ACTION MAD_ANY9
  CASE:18 PLAY ACTION MAD_ANY10
  CASE:19 PLAY ACTION MAD_ANY11
  CASE:20 PLAY ACTION MAD_ANY12
  CASE:21 PLAY ACTION MAD_ANY13
  CASE:ELSE PLAY ACTION MAD_ANY14

:1523	// TRACK_SCOLD
SET last_scoldact2 last_scoldact
SET last_scoldact rndnum
VSAVE boygirl
CALL G_WAIT
CALL G_INC_MAD_MOOD
CALL G_DEC_HAPPY_MOOD
CALL G_BEHAVIOR_SCOLD
RET 1

:1541	// SELECT_SCOLD
SWITCH rndnum
  CASE:0 PLAY ACTION SCOLDED1
  CASE:1 PLAY ACTION SCOLDED2
  CASE:2 PLAY ACTION SCOLDED3
  CASE:3 PLAY ACTION SCOLDED4
  CASE:4 PLAY ACTION SCOLDED5
  CASE:5 PLAY ACTION SCOLDED6
  CASE:6 PLAY ACTION SCOLDED7
  CASE:7 PLAY ACTION SCOLDED8
  CASE:ELSE PLAY ACTION SCOLDED9
GO 1523

:1551	// STANDING?
IF_1ST Posture1 <> POSTURE_STAND 1519
CALL G_RANDOM2
  CASE:1 PLAY ACTION BEENHIT1
  CASE:2 PLAY ACTION BEENHIT2
SET rndnum 999
GO 1523

:1555	// CALM_RNDNUM
RND rndnum 0 8
GO 4110


////////////////////////////////////////////////////////////////////
// STAND4BALL  (Standup while looking at ball)
:G_STAND4BALL

IF sitonly > 0 THEN
  RET 1 // none
ENDIF

CALL G_STOP_HEAD
CALL G_STOP_TAILWAG
PLAY ACTION TRACK_HEAD PINK_BALL
WAIT 1000
CALL G_STOP_HEAD
IF_1ST mood_tired >= 9 2711
WAIT 1
SET pan Head_Pan
SET tilt Head_Tilt
SUB tilt 10	// adjust for standpos
PLAY ACTION STAND
WAIT
PLAY ACTION MOVE.HEAD.FAST pan tilt
WAIT
WAIT 1
IF_1ST Pink_Ball > 0 2712
CALL G_SOCCER_SEARCH4BALL
  CASE:1 RET 4	// rest
  CASE:2 RET 2	// ball
RET 3	// noball

:2711	// none
RET 1

:2712	// ball
RET 2


////////////////////////////////////////////////////////////////////
// STOP_TAILWAG  (Stop tail from wagging)
:G_STOP_TAILWAG
WAIT 1
IF_1ST tailwag > 0
IF_AND Wait > 0 3038
WAIT
RET 1

:3038	// STOP_TAILWAG
PLAY ACTION PALONE.AUTO.TAILSTOP
SET tailwag 0
WAIT
RET 1


////////////////////////////////////////////////////////////////////
// SURPRISE
:G_SURPRISE
RND rndnum 0 12
WAIT 1
SET init_wait Wait
SWITCH rndnum
  CASE:0 PLAY ACTION SURPRISE_ANY1
  CASE:1 PLAY ACTION SURPRISE_ANY2
  CASE:2 PLAY ACTION SURPRISE_ANY3
  CASE:3 PLAY ACTION SURPRISE_ANY4
  CASE:4 PLAY ACTION SURPRISE_ANY5
  CASE:5 PLAY ACTION SURPRISE_ANY6
  CASE:6 PLAY ACTION SURPRISE_ANY7
  CASE:7 PLAY ACTION SURPRISE_ANY8
  CASE:8 PLAY ACTION SURPRISE_ANY9
  CASE:9 PLAY ACTION SURPRISE_ANY10
  CASE:10 PLAY ACTION SURPRISE_ANY11
  CASE:11 PLAY ACTION SURPRISE_ANY12
  CASE:ELSE PLAY ACTION SURPRISE_ANY13
CALL G_WAIT_AWARE
RET 1


////////////////////////////////////////////////////////////////////
// TAKE_A_PICTURE
:G_TAKE_A_PICTURE
WAIT 1
SET init_wait Wait
PLAY ACTION MOVE.HEAD.FAST Head_Pan 0
CALL G_WAIT_AWARE

PLAY ACTION PHOTOSNAP
AP_SNAPSHOT
CALL G_WAIT_AWARE

:3067	// WAIT4SNAP
WHILE AP_Snap_Ready <= 0 
  WAIT 1
WEND

PLAY ACTION+ snapshot_tune
VLOAD snapNum
AP_SAVEIMAGE snapNum

ADD snapNum 1
LAND snapNum 7	// Range 0 to 7, to avoid filling memstick
VSAVE snapNum

PLAY ACTION+ happy_eyes
CALL G_WAIT_AWARE
RET 1



////////////////////////////////////////////////////////////////////
//
//  Throw a temper tantrum...
//
:G_TANTRUM
WAIT 1
SET init_wait Wait
RND rndnum 0 100
CSET:rndnum:<:10:1
CSET:rndnum:<:20:2
CSET:rndnum:<:30:3
CSET:rndnum:<:40:4
CSET:rndnum:<:50:5
CSET:rndnum:<:60:6
CSET:rndnum:<:70:7
CSET:rndnum:<:80:8
CSET:rndnum:<:90:9
CSET:rndnum:>=:90:10
CASE:1:PLAY ACTION TEMPER_TANTRUM1
CASE:2:PLAY ACTION TEMPER_TANTRUM2
CASE:3:PLAY ACTION TEMPER_TANTRUM3
CASE:4:PLAY ACTION TEMPER_TANTRUM4
CASE:5:PLAY ACTION TEMPER_TANTRUM5
CASE:6:PLAY ACTION TEMPER_TANTRUM6
CASE:7:PLAY ACTION TEMPER_TANTRUM7
CASE:8:PLAY ACTION CUTE_EXERCISE5
CASE:9:PLAY ACTION CUTE_EXERCISE6
CASE:10:PLAY ACTION AIBOZYA
CALL G_WAIT
RET 1


////////////////////////////////////////////////////////////////////
//
// Decrement timer counts once per second.  Uses system clock tick
// variables which increments every 32ms.  32ms*32 = ~1 second.
// 
:G_TIMERS
WAIT 1
IF Clock < 0 THEN
  SET Clock 0
ENDIF

IF Clock < 32 THEN
  RET 1
ENDIF

SET Clock 0
SUB maxtime1 1
SUB maxtime2 1
SUB maxtime3 1
SUB maxtime4 1
SUB maxtime5 1
SUB maxtime6 1
SUB maxtime_mood 1
SUB goforit 1

// Keep expired timers from going too negative (basically want
// to avoid wrapping, but no need to reset constantly)...
IF maxtime1 < -1000 THEN
  SET maxtime1 -1
ENDIF
IF maxtime2 < -1000 THEN
  SET maxtime2 -1
ENDIF
IF maxtime3 < -1000 THEN
  SET maxtime3 -1
ENDIF
IF maxtime4 < -1000 THEN
  SET maxtime4 -1
ENDIF
IF maxtime5 < -1000 THEN
  SET maxtime5 -1
ENDIF
IF maxtime6 < -1000 THEN
  SET maxtime6 -1
ENDIF
IF maxtime_mood < -1000 THEN
  SET maxtime_mood -1
ENDIF
IF goforit < -1000 THEN
  SET goforit -1
ENDIF

// If greater than 1000, timer disabled...
IF maxtime1 == 1000 THEN	
  SET maxtime1 MAXINT
ENDIF
IF maxtime2 == 1000 THEN
  SET maxtime2 MAXINT
ENDIF
IF maxtime3 == 1000 THEN
  SET maxtime3 MAXINT
ENDIF
IF maxtime4 == 1000 THEN
  SET maxtime4 MAXINT
ENDIF
IF maxtime5 == 1000 THEN
  SET maxtime5 MAXINT
ENDIF
IF maxtime6 == 1000 THEN
  SET maxtime6 MAXINT
ENDIF
IF maxtime_mood == 1000 THEN
  SET maxtime_mood MAXINT
ENDIF

RET 1


////////////////////////////////////////////////////////////////////
// TIMER1 - Used to time getting bored...
:G_TIMER1
CALL G_TIMERS
IF maxtime1 < 0 THEN
  RET 2 // timeout
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// TIMER2 - Used to time looking around...
:G_TIMER2
CALL G_TIMERS
IF maxtime2 < 0 THEN
  RET 2 // timeout
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// TIMER3 - Used to time getting tired...
:G_TIMER3
CALL G_TIMERS
IF maxtime3 < 0 THEN
  RET 2 // timeout
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// TIMER4 - Used to time getting sad...
:G_TIMER4
CALL G_TIMERS
IF maxtime4 < 0 THEN
  RET 2 // timeout
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// TIMER5 - Used to time getting sad...
:G_TIMER5
CALL G_TIMERS
IF maxtime5 < 0 THEN
  RET 2 // timeout
ENDIF
RET 1



////////////////////////////////////////////////////////////////////
// 
//  Timer used to detect getting bored.  Auto reset the count
//  an update the bored count...
//
:G_BORED_TIMER
CALL G_TIMERS
IF maxtime1 < 0 THEN
  CALL G_STOP_TAILWAG
  RND maxtime1 3 10
  SUB bored_count 1
  RET 2
ENDIF

// If maxtime4 was set, AIBO expected something to happen within
// a limited amount of time.  If timer expires, it didn't happen... :-(
IF maxtime4 < 0 THEN // sad?
  SET maxtime4 MAXINT
  CALL G_INC_SAD_MOOD
ENDIF

IF maxtime5 < 0 THEN
  SET maxtime5 MAXINT
  SET Eye_L1 0		// Clear sad eyes...
  SET Eye_R1 0
ENDIF

// Slowly get better on own if mad or sad...
IF (mood_sad>0) || (mood_mad>0) THEN
  IF maxtime_mood > 1000 THEN
    CALL G_INIT_MOOD_TIMER
  ENDIF
  IF maxtime_mood < 0 THEN
    CALL G_INIT_MOOD_TIMER
    CALL G_DEC_SAD_MOOD
    CALL G_DEC_MAD_MOOD
  ENDIF
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// Set the mood timer, used to slowly improve mood if nothing
// stimulating is happening...
:G_INIT_MOOD_TIMER
RND maxtime_mood 30 60
RET:1


////////////////////////////////////////////////////////////////////
// LOOK_TIMER  (Look around randomly)
:G_LOOK_TIMER
CALL G_TIMER2
  CASE:1 RET 1
WAIT 1
RND tilt -40 10
RND pan -60 60
SET look_wait Wait

#ifdef AIBO310
CALL G_RANDOM2
  CASE:1 PRINT:"ZZZ PLAY ACTION MOVE.HEAD.NORMAL %d %d":pan:tilt
  CASE:1 PLAY ACTION MOVE.HEAD.NORMAL pan tilt 10
  CASE:2 PRINT:"ZZZ PLAY ACTION MOVE.HEAD.SLOW %d %d":pan:tilt
  CASE:2 PLAY ACTION MOVE.HEAD.SLOW pan tilt 10

#else
CALL G_RANDOM3
  CASE:1 PLAY ACTION MOVE.HEAD.FAST pan tilt
  CASE:2 PLAY ACTION MOVE.HEAD.NORMAL pan tilt
  CASE:3 PLAY ACTION MOVE.HEAD.SLOW pan tilt
#endif
RND maxtime2 1 3
RET 1


////////////////////////////////////////////////////////////////////
// REST_TIMER
:G_REST_TIMER
CALL G_TIMER3
  CASE:1:RET 1

// timeout...
RND maxtime3 8 15
CALL G_DEC_TIRED_MOOD
RET 1


////////////////////////////////////////////////////////////////////
// TIMER_TIRED
:G_TIMER_TIRED
CALL G_NEED2REST
  CASE:1 RET 1	// tired

// If something time consuming was happening, 
// compensate in tired timer...
WHILE Clock > 100 
  SUB maxtime_tired 1
  SUB Clock 100
WEND

// Timer tick?
IF (Clock<0) || (Clock>=32) THEN
  SUB maxtime_tired 1
  CALL G_TIMERS
ENDIF

// If tired timer not expired, return...
IF maxtime_tired >= 0 THEN
  RET 2 // play
ENDIF

ADD mood_tired 1
RND maxtime_tired 5 10
ADD maxtime_tired endure

IF mood_tired > MOOD_MAX THEN
  SET mood_tired MOOD_MAX
ENDIF

IF mood_tired > 9 THEN
  RET 1 // tired
ENDIF
RET 2	// play



////////////////////////////////////////////////////////////////////
//
//  Translate tone commands into Voice commands...
//
:G_TONECMD
WAIT 1
IF_1ST rcodeplus > 0
IF_AND AP_Tone > 0 3110
RET 2	// none

:3110	// GET_TONE
WAIT 1
SET ToneCmd AP_Tone
SET AP_Tone 0
WAIT 1
SWITCH ToneCmd
  CASE:11 SET VoiceCmd VOICE_STANDUP	// Stand Up
  CASE:12 SET VoiceCmd VOICE_SITDOWN	// Sit Down
  CASE:13 SET VoiceCmd VOICE_LAYDOWN	// Lie Down
  CASE:23 SET VoiceCmd VOICE_GOFORWARD  // Go Forward
  CASE:24 SET VoiceCmd VOICE_STOP	// Stop
  CASE:25 SET VoiceCmd VOICE_GOBACK	// Go Back
  CASE:28 SET VoiceCmd VOICE_TURNLEFT	// Left
  CASE:29 SET VoiceCmd VOICE_TURNRIGHT	// Right
  CASE:ELSE RET 2			// none - 
RET 1


////////////////////////////////////////////////////////////////////
//
//  Acknowledge a voice command.  Occasionally be directional...
//
:G_TWITCH_EARS
WAIT 1
SET init_wait Wait

IF AiboType==210 THEN
  RND rndnum 0 100
  IF rndnum < 33 THEN
    SWITCH:VoiceHorz
      CASE:2 PLAY ACTION RIGHT_EAR_TWITCH3
      CASE:4 PLAY ACTION RIGHT_EAR_TWITCH3
      CASE:8 PLAY ACTION RIGHT_EAR_TWITCH3
      CASE:32 PLAY ACTION LEFT_EAR_TWITCH3
      CASE:64 PLAY ACTION LEFT_EAR_TWITCH3
      CASE:128 PLAY ACTION LEFT_EAR_TWITCH3
      CASE:ELSE PLAY ACTION BOTH_EAR_TWITCH3
  ELSE
    PLAY ACTION BOTH_EAR_TWITCH3
  ENDIF
ELSE // 220 & 310
  PLAY MWCID VOICEACK
ENDIF

CALL G_WAIT_AWARE
RET:1


////////////////////////////////////////////////////////////////////
// VOICE_HIT  (Recognized a command, and are responding to it.)
:G_VOICE_HIT
CALL G_TWITCH_EARS
CALL G_STOP_TAILWAG
RET:1


////////////////////////////////////////////////////////////////////
// VOICECMD  (See if there is a pending voice command)
:G_VOICECMD
WAIT 1
IF AP_Voice_Cmd == 0 THEN
  RET:GO_IDLE
ENDIF

SET VoiceCmd AP_Voice_Cmd
SET VoiceLevel AP_Voice_Level
SET VoicePitch AP_Voice_Pitch
SET VoiceHorz AP_Voice_Horz
SET VoiceDictID AP_Voice_DicID
SET AP_Voice_Cmd 0
ADD VoiceCmd base_voice_cmd

// Ignor anything with quite voice level.  Too often tends to
//  be disruptive background noise.
IF VoiceLevel < MIN_VOICE_LEVEL THEN
  SET VoiceCmd 0
  SET VoiceLevel 0
  RET:GO_IDLE
ENDIF

// Translate compatible VOICE2 commands into Life1 vocabulary
// to minimize changes needed to support it...
SWITCH VoiceCmd
  CASE:VOICE2_AIBO          SET VoiceCmd VOICE_AIBO
  CASE:VOICE2_HEYAIBO	    SET VoiceCmd VOICE_AIBO
  CASE:VOICE2_THANKS        SET VoiceCmd VOICE_HELLO
  CASE:VOICE2_WHATSYOURNAME SET VoiceCmd VOICE_WHATSYOURNAME
  CASE:VOICE2_SAYHELLO      SET VoiceCmd VOICE_SAYHELLO
  CASE:VOICE2_SHAKEPAW      SET VoiceCmd VOICE_SHAKEPAW
  CASE:VOICE2_MORNING       SET VoiceCmd VOICE_GOODMORNING
  CASE:VOICE2_HELLO         SET VoiceCmd VOICE_HELLO
  CASE:VOICE2_GOODNIGHT     SET VoiceCmd VOICE_GOODNIGHT
  CASE:VOICE2_SEEYOU        SET VoiceCmd VOICE_GOODBYE
  CASE:VOICE2_HOWAREYOU     SET VoiceCmd VOICE_AREYOUOK
  CASE:VOICE2_CHEERUP       SET VoiceCmd VOICE_GOFORIT
  CASE:VOICE2_READYSETGO    SET VoiceCmd VOICE_GOFORIT
  CASE:VOICE2_DONTDOTHAT    SET VoiceCmd VOICE_DONTDOTHAT
  CASE:VOICE2_LETSPLAY      SET VoiceCmd VOICE_LETSPLAY
  CASE:VOICE2_DANCE         SET VoiceCmd VOICE_LETSDANCE
  CASE:VOICE2_SHOWTIME      SET VoiceCmd VOICE_LETSDANCE
  CASE:VOICE2_SINGSONG      SET VoiceCmd VOICE_MEOW
  CASE:VOICE2_POSE          SET VoiceCmd VOICE_POSE
  CASE:VOICE2_CLOWNAROUND   SET VoiceCmd VOICE_POSE
  CASE:VOICE2_HAPPYDAY      SET VoiceCmd VOICE_HELLO
  CASE:VOICE2_STANDUP       SET VoiceCmd VOICE_STANDUP
  CASE:VOICE2_LAYDOWN       SET VoiceCmd VOICE_LAYDOWN
  CASE:VOICE2_SITDOWN       SET VoiceCmd VOICE_SITDOWN
  CASE:VOICE2_TURNRIGHT     SET VoiceCmd VOICE_TURNRIGHT
  CASE:VOICE2_TURNLEFT      SET VoiceCmd VOICE_TURNLEFT
  CASE:VOICE2_GOFORWARD     SET VoiceCmd VOICE_GOFORWARD
  CASE:VOICE2_GOBACKWARD    SET VoiceCmd VOICE_GOBACK
  CASE:VOICE2_GOAHEAD       SET VoiceCmd VOICE_GOFORWARD
  CASE:VOICE2_STOP          SET VoiceCmd VOICE_STOP
  CASE:VOICE2_PINKBALL      SET VoiceCmd VOICE_FINDBALL
  CASE:VOICE2_RIGHTKICK     SET VoiceCmd VOICE_KICKBALL
  CASE:VOICE2_LEFTKICK      SET VoiceCmd VOICE_KICKBALL
  CASE:VOICE2_RIGHTTOUCH    SET VoiceCmd VOICE_KICKBALL
  CASE:VOICE2_LEFTTOUCH     SET VoiceCmd VOICE_KICKBALL
  CASE:VOICE2_BANZAI        SET VoiceCmd VOICE_KARATECHOP
  CASE:VOICE2_SHOWOFF       SET VoiceCmd VOICE_KARATECHOP
  CASE:VOICE2_IAMHERE       SET VoiceCmd VOICE_IAMHERE
  CASE:VOICE2_TAKEAPICTURE  SET VoiceCmd VOICE_TAKEAPICTURE
  CASE:VOICE2_KARATECHOP    SET VoiceCmd VOICE_KARATECHOP
  CASE:VOICE2_WALK          SET VoiceCmd VOICE_WALK
  CASE:VOICE2_AREYOUTIRED   SET VoiceCmd VOICE_AREYOUTIRED
  CASE:VOICE2_AREYOUHUNGRY  SET VoiceCmd VOICE_AREYOUHUNGRY
  CASE:VOICE2_NAMEREG       SET VoiceCmd VOICE_NAMEREG
  CASE:VOICE2_BEQUIET       SET VoiceCmd VOICE_BEQUIET

// These need explicit support, since no obvious mapping...
//  CASE:VOICE2_GOODAIBO	(implemented)
//  CASE:VOICE2_THATSRIGHT    
//  CASE:VOICE2_SORRY
//  CASE:VOICE2_SAYMESSAGE
//  CASE:VOICE2_LETSBESECRET
//  CASE:VOICE2_OPENSESAME
//  CASE:VOICE2_FASTER
//  CASE:VOICE2_SLOWDOWN
//  CASE:VOICE2_YOUWON 		(implemented)
//  CASE:VOICE2_YOULOST 	(implemented)
//  CASE:VOICE2_ACTION1 
//  CASE:VOICE2_ACTION2 
//  CASE:VOICE2_ACTION3 
//  CASE:VOICE2_ACTION4 
//  CASE:VOICE2_ACTION5 
//  CASE:VOICE2_LETSTALK       

PRINT -----
PRINT VoiceCmd=%d VoiceCmd
PRINT VoiceLevel=%d VoiceLevel
PRINT VoicePitch=%d VoicePitch
PRINT VoiceHorz=%d VoiceHorz
PRINT VoiceDictID=%d VoiceDictID

RET:GO_VOICE


////////////////////////////////////////////////////////////////////
// WAIT
:G_WAIT
CALL G_UPDATE_PAUSEBAR
:WAIT_LOOP
WAIT 100
IF_1ST Wait > 0
IF_AND Wait > init_wait WAIT_LOOP
RET 1


////////////////////////////////////////////////////////////////////
//
//  Process attention given while waiting for something...
//
:G_WAIT_ATTENTION
IF (praise+scold)>0 THEN
  RET 1
ENDIF

// HEAD_ON?
IF Head_ON <> 0 THEN
  IOR praise 1
  SET Head_ON 0
  SET back_count 0
ENDIF

// HEAD_HIT?
IF Head_Hit <> 0 THEN
  IOR scold 1
  SET Head_Hit 0
  SET back_count 0
ENDIF

// BACK_ON?
IF Back_ON <> 0 THEN
  IOR praise 2
  SET Back_ON 0
  ADD back_count 1
ENDIF

// JAW_ON?
IF Jaw_ON <> 0 THEN
  IOR praise 4
  SET Jaw_ON 0
  SET back_count 0
ENDIF

// Good-Boy/Bad-Boy?
IF AP_Voice_Cmd > 0 THEN
  IF (AP_Voice_Level < MIN_VOICE_LEVEL) THEN
    SET AP_Voice_Cmd 0
  ELSE
    SWITCH (AP_Voice_Cmd+base_voice_cmd)
      CASE:VOICE_GOODBOT GO WA_GOODBOT	 	// Good Bot
      CASE:VOICE_DONTDOTHAT GO WA_BADBOT	// Don't do that
      CASE:VOICE_BADBOT GO WA_BADBOT	 	// Bad Boy
      CASE:VOICE2_THATSRIGHT GO WA_GOODBOT 	// Good Bot
      CASE:VOICE2_GOODBOY GO WA_GOODBOT 	// Good Boy
      CASE:VOICE2_GOODGIRL GO WA_GOODBOT	// Good Girl
      CASE:VOICE2_BADBOY GO WA_BADBOT		// Bad Boy
      CASE:VOICE2_BADGIRL GO WA_BADBOT		// Bad Girl
  ENDIF
ENDIF

:WA_CHECK_ATTENTION
IF praise > 0 WA_PRAISE
IF scold > 0 WA_SCOLD
RET 1

:WA_SCOLD
RND rndnum 0 8
IF_1ST rndnum = last_scoldact WA_SCOLD
IF_1ST rndnum = last_scoldact2 WA_SCOLD
SWITCH rndnum
  CASE:0 PLAY ACTION SCOLDED1
  CASE:1 PLAY ACTION SCOLDED2
  CASE:2 PLAY ACTION SCOLDED3
  CASE:3 PLAY ACTION SCOLDED4
  CASE:4 PLAY ACTION SCOLDED5
  CASE:5 PLAY ACTION SCOLDED6
  CASE:6 PLAY ACTION SCOLDED7
  CASE:7 PLAY ACTION SCOLDED8
  CASE:ELSE PLAY ACTION SCOLDED9
SET last_scoldact2 last_scoldact
SET last_scoldact rndnum
RET 1

:WA_PRAISE
RND rndnum 0 8
IF_1ST rndnum = last_praiseact WA_PRAISE
IF_1ST rndnum = last_praiseact2 WA_PRAISE
SWITCH rndnum
  CASE:0 PLAY ACTION PRAISED1
  CASE:1 PLAY ACTION PRAISED2
  CASE:2 PLAY ACTION PRAISED3
  CASE:3 PLAY ACTION PRAISED4
  CASE:4 PLAY ACTION PRAISED5
  CASE:5 PLAY ACTION PRAISED6
  CASE:6 PLAY ACTION PRAISED7
  CASE:7 PLAY ACTION PRAISED8
  CASE:ELSE PLAY ACTION PRAISED9
SET last_praiseact2 last_praiseact
SET last_praiseact rndnum
RET 1

:WA_BADBOT
IOR scold 8	// Set bit 3
SET back_count 0
GO WA_CHECK_ATTENTION

:WA_GOODBOT
IOR praise 8	// Set bit 3
SET back_count 0
GO WA_CHECK_ATTENTION



////////////////////////////////////////////////////////////////////
// WAIT_AWARE  (Wait for event to be completed from queue, keeping an eye for praise/scolding)
:G_WAIT_AWARE
CALL G_UPDATE_PAUSEBAR
SET praise 0
SET scold 0

DO
  WAIT 100
  CALL G_WAIT_ATTENTION
LOOP:WHILE (Wait>0) && (Wait>init_wait)

IF_1ST praise > 0 3192
IF_1ST scold = 0 3190
SET Head_Hit 0

:3190	// CLEAR_VOICE?
IF_1ST praise & 8 3191
IF_1ST scold & 8 3191
RET 1

:3191	// CLEAR_VOICE
SET AP_Voice_Cmd 0
RET 1

:3192	// CLEAR_PRAISE
SET Head_ON 0
SET Back_ON 0
SET Jaw_ON 0
GO 3190


////////////////////////////////////////////////////////////////////
//
// TAIL_TWEAKED  (Someone is goofing with our tail)
//
:G_TAIL_TWEAKED
WAIT 1
IF_1ST Tail_Pan > 15 3658
IF_1ST Tail_Pan >= -15 3667

:3658	// TOO_BUSY?
WAIT 1
IF_1ST tailwag >= 0
IF_AND Wait < 4 3659	// Nope
RET 1	// none

:3659	// RANDOM1/3
CALL G_RANDOM1/3
  CASE:1 GO 3663
WAIT 1
SET tailwag -1
SET init_tailwait Wait
PLAY ACTION TAILWAG_HORZ3
WAIT 1000
PLAY ACTION PALONE.AUTO.TAILSTOP

:3661	// STALL
WAIT 250
WAIT 1
IF_1ST Wait > init_tailwait 3661
RET 1	// none

:3663	// HAPPY?
IF_1ST mood_happy > 5 3666	// Tolerate if happy
CALL G_RANDOM2
  CASE:1 RET 3	// scold
SET VoiceCmd VOICE_MEOW		// Roar/Meow
RET 4	// voice

:3666	// DEC_HAPPY_MOOD
SUB mood_happy 2
RET 2	// praise

:3667	// none
RET 1



////////////////////////////////////////////////////////////////////
// STOP_HEAD  (Stop head from tracking ball)
:G_STOP_HEAD
WAIT 1
SET init_stopwait Wait
PLAY ACTION MOVE.HEAD.FAST Head_Pan tilt
WHILE Wait > init_stopwait
  WAIT 250
WEND
RET 1


////////////////////////////////////////////////////////////////////
// STOP_HEADTAIL  (Stop head & tail from moving)
:G_STOP_HEADTAIL
CALL G_STOP_HEAD
CALL G_STOP_TAILWAG
RET 1


////////////////////////////////////////////////////////////////////
// WAITLAST
:G_WAITLAST
WAIT 1
SET init_waitlast Wait

:3796	// STALL
WAIT 100
WAIT 1
IF_1ST Wait > 0
IF_AND Wait >= init_waitlast 3796	// Yup
RET 1


////////////////////////////////////////////////////////////////////
// BEHAVIOR_RND  (Generate random number, referencing learned behavior probabilities.)
:G_BEHAVIOR_RND
CALL G_BEHAVIOR_INIT
SET rndstart rndbase
ADD rndstart 4
AP_GET rndend behavior rndbase 1
SET rndnum 0	// default
IF_1ST rndend < rndstart 3810
RND index rndstart rndend
AP_GET rndnum behavior index
RET 1

:3810	// invalid
RET 2


////////////////////////////////////////////////////////////////////
// BEHAVIOR_DIFF  (Find any behavior different from last two random events...)
:G_BEHAVIOR_DIFF
AP_GET rndend behavior rndbase 1
AP_GET lastact1 behavior rndbase 2
AP_GET lastact2 behavior rndbase 3
IF_1ST rndnum = lastact1 3814
IF_1ST rndnum <> lastact2 3819

:3814	// SETUP_SCAN
SET index rndbase
ADD index 4

:3815	// SCAN_DONE?
IF_1ST index > rndend 3819	// Nope
AP_GET temp behavior index
ADD index 1
IF_1ST temp = lastact1 3815
IF_1ST temp = lastact2 3815
SET rndnum temp

:3819	// RETURN
RET 1


////////////////////////////////////////////////////////////////////
// BEHAVIOR_LOG  (Track last 8 random numbers generated (globally))
:G_BEHAVIOR_LOG
IF_1ST rndnum < 0 3826
AP_GET index behavior 16	// i=b[16]
ADD index 1
LAND index 7
AP_SET rndbase behavior index	// b[i]=rndbase
AP_SET index behavior 16	// b[16]=i
AP_GET lastact1 behavior rndbase 2
AP_GET lastact2 behavior rndbase 3
IF_1ST rndnum <> lastact1
IF_AND rndnum <> lastact2 3825
RET 1

:3825	// UPDATE_LAST
AP_SET rndnum behavior rndbase 2
AP_SET lastact1 behavior rndbase 3

:3826	// RETURN
RET 1


////////////////////////////////////////////////////////////////////
// BEHAVIOR_ADD  (Add number to random list)
:G_BEHAVIOR_ADD
AP_GET rndend behavior rndbase 1
SET index rndend
SUB index rndbase
IF index < 48 THEN
  ADD rndend 1
  AP_SET praise behavior rndend
  AP_SET rndend behavior rndbase 1
ENDIF

:3831	// RETURN
RET 1


////////////////////////////////////////////////////////////////////
// BEHAVIOR_SUB  (Remove number from random list)
:G_BEHAVIOR_SUB
SET rndstart rndbase
ADD rndstart 4
AP_GET rndend behavior rndbase 1
SET index rndend

:3834	// LOOP_DONE?
IF index < rndstart THEN	// Nope
  RET 1
ENDIF
AP_GET temp behavior index
IF temp <> scold THEN
  SUB index 1
  GO 3834
ENDIF

WHILE index < rndend 
  AP_GET temp behavior index 1
  AP_SET temp behavior index
  ADD index 1
WEND

SUB rndend 1
AP_SET rndend behavior rndbase 1
RET 1



////////////////////////////////////////////////////////////////////
// BEHAVIOR_INIT  (Initialize a behavior array entry on demand)
:G_BEHAVIOR_INIT
AP_GET temp behavior rndbase
IF temp == rndcount THEN
  RET 1
ENDIF

AP_SET rndcount behavior rndbase
IF_1ST rndcount > 0 3848
MUL rndcount -1

:3848	// SETUP_HEADER
SET rndend rndbase
ADD rndend rndcount
ADD rndend rndcount
ADD rndend 3
AP_SET rndend behavior rndbase 1
SET index rndbase
ADD index 4
SET temp rndbase

WHILE index < rndend
  AP_SET temp behavior index 0
  AP_SET temp behavior index 1
  ADD index 2
  ADD temp 1
WEND
RET 1


////////////////////////////////////////////////////////////////////
// BEHAVIOR_PRAISE  (Increase probability on most recent two actions performed.)
:G_BEHAVIOR_PRAISE
AP_GET index behavior 16		// Index into lastnum table
AP_GET rndbase behavior index		// Get rndbase of last list
AP_GET praise behavior rndbase 2	// Get last index

// If a behavior has been used recently, update it...
IF rndbase >= 50 THEN
  CALL G_BEHAVIOR_INIT
  CALL G_BEHAVIOR_ADD
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// BEHAVIOR_SCOLD
:G_BEHAVIOR_SCOLD
AP_GET index behavior 16		// Index into lastnum table
AP_GET rndbase behavior index		// Get rndbase of last list
AP_GET scold behavior rndbase 2		// Get last index

// If a behavior has been used recently, update it...
IF rndbase >= 50 THEN
  CALL G_BEHAVIOR_INIT
  CALL G_BEHAVIOR_SUB
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// BEHAVIOR_BORED  (Adjust random probabilities if bored.  
// Interest in bad things goes up.  Good goes down.)
:G_BEHAVIOR_BORED
IF Fav_Color > 0 THEN
  CALL G_DEC_SAD_MOOD
ELSE
  IF Unfav_Color > 0 THEN
    CALL G_INC_SAD_MOOD
  ENDIF
  CALL G_DEC_HAPPY_MOOD
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// BEHAVIOR_RNDN
:G_BEHAVIOR_RNDN
CALL G_BEHAVIOR_RND
  CASE:2 RET 2	// invalid
CALL G_BEHAVIOR_DIFF
CALL G_BEHAVIOR_LOG
RET 1


////////////////////////////////////////////////////////////////////
// BEHAVIOR_RNDNM
:G_BEHAVIOR_RNDNM
CALL G_BEHAVIOR_RND
  CASE:2 RET 3	// invalid

AP_GET rndend behavior rndbase 1
AP_GET lastact1 behavior rndbase 2
AP_GET lastact2 behavior rndbase 3
RND temp 0 100
IF_1ST rndnum = lastact1 3878
IF_1ST rndnum = lastact2 3878

:3877	// BEHAVIOR_LOG
CALL G_BEHAVIOR_LOG
RET 2	// valid

:3878	// RANDOM1/3
IF_1ST temp < 33 3880
CALL G_BEHAVIOR_DIFF
GO 3877

:3880	// same
RET 1


////////////////////////////////////////////////////////////////////
// STAND_UP
:G_STAND_UP
CALL G_VOICE_HIT
WAIT 1

IF sitonly > 0 THEN
  RET:GO_IGNORE
ENDIF

IF_1ST Posture1 <> POSTURE_SIT 3890	// Not sitting
IF_1ST mood_tired > 5 3890	// Yup
IF_1ST mood_mad > 2 3890
CALL G_RANDOM2
  CASE:1 PLAY ACTION STAND
  CASE:2 PLAY ACTION+ stand_quick
WAIT
RET:GO_STANDPOS

:3890	// STAND_SLOW
PLAY ACTION STAND
WAIT
RET:GO_STANDPOS


////////////////////////////////////////////////////////////////////
// SIT_DOWN
:G_SIT_DOWN

RND rndnum 0 100
IF rndnum < 50 THEN
  PLAY ACTION SIT
ELSE
  PLAY ACTION+ sit_quick
ENDIF
WAIT


////////////////////////////////////////////////////////////////////
// INC_BOYGIRL
:G_INC_BOYGIRL
ADD boygirl 1
IF boygirl > 3 THEN
  SET boygirl 3
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// DEC_BOYGIRL
:G_DEC_BOYGIRL
SUB boygirl 1
IF boygirl < -3 THEN
  SET boygirl -3
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// SEE_BALL?
:G_SEE_BALL?
WAIT 1
IF sitonly > 0 THEN	// Ignor ball in sitonly mode
  RET:GO_IGNORE
ENDIF

IF Pink_Ball == 0 THEN	// Nope
  RET:GO_IDLE
ENDIF

CALL G_DEC_SAD_MOOD

IF_1ST soccer < 25
IF_AND endure < 10
IF_AND goforit <= 0 3908

IF_1ST soccer < 25
IF_AND goforit > 0 3907

IF_1ST soccer < 50
IF_AND goforit <= 0 3907

IF_1ST soccer < 50
IF_AND goforit > 0 3906

IF_1ST soccer < 75
IF_AND goforit <= 0 3906

IF_1ST mood_tired > 8 3910
IF_1ST mood_mad > 7 3910
RET:GO_SEEBALL

:3906	// IGNORE?(3)
IF_1ST mood_tired > 7 3910
IF_1ST mood_mad > 5 3910
RET:GO_SEEBALL

:3907	// IGNORE?(2)
IF_1ST mood_tired > 5 3910
IF_1ST mood_mad > 4 3910
RET:GO_SEEBALL

:3908	// IGNORE?
IF_1ST mood_tired > 3 3910
IF_1ST mood_mad > 2 3910
RET:GO_SEEBALL

:3910	// ignor
RET:GO_IGNORE


////////////////////////////////////////////////////////////////////
// WAITZERO
:G_WAITZERO
SET temp 0

:3934	// STALL
ADD temp 1
WAIT 100
IF_1ST Wait > 0
IF_AND temp < 50 3934	// 5 secs?
RET 1


////////////////////////////////////////////////////////////////////
// INC_ENDURE  (Increase endurance)
:G_INC_ENDURE
IF mood_tired > 5 THEN
  ADD ensure 1
  IF endure > 50 THEN
    SET endure 50
  ENDIF
  VSAVE endure
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// DEC_ENDURE
:G_DEC_ENDURE
IF mood_tired < 5 THEN
  SUB endure 1
  IF endure < 1 THEN
    SET endure 1
  ENDIF
  VSAVE endure
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// SHUDDER
:G_SHUDDER
IF_1ST mood_happy > 3
IF_AND mood_mad < 1 3953
RET 2	// shake

:3953	// RANDOM1/5
CALL G_RANDOM1/5
  CASE:2 RET 2	// shake
PLAY ACTION+ shudder
WAIT
RET 1


////////////////////////////////////////////////////////////////////
//
//  Process walk request if in sleep/sit/stand mode...
//
:G_WALK_REQUEST
CALL G_VOICE_HIT
IF_1ST sitonly > 0 3649
IF_1ST mood_tired > 8 3652
IF_1ST mood_tired <= 4 3654
IF_1ST mood_mad > 0 3652

IF mood_happy >= 3 THEN
  CALL G_INC_ENDURE
  RET 1	// walk
ENDIF

CALL G_RANDOM1/3
  CASE:2 RET 1	// walk

:3649	// RANDOM2
CALL G_RANDOM2
  CASE:1 PLAY ACTION NO1
  CASE:2 PLAY ACTION NO2
WAIT
RET 2	// nowalk

:3652	// MAD?
IF_1ST mood_mad <= 5 3649
CALL G_TANTRUM
RET 2	// nowalk

:3654	// walk
RET 1


////////////////////////////////////////////////////////////////////
//
//  Detect if we must be sit or sleep position...
//
:G_CHECK_STAYSIT
IF sitonly > 0 THEN
  CALL G_TWITCH_EARS
  SET init_wait Wait
  RND rndnum 1 4
  SWITCH rndnum
    CASE:1:PLAY:ACTION:NOTHANKS
    CASE:2:PLAY:ACTION:NOT_ME
    CASE:3:PLAY:ACTION:NOWAY1
    CASE:4:PLAY:ACTION:NOWAY2
  CALL G_WAIT
  RET:GO_IGNORE
ENDIF
RET:GO_IDLE


////////////////////////////////////////////////////////////////////
//
//  Detect if we must be sit or sleep position...
//
:G_CHECK_SITONLY
IF sitonly > 0 THEN
  RND rndnum 0 100
  IF rndnum < 50 THEN
    RET:GO_SITPOS
  ELSE
    RET:GO_DOWNPOS
  ENDIF
ENDIF
RET:GO_IDLE


////////////////////////////////////////////////////////////////////
//
//  Turn on the pause / sit-mode bar as required...
//
:G_UPDATE_PAUSEBAR
SET Warn sitonly
RET:1


////////////////////////////////////////////////////////////////////
//
//  Include the various primary submodules...
//
#include "Custom.R"
#include "Startup.R"
#include "Restmode.R"
#include "Station.R"
#include "Sleep.R"
#include "Sit.R"
#include "Stand.R"
#include "Walk.R"
#include "Table.R"
#include "RPS.R"

#ifdef AIBO310
#include "Soccer3.R"
#else
#include "Soccer2.R"
#endif

