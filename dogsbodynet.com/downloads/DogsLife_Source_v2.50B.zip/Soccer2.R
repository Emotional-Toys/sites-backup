
////////////////////////////////////////////////////////////////////
//                                                                //
//  DogsLife Soccer Module for ERS-210/220                        //
//  Copyright (C) 2001-2002 by DogsBody & Ratchet Software        //
//  All Rights Reserved                                           //
//                                                                //
//  This is free software and MAY NOT be sold under any           //
//  circumstances, seperately or bundled.                         //
//                                                                //
////////////////////////////////////////////////////////////////////


#define GO_S_NOBALL 2000
#define GO_S_TRACK 2001
#define GO_S_BALLCLOSE 2002
#define GO_S_TOUCHIT 2003
#define GO_S_KICKIT 2004
#define GO_S_KICKED 2005


////////////////////////////////////////////////////////////////////
//
//  Chase and kick ball until bored or we lose it...
//
:G_SOCCER
CALL G_CHECK_SITONLY
  CASE:GO_DOWNPOS RET:GO_DOWNPOS
  CASE:GO_SITPOS RET:GO_SITPOS

SET scale 10		// Distance scaling factor
PLAY ACTION TRACK_HEAD PINK_BALL
WAIT 500

SET lastmove -1		// 0=Left, 1=Right, 2=Fwd, 3=Back
SET kick_tilt 999	// Headtilt before last kick
SET kick_pan 999	// Headpan before last kick
SET miss_count 0	// # of consequtive misses

RND maxtime_tired 5 10
ADD maxtime_tired endure

IF Pink_Ball <= 0 THEN
  RET:GO_WALK
ENDIF

SET pan Head_Pan
SET tilt Head_Tilt

SET init_wait Wait
PLAY ACTION TUNE_SEEBALL
CALL G_WAIT
CALL G_STOP_HEAD

WAIT 1
IF Head_Pan <= 10 THEN
  IF Head_Pan >= -10 THEN
    IF Pink_Ball > 0 THEN
      STOP
      PLAY ACTION+ happy_eyes
      WAIT
      PLAY ACTION+ pounce
      WAIT
    ENDIF
  ENDIF
ENDIF

:2305	// SEE_BALL?(2)
WAIT 1
IF_1ST Pink_Ball > 0 2309

:2306	// SEARCH4BALL
CALL G_CHECK_SITONLY
  CASE:GO_DOWNPOS RET:GO_DOWNPOS
  CASE:GO_SITPOS RET:GO_SITPOS

CALL G_SOCCER_SEARCH4BALL
  CASE:2 GO 2305
  CASE:3 RET:GO_WALK

:2307	// TURN_AWAY
CALL G_TURN_AWAY
CALL G_INC_ENDURE
RET:GO_RESTPOS

:2309	// ATTENTION?
CALL G_WALK_ATTENTION_HANDLER
  CASE:1 GO 2320
  CASE:2 GO 2307
  CASE:3 GO 2311
  CASE:4 GO 2311
  CASE:6 RET:GO_STANDPOS
  CASE:7 GO 2306

:2310	// DEC_ENDURE(2)
CALL G_DEC_ENDURE
RET:GO_SITPOS

:2311	// START_TRACK
SET scale 10	// Distance scaling factor
PLAY ACTION TRACK_HEAD PINK_BALL
WAIT 1000
SET ballhint 0	// 1=left, 2=right

:2312	// SEE_BALL?(3)
WAIT 1
IF_1ST Pink_Ball <= 0 2306
CALL G_SOCCER_TRACK_BALL
  CASE:1 GO 2320
  CASE:2 GO 2307
  CASE:3 GO 2318
  CASE:4 GO 2315
  CASE:5 GO 2306
  CASE:7 GO 2310
  CASE:8 RET:GO_STANDPOS

:2314	// BALLABOVE
CALL G_SOCCER_BALLABOVE
  CASE:1 GO 2307
  CASE:2 RET:GO_WALK
GO 2312

:2315	// NEARBALL
WAIT 1
SET pan Head_Pan	// Save head position
SET tilt Head_Tilt	// prior to delay...
CALL G_SOCCER_KICK_BALL
  CASE:2 GO 2307
  CASE:3 GO 2306
  CASE:4 GO 2314
  CASE:GO_DOWNPOS  RET:GO_DOWNPOS
  CASE:GO_SITPOS   RET:GO_SITPOS
  CASE:GO_STANDPOS RET:GO_STANDPOS
  CASE:GO_WALK     RET:GO_WALK

:2317	// NEED2REST?
CALL G_NEED2REST
  CASE:1 GO 2307
GO 2305

:2318	// MOVEBACK
WAIT 1
SET init_wait Wait
PLAY ACTION+ mad_eyes
WAIT 200
PLAY ACTION WALK 180 150
SET lastmove 3	// lastmove=back
CALL G_WAIT_AWARE
GO 2317

:2320	// DEC_ENDURE
CALL G_DEC_ENDURE
RET:GO_DOWNPOS

:2321	// noball
RET:GO_WALK



////////////////////////////////////////////////////////////////////
//
//  Someone is holding the ball above our head...
//
:G_SOCCER_BALLABOVE
CALL G_NEED2REST
  CASE:1 RET 1	// rest
SET above_angle 0
SET last_teasedact -1
SET last_teasedact2 -1
SET actcount 0
RND tease 100 300	// 10-30 second timeout

:2329	// START_TRACK
CALL G_SOCCER_START_TRACK

:2330
WAIT 1
IF (Pink_Ball>0) THEN
  IF Head_Tilt>=above_angle 2333
  RET 3 // ball
ENDIF
RET 2 // noball

:2333	// START_TAIL
PLAY ACTION+ happy_eyes
PLAY ACTION TAILWAG_VERT2
RND impat 20 50	// 2-5 secs

:2334	// WAIT4BALL
CALL G_CHECK_SITONLY
  CASE:GO_DOWNPOS RET:2
  CASE:GO_SITPOS RET:2

WAIT 100
SUB tease 1
SUB impat 1
WAIT 1

IF (Head_Tilt>=above_angle) && Pink_Ball && tease 2342
IF Head_Tilt < above_angle 2341
IF Pink_Ball = 0 2341
IF tease > 0 2341

WAIT 1
SET init_wait Wait
PLAY ACTION PALONE.AUTO.TAILSTOP
PLAY ACTION MOVE_HEAD 0 0
CALL G_WAIT_AWARE

:2338	// TURN_AWAY
WAIT 1
SET init_wait Wait
RND angle 100 180	// Pick random turn.
RND temp 0 1		// Make random pos/neg.
MUL temp 2
MUL temp angle
SUB temp angle

IF Head_Pan > 0 THEN
  RND pan -20 0
ELSE
  RND pan 0 20
ENDIF

SET tilt Head_Tilt
PLAY ACTION MOVE_HEAD pan tilt
PLAY ACTION TURN 180
CALL G_INC_MAD_MOOD
CALL G_WAIT_AWARE
RET 2	// noball

:2341	// STOP_TAIL
WAIT 500
PLAY ACTION PALONE.AUTO.TAILSTOP
SET init_wait 1
GO 2330

:2342	// IMPATIENT?
IF_1ST impat > 0 2334
WAIT 1
SET pan Head_Pan
SET tilt Head_Tilt
SET above_angle 0	// Reset above angle...
CALL G_SOCCER_STOP_TRACK

:2345	// PICK_ACT
RND temp 0 25
IF_1ST temp = last_teasedact 2345
IF_1ST temp = last_teasedact2 2345
IF_1ST temp <= 8 2370
IF_1ST temp <= 21 2353
IF_1ST actcount < 2 2345
IF_1ST temp = 22 2352
IF_1ST temp = 23 2351
IF_1ST temp = 24 2350
CALL G_TANTRUM
SET mood_mad MOOD_MAX
SET mood_happy 0
GO 2338

:2350	// resign
PLAY ACTION RESIGNATION
WAIT
GO 2338

:2351	// so_sad
CALL G_INC_SAD_MOOD
PLAY ACTION NOD_STAND
WAIT
GO 2338

:2352	// frust
PLAY ACTION FRUSTRATED
WAIT
GO 2338

:2353	// SELECT_SITACT
SWITCH temp
  CASE:9 PLAY ACTION BEG_BALL
  CASE:10 PLAY ACTION NOBI4
  CASE:11 PLAY ACTION SIT
  CASE:12 PLAY ACTION CUTE_BANZAI1
  CASE:13 PLAY ACTION COMEON
  CASE:14 PLAY ACTION IMPATIENT_SIT1
  CASE:15 PLAY ACTION IMPATIENT_SIT2
  CASE:16 PLAY ACTION LOOKAROUND_SIT3
  CASE:17 PLAY ACTION SIGH
  CASE:18 PLAY ACTION YOUSILLY1
  CASE:19 PLAY ACTION YOUSILLY2
  CASE:20 PLAY ACTION YOUSILLY3
  CASE:ELSE PLAY ACTION YOUSILLY4
WAIT
SET last_teasedact2 last_teasedact
SET last_teasedact temp
SET above_angle -25	// Head level at -25 now
ADD actcount 1

:2356	// DEC_HAPPY_MOOD
CALL G_DEC_HAPPY_MOOD
PLAY ACTION MOVE_HEAD pan tilt
WAIT
GO 2329

:2370	// SELECT_STAND
SWITCH temp
  CASE:0 PLAY ACTION CUTE_SMILE1
  CASE:1 PLAY ACTION+ beg_leftpaw
  CASE:2 PLAY ACTION+ beg_rightpaw
  CASE:3 PLAY ACTION CUTE_BARK2
  CASE:4 PLAY ACTION LETSPLAY1
  CASE:5 PLAY ACTION LETSPLAY2
  CASE:6 PLAY ACTION LEANRIGHT
  CASE:7 PLAY ACTION WANTBALL
  CASE:ELSE PLAY ACTION TUNE_JAWS
WAIT
SET last_teasedact2 last_teasedact
SET last_teasedact temp
ADD actcount 1
GO 2356

:2383	// ball
RET 3



////////////////////////////////////////////////////////////////////
//
//  Estimate Distance to the Ball...
//
:G_SOCCER_DIST2BALL
IF Pink_Ball==0 THEN
  RET 1 // noball
ENDIF

WAIT 1
SET tilt Head_Tilt
IF_1ST Pink_Ball_Dist < PINK_BALL_NEAR 
IF_AND rcodeplus > 0 2402	// rcodeplus
IF_1ST Head_Tilt <= -60		// Ball in front
IF_AND Head_Pan > -20
IF_AND Head_Pan < 20 2402
IF_1ST Head_Tilt <= -65 2402	// Ball nearby
IF_1ST tilt >= 10 2401
IF_1ST tilt > 0 2400
IF_1ST tilt > -10 2399
IF_1ST tilt > -15 2398
IF_1ST tilt > -20 2397
IF_1ST tilt > -30 2396
IF_1ST tilt > -40 2395
IF_1ST tilt > -60 2394
SET d 20
ADD tilt 70
MUL tilt 3
ADD d tilt

:2389	// ADJUST_DIST
MUL d scale
DIV d 10
SUB d 20

IF d > 1000 THEN // max
  SET d 1000
ENDIF
IF d < 0 THEN // min
  SET d 0
ENDIF
RET 2	// balldist

:2394	// TILT60
SET d 50
ADD tilt 60
MUL tilt 6
ADD d tilt
GO 2389

:2395	// TILT40
SET d 170
ADD tilt 40
MUL tilt 9
ADD d tilt
GO 2389

:2396	// TILT30
SET d 260
ADD tilt 30
MUL tilt 12
ADD d tilt
GO 2389

:2397	// TILT20
SET d 380
ADD tilt 20
MUL tilt 20
ADD d tilt
GO 2389

:2398	// TILT15
SET d 480
ADD tilt 15
MUL tilt 62
ADD d tilt
GO 2389

:2399	// TILT10
SET d 800
GO 2389

:2400	// ABOVE
SET d 200
GO 2389

:2401	// ABOVE10
SET d 0
RET 3	// ballabove

:2402	// BALL
SET d 0
RET 4	// nearball


////////////////////////////////////////////////////////////////////
//
//  Try to infer where ball might have gone, based on last 
//  head track position...
//
:G_SOCCER_INFER_BALL
SET panr pan
SET panl pan
SET tiltd tilt
SET tiltu tilt
SUB panr 5
ADD panl 5
SUB tiltd 5
ADD tiltu 5
SET pan2 0

WAIT 1

// Maybe to the right?  
IF Head_Pan < panr THEN
  IF Head_Tilt > tilt THEN // Right-forward
    SET d 300
  ELSE
    SET d 0
  ENDIF
  CALL G_SOCCER_SEARCHTURN
    CASE:1 RET:GO_IDLE // noball
  RET GO_SEEBALL
ENDIF

// Maybe to the right?
IF Head_Pan > panl THEN
  IF Head_Tilt > tilt THEN // Left-forward
    SET d 300
  ELSE
    SET d 0
  ENDIF
  CALL G_SOCCER_SEARCHTURN
    CASE:1 RET:GO_IDLE // noball
  RET:GO_SEEBALL
ENDIF

// Maybe forward?
IF Head_Tilt > tiltu THEN
  SET d 300
  CALL G_SOCCER_SEARCHTURN
    CASE:1 RET:GO_IDLE // noball
  RET:GO_SEEBALL
ENDIF

IF Head_Tilt >= tiltd THEN
  RET:GO_IDLE
ENDIF

PLAY ACTION WALK 180 200
RET:GO_IDLE




////////////////////////////////////////////////////////////////////
//
//  Kick the ball...
//
:G_SOCCER_KICK_BALL
WAIT 1

// If no ball, try to infer where it went...
IF Pink_Ball == 0 THEN
  CALL G_SOCCER_INFER_BALL
    CASE:GO_SEEBALL RET:1
  RET 3
ENDIF

CALL G_SOCCER_DIST2BALL
  CASE:1 RET 3	// noball
  CASE:2 RET 1	// track
  CASE:3 RET 4	// ballabove
WAIT 1

// Check to see if can kick from walking posture...
IF (Posture1 == POSTURE_WALK) && (Head_Tilt<-70) THEN
  IF ((Head_Pan<-5) && (Head_Pan>-35)) || ((Head_Pan>5) && (Head_Pan<35)) THEN
    CALL G_SOCCER_OK_TO_KICK
      CASE:1 GO SKB_SMALLSTEP
      CASE:2 GO SKB_WALKPOSE_KICK
  ENDIF
ENDIF

// If not standing straight already...
IF Posture1 != POSTURE_STAND THEN 
  // Are we too close to the ball?
:SKB_TOOCLOSE_LOOP	
  WAIT 1
  IF Pink_Ball == 0 THEN
    RET 3 // noball
  ENDIF
  // Too close to the ball?
  IF Pink_Ball_Vert < 0 THEN
    IF Head_Tilt < -73 THEN
      IF Wait != 0 THEN
        WAIT 1
        SET init_wait Wait
        PLAY ACTION WALK 180 10	// Take a step backwards
        CALL G_WAIT_AWARE
        WAIT 500
        GO SKB_TOOCLOSE_LOOP
      ENDIF
    ENDIF
  ENDIF
  
  // Stand straight...
  WAIT 1
  SET init_wait Wait
  PLAY ACTION STOP_WALK
  CALL G_WAIT_AWARE
ENDIF

// Stop tracking the ball...
CALL G_SOCCER_STOP_TRACK

// Call customization routine...
CALL G_CUSTOM_SOCCER_KICK
  CASE:GO_DOWNPOS  RET:GO_DOWNPOS
  CASE:GO_SITPOS   RET:GO_SITPOS
  CASE:GO_STANDPOS RET:GO_STANDPOS
  CASE:GO_WALK     RET:GO_WALK

// Still close enough to kick?
CALL G_SOCCER_CLOSE_ENOUGH?
  CASE:GO_S_NOBALL RET 3	// noball
  CASE:GO_S_TRACK GO SKB_NOKICK

// Close enough...
CALL G_SOCCER_INIT_KICK

// 80% of time do a normal kick...
RND rndnum 0 100
IF rndnum < 80 THEN
  // If mad, only aibo kicks are performed.  Good mood needed to do something fancy.
  // This intentionally creates situations where Aibo misses & makes himself angrier.
  // Otherwise, 4/5ths of time do aibo kick (if ball in range)...
  CALL G_BEHAVIOR_RND
    CASE:2 RET 2	// no kick options available? 
  WAIT 1
  IF (Pink_Ball==0) SKB_SURPRISE	// Hey?!?
  IF (mood_mad>1) SKB_AIBOKICK
  IF (rndnum==rndbase) && (pan>=-35) && (pan<=35) && (tilt<=-65) SKB_AIBOKICK
ELSE
  // See if ball close enough to touch...
  CALL G_SOCCER_TOUCH_BALL
    CASE:GO_S_NOBALL GO SKB_SURPRISE
    CASE:GO_S_TRACK GO SKB_NOKICK
ENDIF

// Swing kick.  See if should touch it first...
CALL G_SOCCER_CHECK_SWING
  CASE:GO_S_TRACK GO SKB_NOKICK

CALL G_SOCCER_PLAY_SWING
  CASE:GO_S_KICKED GO SKB_WAIT4KICK

:SKB_NOKICK
SET pan 999
SET tilt 999

:SKB_RESUMETRACK
SET init_wait 1
PLAY ACTION TRACK_HEAD PINK_BALL

// Accelerate getting tired after kicking, since the 
// tired timer doesn't work here...
SUB maxtime_tired 3

:SKB_WAIT4KICK	
CALL G_WAIT_AWARE
SET kick_pan pan
SET kick_tilt tilt
RET 1	// track


:SKB_AIBOKICK
// Kick left?
IF (pan>=0) && (pan<=10) && (tilt<=-70) THEN
  PRINT KICKFWDL
  PLAY ACTION KICK LEFTFRONT
  SET ballhint 1	// 1=left, 2=right
  SET last_kick 3
  GO SKB_RESUMETRACK
ENDIF
// Kick right?
IF (pan>=-10) && (pan<=0) && (tilt<=-70) THEN
  PRINT KICKFWDR
  PLAY ACTION KICK RIGHTFRONT
  SET ballhint 2	// 1=left, 2=right
  SET last_kick 4
  GO SKB_RESUMETRACK
ENDIF

// Kick based on head position & hope for the best...
PRINT KICKLR
PLAY ACTION KICK pan tilt
SET last_kick 5
GO SKB_RESUMETRACK


// Kick ball from walking pose, but need small step to get 
// into a stable stance to avoid a face-plant...
:SKB_SMALLSTEP
WAIT 1
SET init_wait Wait
PLAY ACTION WALK 0 10
CALL G_WAIT_AWARE

// Kick ball from walking pose...
:SKB_WALKPOSE_KICK
WAIT 1
IF Head_Pan > 0 THEN // kick left
  PRINT KICKL
  SET pan Head_Pan
  SET tilt Head_Tilt
  PLAY ACTION KICK LEFTFRONT
  SET last_kick 1
ELSE
  PRINT KICKR
  SET pan Head_Pan
  SET tilt Head_Tilt
  PLAY ACTION KICK RIGHTFRONT
  SET last_kick 2
ENDIF
GO SKB_RESUMETRACK

:SKB_SURPRISE
CALL G_SURPRISE
RET 3	// noball



////////////////////////////////////////////////////////////////////
//
//  Update mood after kicking (or missing ball).  See if it 
//  moved and update...
//
:G_SOCCER_KICK_MOOD

// If no kick has occured, exit now...
IF kick_tilt >= 999 THEN
  IF kick_pan >= 999 THEN
    RET 2
  ENDIF
ENDIF

WAIT 1
SET pan Head_Pan	// Remember where head currently pointed.
SET tilt Head_Tilt
SUB kick_pan pan	// Compute movement.
SUB kick_tilt tilt

// If ball moved more than 15 degrees, get happy...
IF kick_pan > 15 SKM_KICKED_BALL
IF kick_pan < -15 SKM_KICKED_BALL
IF kick_tilt > 15 SKM_KICKED_BALL
IF kick_tilt < -15 SKM_KICKED_BALL

// Otherwise, not happy...
PRINT "MISSED_BALL"
ADD miss_count 1
SUB soccer 1
CALL G_INC_MAD_MOOD
CALL G_DEC_HAPPY_MOOD

// If getting mad, show our frustration...
RND rndnum 0 100
IF_1ST rndnum < 50
IF_AND mood_mad >= 4 SKM_FRUSTRATED

// Flash mad eye's...
WAIT 1
SET init_wait Wait
PLAY ACTION+ mad_eyes
CALL G_WAIT_AWARE

:SKM_DONE
SET kick_pan 999
SET kick_tilt 999
CALL G_SAVE_SOCCER
RET 1	// done

:SKM_FRUSTRATED
WAIT 1
SET init_wait Wait
PLAY ACTION FRUSTRATED
CALL G_WAIT_AWARE

// Look at ball & resume soccer play...
:SKM_LOOK2BALL	
WAIT 1
SET init_wait Wait
PLAY ACTION MOVE.HEAD.FAST pan tilt
CALL G_WAIT_AWARE
CALL G_SOCCER_START_TRACK
GO SKM_DONE

// Yea!  Kicked the ball!!!
:SKM_KICKED_BALL
PRINT KICKED_BALL
SET miss_count 0
ADD soccer 2
CALL G_INC_HAPPY_MOOD
CALL G_DEC_MAD_MOOD

// Occasionally do a happy dance...
RND rndnum 0 100
IF rndnum >= 75 THEN
  IF mood_happy >= 4 THEN
    IF mood_mad <= 0 THEN
      CALL G_HAPPYDANCE
      GO SKM_LOOK2BALL
    ENDIF
  ENDIF
ENDIF

WAIT 1
SET init_wait Wait
PLAY ACTION+ happy_eyes
CALL G_WAIT_AWARE
GO SKM_DONE




////////////////////////////////////////////////////////////////////
//
//  Look for the ball...
//
:G_SOCCER_LOOK4BALL
CALL G_SOCCER_STOP_TRACK
WAIT 1
SET init_wait Wait
PLAY ACTION MOVE_HEAD 0 -60

:2487	// SEE_BALL?
WAIT 1
IF_1ST Wait > init_wait
IF_AND Pink_Ball = 0 2487
IF_1ST Pink_Ball > 0 2494
IF_1ST searchmode = 0 2492
CALL G_RANDOM2
  CASE:1 GO 2491
PLAY ACTION SEARCH.HEAD.NORMALCENT PINK_BALL
SET t 1

:2490	// LOCKED_ON?
WAIT 1
IF_1ST Wait > 0
IF_AND Pink_Ball = 0 2490
IF_1ST Pink_Ball > 0 2494
RET 1	// noball

:2491	// search_fast
PLAY ACTION SEARCH.HEAD.FASTCENT PINK_BALL
GO 2490

:2492	// search_low
PLAY ACTION SEARCH.HEAD.LOWCENT PINK_BALL
GO 2490

:2494	// ball
RET 2


////////////////////////////////////////////////////////////////////
//
//  Move to ball, keeping an eye out for obstructions & cliff's...
//
:G_SOCCER_MOVE2BALL
PRINT "MOVE2BALL"

CALL G_SOCCER_DIST2BALL
  CASE:1 GO 2520
  CASE:3 RET 6	// ballabove
  CASE:4 RET 5	// nearball

WAIT 1
IF Wait == 0 THEN			// Resume tracking.
  PLAY ACTION TRACK_HEAD PINK_BALL
  WAIT 500
  GO G_SOCCER_MOVE2BALL
ENDIF

// If tracking not good, loop...
IF (Wait < 1) || (Pink_Ball==0) THEN
  WAIT 250
  GO G_SOCCER_MOVE2BALL
ENDIF

WAIT 1
SET dd d
RND temp 0 1				// Randomly decide to
MUL temp Head_Pan			// walk at an angle
SET lastmove 2				// towards ball...

RND rndnum 0 100
IF_1ST d < 200 2518			// If close, or normal
IF_1ST last_walkmode = 0 2518		//  walk used earlier...
IF_1ST last_walkmode = 1 2501		// If stalked before...
IF_1ST Posture1 <> POSTURE_STAND 2518	// If already walking,
IF_1ST rndnum < 80 2518			//  do normal walk.

:2501	// STALK1
SET last_walkmode 1
PLAY ACTION BALLSTALK temp d

:2502	// HEAD_POSITION
WAIT 1
SET tilt Head_Tilt
SET pan Head_Pan
CALL G_WALK_ATTENTION_HANDLER
  CASE:1 RET 2	// down
  CASE:2 RET 1	// rest
  CASE:5 RET 7	// sit
  CASE:6 RET 8	// stand
  CASE:7 RET 8	// stand
WAIT 1

IF Pink_Ball == 0 THEN
  WAIT 1
  SET init_wait Wait
  PLAY ACTION WALK 0 0
  CALL G_WAIT_AWARE
  WAIT 200
  RET 3	// noball
ENDIF

IF tilt >= 10 THEN
  RET 6 // ballabove
ENDIF

CALL G_SOCCER_NEAR2BALL?
  CASE:1 GO 2509
WAIT 1
SET init_wait Wait
PLAY ACTION WALK 0 0
CALL G_WAIT_AWARE

:2508	// PAN2BALL?
CALL G_SOCCER_PAN2BALL?
  CASE:1 GO G_SOCCER_MOVE2BALL
RET 5	// nearball

:2509	// WALKING?
WAIT 1
IF_1ST Wait <= 1 2508

// If looking straight & distance is too far, might be a cliff!
IF (Head_Tilt<-30) && (Head_Pan<30) && (Head_Pan>-30) && (Distance>CLIFFDIST) THEN
  WAIT 1
  SET init_wait Wait
  PLAY ACTION+ sad_eyes
  PLAY ACTION WALK 0 0
  CALL G_WAIT_AWARE

  // Once standing still, if still see cliff, exit...
  IF (Head_Tilt<-30) && (Head_Pan<30) && (Head_Pan>-30) && (Distance>CLIFFDIST) THEN
    RET 4
  ENDIF
  GO G_SOCCER_MOVE2BALL
ENDIF

WAIT 100
GO 2502


:2518	// WALK
SET last_walkmode 0
PLAY ACTION WALK temp d
GO 2502

:2520	// debug2
WAIT 200
RET 3	// noball



////////////////////////////////////////////////////////////////////
//
//  SOCCER NEAR2BALL?
//
:G_SOCCER_NEAR2BALL?
WAIT 1
IF_1ST Pink_Ball_Dist < PINK_BALL_NEAR
IF_AND rcodeplus > 0 2536
IF_1ST last_walkmode <> 1 2533
IF_1ST tilt <= -40	// Close enough while
IF_AND pan > -20	// stalking?
IF_AND pan < 20 2536
IF_1ST tilt <= -50 2536
RET 1	// no

:2533	// NEAR2BALL?(2)
IF_1ST tilt <= -60	// Close enough while
IF_AND mood_mad < 2	// walking normally?
IF_AND pan > -20
IF_AND pan < 20 2536
IF_1ST tilt <= -70 2536
IF_1ST tilt <= -50	// Need to turn?
IF_AND pan > 40 2537
IF_1ST tilt <= -50
IF_AND pan < -40 2537
RET 1

:2536	// yes
RET 2

:2537	// turn
RET 3


////////////////////////////////////////////////////////////////////
//
//  Check if ok to kick from walking position? (versas standing)...
//
:G_SOCCER_OK_TO_KICK
WAIT 1
SET mRFLeg_1 RFLeg_1
SET mRFLeg_2 RFLeg_2
SET mRFLeg_3 RFLeg_3
SET mLFLeg_1 LFLeg_1
SET mLFLeg_2 LFLeg_2
SET mLFLeg_3 LFLeg_3
SET mRRLeg_1 RRLeg_1
SET mRRLeg_2 RRLeg_2
SET mRRLeg_3 RRLeg_3
SET mLRLeg_1 LRLeg_1
SET mLRLeg_2 LRLeg_2
SET mLRLeg_3 LRLeg_3
DIV mRFLeg_1 8
DIV mRFLeg_2 8
DIV mRFLeg_3 8
DIV mLFLeg_1 8
DIV mLFLeg_2 8
DIV mLFLeg_3 8
DIV mRRLeg_1 8
DIV mRRLeg_2 8
DIV mRRLeg_3 8
DIV mLRLeg_1 8
DIV mLRLeg_2 8
DIV mLRLeg_3 8
IF_1ST mRFLeg_1 = -1 2578
IF_1ST mRFLeg_1 = 0 2578

:2542	// CROUCH?(1)
IF_1ST mRFLeg_2 = -1 2574
IF_1ST mRFLeg_2 = 0 2574

:2543	// OK?(1)
SWITCH mRFLeg_1
  CASE:1 GO 2567
  CASE:0 GO 2567

:2544	// OK?(11)
SWITCH mLFLeg_1
  CASE:1 GO 2560
  CASE:0 GO 2560

:2545	// NEEDSTEP?(1)
SWITCH mRFLeg_1
  CASE:2 GO 2554
  CASE:1 GO 2554

:2546	// NEEDSTEP?(11)
SWITCH mLFLeg_1
  CASE:2 GO 2548
  CASE:1 GO 2548
RET 3	// not_ok

:2548	// NEEDSTEP?(12)
SWITCH mLFLeg_2
  CASE:0 GO 2549
  CASE:1 GO 2549
RET 3	// not_ok

:2549	// NEEDSTEP?(13)
SWITCH mRFLeg_2
  CASE:1 GO 2550
  CASE:0 GO 2550
RET 3	// not_ok

:2550	// NEEDSTEP?(14)
SWITCH mRRLeg_3
  CASE:11 GO 2551
  CASE:10 GO 2551
RET 3	// not_ok

:2551	// NEEDSTEP?(15)
SWITCH mRFLeg_3
  CASE:5 GO 2552
  CASE:6 GO 2552
RET 3	// not_ok

:2552	// NEEDSTEP?(16)
IF_1ST mRRLeg_2 = 0
IF_AND mRRLeg_2 = 1 2553
RET 3	// not_ok

:2553	// NEEDSTEP?(18)
WAIT 1
IF_1ST mLFLeg_3 = 2
IF_AND mRFLeg_1 = -1
IF_AND mLRLeg_1 = -5
IF_AND mLRLeg_2 = 1
IF_AND mLRLeg_3 = 12
IF_AND mRRLeg_1 = -2
IF_AND Head_Pan < 0 2582
RET 3	// not_ok

:2554	// NEEDSTEP?(2)
SWITCH mRFLeg_2
  CASE:0 GO 2555
  CASE:1 GO 2555
GO 2546

:2555	// NEEDSTEP?(3)
SWITCH mLFLeg_2
  CASE:1 GO 2556
  CASE:0 GO 2556
GO 2546

:2556	// NEEDSTEP?(4)
SWITCH mLRLeg_3
  CASE:11 GO 2557
  CASE:10 GO 2557
GO 2546

:2557	// NEEDSTEP?(5)
SWITCH mLFLeg_3
  CASE:5 GO 2558
  CASE:6 GO 2558
GO 2546

:2558	// NEEDSTEP?(6)
IF_1ST mLRLeg_2 = 0
IF_AND mLRLeg_2 = 1 2559
GO 2546

:2559	// NEEDSTEP?(8)
WAIT 1
IF_1ST mRFLeg_3 = 2
IF_AND mLFLeg_1 = -1
IF_AND mRRLeg_1 = -5
IF_AND mRRLeg_2 = 1
IF_AND mRRLeg_3 = 12
IF_AND mLRLeg_1 = -2
IF_AND Head_Pan > 0 2582
GO 2546

:2560	// OK?(12)
SWITCH mRRLeg_2
  CASE:3 GO 2561
  CASE:2 GO 2561
GO 2545

:2561	// OK?(13)
IF_1ST mRFLeg_1 = -1 2562
IF_1ST mRFLeg_1 <> 0 2545

:2562	// OK?(14)
SWITCH mRRLeg_3
  CASE:11 GO 2563
  CASE:10 GO 2563
GO 2545

:2563	// OK?(15)
IF_1ST mLRLeg_1 = -4 2564
IF_1ST mLRLeg_1 <> -3 2545

:2564	// OK?(16)
SWITCH mRFLeg_2
  CASE:2 GO 2565
  CASE:1 GO 2565
GO 2545

:2565	// OK?(17)
SWITCH mRFLeg_3
  CASE:3 GO 2566
  CASE:2 GO 2566
GO 2545

:2566	// OK?(18)
WAIT 1
IF_1ST mLFLeg_2 = 0
IF_AND mLFLeg_3 = 2
IF_AND mLRLeg_2 = 0
IF_AND mLRLeg_3 = 12
IF_AND mRRLeg_1 = -6
IF_AND Head_Pan < 0 2583
GO 2545

:2567	// OK?(2)
SWITCH mLRLeg_2
  CASE:3 GO 2568
  CASE:2 GO 2568
GO 2544

:2568	// OK?(3)
IF_1ST mLFLeg_1 = -1 2569
IF_1ST mLFLeg_1 <> 0 2544

:2569	// OK?(4)
SWITCH mLRLeg_3
  CASE:11 GO 2570
  CASE:10 GO 2570
GO 2544

:2570	// OK?(5)
IF_1ST mRRLeg_1 = -4 2571
IF_1ST mRRLeg_1 <> -3 2544

:2571	// OK?(6)
SWITCH mLFLeg_2
  CASE:2 GO 2572
  CASE:1 GO 2572
GO 2544

:2572	// OK?(7)
SWITCH mLFLeg_3
  CASE:3 GO 2573
  CASE:2 GO 2573
GO 2544

:2573	// OK?(8)
WAIT 1
IF_1ST mRFLeg_2 = 0
IF_AND mRFLeg_3 = 2
IF_AND mRRLeg_2 = 0
IF_AND mRRLeg_3 = 12
IF_AND mLRLeg_1 = -6
IF_AND Head_Pan > 0 2583
GO 2544

:2574	// CROUCH?(2)
IF_1ST mLFLeg_2 = -1 2575
IF_1ST mLFLeg_2 <> 0 2543

:2575	// CROUCH?(3)
IF_1ST mRRLeg_1 = -2 2576
IF_1ST mRRLeg_1 <> -3 2543

:2576	// CROUCH?(4)
IF_1ST mLRLeg_1 = -2 2577
IF_1ST mLRLeg_1 <> -3 2543

:2577	// CROUCH?(5)
IF_1ST mRFLeg_1 = -3
IF_AND mRFLeg_3 = 8
IF_AND mLFLeg_1 = -3
IF_AND mLFLeg_3 = 8
IF_AND mRRLeg_2 = 0
IF_AND mRRLeg_3 = 9
IF_AND mLRLeg_2 = 0
IF_AND mLRLeg_3 = 9 2583
GO 2543

:2578	// STANDING?(2)
IF_1ST mLFLeg_1 = -1 2579
IF_1ST mLFLeg_1 <> 0 2542

:2579	// STANDING?(3)
SWITCH mRRLeg_3
  CASE:3 GO 2580
  CASE:2 GO 2580
GO 2542

:2580	// STANDING?(4)
SWITCH mLRLeg_3
  CASE:3 GO 2581
  CASE:2 GO 2581
GO 2542

:2581	// STANDING?(5)
IF_1ST mRFLeg_2 = 0
IF_AND mRFLeg_3 = 3
IF_AND mLFLeg_2 = 0
IF_AND mLFLeg_3 = 3
IF_AND mRRLeg_1 = 0
IF_AND mRRLeg_2 = 0
IF_AND mLRLeg_1 = 0
IF_AND mLRLeg_2 = 0 2583
GO 2542

:2582	// needstep
RET 1

:2583	// kick_ok
RET 2


////////////////////////////////////////////////////////////////////
//
//  Do we need to turn to the ball?
//
:G_SOCCER_PAN2BALL?
WAIT 1
IF_1ST miss_count >= 2 2591
IF_1ST Head_Pan > 39 2593
IF_1ST Head_Pan < -39 2593
IF_1ST Head_Pan > 34 2590
IF_1ST Head_Pan < -34 2590
IF_1ST Head_Pan = 34 2589
IF_1ST Head_Pan = -34 2589
IF_1ST Head_Pan = 33 2588
IF_1ST Head_Pan <> -33 2592

:2588	// PAN33
WAIT 1
IF Head_Tilt > -66 2593
RET 1	// noturn

:2589	// PAN34
WAIT 1
IF Head_Tilt > -71 2593
RET 1	// noturn

:2590	// PAN35
WAIT 1
IF Head_Tilt > -75 2593
RET 1	// noturn

:2591	// MISS_PAN?
WAIT 1
IF Head_Pan > 10 2593
IF Head_Pan < -10 2593

:2592	// noturn
RET 1

:2593	// turn
RET 2


////////////////////////////////////////////////////////////////////
//
//  Search for the ball (forward, move back, turn to sides, etc...)
//
:G_SOCCER_SEARCH4BALL
SET searchmode 1
SET searchmove 0	// Set if move while searching
CALL G_SOCCER_LOOK4BALL
  CASE:1 GO 2606

:2597	// NEED2REST?
CALL G_NEED2REST
  CASE:1 RET 1	// rest
CALL G_SEE_BALL?
  CASE:GO_IDLE GO 2600
  CASE:GO_SEEBALL RET 2	// ball
RET 1	// rest

:2600	// NOBALL
SET kick_tilt 999	// Clear kick track
SET kick_pan 999
CALL G_RANDOM3
  CASE:1 PLAY ACTION+ ummm
  CASE:2 PLAY ACTION OHWELL
  CASE:3 PLAY ACTION SAD8
WAIT
RET 3	// noball

:2606	// MOOD?
IF_1ST mood_mad > 0 2600
IF_1ST mood_happy > 3 2611

:2607	// RANDOM
RND rndnum 0 100
IF_1ST ballhint > 0 2609
IF_1ST rndnum < 33 2600	// Don't bother...
IF_1ST rndnum < 66 2611	// Turn left/right...
IF_1ST lastmove >= 3 2607	// Move back (if last

:2609	// MOVE_BACK
PLAY ACTION WALK 180 200
WAIT
SET lastmove 3	// back
SET kick_tilt 999	// Force kick success
SET searchmode 0
SET searchmove 1	// Moved.
CALL G_SOCCER_LOOK4BALL
  CASE:2 GO 2597

:2611	// HINT?
SWITCH ballhint
  CASE:1 GO 2621	// turn left first
  CASE:2 GO 2620	// turn right first
RND sign 0 1
MUL sign 2
SUB sign 1

:2613	// START_TURN
RND turn 90 150
MUL turn sign
SET pan turn
SET d 0
SET pan2 0
SET searchmode 1
SET kick_tilt 999	// Force kick success
SET searchmove 1
CALL G_SOCCER_SEARCHTURN
  CASE:2 GO 2597
IF_1ST mood_happy < 5 2619

:2616	// TURN180
SET pan 270
MUL pan sign
SUB pan turn
CALL G_SOCCER_SEARCHTURN
  CASE:2 GO 2597
CALL G_SOCCER_SEARCHTURN
  CASE:1 GO 2600
GO 2597

:2619	// RANDOM2
CALL G_RANDOM2
  CASE:1 GO 2600
GO 2616

:2620	// TURNR
SET sign -1
SET ballhint 0
GO 2613

:2621	// TURNL
SET sign 1
SET ballhint 0
GO 2613



////////////////////////////////////////////////////////////////////
//
//  Turn while also looking for ball...
//
:G_SOCCER_SEARCHTURN
RND rndnum 0 100
IF_1ST rndnum < 33 2644
PLAY ACTION TURN pan

:2629	// TURNING?
WAIT 1
IF_1ST Wait > 0
IF_AND Pink_Ball = 0 2629
IF_1ST Wait > 0
IF_AND Pink_Ball > 0 2637
IF_1ST d > 0 2639

:2631	// TURN2?
IF_1ST pan2 <> 0 2633

:2632	// LOOK4BALL
CALL G_SOCCER_LOOK4BALL
  CASE:1 RET 1	// noball
RET 2	// ball

:2633	// PICK(3)
RND rndnum 0 100
IF_1ST rndnum < 33 2638
PLAY ACTION TURN pan2

:2636	// TURNING(2)?
WAIT 1
IF_1ST Wait > 0
IF_AND Pink_Ball = 0 2636
IF_1ST Wait > 0
IF_AND Pink_Ball > 0 2637
GO 2632

:2637	// STOP_TURN
CALL G_SOCCER_STOP_TRACK
RET 2	// ball

:2638	// FAST_TURN(2)
PLAY ACTION MOVE.TURN.FAST pan2
GO 2636

:2639	// PICK(2)
RND rndnum 0 100
IF_1ST rndnum < 33 2643
PLAY ACTION WALK 0 d

:2642	// WALKING?
WAIT 1
IF_1ST Wait > 0
IF_AND Pink_Ball = 0 2642
IF_1ST Wait > 0
IF_AND Pink_Ball > 0 2637
IF_1ST Distance < 200 2637
GO 2631

:2643	// FAST_WALK
PLAY ACTION MOVE.MOVE.FAST 0 d
GO 2642

:2644	// FAST_TURN
PLAY ACTION MOVE.TURN.FAST pan
GO 2629


////////////////////////////////////////////////////////////////////
//
//  Start tracking ball, if not already...
//
:G_SOCCER_START_TRACK

:2648	// STALL
WAIT 100
WAIT 1
IF_1ST Wait = 0 2651	// Resume tracking.
IF_1ST Wait > 0
IF_AND Pink_Ball > 0 2652	// Tracking ok.  Move.
WAIT 1000
GO 2648

:2651	// TRACK_BALL
PLAY ACTION TRACK_HEAD PINK_BALL
WAIT 500

:2652	// RETURN
RET 1



////////////////////////////////////////////////////////////////////
//
//  Stop tracking the ball...
//
:G_SOCCER_STOP_TRACK
WAIT 1
IF Wait < 1 THEN
  WAIT 100
  RET 1
ENDIF

WAIT 500
IF Wait > 0 THEN
  STOP
  CALL G_WAITZERO
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
//
// SOCCER TRACK_BALL
//
:G_SOCCER_TRACK_BALL
SET last_walkmode -1	// 0=norm 1=stalk 2=turn
SET walking 2	// Soccer Mode
ADD soccer 1
VSAVE soccer

:2663	// NEED2REST?
CALL G_NEED2REST
  CASE:1 RET 2	// rest

CALL G_SOCCER_KICK_MOOD
IF_1ST mood_mad > 6 2677
CALL G_WALK_ATTENTION_HANDLER
  CASE:1 RET 1	// down
  CASE:2 RET 2	// rest
  CASE:5 RET 7	// sit
  CASE:6 RET 8	// stop
  CASE:7 RET 5	// stand
CALL G_SOCCER_TURN2BALL
  CASE:1 RET 2	// rest
  CASE:2 RET 1	// down
  CASE:3 RET 3	// noball
  CASE:5 RET 7	// sit
  CASE:6 RET 8	// stop
  CASE:7 RET 5	// stand
CALL G_WALK_ATTENTION_HANDLER
  CASE:1 RET 1	// down
  CASE:2 RET 2	// rest
  CASE:5 RET 7	// sit
  CASE:6 RET 8	// stop
  CASE:7 RET 5	// stand
CALL G_SOCCER_MOVE2BALL
  CASE:1 RET 2	// rest
  CASE:2 RET 1	// down
  CASE:3 RET 3	// noball
  CASE:4 GO 2674
  CASE:5 GO 2672
  CASE:7 RET 7	// sit
  CASE:8 RET 5	// stand
WAIT 500
CALL G_SOCCER_PAN2BALL?
  CASE:1 RET 6	// ballabove
GO 2663

:2672	// SETTLE
WAIT 500
CALL G_SOCCER_PAN2BALL?
  CASE:1 RET 4	// nearball
GO 2663

:2674	// STOP_TRACK
CALL G_SOCCER_STOP_TRACK
CALL G_WALK_FOUND_CLIFF
  CASE:1 RET 3	// noball
  CASE:2 RET 3	// noball
  CASE:3 RET 2	// rest
  CASE:4 GO 2663
  CASE:6 RET 7	// sit
  CASE:7 RET 5	// stand
RET 1

:2677	// rest
RET 2


////////////////////////////////////////////////////////////////////
//
//  Turn to ball & leave head pointing at it...
//
:G_SOCCER_TURN2BALL
CALL G_SOCCER_PAN2BALL?
  CASE:1 GO 2693
WAIT 1
IF_1ST Head_Pan > 0 2694
SET lastmove 1

:2688	// START_TRACK
CALL G_SOCCER_START_TRACK
WAIT 1
SET pan Head_Pan
SET init_turnwait Wait
SET last_walkmode 2	// Last move was turn
PLAY ACTION TURN pan

:2690	// ATTENTION?
CALL G_WALK_ATTENTION_HANDLER
  CASE:1 RET 2	// down
  CASE:2 RET 1	// rest
  CASE:3 RET 4	// ball
  CASE:5 RET 5	// sit
  CASE:6 RET 6	// stop
  CASE:7 RET 7	// stand
WAIT 1
IF_1ST Head_Pan < 10
IF_AND Head_Pan > -10 2692
IF_1ST Pink_Ball > 0
IF_AND Wait <= init_turnwait 2692
IF_1ST Wait <> 0 2690

:2692	// STOP_TURN
PLAY ACTION TURN 0
SET last_walkmode -1

:2693	// SEE_BALL?
WAIT 1
IF_1ST Pink_Ball > 0 2698
RET 3	// noball

:2694	// LEFT
SET lastmove 0
GO 2688

:2698	// ball
RET 4



////////////////////////////////////////////////////////////////////
//
//  Determine if we are close enough to ball for a kick...
//
:G_SOCCER_CLOSE_ENOUGH?
WAIT 1
IF Pink_Ball == 0 THEN
  RET:GO_S_NOBALL // noball
ENDIF

IF_1ST Head_Pan > 39 SCE_TRACK
IF_1ST Head_Pan < -39 SCE_TRACK
IF_1ST Head_Tilt > -60 SCE_TRACK

IF_1ST Head_Pan > 34 SCE_PAN35
IF_1ST Head_Pan < -34 SCE_PAN35

IF_1ST Head_Pan = 34 SCE_PAN34
IF_1ST Head_Pan = -34 SCE_PAN34

IF_1ST Head_Pan = 33 SCE_PAN33
IF_1ST Head_Pan = -33 SCE_PAN33
RET:GO_S_BALLCLOSE

:SCE_PAN33
IF_1ST Head_Tilt > -66 SCE_TRACK
RET:GO_S_BALLCLOSE

:SCE_PAN34
IF_1ST Head_Tilt > -71 SCE_TRACK
RET:GO_S_BALLCLOSE

:SCE_PAN35
IF_1ST Head_Tilt > -70 SCE_TRACK
RET:GO_S_BALLCLOSE

:SCE_TRACK
RET:GO_S_TRACK



////////////////////////////////////////////////////////////////////
//
//  Pick a soccer skit based on the ball's position.  The 'ballhint'
//  variable gives a heads-up to the soccer search routine (after all,
//  if you kick left, one might assume the ball would go that way)...
//
:G_SOCCER_CHECK_SWING
SET swing_kick 0

// Belly flop kick forward (zone 1)...
IF (pan>=-30) && (pan<-18) && (tilt>=-70) && (tilt<-60) THEN
  PRINT BELLYFWD
  SET swing_kick 6
  RET:GO_S_KICKIT
ENDIF

// Belly flop kick forward (zone 2)...
IF (pan<=30) && (pan>18) && (tilt>=-70) && (tilt<-60) THEN
  PRINT BELLYFWD
  SET swing_kick 6
  RET:GO_S_KICKIT
ENDIF

// Belly flop kick to right (zone 1)...
IF (pan<-34) && (tilt<-70) THEN
  PRINT BELLYR
  SET swing_kick 7
  RET:GO_S_KICKIT
ENDIF

// Belly flop kick to right (zone 2)...
IF (pan<-18) && (tilt>=-70) && (tilt<-60) THEN
  PRINT BELLYR
  SET swing_kick 7
  RET:GO_S_KICKIT
ENDIF

// Belly flop kick to left (zone 1)...
IF (pan>34) && (tilt<-70) THEN
  PRINT BELLYL
  SET swing_kick 8
  RET:GO_S_KICKIT
ENDIF

// Belly flop kick to left (zone 2)...
IF (pan>18) && (tilt>=-70) && (tilt<-60) THEN
  PRINT BELLYL
  SET swing_kick 8
  RET:GO_S_KICKIT
ENDIF

// Side kick to right...
IF (pan<-25) && (tilt<-70) THEN
  PRINT SIDER
  SET swing_kick 9
  RET:GO_S_KICKIT
ENDIF

// Side kick to left...
IF (pan>25) && (tilt<-70) THEN
  PRINT SIDEL
  SET swing_kick 10
  RET:GO_S_KICKIT
ENDIF

// Big kick to right...
IF (pan<-18) && (tilt<-70) THEN
  PRINT SWINGR
  SET swing_kick 11
  RET:GO_S_KICKIT
ENDIF

// Big kick to left...
IF (pan>18) && (tilt<-70) THEN
  PRINT SWINGL
  SET swing_kick 12
  RET:GO_S_KICKIT
ENDIF

// Header to the right...
IF (pan<-5) && (pan>=-18) && (tilt<-65) THEN
  PRINT HEAD_R
  SET swing_kick 13
  RET:GO_S_KICKIT
ENDIF

// Header to the left...
IF (pan>5) && (pan<=18) && (tilt<-65) THEN
  PRINT HEAD_L
  SET swing_kick 14
  RET:GO_S_KICKIT
ENDIF

// Ball in front, but too close for straight header...
IF (pan>=-5) && (pan<=5) && (tilt<-73) THEN 
  PRINT HEAD_L
  SET swing_kick 14
  RET:GO_S_KICKIT
ENDIF

// Header straight...
IF (pan>=-5) && (pan<=5) && (tilt>=-73) THEN
  PRINT HEADFWD
  SET swing_kick 15
  RET:GO_S_KICKIT
ENDIF

// Not in range of swing kick...
RET:GO_S_TRACK



////////////////////////////////////////////////////////////////////
//
//  Do a soccer skit based on the ball's position.  The 'ballhint'
//  variable gives a heads-up to the soccer search routine (after all,
//  if you kick left, one might assume the ball would go that way)...
//
:G_SOCCER_PLAY_SWING
SET init_wait 0

PRINT:"swing_kick = %d":swing_kick

SWITCH swing_kick 
  CASE 6 : PLAY ACTION+ kick_bellyflop_fwd
  CASE 7 : PLAY ACTION+ kick_bellyflop_right
  CASE 8 : PLAY ACTION+ kick_bellyflop_left
  CASE 9  : PLAY ACTION+ aibostand_sidekick_right
  CASE 10 : PLAY ACTION+ aibostand_sidekick_left
  CASE 11 : PLAY ACTION+ aibostand_bigkick_right
  CASE 12 : PLAY ACTION+ aibostand_bigkick_left
  CASE 13 : PLAY ACTION CONTACT.FRONT.HEADR
  CASE 14 : PLAY ACTION CONTACT.FRONT.HEADL
  CASE 15 : PLAY ACTION CONTACT.FRONT.HEAD
  CASE:ELSE RET:GO_S_TRACK

SET last_kick swing_kick

SWITCH swing_kick 
  CASE 7 : SET ballhint 2 // right
  CASE 8 : SET ballhint 1 // left 
  CASE 9  : SET ballhint 2 // right
  CASE 10 : SET ballhint 1 // left
  CASE 11 : SET ballhint 2 // right
  CASE 12 : SET ballhint 1 // left
  CASE 13 : SET ballhint 2 // right
  CASE 14 : SET ballhint 1 // left

RET:GO_S_KICKED



////////////////////////////////////////////////////////////////////
//
//  If ball properly positioned, touch it carefully, then 
//  setup to whallop it...
//
:G_SOCCER_TOUCH_BALL

// Ball missing?
WAIT 1
IF Pink_Ball = 0 THEN
  RET:GO_S_NOBALL 
ENDIF

// Touch ball?
IF (Head_Tilt<=-69) && (Head_Tilt>=-73) THEN
  // to the left?
  IF (Head_Pan>=9) && (Head_Pan<=17) THEN
    PLAY ACTION+ aibostand_touchball_left
    GO STB_LOOKATBALL
  ENDIF

  // to the right?
  IF (Head_Pan<=-9) && (Head_Pan>=-17) THEN
    PLAY ACTION+ aibostand_touchball_right
    GO STB_LOOKATBALL
  ENDIF
ENDIF

RET:GO_S_KICKIT	

// Look back at ball & decide if close enough to kick...
:STB_LOOKATBALL	
WAIT
PLAY ACTION MOVE.HEAD.FAST pan tilt
WAIT
PLAY ACTION TRACK_HEAD PINK_BALL
WAIT 1000
CALL G_SOCCER_STOP_TRACK
GO G_SOCCER_CLOSE_ENOUGH?



////////////////////////////////////////////////////////////////////
//
//  Initialize the kick behavior tracking information...
//
:G_SOCCER_INIT_KICK
WAIT 1
SET pan Head_Pan
SET tilt Head_Tilt
SET rndbase 1800
SET rndcount 2
AP_GET temp behavior rndbase

// Exit if initialized already...
IF temp == rndcount THEN
  RET 1
ENDIF

// Need to initialize kick behavior.  Skew init so that kicks
// are initially favored 5 to 1 (instead of 1 to 1).
CALL G_BEHAVIOR_INIT
SET index rndbase
ADD index 1
ADD rndend 1
AP_SET rndbase behavior rndend
ADD rndend 1
AP_SET rndbase behavior rndend
ADD rndend 1
AP_SET rndbase behavior rndend
ADD rndend 1
AP_SET rndbase behavior rndend
AP_SET rndend behavior index
RET 1



////////////////////////////////////////////////////////////////////
//
//  Save soccer skill to memstick...
//
:G_SAVE_SOCCER
IF soccer < 1 THEN
  SET soccer 1
ENDIF
IF soccer > 100 THEN
  SET soccer 100
ENDIF
VSAVE soccer
RET 1



////////////////////////////////////////////////////////////////////
//
//  TURN_AWAY
//
:G_TURN_AWAY
WAIT 1

SET dir -1
IF Head_Pan > 10 THEN	// Go left if looking left...
  SET dir 1
ENDIF

IF Head_Pan >= -10 THEN	// If looking straight, go left or right...
  CALL G_RANDOM2
    CASE:1 SET dir 1
    CASE:2 SET dir -1
ENDIF

// Start turn...
RND p 150 180
MUL p dir

CALL G_SOCCER_STOP_TRACK

SET init_wait Wait
PLAY ACTION TURN p
PLAY ACTION MOVE_HEAD 0 0
CALL G_WAIT_AWARE
RET 1


