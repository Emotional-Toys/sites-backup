
////////////////////////////////////////////////////////////////////
//                                                                //
//  DogsLife Sit Position Behavior Module                         //
//  Copyright (C) 2001-2002 by DogsBody & Ratchet Software        //
//  All Rights Reserved                                           //
//                                                                //
//  This is free software and MAY NOT be sold under any           //
//  circumstances, seperately or bundled.                         //
//                                                                //
////////////////////////////////////////////////////////////////////


//
//  Behavior when sitting...
//
:G_SITPOS
CALL G_INIT_SITPOS

:SIT_LOOP	// INIT_TIMERS
CALL G_UPDATE_PAUSEBAR
SET Clock 0
RND maxtime1 3 10	// 3 to 10 seconds
RND maxtime2 0 2	// 0 to 2 seconds
RND maxtime3 5 10	// 5 to 10 seconds
SET tailwag 0
SET tilt Head_Tilt
SET pan Head_Pan
IF_1ST mood_happy > 3 1929

:1895	// NEED2REST?
CALL G_NEED2REST
  CASE:1 GO 1928
WAIT 50
CALL G_REST_TIMER
CALL G_SEE_BALL?
  CASE:GO_IDLE GO 1900
  CASE:GO_IGNORE GO 1900

CALL G_STAND4BALL
  CASE:2 RET:GO_SEEBALL
  CASE:3 RET:GO_STANDPOS
  CASE:4 RET:GO_RESTPOS

:1900	// ATTENTION?
CALL G_SIT_ATTENTION
  CASE:1 GO 1927
  CASE:2 GO 1926
  CASE:3 GO 1925
  CASE:4 GO 1922

// Call voice command customization routine...
IF sitonly > 0 THEN
  CALL G_CUSTOM_SIT_VOICECMD
    CASE:GO_DOWNPOS  RET:GO_DOWNPOS
    CASE:GO_STANDPOS GO 1902
    CASE:GO_WALK     GO 1902
    CASE:GO_SEEBALL  GO 1902
    CASE:GO_IGNORE   GO 1902
ELSE
  CALL G_CUSTOM_SIT_VOICECMD
    CASE:GO_DOWNPOS  RET:GO_DOWNPOS
    CASE:GO_STANDPOS RET:GO_STANDPOS
    CASE:GO_WALK     RET:GO_WALK
    CASE:GO_SEEBALL  RET:GO_SEEBALL
    CASE:GO_IGNORE   GO 1902
ENDIF

// If not overridden, do normal voice command processing...
CALL G_SIT_VOICE_HANDLER
  CASE:1 GO 1903
  CASE:3 RET:GO_WALK
  CASE:4 RET:GO_DOWNPOS
  CASE:5 RET:GO_SEEBALL
  CASE:6 RET:GO_STANDPOS
  CASE:7 RET:GO_RESTPOS

:1902	// loop
ADD change_thres 2
GO SIT_LOOP

:1903	// NOSE_SENSE?
CALL G_SIT_NOSE_SENSE
CALL G_BORED_TIMER
  CASE:1 GO 1895

// Go process pending voice command...
IF_1ST AP_Voice_Cmd > 0 
IF_AND AP_Voice_Level >= 2 1900

// Should we go walking?  10% of the time, yes (if not too tired)...
RND rndnum 0 100
IF (sitonly == 0) && (rndnum<=10) && (mood_tired<=5) && (bored_count<1) THEN
  RET:GO_WALK
ENDIF

IF rndnum <= 10 THEN
  SET sleepsit 1
  RET:GO_DOWNPOS
ENDIF

IF rndnum < change_thres THEN
  CALL G_SIT_CHANGEPOS
  ADD change_thres 2
  GO SIT_LOOP
ENDIF

IF rndnum < 90 THEN
  RND rndnum 0 100

  // If upset, cry...
  IF (mood_sad>5) && (rndnum<(mood_sad-5)*10) THEN
    CALL:G_SAD
    GO SIT_LOOP
  ENDIF

  // Bored skit?
  IF (rndnum>33) && (bored_count<3) THEN 
    CALL G_SIT_BORED
    CALL G_BEHAVIOR_BORED
    ADD change_thres 2
    GO SIT_LOOP
  ENDIF

  // Happy skit?
  IF (rndnum>66) && (bored_count>=3) && (mood_happy>5) THEN 
    CALL G_SIT_HAPPY
    ADD change_thres 2
    GO SIT_LOOP
  ENDIF

  // Tailsong skit?
  IF (rndnum>66) && (bored_count>=3) && (mood_happy>2) THEN 
    CALL G_SIT_TAILSONG
    ADD change_thres 2
    GO SIT_LOOP
  ENDIF
ENDIF

CALL G_SIT_CALM
ADD change_thres 2
GO SIT_LOOP

:1922	// SCOLD
CALL G_SCOLD_REST

:1923	// RESET_BORED
RND bored_count 5 10
CALL G_CLEAR_SENSORS
ADD change_thres 2
GO SIT_LOOP

:1925	// SIT_PETTED
CALL G_SIT_PETTED
GO 1923

:1926	// PRAISE
CALL G_PRAISE_REST
GO 1923

:1927	// LOOK_TIMER
CALL G_LOOK_TIMER
GO 1903

:1928	// STOP_TAILWAG1
CALL G_STOP_TAILWAG
RET:GO_RESTPOS

:1929	// START_TAILWAG
PLAY ACTION TAILWAG_VERT1
SET tailwag 1
GO 1895



////////////////////////////////////////////////////////////////////
// INIT_SITPOS
:G_INIT_SITPOS
WAIT 1
PRINT SITPOS
SET sitstate 0	// 0=pos,1=wide,2=flat
SET change_thres 40	// Change threshold
SET nosecount 0	// # of nose triggers
SET back_count 0	// # b2b back pets
SET init_wait Wait
PLAY ACTION SIT
SET tilt -25
SET pan 0
CALL G_WAIT
CALL G_CLEAR_SENSORS
IF_1ST sleepsit > 0
IF_AND bored_count < 3 1238
IF_1ST sleepsit > 0 1237
RND bored_count 3 10

:1237	// DONE
SET sleepsit 0
RET 1

:1238	// SLEEP2SIT
RND bored_count 3 5
SET sleepsit 0
RET 1


////////////////////////////////////////////////////////////////////
// SIT_ATTENTION
:G_SIT_ATTENTION
CALL G_ATTENTION_HANDLER
  CASE:2 RET 2	// praise
  CASE:3 RET 3	// pet
  CASE:4 RET 4	// scold
  CASE:5 RET 5	// voice

CALL G_TAIL_TWEAKED
  CASE:2 RET 2	// praise
  CASE:3 RET 4	// scold
  CASE:4 RET 5	// voice

IF sitstate != 0 THEN	// Rear feet not on floor
  WAIT 1
  IF RRLeg_3 < 30 THEN
    IF RRLeg_ON > 0 THEN
      ADD pet 32
      SET RRLeg_ON 0
      SET back_count 0
    ENDIF
  ENDIF

  IF LRLeg_3 < 30 THEN
    IF LRLeg_ON > 0 THEN
      ADD pet 64
      SET LRLeg_ON 0
      SET back_count 0
    ENDIF
  ENDIF
ENDIF

IF pet == 0 THEN
  RET 1 // none
ENDIF
RET 3	// pet



////////////////////////////////////////////////////////////////////
// SIT_BORED
:G_SIT_BORED

:1580	// SITSTATE?
IF_1ST sitstate = 0 1589	// SitPos
SET rndbase 1150
SET rndcount 3
SET lastact1 last_boredact
SET lastact2 last_boredact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1588
  CASE:3 RET 1
SWITCH rndnum
  CASE:1150 PLAY ACTION BORED_SIT1
  CASE:1151 PLAY ACTION HOWL_SIT1
  CASE:ELSE PLAY ACTION HOWL_SIT2
SET last_boredact rndnum
WAIT
PLAY ACTION SIT
WAIT
SET sitstate 0
RET 1

:1588	// SIT_PICKPOS
CALL G_SIT_PICKPOS
GO 1580

:1589	// SITPOS
SET rndbase 1100
SET rndcount 12
SET lastact1 last_boredact
SET lastact2 last_boredact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1588
  CASE:3 RET 1
IF_1ST rndnum = 1100
IF_AND mood_tired < 9 1605
SWITCH rndnum
  CASE:1101 PLAY ACTION BORED_SIT2
  CASE:1102 PLAY ACTION BORED_SIT3
  CASE:1103 PLAY ACTION BEG_PET1
  CASE:1104 PLAY ACTION IMPATIENT_SIT1
  CASE:1105 PLAY ACTION IMPATIENT_SIT2
  CASE:1106 PLAY ACTION NOBI4
  CASE:1107 PLAY ACTION ANYONE_THERE5
  CASE:1108 PLAY ACTION SIGH
  CASE:1109 PLAY ACTION WANT_ATTENTION_SIT1
  CASE:1110 PLAY ACTION WANT_ATTENTION_SIT2
  CASE:ELSE PLAY ACTION COMEON

:1594	// WAIT_POS
SET last_boredact rndnum
SET sitstate 0
WAIT
RET 1

:1605	// beg_ball
IF_1ST sitonly > 0 1589	// no begging in sitonly mode
PLAY ACTION BEG_BALL
GO 1594


////////////////////////////////////////////////////////////////////
// SIT_CALM
:G_SIT_CALM

:1608	// SITSTATE?
SWITCH sitstate
  CASE:0 GO 1633	// SitPos
  CASE:1 GO 1620	// SitPos
SET rndbase 1400
SET rndcount 4
SET lastact1 last_calmact
SET lastact2 last_calmact2
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1619
  CASE:2 GO 1612
RET 1

:1612	// SELECT_FLAT
SWITCH rndnum
  CASE:1400 PLAY ACTION EXERCISE5
  CASE:1401 PLAY ACTION EXERCISE6
  CASE:1402 PLAY ACTION EXERCISE7
  CASE:ELSE PLAY ACTION EXERCISE8
GO 1634

:1619	// SIT_PICKPOS(2)
CALL G_SIT_PICKPOS
GO 1608

:1620	// SITWIDE
SET rndbase 1350
SET rndcount 9
SET lastact1 last_calmact
SET lastact2 last_calmact2
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1619
  CASE:3 RET 1

SWITCH rndnum
  CASE:1350 PLAY ACTION LOOKAROUND_SIT1
  CASE:1351 PLAY ACTION STRETCH1
  CASE:1352 PLAY ACTION SCRATCH_LEFTEAR
  CASE:1353 PLAY ACTION STRETCH2
  CASE:1354 PLAY ACTION SCRATCH_RIGHTEAR1
  CASE:1355 PLAY ACTION TAP_RIGHT
  CASE:1356 PLAY ACTION HICCUPS_SIT1
  CASE:1357 PLAY ACTION TAP_LEFT
  CASE:ELSE PLAY ACTION HICCUPS_SIT2
GO 1634

:1633	// SITPOS
SET rndbase 1300
SET rndcount 19
SET lastact1 last_calmact
SET lastact2 last_calmact2
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1619
  CASE:3 RET 1

SWITCH rndnum
  CASE:1300 PLAY ACTION CLEANPAW
  CASE:1301 PLAY ACTION LOOKBACK1
  CASE:1302 PLAY ACTION LOOKBACK2
  CASE:1303 PLAY ACTION LOOKAROUND_SIT2
  CASE:1304 PLAY ACTION LOOKAROUND_SIT3
  CASE:1305 PLAY ACTION SWATFLY
  CASE:1306 PLAY ACTION SCRATCH_RIGHTEAR2
  CASE:1307 PLAY ACTION SCRATCH_RIGHTEAR3
  CASE:1308 PLAY ACTION SCRATCH_LEFTEAR1
  CASE:1309 PLAY ACTION LOOKUP1
  CASE:1310 PLAY ACTION LOOKUP2
  CASE:1311 PLAY ACTION SCRATCH_MOUTH
  CASE:1312 PLAY ACTION SCRATCH_RIGHTCHEEK
  CASE:1313 PLAY ACTION+ piano
  CASE:1314 PLAY ACTION+ beethoven5
  CASE:1315 PLAY ACTION+ scratch_rearend
  CASE:1316 PLAY ACTION+ typing2
  CASE:1317 GO 1638
  CASE:ELSE GO 1637

:1634
WAIT
SET last_calmact2 last_calmact
SET last_calmact rndnum
RET 1

:1637
IF_1ST Batt_Rest < 50 1633
PLAY ACTION+ driving0
WAIT
PLAY ACTION+ driving1
GO 1634

:1638	// TYPING
PLAY ACTION+ typing
WAIT
PLAY ACTION+ sigh
WAIT
PLAY ACTION+ answer_phone
GO 1634


////////////////////////////////////////////////////////////////////
// SIT_CHANGEPOS  (Change into new sitting leg position)
:G_SIT_CHANGEPOS
CALL G_SIT_PICKPOS
SWITCH sitstate
  CASE:0 PLAY ACTION SIT
  CASE:1 PLAY ACTION SITWIDE
  CASE:ELSE PLAY ACTION SITFLAT
SET change_thres 15
WAIT
CALL G_CLEAR_SENSORS
RET 1


////////////////////////////////////////////////////////////////////
//
//  Do a dance while sitting...
//
:G_SIT_DANCE

// If not in normal sit position...
IF sitstate > 0 THEN
  SET rndbase 1550
  SET rndcount 4
  SET lastact1 last_danceact
  SET lastact2 last_danceact
  CALL G_BEHAVIOR_RNDNM
    CASE:1 GO 1674
    CASE:3 RET 1
  SWITCH rndnum
    CASE:1550 PLAY ACTION DANCE_SIT7
    CASE:1551 PLAY ACTION DANCE_SIT8
    CASE:1552 PLAY ACTION DANCE_SIT9
    CASE:ELSE PLAY ACTION DANCE_SIT10
  SET last_danceact rndnum
  WAIT
  RET 1
ENDIF

// Normal sit position dance code...
SET rndbase 1500
SET rndcount 6
SET lastact1 last_danceact
SET lastact2 last_danceact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1674
  CASE:3 RET 1
SWITCH rndnum
  CASE:1500 PLAY ACTION DANCE_SIT1
  CASE:1501 PLAY ACTION DANCE_SIT2
  CASE:1502 PLAY ACTION DANCE_SIT3
  CASE:1503 PLAY ACTION DANCE_SIT4
  CASE:1504 PLAY ACTION DANCE_SIT5
  CASE:ELSE PLAY ACTION DANCE_SIT6
SET last_danceact rndnum
WAIT
RET 1

:1674	// SIT_PICKPOS
CALL G_SIT_PICKPOS
GO G_SIT_DANCE



////////////////////////////////////////////////////////////////////
//
//  Do something happy while sitting...
//
:G_SIT_HAPPY

// If not in normal sit position...
IF sitstate > 0 THEN
  SET rndbase 1250
  SET rndcount 7
  SET lastact1 last_happyact
  SET lastact2 last_happyact
  CALL G_BEHAVIOR_RNDNM
    CASE:1 GO 1698
    CASE:3 RET 1
  
  SWITCH rndnum
    CASE:1250 PLAY ACTION CUTE_JOY1
    CASE:1251 PLAY ACTION CUTE_JOY2
    CASE:1252 PLAY ACTION DANCE_SIT7
    CASE:1253 PLAY ACTION DANCE_SIT8
    CASE:1254 PLAY ACTION DANCE_SIT9
    CASE:1255 PLAY ACTION DANCE_SIT10
    CASE:ELSE PLAY ACTION DANCE_SIT11

  SET last_happyact rndnum
  WAIT
  RET 1
ENDIF

// Normal sit position happy code...
SET rndbase 1200
SET rndcount 14
SET lastact1 last_happyact
SET lastact2 last_happyact
CALL G_BEHAVIOR_RNDNM
  CASE:1 GO 1698
  CASE:3 RET 1

IF rndnum == 1200 THEN
  PLAY ACTION+ dial_phone
  WAIT
  PLAY ACTION+ dial_phone2
ENDIF

// Some things boy bots don't like doing...
IF BOYBOT THEN
  IF rndnum == 1201 G_SIT_HAPPY
  IF rndnum == 1202 G_SIT_HAPPY 
ENDIF

SWITCH rndnum
  CASE:1201 PLAY ACTION KISS1
  CASE:1202 PLAY ACTION KISS2
  CASE:1203 PLAY ACTION DANCE_SIT1
  CASE:1204 PLAY ACTION DANCE_SIT2
  CASE:1205 PLAY ACTION DANCE_SIT3
  CASE:1206 PLAY ACTION DANCE_SIT4
  CASE:1207 PLAY ACTION DANCE_SIT5
  CASE:1208 PLAY ACTION DANCE_SIT6
  CASE:1209 PLAY ACTION DRUMS_SONG
  CASE:1210 PLAY ACTION LETSPLAY3
  CASE:1211 PLAY ACTION LETSPLAY4
  CASE:1212 PLAY ACTION LETSPLAY5
  CASE:1213 PLAY ACTION LETSPLAY6

SET last_happyact rndnum
WAIT
RET 1

:1698	// SIT_PICKPOS
CALL G_SIT_PICKPOS
GO G_SIT_HAPPY


////////////////////////////////////////////////////////////////////
// SIT_NOSE_SENSE
:G_SIT_NOSE_SENSE
WAIT 1
IF_1ST Wait = 0
IF_AND nosecount < 3 1720
IF_1ST Wait = 1
IF_AND tailwag > 0
IF_AND nosecount < 3 1720
RET 1

:1720	// NOSE_DIST?
IF Distance < 200 THEN		// If sitting and something close to nose,
  IF Head_Tilt > -30 THEN	// it might be someones hand.  Be polite...
    ADD nosecount 1
    CALL G_RANDOM1/3
      CASE:2 RET 1
    CALL G_SIT_SHAKEHANDS
  ENDIF
ENDIF
RET 1


////////////////////////////////////////////////////////////////////
// SIT_OTHERHAND
:G_SIT_OTHERHAND
WAIT 1
SET init_wait Wait
IF last_shakehand > 0 THEN
  CALL G_RANDOM2
    CASE:1 PLAY ACTION SHAKERIGHT3
    CASE:2 PLAY ACTION SHAKERIGHT4
  SET last_shakehand 0
ELSE
  CALL G_RANDOM2
    CASE:1 PLAY ACTION SHAKELEFT3
    CASE:2 PLAY ACTION SHAKELEFT4
  SET last_shakehand 1
ENDIF

CALL G_WAIT

// Setup amount of time to wait with paw extended...
SET timetrack Sec
RND maxtime 2 4	// Wait 2 to 4 seconds
SET RFLeg_ON 0
SET LFLeg_ON 0

:1732	// TIMER
WAIT 1
SET newtime Sec
IF_1ST RFLeg_ON > 0
IF_AND last_shakehand = 0 1741
IF_1ST LFLeg_ON > 0
IF_AND last_shakehand = 1 1741
IF_1ST newtime > timetrack 1740
IF_1ST newtime >= timetrack 1732
ADD maxtime timetrack
SUB maxtime newtime
SUB maxtime 60
SET timetrack newtime

:1736	// TIMEOUT?
IF_1ST maxtime >= 0 1732
PLAY ACTION SIT
CALL G_SAD
CALL G_INC_SAD_MOOD
CALL G_DEC_HAPPY_MOOD
RET 1

:1740	// ADJUSTP
ADD maxtime timetrack
SUB maxtime newtime
SET timetrack newtime
GO 1736

:1741	// PRAISE
CALL G_PRAISE
PLAY ACTION SIT
CALL G_WAIT
RET 1


////////////////////////////////////////////////////////////////////
// SIT_PETTED
:G_SIT_PETTED
CALL G_RANDOM3
  CASE:1 GO 1784
  CASE:2 GO 1779

:1751	// LOTS_BACK_PET?
IF_1ST back_count > 4 1776

:1752	// RNDNUM
RND rndnum 0 16
WAIT 1
SET init_wait Wait
IF_1ST rndnum = last_petsong 1752
SWITCH rndnum
  CASE:0 PLAY ACTION BEEN_PETTED1
  CASE:1 PLAY ACTION BEEN_PETTED8
  CASE:2 PLAY ACTION BEEN_PETTED2
  CASE:3 PLAY ACTION BEEN_PETTED9
  CASE:4 PLAY ACTION BEEN_PETTED3
  CASE:5 PLAY ACTION BEEN_PETTED10
  CASE:6 PLAY ACTION BEEN_PETTED4
  CASE:7 PLAY ACTION BEEN_PETTED11
  CASE:8 PLAY ACTION BEEN_PETTED5
  CASE:9 PLAY ACTION BEEN_PETTED12
  CASE:10 PLAY ACTION BEEN_PETTED6
  CASE:11 PLAY ACTION BEEN_PETTED13
  CASE:12 PLAY ACTION BEEN_PETTED7
  CASE:13 PLAY ACTION BEEN_PETTED14
  CASE:14 PLAY ACTION BEEN_PETTED18
  CASE:15 PLAY ACTION BEEN_PETTED19
  CASE:ELSE PLAY ACTION BEEN_PETTED20
SET last_petsong rndnum
CALL G_WAIT

:1758	// INC_HAPPY_MOOD
CALL G_INC_HAPPY_MOOD
CALL G_DEC_MAD_MOOD
CALL G_DEC_SAD_MOOD
RET 1

:1776	// petkick
WAIT 1
SET init_wait Wait
PLAY ACTION+ petting_kick_sit
SET sleepstate 0
SET last_petsong 999
CALL G_WAIT
SET Back_ON 0
GO 1758

:1779	// petted2
WAIT 1
SET init_wait Wait
PLAY ACTION TUNE_PETTED2

:1780	// WAIT
CALL G_WAIT
IF_1ST mood_happy > 4 1783
CALL G_RANDOM1/3
  CASE:1 GO 1751
GO 1758

:1783	// RANDOM(1)
CALL G_RANDOM1/3
  CASE:1 GO 1758
GO 1751

:1784	// petted1
WAIT 1
SET init_wait Wait
PLAY ACTION TUNE_PETTED1
GO 1780


////////////////////////////////////////////////////////////////////
// SIT_PICKPOS
:G_SIT_PICKPOS

:1787	// NEW_STATE
RND rndnum 0 2
IF_1ST rndnum = sleepstate 1787
SET sitstate rndnum
RET 1


////////////////////////////////////////////////////////////////////
// SIT_POSE
:G_SIT_POSE
CALL G_VOICE_HIT

IF_1ST sitstate <> 1 1804	// Nope
CALL G_RANDOM1/3
  CASE:1 GO 1804

SET rndbase 1050
SET rndcount 3
SET lastact1 last_poseact
SET lastact2 last_poseact
CALL G_BEHAVIOR_RNDN
  CASE:2 RET 1

// Poses when in SITWIDE position...
WAIT 1
SET init_wait Wait
SWITCH rndnum
  CASE:1050 PLAY ACTION POSE_SIT1
  CASE:1051 PLAY ACTION POSE_SIT2
  CASE:ELSE PLAY ACTION POSE_SIT3

SET sitstate 1
CALL G_WAIT
SET last_poseact rndnum
RET 1

:1804	// SITPOS
SET rndbase 1000
SET rndcount 5
SET lastact1 last_poseact
SET lastact2 last_poseact
CALL G_BEHAVIOR_RNDN
  CASE:2 RET 1

// Poses when sitting straight...
WAIT 1
SET init_wait Wait
SWITCH rndnum
  CASE:1000 PLAY ACTION POSE_ATLAS
  CASE:1001 PLAY ACTION POSE_MUSCLE
  CASE:1002 PLAY ACTION POSE_SUPERMAN
  CASE:1003 PLAY ACTION POSE_TAPAIR
  CASE:ELSE PLAY ACTION+ headstand_sit

SET sitstate 0
CALL G_WAIT
SET last_poseact rndnum
RET 1


////////////////////////////////////////////////////////////////////
// SIT_SHAKEHANDS
:G_SIT_SHAKEHANDS
WAIT 1
SET init_wait Wait
CALL G_RANDOM4
  CASE:1 GO 1832
  CASE:2 GO 1831
  CASE:3 GO 1830
PLAY ACTION SHAKELEFT4

:4117	// LEFT4
SET last_shakehand 1

:1816	// WAIT
CALL G_WAIT
WAIT 1
SET timetrack Sec
RND maxtime 2 4	// Wait 2 to 4 seconds
SET RFLeg_ON 0
SET LFLeg_ON 0

:1818	// TIMER
WAIT 1
SET newtime Sec
IF_1ST RFLeg_ON > 0
IF_AND last_shakehand = 0 1827
IF_1ST LFLeg_ON > 0
IF_AND last_shakehand = 1 1827
IF_1ST newtime > timetrack 1826
IF_1ST newtime >= timetrack 1818
ADD maxtime timetrack
SUB maxtime newtime
SUB maxtime 60
SET timetrack newtime

:1822	// TIMEOUT?
IF_1ST maxtime >= 0 1818
PLAY ACTION SIT
CALL G_SAD
CALL G_INC_SAD_MOOD
CALL G_DEC_HAPPY_MOOD
RET 1

:1826	// ADJUSTP
ADD maxtime timetrack
SUB maxtime newtime
SET timetrack newtime
GO 1822

:1827	// PRAISE
CALL G_PRAISE
PLAY ACTION SIT
CALL G_WAIT
RET 1

:1830	// LEFT3
PLAY ACTION SHAKELEFT3
GO 4117

:1831	// RIGHT4
PLAY ACTION SHAKERIGHT4
SET last_shakehand 0
GO 1816

:1832	// RIGHT3
PLAY ACTION SHAKERIGHT3
SET last_shakehand 0
GO 1816


////////////////////////////////////////////////////////////////////
// SIT_TAILSONG
:G_SIT_TAILSONG
SET rndbase 1450
SET rndcount 3
SET lastact1 last_tailsong
SET lastact2 last_tailsong
CALL G_BEHAVIOR_RNDN
  CASE:2 RET 1
SWITCH rndnum
  CASE:1450 PLAY ACTION TAILWAG_SONG7
  CASE:1451 PLAY ACTION TAILWAG_SONG8
  CASE:ELSE PLAY ACTION TAILWAG_SONG9
SET last_tailsong rndnum
WAIT
RET 1


////////////////////////////////////////////////////////////////////
// SIT_VOICE_HANDLER  (Voice Processing when sitting down)
:G_SIT_VOICE_HANDLER
CALL G_STOP_HEAD
SWITCH VoiceCmd
  CASE:HEARD_RHYTHM GO 1860		// Heard Rhythm
  CASE:VOICE_WALK GO 1883		// Walk
  CASE:VOICE_FINDBALL GO 1871		// Find Ball
  CASE:VOICE_KICKBALL GO 1871		// Kick Ball
  CASE:VOICE_AREYOUHUNGRY GO 1870	// Hungry?
  CASE:VOICE_LETSDANCE GO 1868		// Dance
  CASE:VOICE_AREYOUOK GO 1867		// Are you ok?
  CASE:VOICE_GOODNIGHT GO 1866		// Good Night
  CASE:VOICE_GOODBYE GO 1866		// Goodbye
  CASE:VOICE_AIBO GO 1866		// AIBO
  CASE:VOICE_GOODMORNING GO 1866	// Good Morning
  CASE:VOICE_HELLO GO 1866		// Hello
  CASE:VOICE_SAYHELLO GO 1866		// Say Hello
  CASE:VOICE_SITDOWN GO 1865		// Sit down
  CASE:VOICE_KARATECHOP GO 1864		// Karate Chop
  CASE:VOICE_POSE GO 1863		// Pose
  CASE:VOICE_AREYOUTIRED GO 1862	// Tired?
  CASE:VOICE_LETSPLAY GO 1861		// Let's Play
  CASE:VOICE_SHAKEPAW GO 1858		// Shake
  CASE:VOICE_SHAKE GO 1858		// Shake
  CASE:VOICE_OTHERPAW GO 1856		// Other Paw
  CASE:VOICE_ROAR GO 1855		// Roar
  CASE:VOICE_MEOW GO 1855		// Meow
  CASE:VOICE_TURNLEFT GO 1854		// Left
  CASE:VOICE_GOFORWARD GO 1853		// Forward
  CASE:VOICE_TURNRIGHT GO 1852		// Right
  CASE:VOICE_GOBACK GO 1851		// Back
  CASE:VOICE_GETUP GO 1850		// Get Up
  CASE:VOICE_STANDUP GO 1850		// Stand Up
  CASE:VOICE_LAYDOWN GO 1848		// Lay Down
RET 1	// none

:1848	// LAY_DOWN
CALL G_VOICE_HIT
PLAY ACTION LIE
WAIT
RET 4	// down

:1850	// STAND_UP
CALL G_CHECK_STAYSIT
  CASE:GO_IGNORE RET 2 // done
CALL G_STAND_UP
RET 6 // stand

:1851	// BACK
CALL G_CHECK_STAYSIT
  CASE:GO_IGNORE RET 2 // done
CALL G_GO_BACK
RET 6	// stand

:1852	// RIGHT
CALL G_LAZY_GORIGHT
  CASE:1 RET 2	// done
RET 6	// stand

:1853	// FWD
CALL G_CHECK_STAYSIT
  CASE:GO_IGNORE RET 2 // done
CALL G_GO_FORWARD
RET 6	// stand

:1854	// LEFT
CALL G_LAZY_GOLEFT
  CASE:1 RET 2	// done
RET 6	// stand

:1855	// BARK
CALL G_CHECK_STAYSIT
  CASE:GO_IGNORE RET 2 // done
CALL G_STAND_BARK
RET 6	// stand

:1856	// OTHERPAW_CMD
CALL G_VOICE_HIT
CALL G_SIT_OTHERHAND
RET 2	// done

:1858	// SHAKEPAW_CMD
CALL G_VOICE_HIT
CALL G_SIT_SHAKEHANDS
RET 2	// done

:1860	// SIT_RHYTHM
CALL G_SIT_RHYTHM
RET 2	// done

:1861	// RPS
CALL G_RPS
RET 2	// done

:1862	// ARE_YOU_TIRED?
CALL G_QUERY_TIRED
RET 2	// done

:1863	// SIT_POSE
CALL G_SIT_POSE
RET 2	// done

:1864	// KARATE_CHOP
CALL G_KARATE_CHOP
RET 2	// done

:1865	// SIT_HUH?
CALL G_SIT_HUH
RET 2	// done

:1866	// SIT_GREET
CALL G_SIT_GREET
RET 2	// done

:1867	// ARE_YOU_OK?
CALL G_QUERY_MOOD
RET 2	// done

:1868	// LETS_DANCE
CALL G_VOICE_HIT
CALL G_SIT_DANCE
RET 2	// done

:1870	// HUNGRY?
CALL G_QUERY_HUNGRY
  CASE:1 RET 2	// done
RET 2	// done

:1871	// FIND_BALL
CALL G_VOICE_HIT

// If sitonly, do a quick look around then quit...
IF sitonly > 0 THEN
  CALL G_SOCCER_LOOK4BALL
  RET 2 // done
ENDIF

CALL G_SOCCER_SEARCH4BALL
  CASE:1 RET 7	// rest
  CASE:2 GO 1875

:1873	// STOOD_UP?(2)
IF searchmove <= 0 THEN	// If didn't standup, then we're done...
  RET 1	
ENDIF

CALL G_SIT_DOWN
RET 2	// done

// If saw ball, but too tired...
:1875	// TIRED?
IF_1ST mood_tired >= 9 1873

// If saw ball and now standing...
IF_1ST searchmove <> 0 1888

// Saw ball and still sitting.  Stand up and reaquire the ball...
WAIT 1
SET tilt Head_Tilt
SET pan Head_Pan
SET init_wait Wait
PLAY ACTION STAND
CALL G_WAIT_AWARE

PLAY ACTION MOVE.HEAD.FAST pan tilt
CALL G_WAIT_AWARE

IF_1ST Pink_Ball <> 0 1888
CALL G_SOCCER_SEARCH4BALL
  CASE:1 RET 7	// rest
  CASE:2 RET 5	// ball
RET 2	// done

:1883	// WALK_REQUEST
CALL G_WALK_REQUEST
  CASE:1 RET 3	// walk

:1885	// done
RET 2

:1888	// ball
RET 5


////////////////////////////////////////////////////////////////////
// SIT_GREET
:G_SIT_GREET
WAIT 1
SET init_wait Wait
RND rndnum 0 19
SWITCH rndnum
  CASE:0 PLAY ACTION WINK_LEFT1
  CASE:1 PLAY ACTION WINK_LEFT2
  CASE:2 PLAY ACTION WINK_RIGHT1
  CASE:3 PLAY ACTION WINK_RIGHT2
  CASE:4 PLAY ACTION WAVE_RIGHT_SIT1
  CASE:5 PLAY ACTION WAVE_RIGHT_SIT2
  CASE:6 PLAY ACTION WAVE_RIGHT_SIT3
  CASE:7 PLAY ACTION WAVE_RIGHT_SIT5
  CASE:8 PLAY ACTION WAVE_RIGHT_SIT6
  CASE:9 PLAY ACTION WAVE_LEFT_SIT9
  CASE:10 PLAY ACTION WAVE_LEFT_SIT10
  CASE:11 PLAY ACTION WAVE_LEFT_SIT1
  CASE:12 PLAY ACTION WAVE_LEFT_SIT2
  CASE:13 PLAY ACTION WAVE_LEFT_SIT4
  CASE:14 PLAY ACTION WAVE_LEFT_SIT3
  CASE:15 PLAY ACTION WAVE_LEFT_SIT5
  CASE:16 PLAY ACTION WAVE_LEFT_SIT6
  CASE:ELSE GO 3675
CALL G_WAIT_AWARE
SET sitstate 0
RET 1

:3675	// SELECT3
SWITCH rndnum
  CASE:17 PLAY ACTION WAVE_RIGHT_SIT4
  CASE:18 PLAY ACTION WAVE_LEFT_SIT7
  CASE:ELSE PLAY ACTION WAVE_LEFT_SIT8
CALL G_WAIT_AWARE
SET sitstate 1
RET 1


////////////////////////////////////////////////////////////////////
// SIT_HUH
:G_SIT_HUH
CALL G_VOICE_HIT
CALL G_RANDOM6
  CASE:1 GO 3710
  CASE:2 GO 3709
  CASE:3 GO 3708
  CASE:4 GO 3706
  CASE:5 PLAY ACTION HUH_LEFT
  CASE:ELSE PLAY ACTION HUH_RIGHT
WAIT
RET 1

:3706	// HUH4
PLAY ACTION HUH_SIT4
SET sitstate 0
WAIT
RET 1

:3708	// HUH3
PLAY ACTION HUH_SIT3
SET sitstate 0
WAIT
RET 1

:3709	// HUH2
PLAY ACTION HUH_SIT2
SET sitstate 0
WAIT
RET 1

:3710	// HUH1
PLAY ACTION HUH_SIT1
SET sitstate 0
WAIT
RET 1


////////////////////////////////////////////////////////////////////
// SIT_RHYTHM
:G_SIT_RHYTHM
SET rndbase 1900
SET rndcount 7
CALL G_BEHAVIOR_RNDNM
  CASE:3 RET 1	// no valid number available

SWITCH rndnum
  CASE:1900 PLAY ACTION+ dancestep_aibosit_beat
  CASE:1901 PLAY ACTION+ dancestep_aibosit1
  CASE:1902 PLAY ACTION+ dancestep_aibosit2
  CASE:1903 PLAY ACTION+ dancestep_aibosit3
  CASE:1904 PLAY ACTION+ dancestep_sit_conduct1
  CASE:1905 PLAY ACTION+ dancestep_sit_conduct2
  CASE:ELSE PLAY ACTION+ dancestep_sit_piano
WAIT
RET 1


