
////////////////////////////////////////////////////////////////////
//                                                                //
//  DogsLife Rock-Paper-Scissors Game                             //
//  Copyright (C) 2001-2002 by DogsBody & Ratchet Software        //
//  All Rights Reserved                                           //
//                                                                //
//  This is free software and MAY NOT be sold under any           //
//  circumstances, seperately or bundled.                         //
//                                                                //
////////////////////////////////////////////////////////////////////


//
// Rock-Paper-Scissors Game...
//
:G_RPS
CALL G_TWITCH_EARS
PLAY ACTION+ rps_intro
WAIT

SET win_count 0
SET tie_count 0
SET lose_count 0
RND limit 3 6
SET Back_ON 0
WAIT 500

:RPS_NEWROUND
SET Head_ON 0
SET Back_ON 0
SET Jaw_ON 0
PLAY ACTION+ rps_countdown
WAIT

RND last_rps 0 2
SWITCH last_rps
  CASE:0 PLAY ACTION+ rps_rock
  CASE:1 PLAY ACTION+ rps_paper
  CASE:ELSE PLAY ACTION+ rps_scissors

WAIT
RND timeout 20 40	// Wait 2-4 secs...

:RPS_LOOP
CALL G_UPDATE_PAUSEBAR
CALL G_NEED2REST
  CASE:1 GO RPS_STOPGAME

WAIT 100
IF_1ST Back_ON > 0 RPS_STOPGAME
IF_1ST Jaw_ON > 0 RPS_TIE
IF_1ST Head_ON > 0 RPS_WIN
IF_1ST timeout < 0 RPS_LOSE
IF_1ST Pink_Ball > 0	// Rock & Rock
IF_AND last_rps = 0 RPS_TIE
IF_1ST Pink_Ball > 0	// Paper wraps Rock
IF_AND last_rps = 1 RPS_WIN
IF_1ST Pink_Ball > 0	// Rock dulls scissors
IF_AND last_rps = 2 RPS_LOSE
IF_1ST Fav_Color > 0	// Paper & Paper
IF_AND last_rps = 1 RPS_TIE
IF_1ST Fav_Color > 0	// Scissor cuts paper
IF_AND last_rps = 2 RPS_WIN
IF_1ST Fav_Color > 0	// Paper wraps rock
IF_AND last_rps = 0 RPS_LOSE
IF_1ST Unfav_Color > 0	// Scissors & Scissors
IF_AND last_rps = 2 RPS_TIE
IF_1ST Unfav_Color > 0	// Rock dulls scissors
IF_AND last_rps = 0 RPS_WIN
IF_1ST Unfav_Color > 0	// Scissors cut paper
IF_AND last_rps = 1 RPS_LOSE

SUB timeout 1
SET Head_Hit 0
SET Head_ON 0
SET Back_ON 0
SET Jaw_ON 0

CALL G_RPS_ATTENTION
  CASE:GO_PRAISE CALL G_PRAISE
  CASE:GO_SCOLD CALL G_SCOLD
  CASE:GO_VOICE GO RPS_VOICE
GO RPS_LOOP

:RPS_VOICE
SWITCH VoiceCmd
  CASE:VOICE_STOP GO RPS_STOPGAME	// Stop
  CASE:VOICE_WALK GO RPS_DOVOICE	// Walk
  CASE:VOICE_FINDBALL GO RPS_DOVOICE	// Find Ball
  CASE:VOICE_KICKBALL GO RPS_DOVOICE	// Kick Ball
  CASE:VOICE_LETSDANCE GO RPS_DOVOICE	// Dance
  CASE:VOICE_GOODNIGHT GO RPS_DOVOICE	// Good Night
  CASE:VOICE_GOODBYE GO RPS_DOVOICE	// Goodbye
  CASE:VOICE_GOODMORNING GO RPS_DOVOICE	// Good Morning
  CASE:VOICE_AREYOUTIRED GO RPS_DOVOICE	// Tired?
  CASE:VOICE_LAYDOWN GO RPS_DOVOICE	// Lie Down / Play Dead
  CASE:VOICE_ROAR GO RPS_DOVOICE	// Roar / Roll Over
  CASE:VOICE2_YOUWON GO RPS_WIN		// Win!
  CASE:VOICE2_YOULOST GO RPS_LOSE	// Lost!
PLAY ACTION+ rps_huh
WAIT
GO RPS_LOOP

:RPS_DOVOICE
PLAY ACTION+ rps_close
WAIT
SET AP_Voice_Cmd (VoiceCmd-base_voice_cmd) // Make normal loop respond to voice command...
RET 1

:RPS_STOPGAME
PLAY ACTION+ rps_close
WAIT
RET 1

:RPS_CHECKLIMIT	// Had enough yet?
IF temp < limit RPS_NEWROUND // nope

PLAY ACTION+ rps_close
WAIT

RND rndnum 0 2

// Tie Endgame?
IF tie_count >= limit THEN
  SWITCH rndnum
    CASE:1:PLAY ACTION IMPATIENT_SIT1
    CASE:2:PLAY ACTION IMPATIENT_SIT2
    CASE:ELSE:PLAY ACTION BORED_SIT2
  WAIT
  PLAY ACTION SIT
  WAIT
  RET 1
ENDIF

// Win Endgame?
IF win_count > lose_count THEN
  SWITCH rndnum
    CASE:1:PLAY ACTION CUTE_BANZAI1
    CASE:2:PLAY ACTION SALUTE2
    CASE:ELSE:PLAY ACTION POUNCE1
  WAIT
  RET 1
ENDIF

// Lose Endgame...
SWITCH rndnum
  CASE:1:PLAY ACTION DONTWANNA1
  CASE:2:PLAY ACTION NOTHANKS
  CASE:ELSE:PLAY ACTION NOT_ME
WAIT
RET 1



// Lost round...
:RPS_LOSE
ADD lose_count 1
CALL G_DEC_HAPPY_MOOD
CALL G_INC_MAD_MOOD

IF lose_count > 3 THEN
  CALL G_RANDOM3
ELSE
  SWITCH lose_count
ENDIF
CASE:1 PLAY ACTION+ rps_lose1
CASE:2 PLAY ACTION+ rps_lose2
CASE:3 PLAY ACTION+ rps_lose3
WAIT

SET temp lose_count
GO RPS_CHECKLIMIT


// Won round!!!
:RPS_WIN
ADD win_count 1
CALL G_INC_HAPPY_MOOD
CALL G_DEC_MAD_MOOD

IF win_count > 3 THEN
  CALL G_RANDOM3
ELSE
  SWITCH win_count
ENDIF
CASE:1 PLAY ACTION+ rps_win1
CASE:2 PLAY ACTION+ rps_win2
CASE:3 PLAY ACTION+ rps_win3
WAIT

SET temp win_count
GO RPS_CHECKLIMIT


// Got a tie!
:RPS_TIE
ADD tie_count 1
CALL G_DEC_HAPPY_MOOD

IF tie_count > 3 THEN
  CALL G_RANDOM3
ELSE
  SWITCH tie_count
ENDIF
CASE:1 PLAY ACTION+ rps_tie1
CASE:2 PLAY ACTION+ rps_tie2
CASE:3 PLAY ACTION+ rps_tie3
WAIT

SET temp tie_count
GO RPS_CHECKLIMIT


////////////////////////////////////////////////////////////////////
//
//  Check for user voice input...
//
:G_RPS_ATTENTION
SET pet 0
SET praise 0
SET scold 0
WAIT 1

IF Back_ON > 0 THEN
  ADD pet 2
  SET Back_ON 0
  ADD back_count 1
  RET:GO_PRAISE
ENDIF

IF AP_Voice_Cmd > 0 THEN
  CALL G_VOICECMD
    CASE:GO_VOICE GO RPSA_VOICECMD
ENDIF

IF AP_Tone > 0 THEN
  CALL G_TONECMD
    CASE:1 GO RPSA_VOICECMD
ENDIF

RET:GO_IDLE // none
  

:RPSA_VOICECMD
SET back_count 0
WAIT 1

IF VoiceCmd == VOICE_GOODBOT THEN
  IF VoiceDictID >= 149	THEN 	// Good Boy
    IF VoiceDictID <= 150 THEN
      CALL G_INC_BOYGIRL
      RET:GO_PRAISE
    ENDIF
  ENDIF

  IF VoiceDictID >= 151	THEN 	// Good Girl
    IF VoiceDictID <= 154 THEN
      CALL G_DEC_BOYGIRL
      RET:GO_PRAISE
    ENDIF
  ENDIF
ENDIF

IF VoiceCmd == VOICE_BADBOT THEN 
  IF VoiceDictID >= 160 THEN	// Bad Boy
    IF VoiceDictID <= 161 THEN
      CALL G_INC_BOYGIRL
      RET:GO_SCOLD
    ENDIF
  ENDIF

  IF VoiceDictID >= 162 THEN	// Bad Girl
    IF VoiceDictID <= 165 THEN	
      CALL G_DEC_BOYGIRL
      RET:GO_SCOLD
    ENDIF
  ENDIF
ENDIF

IF VoiceCmd == VOICE2_GOODBOY THEN		// Good Boy (voice2)
  CALL G_INC_BOYGIRL
  RET:GO_PRAISE
ENDIF

IF VoiceCmd == VOICE2_GOODGIRL THEN		// Good Girl (voice2)
  CALL G_DEC_BOYGIRL
  RET:GO_PRAISE
ENDIF

IF VoiceCmd == VOICE2_BADBOY THEN		// Bad Boy (voice2)
  CALL G_INC_BOYGIRL
  RET:GO_SCOLD
ENDIF

IF VoiceCmd == VOICE2_BADGIRL THEN		// Bad Girl (voice2)
  CALL G_DEC_BOYGIRL
  RET:GO_SCOLD
ENDIF

IF VoiceCmd == VOICE_GOFORIT THEN	// Go For It
  SET goforit 60
  RET:GO_PRAISE
ENDIF

IF VoiceCmd == VOICE_DONTDOTHAT THEN
  RET:GO_SCOLD
ENDIF

IF VoiceCmd == VOICE_TAKEAPICTURE THEN
  IF Posture1 != POSTURE_WALK THEN
    CALL G_TAKE_A_PICTURE
  ENDIF
  RET:GO_IDLE
ENDIF

RET:GO_VOICE


