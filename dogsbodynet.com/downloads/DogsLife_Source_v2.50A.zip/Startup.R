
////////////////////////////////////////////////////////////////////
//                                                                //
//  DogsLife Startup & Initialization Module                      //
//  Copyright (C) 2001-2002 by DogsBody & Ratchet Software        //
//  All Rights Reserved                                           //
//                                                                //
//  This is free software and MAY NOT be sold under any           //
//  circumstances, seperately or bundled.                         //
//                                                                //
////////////////////////////////////////////////////////////////////


//
// Startup Processing...
//
:G_STARTUP
WAIT 1
SET temp Status
PRINT:"Status=%d",temp
WAIT
CLR SENSORS

SET Seed Sec
SET dogslife REQ_RCODE_VERSION
SET behavior 1
SET kickhist 2
SET distmap 8
SET turnhist 9
SET sitonly 0				// Used to keep DogsLife sitting/sleeping (no walking)

WAIT 1
IF AP_Version >= dogslife THEN
  SET rcodeplus 1
  SET AP_Voice_Cmd 0
ELSE
  SET rcodeplus 0
ENDIF

// If RCode 1.2 vocabulary, offset the base value...
VLOAD AP_Vocab
SWITCH:AP_Vocab
  CASE:0 SET base_voice_cmd 0x100
  CASE:2 SET base_voice_cmd 0x100
  CASE:ELSE SET base_voice_cmd 0

// Make sure we are good with battery & temp...
CALL G_NEED2REST
  CASE:1 GO STARTUP_INITMOOD

// Cold boot?
IF_1ST temp = 0 STARTUP_INITMOOD

// Recover boot...
RND rndnum 0 100

// AIBO restarts after the first act, so track the restarts 
// with "shudder" variable...
IF shudder == 0 THEN
  SET shudder 1	
  IF rndnum < 50 THEN
    PLAY ACTION ATCLIFF	
  ELSE
    PLAY ACTION SHUDDER	
  ENDIF
  WAIT		
ENDIF

SET shudder 0

// Aperios sometimes goes a little "funny" after a recovery.
// This stuff seems to help a little (not always though)...
PLAY ACTION WALK 0 0
WAIT
SET d Distance
WAIT 1000
SET dd Distance

// Test the behavior arrays to make sure they wen't wiped...
AP_SET 123 behavior 3999
AP_SET 456 behavior 3998
AP_GET temp behavior 3999

// If pass test, start in standing position...
IF temp == 123 THEN
  RET:GO_STANDPOS
ELSE
  GO STARTUP_LOADVARS
ENDIF


:STARTUP_INITMOOD
SET mood_happy 0
SET mood_mad 0
SET mood_sad 0
SET mood_curious 0
SET mood_bored 0
SET mood_tired 0	// 0=rested  10=tired
SET last_happydance -1
SET last_happydance2 -1
SET last_walkact -1
SET last_tailsong -1
SET last_danceact -1
SET last_happyact -1
SET last_boredact -1
SET last_calmact -1
SET last_poseact -1
SET last_praiseact -1
SET last_praiseact2 -1
SET last_scoldact -1
SET last_scoldact2 -1
SET last_shakehand 0
SET last_kick -1
SET maxtime1 MAXINT
SET maxtime2 MAXINT
SET maxtime3 MAXINT
SET maxtime4 MAXINT
SET maxtime5 MAXINT
SET maxtime6 MAXINT
SET maxtime_mood MAXINT

#ifdef RCODE250
SET Eye_L1 0
SET Eye_L2 0
SET Eye_L3 0
SET Eye_R1 0
SET Eye_R2 0
SET Eye_R3 0
SET Warn 0
#endif

:STARTUP_LOADVARS
SET AP_Voice_Cmd 0
SET VoiceCmd 0
VLOAD boygirl
VLOAD endure
VLOAD soccer

IF soccer < 1 THEN
  SET soccer 30
ENDIF

IF endure < 1 THEN
  SET endure 20
ENDIF

IF rcodeplus > 0 THEN
  AP_DIM behavior 4000 1	// autosave behavior array
  AP_DIM kickhist 1000
  AP_DIM distmap 1000
  AP_DIM turnhist 1000
ENDIF

// One more check on battery/temp status.  If good, go into
// sleep position.  If not, the rest mode...
CALL G_NEED2REST
  CASE:1 RET:GO_RESTPOS
RET:GO_DOWNPOS





