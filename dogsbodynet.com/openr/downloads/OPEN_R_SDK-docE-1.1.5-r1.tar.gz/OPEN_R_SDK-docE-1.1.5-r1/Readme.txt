Differences between OPEN_R_SDK-docE-1.1.4-r1 and OPEN_R_SDK-docE-1.1.5-r1

  ModelInformation_7_E.doc
    New document
  
  InstallationGuide_E.doc
    Mainly update version numbers of packages referred to
    (cygipc is included in cygwin-packages-1.1.5-bin.exe)

  ProgrammersGuide_E.doc
    Change "Chapter7 Safety Guidelines"
  
  Level2ReferenceGuide_E.doc
    Add OPENR::GetJointGain() and OPENR::GetDefaultJointGain()

  ModelInformation_210_E.doc
  ModelInformation_220_E.doc
  InternetProtocolVersion4_E.doc
    No changes
