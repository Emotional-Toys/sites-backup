//
// StandardAttachedPosition.h
//
// Copyright 2000 Sony Corporation
//

#include <OPENR/MWInformationTypes.h>

#ifndef _StandardAttachedPosition_h_DEFINED
#define _StandardAttachedPosition_h_DEFINED

#endif  //  _StandardAttachedPosition_h_DEFINED
