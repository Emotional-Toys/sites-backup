//
// Copyright 1999,2002 Sony Corporation 
//
// Permission to use, copy, modify, and redistribute this software for
// non-commercial use is hereby granted.
//
// This software is provided "as is" without warranty of any kind,
// either expressed or implied, including but not limited to the
// implied warranties of fitness for a particular purpose.
//

#ifndef _OMTECmdList_h_DEFINED
#define _OMTECmdList_h_DEFINED

#define TECOM_BACK_TO_HOMEPOSITION    0x0000
#define TECOM_COLOR_TRACKING          0x1000

#endif  //  _OMTECmdList_h_DEFINED
