/////////////////////////////////////////////////////////////////////////////
// NDS compatible types
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned long uint32;

/////////////////////////////////////////////////////////////////////////////
// Animal Crossing 256KB romsave specific info

// There are two kinds of ROMSAVEs, English and Japanese
// English applies to all non-Japanese games (US 1.0, US 1.1, EU version)
// Some of the more advanced features are not implemented for the Japanese
//  gamesaves. They could be added if someone did the work to find the
//  correct offsets, and test the functionality.
// The function "ENGLISH_CHECK()" will abort early if the gamesave is
//  not 'English' (or more accurately is Japanese). Sorry to the Japanese users.

// The language used in the program is something else.
//  The user interface can be English or Japanese independent of the gamesave.
//  That's picked by the version of Windows (or command line switch)

// Please see the ROMSAVE.TXT file as well


#define FULL_SAVE_SIZE 0x40000

struct VERINFO
{
    const char* szLang;

// NOTE: this is the old way, newer features use the "EORJ" macro
    int gameSaveSize;
    int offsetTilemap;    // 6x6 bytes, last 6 usually "EEEEEE"

    int offsetInvent1;    // inventory for player 1
    int offsetBank1;
    int offsetPoints1;

    int offsetWorldMap;
    int offsetMainRoom;    // start of 8x8 layout
    int offsetBuryBitmap;

};

extern VERINFO* g_verinfo;

// The gamesave sizes, up to 4 players per ROMSAVE
#define GAMESIZE_ENG 0x15FE0 /* for ANMLSAVE only */
#define GAMESIZE_JPN 0x12224 /* for ANMJSAVE only */
#define PLAYER_SIZE_ENG 0x228C
#define PLAYER_SIZE_JPN 0x1D10

#define IS_ENGLISH() (g_verinfo->gameSaveSize == GAMESIZE_ENG)

#define ENGLISH_CHECK()    \
    if (g_verinfo->gameSaveSize != GAMESIZE_ENG) { AfxMessageBox("Sorry - no J support (yet)"); return; }

#define EORJ(e_offset, j_offset)    \
    ((g_verinfo->gameSaveSize == GAMESIZE_ENG) ? (e_offset) : (j_offset))

// Checksum is at the end. Recalculate after any change
#define GAMESIZE (g_verinfo->gameSaveSize)
#define OFF_CSUM (g_verinfo->gameSaveSize-4)

uint16 CalcSumW(const void* pv, int cb);

// common ROMSAVE offsets for player (newer ones use 'EORJ' macro)
#define OFFSET_INVENTORY1 (g_verinfo->offsetInvent1)
    // 0x1B2E (English) - inventory
#define OFFSET_MONEY1 (OFFSET_INVENTORY1 + 30)
    // 0x1B4C (English) - money
#define OFFSET_POINTS1 (g_verinfo->offsetPoints1)
    // Nook points
#define OFFSET_BANK1 (g_verinfo->offsetBank1)
    // Bank balance
#define OFFSET_PLAYER_NAME EORJ(0x228C, 0x1D10) // At end of record

// Other town attributes
#define OFFSET_BURY_BITMAP (g_verinfo->offsetBuryBitmap)
    // 0xE354 (English), burried item bitmap
#define OFFSET_DRAWER_BASE EORJ(0x15430, 0x11764)
    // Drawers in house (90 items)
#define OFFSET_NOOK_ITEMS EORJ(0x15DB8, 0x1200C)
    // Nook items for sale
#define OFFSET_LOSTNFOUND EORJ(0x15EC0, 0x12114)
    // Lost and found
#define OFFSET_RECYCLER EORJ(0x15EDE, 0x12132)
    // Recycler
#define OFFSET_GIFTS (0x1244)
    // Gifts

/////////////////////////////////////////////////////////////////////////////
// ROMSAVE class for access to the raw data

class ROMSAVE
{
// Attributes
protected:
    uint8 m_buffer[FULL_SAVE_SIZE]; // expanded rom data (entire ROM)
    bool m_bModified;

    int WriteBufferB(uint32 addr, uint8 data);
    int WriteBufferW(uint32 addr, uint16 data);
    int WriteBufferL(uint32 addr, uint32 data);

// Operations
public:
    uint8* GetBufferPtr(uint32 addr);

    uint8 GetBufferB(uint32 addr);
    uint16 GetBufferW(uint32 addr);
    uint32 GetBufferL(uint32 addr);

    void WriteB(int offset, uint8 data);
    void WriteW(int offset, uint16 data);
    void WriteL(int offset, uint32 data);
    // update both copies and checksums

    void SetModifiedFlag(bool bFlag) { m_bModified = true; }
    bool GetModifiedFlag() { return m_bModified; }

    bool GuessVersion();

    void CountDangerous(int danger_counts[1+4]);
};


extern ROMSAVE g_romsave;

// Compression for my custom format (used with the Homebrew trainer)
int ExpandSave2(const uint8* pbIn, int cbIn, uint8* pbOut, int cbOutExpected, int cbMirror);
int CompressSave2(const uint8* pbIn, int cbIn, uint8* pbOutStart, int cbOutMax, int cbMirror, bool bSaveJ);

/////////////////////////////////////////////////////////////////////////////
// Neighbors (NPCs)

#define CALC_NOFFSET_E(in) (0x9094 + 0x700 * (in))
#define CALC_NOFFSET_J(in) (0x7976 + 0x5C0 * (in))

extern int CALC_NOFFSET(int index);

#define NOFFSET_9TH_ENG    0x113D0
    // 9th neighbor slot is special

// offsets for neigbor info
#define NDELTA_SPECIES EORJ(0x73,0x6B)
#define NDELTA_PERSONALITY EORJ(0x72,0x6A)
#define NDELTA_ROOMCONTENT EORJ(0x54,0x4E)
#define NDELTA_WALLRUG EORJ(0x74,0x6C)

// special for NPC house location
#define NDELTA_X2 EORJ(0x90,0x80)
#define NDELTA_Y2 EORJ(0x91,0x81)

/////////////////////////////////////////////////////////////////////////////
