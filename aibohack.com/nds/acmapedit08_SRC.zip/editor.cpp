// AnimalMap
// editor.cpp - main editor implementation file
// NOTE: the CEditor class is used for most of the main editors
// (inventory, world map, room contents, nooks offerings, etc)
// Both basic and advanced mode

// The code is very general.
//  It supports multiple grid controls
// The dialog templates can be different for different editors

#include "stdafx.h"
#include "AnimalMap.h"
#include "romsave.h"
#include "editor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif




/////////////////////////////////////////////////////////////////////////////
// Edit

static void ResizeControl(CWnd* pWnd, int cx, int cy)
{
    CRect rcWindow, rcClient;
    pWnd->GetWindowRect(rcWindow);
    pWnd->GetClientRect(rcClient);
    int dx = cx - rcClient.Width();
    int dy = cy - rcClient.Height();
    pWnd->SetWindowPos(NULL, 0, 0,
        rcWindow.Width() + dx, rcWindow.Height() + dy,
        SWP_NOMOVE | SWP_NOZORDER);

}

////////////////////////////////////////////////////////////
// Photo Control

BEGIN_MESSAGE_MAP(CGridCtrl, CWnd)
    //{{AFX_MSG_MAP(CGridCtrl)
    ON_WM_PAINT()
    ON_WM_LBUTTONDOWN()
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

CGridCtrl::CGridCtrl()
{
    m_info.array = NULL;
    m_tilemap = NULL;
    m_holemap = NULL;
    m_bBackdrop = false;
    }

void CGridCtrl::Init(CEditor* pParent, int nIDC, GRID_INFO const& info, bool bBig)
{
    m_parent = pParent;
    m_info = info;    // copy it

    m_cxCell = (bBig) ? 40 : 10;
    m_cyCell = (bBig) ? 20 : 10;

    VERIFY(SubclassWindow(::GetDlgItem(pParent->m_hWnd, nIDC)));
    ResizeControl(this, m_cxCell * m_info.gridX, m_cyCell * m_info.gridY);
}


#include "tiles.c_"

void CGridCtrl::OnPaint()
{
    PAINTSTRUCT ps;
    CDC* pdc = BeginPaint(&ps);
    CRect rc;
    GetClientRect(&rc);

    pdc->SetBkMode(TRANSPARENT);

    pdc->SetTextColor(RGB(192, 192, 192));
    CBrush brBorder(RGB(192, 192, 192));
    
    // solid brushes for FillRect
    CBrush brWhite(RGB(255, 255, 255));
    CBrush brLtGrey(RGB(128, 128, 128));
    CBrush brDkGrey(RGB(48, 48, 48));
    CBrush brLtRed(RGB(192, 0, 0));
    CBrush brDkRed(RGB(128, 0, 0));
    CBrush brRed(RGB(255, 0, 0));
    CBrush brOrange(RGB(255, 165, 0));
    CBrush brDkOrange(RGB(0xDF, 0x74, 0x00));
    CBrush brDkGreen(RGB(0, 128, 0));

    CBrush brPink(RGB(0xFF, 0x6E, 0xC7));
    CBrush brDkPink(RGB(0xBC, 0x90, 0x90));
    CBrush brVDkPink(RGB(0xBC*3/4, 0x90*3/4, 0x90*3/4));
    CBrush brPattern(RGB(0xFF, 0x9F, 0x80));

    CBrush brGreen(RGB(0, 255, 0));
    CBrush brDkBlue(RGB(0, 0, 128));
    CBrush brLtBlue(RGB(0, 0, 255));
    CBrush brCyan(RGB(0, 255, 255));
    CBrush brLtYellow(RGB(255, 255, 0));
    CBrush brDkYellow(RGB(128, 128, 0));
    CBrush brBrown(RGB(139, 115, 85));

    uint16* pw = m_info.array;
    CRect rectFull;

    for (int row = 0; row < m_info.gridY; row++)
    {
        int yTop = m_cyCell * row;
        rectFull.top = yTop;
        rectFull.bottom = yTop + m_cyCell;

        uint8* holemap = NULL;
        if (m_holemap != NULL)
        {
            ASSERT((m_info.gridX % 8) == 0);
            holemap = m_holemap + (row * m_info.gridX / 8);
        }

        for (int col = 0; col < m_info.gridX; col++)
        {
            uint16 code = *pw++;
            int xLeft = m_cxCell * col;
            rectFull.left = xLeft;
            rectFull.right = xLeft + m_cxCell;

            CRect rect(rectFull);
            CBrush* pbr = &brWhite;    // background of item tile
            bool bHotspot = false;
            if (m_bBackdrop && m_tilemap != NULL)
            {
                uint8 tile = m_tilemap[(row/16)*4 + (col/16)];
                if (tile < sizeof(g_tileDirectory)/sizeof(const char*))
                {
                    const char* pch = g_tileDirectory[tile];

                    if (pch != NULL)
                    {
                        pch += (row&15)*16 + (col&15);
                        char ch = *pch;
                        if (ch == 'W')
                            pbr = &brDkBlue;
                        else if (ch == 'S')
                            pbr = &brLtBlue;
                        else if (ch == 'P')
                            pbr = &brLtGrey;
                        else if (ch == 'B')
                            pbr = &brBrown;
                        else if (ch == 'H')
                        {
                            pbr = &brLtGrey;
                            bHotspot = true;
                        }
                        else if (ch != ' ')
                            { ASSERT(false); }
                    }
                }
            }

            if (code != CODE_BLANK)
            {
                // fill in content
                if (IsWeed(code))
                {
                    // weeds
                    pbr = &brDkGreen;
                }
                else if (IsRock(code))
                {
                    // rock
                    pbr = &brDkGrey;
                    // if (code >= 0xED && code <= 0xFB) layer = (code-0xED)/5 + 1;    // 1, 2 or 3 -- DEPRECATED
                }
                else if (IsPattern(code))
                {
                    pbr = &brPattern;
                }
                else if (IsFlower0(code))
                {
                    pbr = &brPink;
                }
                else if (IsFlower1(code))
                {
                    pbr = &brVDkPink;
                }
                else if (IsFlower2(code))
                {
                    pbr = &brDkPink;
                }
                else if (code <= MAX_TERRAIN_CODE)
                {
                    // other terrain (trees)
                    pbr = &brGreen;
                    if (IsStump(code))
                       pbr = &brDkOrange;    // tree stumps
#ifdef _DEBUG
                    if (code >= 0x2F+0x28 && code <= 0x5B)
                        pbr = &brDkGreen;    // money tree
                    if (code >= 0x66 && code <= 0x6D)
                        pbr = &brDkGreen;    // special trees
                    if (code == 0x69)
                        pbr = &brDkRed;    // acorn
                    if (code == 0x6D)
                        pbr = &brDkPink;    // festive
                    if (code == 0x66)
                        pbr = &brDkPink;    // lots of furniture
#endif
                }
                else if ((code & 0xFF00) == 0x5000)
                {
                    // house or sign post (can't change)
                    pbr = &brDkRed;
                }
                else if ((code & 0xFFF0) == 0xF030)
                {
                    // extended object (wall around house or wider furnature inside)
                    pbr = &brLtRed;
                }
                else if (code == 0x1518)
                {
                    // apple (good for marker)
                    pbr = &brRed;
                }
                else if (code == 0x1519)
                {
                    // orange (good for marker)
                    pbr = &brOrange;
                }
                else if ((code & 0xF000) == 0x1000)
                {
                    pbr = &brLtYellow; // probably item
                }
                else if ((code & 0xF000) == 0x3000 || (code & 0xF000) == 0x4000)
                {
                    pbr = &brCyan;    // probably feature (inside house)
                }
                else
                {
                    // other - may be dropped item or other
                    pbr = &brDkYellow;
                }
            }
            pdc->FillRect(rect, pbr);
            if (code != CODE_BLANK && m_cxCell > 10)
            {
                // big
                char szT[32];
                sprintf(szT, "%04X", code);
                if ((code & 0xFFF0) == 0xF030)
                    strcpy(szT, "++++");
                pdc->DrawText(szT, strlen(szT), rect, DT_VCENTER | DT_CENTER);
            }
            pdc->FrameRect(rectFull, &brBorder);
            if (holemap != NULL)
            {
                if (holemap[col / 8] & (1 << (col & 7)))
                {
                    // buried
                    pdc->MoveTo(rectFull.left, rectFull.top);
                    pdc->LineTo(rectFull.right, rectFull.bottom);
                    pdc->MoveTo(rectFull.left, rectFull.bottom);
                    pdc->LineTo(rectFull.right, rectFull.top);
                }
            }
            if (bHotspot)
            {
                // hotspot on concrete
                CPen penRedGrey(PS_SOLID, 1, RGB(255, 128, 255));
                CGdiObject* pOldPen = pdc->SelectObject(&penRedGrey);
                const int futz = 3;
                pdc->MoveTo(rectFull.left+futz, rectFull.top+futz);
                pdc->LineTo(rectFull.right-futz, rectFull.bottom-futz);
                pdc->MoveTo(rectFull.left+futz, rectFull.bottom-futz);
                pdc->LineTo(rectFull.right-futz, rectFull.top+futz);
                pdc->SelectObject(pOldPen);
            }
#if 0 // DEPRECATED layered rock code, may be useful later
            if (layer > 0)
            {
                // draw tiny number (using lines so we don't have to worry about fonts)
                CPen pen(PS_SOLID, 1, RGB(0xC0, 0xC0, 0xC0));
                CGdiObject* pOldPen = pdc->SelectObject(&pen);
                if (layer == 1)
                {
                    int xCenter = (rectFull.left+rectFull.right)/2;
                    pdc->MoveTo(xCenter, rectFull.top+2);
                    pdc->LineTo(xCenter, rectFull.bottom-2);
                }
                else
                {
                    // 2 or 3
                    int yCenter = (rectFull.top+rectFull.bottom)/2;
                    int x1 = rectFull.left+3;
                    int x2 = rectFull.right-3;
                    int y1 = rectFull.top+3;
                    int y2 = rectFull.bottom-3;
                    pdc->MoveTo(x1, y1);
                    pdc->LineTo(x2, y1);
                    pdc->MoveTo(x1, yCenter);
                    pdc->LineTo(x2, yCenter);
                    pdc->MoveTo(x1, y2);
                    pdc->LineTo(x2+1, y2);
                    pdc->MoveTo(x2, y1);
                    if (layer == 2)
                    {
                        pdc->LineTo(x2, yCenter+1);
                        pdc->MoveTo(x1, yCenter);
                        pdc->LineTo(x1, y2+1);
                    }
                    else
                    {
                        // 3
                        pdc->LineTo(x2, y2+1);
                    }
                }

                pdc->SelectObject(pOldPen);
            }
#endif
        }

    }

    if (m_info.cxInset > 0)
    {
        // draw inset rectangle in lighter grey
        CBrush brInset(RGB(128, 128, 128));
        CRect rect;
        rect.top = m_info.yInset * m_cyCell;
        rect.bottom = rect.top + m_info.cyInset * m_cyCell;
        rect.left = m_info.xInset * m_cxCell;
        rect.right = rect.left + m_info.cxInset * m_cxCell;

        pdc->FrameRect(rect, &brInset);

    }
    else if (m_info.cxInset < 0)
    {
        // draw cross grid
        CBrush brInset(RGB(128, 128, 128));
        int cxSubGrid = -m_info.cxInset;
        int cySubGrid = -m_info.cyInset;

        for (int dy = 0; dy < m_info.gridY; dy += cySubGrid)
        {
            CRect rect2;
            rect2.top = dy * m_cyCell;
            rect2.bottom = rect2.top + cySubGrid * m_cyCell;
            for (int dx = 0; dx < m_info.gridX; dx += cxSubGrid)
            {
                rect2.left = dx * m_cxCell;
                rect2.right = rect2.left + cxSubGrid * m_cxCell;
                pdc->FrameRect(rect2, &brInset);
            }
        }

    }
    EndPaint(&ps);
}


/////////////////////////////////////////////////////////////////////////////
// CEditor dialog


inline int WhichDialogTemplate(enum EDIT_MODE mode)
{

    if (mode == EM_WORLD || mode == EM_WORLD_ADVANCED)
        return IDD_EDITOR_WORLD;
    else if (mode == EM_SUPERROOMS)
        return IDD_EDITOR_SUPERROOMS;
    else if (mode == EM_NEIGHROOM)
        return IDD_EDITOR_NEIGHROOM;
    else if (mode == EM_ROOMS)
        return IDD_EDITOR_ROOMS;
    else if (mode == EM_BEDROOM)
        return IDD_EDITOR_BEDROOM;
    else if (mode == EM_EQUIP)
        return IDD_EDITOR_EQUIP;
    else
        return IDD_EDITOR_INVENT;
}

CEditor::CEditor(CWnd* pParent, enum EDIT_MODE mode, GRID_INFO const* info, int nGrid)
    : CDialog(WhichDialogTemplate(mode), pParent)
{
    m_mode = mode;
    m_info = info; // for OnInitDialog init
    m_tilemap = NULL;
    m_holemap = NULL;

    m_nGrids = nGrid;

    m_activeGrid = NULL;
    m_bNoAutoPlace = false;
    m_action = ACTION_PLACE;
    m_codePlace = 0x1518;    // apple
}

void CEditor::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CEditor)
    DDX_Control(pDX, IDC_CURINFO, m_infoText);
    DDX_Control(pDX, IDC_TREE1, m_partTree);
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEditor, CDialog)
    //{{AFX_MSG_MAP(CEditor)
    ON_BN_CLICKED(IDC_IDENT, OnModeIdent)
    ON_BN_CLICKED(IDC_PLACE, OnModePlace)
    ON_BN_CLICKED(IDC_DELETE, OnModeDelete)
    ON_WM_LBUTTONDOWN()
    ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnSelchangedTree)
    ON_WM_LBUTTONUP()
    ON_WM_MOUSEMOVE()
    ON_WM_RBUTTONDOWN()
    ON_WM_RBUTTONUP()
    ON_BN_CLICKED(IDC_REMOVE_WEEDS, OnRemoveWeeds)
    ON_BN_CLICKED(IDC_REMOVE_STRAYS, OnRemoveStrays)
    ON_BN_CLICKED(IDC_REMOVE_PLANTS, OnRemovePlants)
    ON_BN_CLICKED(IDC_REMOVE_ROCKS, OnRemoveRocks)
    ON_BN_CLICKED(IDC_REMOVE_BUILDINGS, OnRemoveBuildings)
    ON_BN_CLICKED(IDC_TOGGLEBACK, OnToggleback)
    ON_BN_CLICKED(IDC_BURY_UNBURY, OnModeBuryUnbury)
    ON_BN_CLICKED(IDC_WATER_FLOWERS1, OnWaterFlowers1)
    ON_BN_CLICKED(IDC_WATER_FLOWERS2, OnWaterFlowers2)
    ON_BN_CLICKED(IDC_REPLENISH_FRUIT, OnReplenishFruit)
    ON_BN_CLICKED(IDC_FINDPART, OnFindPart)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditor message handlers

void CEditor::OnOK() 
{
    CDialog::OnOK();
}


struct TAG_DATA
{
    uint16 id;    // or 0xFFFF for special heading
    const char* name;
    const char* name_j; // may be NULL
    HTREEITEM hItem;    // filled in from last use
};

TAG_DATA tagdataTerrainWorld[] =
{
#include "terrain.c_"
};

TAG_DATA tagdataTerrainBuildings[] =
{
#include "buildings.c_"
};

TAG_DATA tagdataItems[] =
{
// #include "items.c_"
#include "items.cj_"
};

TAG_DATA tagdataFeatures[] =
{
//#include "features.c_"
#include "features.cj_"
};

TAG_DATA tagdataTerrainDanger1[] =
{
#include "danger1.c_"
};

TAG_DATA tagdataTerrainDanger2[] =
{
#include "danger2.c_"
};

TAG_DATA tagdataTerrainDanger3[] =
{
#include "danger3.c_"
};

TAG_DATA tagdataTerrainDanger4[] =
{
#include "danger4.c_"
};


static void FillTree(CTreeCtrl& tree, HTREEITEM hTop, TAG_DATA* data)
{
    HTREEITEM hCat = NULL;
    while (data->name != NULL)
    {
        const char* name = data->name;
        if (g_bJpn && data->name_j != NULL)
            name = data->name_j;
        if (data->id == 0xFFFF)
        {
            hCat = tree.InsertItem(name, hTop);
            tree.SetItemData(hCat, 0xFFFF);
            data->hItem = NULL;
        }
        else
        {
            ASSERT(hCat != NULL);
            HTREEITEM hItem = tree.InsertItem(name, hCat);
            tree.SetItemData(hItem, data->id);
            data->hItem = hItem;
        }
        data++;
    }
}

static TAG_DATA const* FindTagData(uint16 code, TAG_DATA const* data)
{
    ASSERT(code != 0xFFFF);
    while (data->name != NULL)
    {
        if (data->id == code)
            return data;
        data++;
    }
    return NULL;
}

BOOL CEditor::OnInitDialog() 
{
    CDialog::OnInitDialog();

    for (int iGrid = 0; iGrid < m_nGrids; iGrid++)
    {
        GRID_INFO const& info = m_info[iGrid];
        CGridCtrl& grid = m_grids[iGrid];
        grid.Init(this, IDC_GRID1 + iGrid, info, info.gridX < 10);

    }
    if (m_tilemap != NULL)
    {
        ASSERT(m_nGrids == 1);
        CGridCtrl& grid = m_grids[0];
        grid.m_tilemap = m_tilemap;
        grid.m_bBackdrop = true;    // on at start
    }
    if (m_holemap != NULL)
    {
        ASSERT(m_nGrids == 1);
        CGridCtrl& grid = m_grids[0];
        grid.m_holemap = m_holemap;
    }

    // fill tree list with possible inputs
    if (m_mode == EM_WORLD || m_mode == EM_WORLD_ADVANCED)
    {
        // Terrain - only available for world map
        HTREEITEM hTop = m_partTree.InsertItem("Terrain");
        m_partTree.SetItemData(hTop, 0xFFFF);
        FillTree(m_partTree, hTop, tagdataTerrainWorld);
    }
    if (m_mode == EM_WORLD_ADVANCED)
    {
        // Advanced Terrain
        HTREEITEM hTop = m_partTree.InsertItem("Houses (DANGER)");
        m_partTree.SetItemData(hTop, 0xFFFF);
        FillTree(m_partTree, hTop, tagdataTerrainBuildings);
    }
    //BLOCK: Items
    {
        HTREEITEM hTop = m_partTree.InsertItem("Items");
        m_partTree.SetItemData(hTop, 0xFFFF);
        FillTree(m_partTree, hTop, tagdataItems);
    }
    //BLOCK: Features
    {
        HTREEITEM hTop = m_partTree.InsertItem("Features");
        m_partTree.SetItemData(hTop, 0xFFFF);
        FillTree(m_partTree, hTop, tagdataFeatures);
    }

    if (m_mode >= EM_INVENTORY_DANGER1 && m_mode <= EM_INVENTORY_DANGER4)
    {
        HTREEITEM hTop = m_partTree.InsertItem("Terrain Items (danger 1)");
        m_partTree.SetItemData(hTop, 0xFFFF);
        FillTree(m_partTree, hTop, tagdataTerrainDanger1);
    }
    if (m_mode >= EM_INVENTORY_DANGER2 && m_mode <= EM_INVENTORY_DANGER4)
    {
        HTREEITEM hTop = m_partTree.InsertItem("Terrain Items (danger 2)");
        m_partTree.SetItemData(hTop, 0xFFFF);
        FillTree(m_partTree, hTop, tagdataTerrainDanger2);
    }
    if (m_mode >= EM_INVENTORY_DANGER3 && m_mode <= EM_INVENTORY_DANGER4)
    {
        HTREEITEM hTop = m_partTree.InsertItem("Terrain Items (danger 3)");
        m_partTree.SetItemData(hTop, 0xFFFF);
        FillTree(m_partTree, hTop, tagdataTerrainDanger3);
    }
    if (m_mode == EM_INVENTORY_DANGER4)
    {
        HTREEITEM hTop = m_partTree.InsertItem("Terrain Items (danger 4)");
        m_partTree.SetItemData(hTop, 0xFFFF);
        FillTree(m_partTree, hTop, tagdataTerrainDanger4);
    }
    OnModeIdent(); // start in identify mode
	if (m_mode != EM_WORLD_ADVANCED)
	{
		CWnd* pbtn = GetDlgItem(IDC_REMOVE_BUILDINGS);
		if (pbtn != NULL)
			pbtn->ShowWindow(FALSE); // very dangerous
	}
    
    return TRUE;
}

static HTREEITEM FindItemName(char* szOut, uint16 code, enum EDIT_MODE mode)
{
    TAG_DATA const* data = NULL;
    szOut[0] = '\0';

    if (code == CODE_BLANK)
    {
        sprintf(szOut, "empty space");
    }
    else if ((code >= 0 && code <= MAX_TERRAIN_CODE) || (code & 0xFF00) == 0xB000)
    {
        // Terrain or maybe snowman
        if (mode == EM_WORLD || mode == EM_WORLD_ADVANCED)
            data = FindTagData(code, tagdataTerrainWorld);
        if (data == NULL && mode >= EM_INVENTORY_DANGER1 && mode <= EM_INVENTORY_DANGER4)
            data = FindTagData(code, tagdataTerrainDanger1);
        if (data == NULL && mode >= EM_INVENTORY_DANGER2 && mode <= EM_INVENTORY_DANGER4)
            data = FindTagData(code, tagdataTerrainDanger2);
        if (data == NULL && mode >= EM_INVENTORY_DANGER3 && mode <= EM_INVENTORY_DANGER4)
            data = FindTagData(code, tagdataTerrainDanger3);
        if (data == NULL && mode == EM_INVENTORY_DANGER4)
            data = FindTagData(code, tagdataTerrainDanger4);
    }
    else if (code >= 0x1000 && code <= 0x156D)
    {
        data = FindTagData(code, tagdataItems);
        if (data == NULL && mode >= EM_INVENTORY_DANGER2 && mode <= EM_INVENTORY_DANGER4)
            data = FindTagData(code, tagdataTerrainDanger2); // has some regular items too
        if (data == NULL && mode >= EM_INVENTORY_DANGER3 && mode <= EM_INVENTORY_DANGER4)
            data = FindTagData(code, tagdataTerrainDanger3); // has some regular items too
        if (data == NULL && mode == EM_INVENTORY_DANGER4)
            data = FindTagData(code, tagdataTerrainDanger4);
    }
    else if (code >= 0x3000 && code <= 0x4BA0+3)
    {
        data = FindTagData(code & ~3, tagdataFeatures);
    }
    else if (IsBuilding(code))
    {
        if (mode == EM_WORLD_ADVANCED)
            data = FindTagData(code, tagdataTerrainBuildings);
        else if (mode == EM_INVENTORY_DANGER4)
            data = FindTagData(code, tagdataTerrainDanger4);
        else
            sprintf(szOut, "house or sign (can not delete)");
    }
    else if (IsWarning(code))
    {
        sprintf(szOut, "surrounding area not available");
    }
    else
    {
        sprintf(szOut, "Other $%04X", code);
    }

    if (data != NULL)
    {
        // item in tree list - point to it
        strcpy(szOut, data->name);
        if (g_bJpn && data->name_j != NULL)
            strcpy(szOut, data->name_j);
        return data->hItem;
    }
    else if (szOut[0] == '\0')
    {
        sprintf(szOut, "Unknown or dangerous ($%04X)", code);
    }
    return NULL;
}


void CEditor::OnModeIdent() 
{
    m_action = ACTION_IDENT;
    m_infoText.SetWindowText("click on map to see what's there");
    m_partTree.SelectItem(NULL);

    CheckDlgButton(IDC_IDENT, TRUE);
    CheckDlgButton(IDC_PLACE, FALSE);
    CheckDlgButton(IDC_DELETE, FALSE);
    CheckDlgButton(IDC_BURY_UNBURY, FALSE);
}

void CEditor::OnModePlace() 
{
    m_action = ACTION_PLACE;
    char szItem[64];
    HTREEITEM hItem = FindItemName(szItem, m_codePlace, m_mode);
    char szT[64];
    sprintf(szT, "click on map to place '%s'", szItem);
    m_infoText.SetWindowText(szT);
    m_partTree.SelectItem(hItem);

    CheckDlgButton(IDC_IDENT, FALSE);
    CheckDlgButton(IDC_PLACE, TRUE);
    CheckDlgButton(IDC_DELETE, FALSE);
    CheckDlgButton(IDC_BURY_UNBURY, FALSE);
}

void CEditor::OnModeDelete() 
{
    m_action = ACTION_PLACE;
    m_codePlace = CODE_BLANK;
    m_infoText.SetWindowText("click on map to clear items");

    CheckDlgButton(IDC_IDENT, FALSE);
    CheckDlgButton(IDC_PLACE, FALSE);
    CheckDlgButton(IDC_DELETE, TRUE);
    CheckDlgButton(IDC_BURY_UNBURY, FALSE);
}

void CEditor::OnToggleback() 
{
    CGridCtrl& grid = m_grids[0]; // only 
    grid.m_bBackdrop = !grid.m_bBackdrop;
    grid.InvalidateRect(NULL, TRUE);
}

void CEditor::OnModeBuryUnbury() // mode
{
    m_action = ACTION_BURY;
    m_codePlace = CODE_BLANK;
    m_infoText.SetWindowText("click on map to bury/unbury items");

    CheckDlgButton(IDC_IDENT, FALSE);
    CheckDlgButton(IDC_PLACE, FALSE);
    CheckDlgButton(IDC_DELETE, FALSE);
    CheckDlgButton(IDC_BURY_UNBURY, TRUE);
}

void CEditor::OnGridClick(CGridCtrl* pFrom, int xGrid, int yGrid)
{
    if (xGrid < 0 || xGrid >= pFrom->m_info.gridX)
        return;
    if (yGrid < 0 || yGrid >= pFrom->m_info.gridY)
        return;

    uint16* codePtr = &pFrom->m_info.array[yGrid * pFrom->m_info.gridX + xGrid];
    uint16 codeOld = *codePtr;
    uint8* phole = NULL;
    uint8 holeMask = 0;

    if (m_holemap != NULL)
    {
        ASSERT((pFrom->m_info.gridX % 8) == 0);
        phole = m_holemap + yGrid * (pFrom->m_info.gridX / 8) + (xGrid / 8);
        holeMask = 1 << (xGrid & 7);
    }
    if (m_action == ACTION_IDENT)
    {
        // Identify item clicked
        // TRACE("Ident %d,%d = $%04X\n", xGrid, yGrid, code);
        char szItem[64];
        HTREEITEM hItem = FindItemName(szItem, codeOld, m_mode);
        char szT[64];
        sprintf(szT, "You clicked on: $%04X = %s", codeOld, szItem);
        m_infoText.SetWindowText(szT);

        // will hopefully scroll tree list into view
        m_bNoAutoPlace = true;
        m_partTree.SelectItem(hItem);
        m_bNoAutoPlace = false;

        m_codePlace = codeOld; // next one to place
        if (m_mode != EM_WORLD_ADVANCED && m_mode != EM_INVENTORY_DANGER4)
        {
            if (IsBuilding(m_codePlace))
                m_codePlace = CODE_BLANK;
        }
    }
    else if (m_action == ACTION_PLACE)
    {
        // Place
        if (m_mode != EM_WORLD_ADVANCED)
        {
            if (IsWarning(m_codePlace) || m_codePlace == 0xFFFF)
            {
                AfxMessageBox("Internal error - can't place that object");
                m_activeGrid = NULL;
                return;
            }
            if (IsBuilding(m_codePlace) && m_mode != EM_INVENTORY_DANGER4)
            {
                AfxMessageBox("Can not place house or signpost");
                m_activeGrid = NULL;
                return;
            }
            if (IsBuilding(codeOld) && m_mode != EM_INVENTORY_DANGER4) 
            {
                AfxMessageBox("Can not delete house or signpost");
                m_activeGrid = NULL;
                return;
            }
        }

        if (IsWarning(codeOld))
        {
            // but place them anyway
            if (m_mode == EM_WORLD)
            {
                AfxMessageBox("Placing items close to a house will not remain\n"
                        "when the game runs, walls will be restored");
                m_activeGrid = NULL;
            }
            else if (m_mode == EM_ROOMS)
            {
                // warn a few times
                static int s_nWarn = 0;
                if (s_nWarn < 4)
                {
                    AfxMessageBox("That's the space next to a large item\n"
                        "if you place two items close together, only one will show");
                    s_nWarn++;
                }
                m_activeGrid = NULL;
            }
            // no warnings for advanced modes
        }
        *codePtr = m_codePlace;
        if (phole != NULL)
            *phole = (*phole) & ~holeMask; // unburry when added
        pFrom->InvalidateRect(NULL, TRUE);
    }
    else if (m_action == ACTION_BURY)
    {
        if (phole != NULL)
        {
            if ((codeOld & 0xF000) == 0x1000 || (codeOld & 0xF000) == 0x3000 || (codeOld & 0xF000) == 0x4000)
            {
                // items or features only
                *phole ^= holeMask;    // toggle
            }
            else
            {
                *phole &= ~holeMask;    // turn off (terrain or other)
            }
            pFrom->InvalidateRect(NULL, TRUE); // redraw all
        }
    }
    else
    {
        ASSERT(FALSE);    // WTF
    }
}

void CEditor::OnLButtonDown(UINT nFlags, CPoint point) 
{
// since the grid subclasses a static text control - the container gets all the extra clicks...
    m_activeGrid = NULL;
    ClientToScreen(&point);
    CRect rect;

    for (int iGrid = 0; iGrid < m_nGrids; iGrid++)
    {
        CGridCtrl& grid = m_grids[iGrid];
        grid.GetWindowRect(rect);
        if (rect.PtInRect(point))
        {
            grid.ScreenToClient(&point);
            if (point.x >= 0 && point.x < grid.m_cxCell * grid.m_info.gridX &&
                point.y >= 0 && point.y < grid.m_cyCell * grid.m_info.gridY)
            {
                m_activeGrid = &grid;
                OnGridClick(&grid, point.x/grid.m_cxCell, point.y/grid.m_cyCell);
                return; // hit one
            }
        }
    }
}
void CEditor::OnRButtonDown(UINT nFlags, CPoint point) 
{
    // place and advance
    OnLButtonDown(nFlags, point);

    if (m_activeGrid != NULL)
    {
        // something was placed
        m_activeGrid = NULL;    // don't repeat
        uint16 codeNext = m_codePlace + 1;
        if ((codeNext & 0xF000) == 0x3000 || (codeNext & 0xF000) == 0x4000)
        {
            // jump by 4s
            codeNext = (codeNext+3) & ~3;
        }
        char szItem[64];    // ignored
        HTREEITEM hItem = FindItemName(szItem, codeNext, m_mode);
        if (hItem != NULL)
        {
            // save to advance
            m_codePlace = codeNext;
            OnModePlace();
        }
    }
}


void CEditor::OnLButtonUp(UINT nFlags, CPoint point) 
{
    m_activeGrid = NULL;
}
void CEditor::OnRButtonUp(UINT nFlags, CPoint point) 
{
    m_activeGrid = NULL;
}

void CEditor::OnMouseMove(UINT nFlags, CPoint point) 
{
    if (m_activeGrid != NULL && m_action != ACTION_BURY)
    {
        OnLButtonDown(nFlags, point);
    }    
}

void CEditor::OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
    NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

    HTREEITEM hItem = m_partTree.GetSelectedItem();
    if (!m_bNoAutoPlace && hItem != NULL)
    {
        DWORD code = m_partTree.GetItemData(hItem);
        if (code >= 0 && code < 0xFFFF)
        {
            // go into place mode
            m_codePlace = (uint16)code;
            OnModePlace();
        }
    }
    *pResult = 0;
}




void CEditor::OnRemoveWeeds() 
{
    ASSERT(m_mode == EM_WORLD || m_mode == EM_WORLD_ADVANCED);

    CGridCtrl& grid = m_grids[0]; // only 
    uint16* pw = grid.m_info.array;
    int cw = grid.m_info.gridY * grid.m_info.gridX;

    int nRemoved = 0;
    // regular de-weed
    while (cw--)
    {
        uint16 code = *pw;
        if (IsWeed(code))
        {
            *pw = CODE_BLANK;
            nRemoved++;
        }
        pw++;
    }
    grid.InvalidateRect(NULL, TRUE);
    CString str;
    str.Format("Removed %d weeds", nRemoved);
    AfxMessageBox(str);
}



void CEditor::OnRemoveStrays() 
{
    ASSERT(m_mode == EM_WORLD || m_mode == EM_WORLD_ADVANCED);
    CGridCtrl& grid = m_grids[0]; // only 

    if (m_holemap == NULL)
    {
        AfxMessageBox("Sorry not supported"); // REVIEW DEPRECATED
        return;
    }

    int nRemoved = 0;
    int nWereBuried = 0;

    uint16* pw = grid.m_info.array;
    uint8* phole = grid.m_holemap;
    ASSERT((grid.m_info.gridX % 8) == 0);
    uint8 holeMask = 1;

    for (int row = 0; row < grid.m_info.gridY; row++)
    {
        for (int col = 0; col < grid.m_info.gridX; col++)
        {
            uint16 code = *pw;

            if ((code & 0xF000) == 0x1000 || (code & 0xF000) == 0x3000 || (code & 0xF000) == 0x4000)
            {
                // remove it
                *pw = CODE_BLANK;
                if (*phole & holeMask)
                {
                    *phole &= ~holeMask;
                    nWereBuried++;
                }
                nRemoved++;
            }
            pw++;
            holeMask = holeMask << 1;
            if (holeMask == 0)
            {
                phole++;
                holeMask = 1;
            }
        }
    }

    grid.InvalidateRect(NULL, TRUE);
    CString str;
    str.Format("Removed %d stray items and features\n(%d were buried)", nRemoved, nWereBuried);
    AfxMessageBox(str);
}


void CEditor::OnRemovePlants() 
{
    ASSERT(m_mode == EM_WORLD || m_mode == EM_WORLD_ADVANCED);
    CGridCtrl& grid = m_grids[0]; // only 
    uint16* pw = grid.m_info.array;
    int cw = grid.m_info.gridY * grid.m_info.gridX;

    int nRemoved = 0;

    // more explicit control for testing
    bool bRemoveTrees = AfxMessageBox("Remove all trees?", MB_YESNO) == IDYES;
    bool bRemoveFlowers = AfxMessageBox("Remove all flowers?", MB_YESNO) == IDYES;
    bool bRemovePatterns = AfxMessageBox("Remove all patterns?", MB_YESNO) == IDYES;

    while (cw--)
    {
        uint16 code = *pw;
        if (bRemoveTrees)
        {
            if ((code >= 0x25 && code <= 0x6D) ||
                (code >= 0x00C7 && code <= 0x00D2))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }

        if (bRemoveFlowers)
        {
            if ((code >= 0 && code < 0x25) ||
                (code >= 0x6E && code <= 0xA5))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        if (bRemovePatterns)
        {
            if (code >= 0xA7 && code < 0xC6)
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        pw++;
    }

    grid.InvalidateRect(NULL, TRUE);
    CString str;
    str.Format("Removed %d flowers&trees&patterns", nRemoved);
    AfxMessageBox(str);
}

void CEditor::OnRemoveRocks() 
{
    ASSERT(m_mode == EM_WORLD || m_mode == EM_WORLD_ADVANCED);
    CGridCtrl& grid = m_grids[0]; // only 
    uint16* pw = grid.m_info.array;
    int cw = grid.m_info.gridY * grid.m_info.gridX;

    int nRemoved = 0;
    while (cw--)
    {
        uint16 code = *pw;
        if (IsRock(code))
        {
            *pw = CODE_BLANK;
            nRemoved++;
        }
        pw++;
    }
    grid.InvalidateRect(NULL, TRUE);
    CString str;
    str.Format("Removed %d rocks", nRemoved);
    AfxMessageBox(str);
}

void CEditor::OnReplenishFruit()
{
    ASSERT(m_mode == EM_WORLD || m_mode == EM_WORLD_ADVANCED);
    CGridCtrl& grid = m_grids[0]; // only 
    uint16* pw = grid.m_info.array;
    int cw = grid.m_info.gridY * grid.m_info.gridX;

    int nPeach0 = 0;
    int nApple0 = 0;
    int nOrange0 = 0;
    int nPear0 = 0;
    int nCherry0 = 0;
    int nNut0 = 0;
    while (cw--)
    {
        uint16 code = *pw;
        int codeNew2 = code;
        if (code >= 0x34 && code <= 0x36)
        {
            *pw = code = 0x33;
            nPeach0++;
        }
        int codeNew3 = code;
        if (code >= 0x3C && code <= 0x3E)
        {
            *pw = code = 0x3B;
            nApple0++;
        }
        int codeNew4 = code;
        if (code >= 0x44 && code <= 0x46)
        {
            *pw = code = 0x43;
            nOrange0++;
        }
        int codeNew5 = code;
        if (code >= 0x4C && code <= 0x4E)
        {
            *pw = code = 0x4B;
            nPear0++;
        }
        int codeNew6 = code;
        if (code >= 0x54 && code <= 0x56)
        {
            *pw = code = 0x53;
            nCherry0++;
        }
        int codeNew7 = code;
        if (code >= 0xCD && code <= 0xCF)
        {
            *pw = code = 0xCC;
            nNut0++;
        }
        pw++;
    }
    grid.InvalidateRect(NULL, TRUE);
    CString str;
    CString strT;
    str.Format("%d Fruit tree(s) replenished\n", nPeach0+nApple0+nOrange0+nPear0+nCherry0+nNut0);
    strT.Format("\n%d Peach", nPeach0);
    str += strT;
    strT.Format("\n%d Apple", nApple0);
    str += strT;
    strT.Format("\n%d Orange", nOrange0);
    str += strT;
    strT.Format("\n%d Pear", nPear0);
    str += strT;
    strT.Format("\n%d Cherry", nCherry0);
    str += strT;
    strT.Format("\n%d Coconut", nNut0);
    str += strT;
    AfxMessageBox(str);
}



void CEditor::OnRemoveBuildings()
{
    if (m_mode != EM_WORLD_ADVANCED)
    {
		// should never happen
        AfxMessageBox("You must use the advanced world editor to use this feature.");
        return;
    }

    CGridCtrl& grid = m_grids[0]; // only 
    uint16* pw = grid.m_info.array;
    int cw = grid.m_info.gridY * grid.m_info.gridX;

    int nRemoved = 0;
    int nRemoved1 = 0;
    
    bool bRemoveCenter = AfxMessageBox("Remove all Town Centers?", MB_YESNO) == IDYES;
    bool bRemoveMuseum = AfxMessageBox("Remove all Museums?", MB_YESNO) == IDYES;
    bool bRemoveGate = AfxMessageBox("Remove all Gate Houses?", MB_YESNO) == IDYES;
    bool bRemoveNook = AfxMessageBox("Remove all Nooks?", MB_YESNO) == IDYES;
    bool bRemoveAbles = AfxMessageBox("Remove all Sister's Stores?", MB_YESNO) == IDYES;
    bool bRemoveHouse = AfxMessageBox("Remove all Player Houses?", MB_YESNO) == IDYES;
    bool bRemoveNeighbor = AfxMessageBox("Remove all Neighbor Houses?", MB_YESNO) == IDYES;
    bool bRemoveBoard = AfxMessageBox("Remove all Bulletin Boards?", MB_YESNO) == IDYES;
    bool bRemoveSign = AfxMessageBox("Remove all Signs?", MB_YESNO) == IDYES;
    bool bRemoveSpecial = AfxMessageBox("Remove all Special Buildings?", MB_YESNO) == IDYES;
    bool bRemoveOther = AfxMessageBox("Remove all other buildings and 'seeds'?", MB_YESNO) == IDYES;
    bool bRemoveWalls = AfxMessageBox("Remove all Surrounding Walls?", MB_YESNO) == IDYES;

        while (cw--)
    {
        uint16 code = *pw;
        if (bRemoveCenter)
        {
            if ((code == 0x5000))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }

        if (bRemoveGate)
        {
            if ((code == 0x500B))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        if (bRemoveAbles)
        {
            if ((code == 0x500C))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        if (bRemoveNook)
        {
            if ((code >= 0x500D && code <= 0x5010))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        if (bRemoveMuseum)
        {
            if ((code == 0x5011))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }

        if (bRemoveBoard)
        {
            if ((code == 0x501C))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        if (bRemoveSign)
        {
            if ((code == 0x500A))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        if (bRemoveHouse)
        {
            if ((code >= 0x5014 && code <= 0x501A))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        if (bRemoveNeighbor)
        {
            if ((code >= 0x5001 && code <= 0x5008))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        if (bRemoveSpecial)
        {
            if ((code == 0x5012 || code == 0x5013 || code == 0x501E || code == 0x501D || code == 0x5020 || code == 0x5021))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        if (bRemoveOther)
        {
            if ((code >= 0x5022 && code <= 0x502F || code == 0x5009 || code == 0x501B || code == 0x501F))
            {
                *pw = CODE_BLANK;
                nRemoved++;
            }
        }
        if (bRemoveWalls)
        {
            if ((code == 0xF030))
            {
                *pw = CODE_BLANK;
                nRemoved1++;
            }
        }
        pw++;
    }

    grid.InvalidateRect(NULL, TRUE);
    CString str;
    CString strT;
    str.Format("Removed %d buildings(s)\n", nRemoved);
    {
        strT.Format("Removed %d surrounding wall(s)", nRemoved1);
        str += strT;
    }
}



void CEditor::OnWaterFlowers1()
{
    ASSERT(m_mode == EM_WORLD || m_mode == EM_WORLD_ADVANCED);
    CGridCtrl& grid = m_grids[0]; // only 
    uint16* pw = grid.m_info.array;
    int cw = grid.m_info.gridY * grid.m_info.gridX;

    // like going around watering things
    int nWater0 = 0;
    int nWater1 = 0;
    int nRaff0 = 0;
    int nRaff1 = 0;
    int nGold0 = 0;
    while (cw--)
    {
        uint16 code = *pw;
        int codeNew = code;
        if (code >= 0 && code <= 0x1A)
        {
            *pw = code + 0x8A;
            nWater0++;
        }
        else if (code == 0x1B)
        {
            // regular Raff
            nRaff0++;
        }
        else if (code == 0x1C)
        {
            // gold roses
            nGold0++;
        }
        else if (code >= 0x6E && code <= 0x88)
        {
            *pw = code - 0x6E + 0x8A;
            nWater1++;
        }
        else if (code == 0x89)
        {
            // parched Raff
            nRaff1++;
        }
        else if (code >= 0x8A && code <= 0xA4)
        {
            // recently watered
        }
        else if (code >= 0xA5)
        {
            // recently watered black->gold
        }
        pw++;
    }
    grid.InvalidateRect(NULL, TRUE);
    CString str;
    CString strT;
    str.Format("Watered %d flowers\n(%d were parched)", nWater0+nWater1, nWater1);
    if (nGold0 > 0)
    {
        strT.Format("\n%d gold roses were not watered", nGold0);
        str += strT;
    }
    if (nRaff0 > 0)
    {
        strT.Format("\n%d regular rafflesia were not watered", nRaff0);
        str += strT;
    }
    if (nRaff1 > 0)
    {
        strT.Format("\n%d parched rafflesia were not watered", nRaff1);
        str += strT;
    }
    AfxMessageBox(str);
}

void CEditor::OnWaterFlowers2() 
{
    ASSERT(m_mode == EM_WORLD || m_mode == EM_WORLD_ADVANCED);
    CGridCtrl& grid = m_grids[0]; // only 
    uint16* pw = grid.m_info.array;
    int cw = grid.m_info.gridY * grid.m_info.gridX;

    // turn them into live plants (but may whither later)
    int nRevive1 = 0;
    int nRevive2 = 0;
    while (cw--)
    {
        uint16 code = *pw;
        int codeNew = code;
        if (code >= 0 && code <= 0x1C)
        {
            // already regular (including raff and golden)
        }
        else if (code >= 0x6E && code <= 0x89)
        {
            // parched, including raff
            *pw = code - 0x6E + 0;
            nRevive1++;
        }
        else if (code >= 0x8A && code <= 0xA4)
        {
            // recently watered
            *pw = code - 0x8A + 0;
            nRevive2++;
        }
        else if (code >= 0xA5)
        {
            // recently watered black->gold - ignore, let the game do it
        }
        pw++;
    }
    grid.InvalidateRect(NULL, TRUE);
    CString str;
    CString strT;
    str.Format("Revived %d flowers\n(%d had been watered)", nRevive1+nRevive2, nRevive2);
    AfxMessageBox(str);
}

/////////////////////////////////////////////////////////////////////////////
// Find parts by name

class CFindPartDlg : public CDialog
{
// Construction
public:
    CFindPartDlg(CWnd* pParent = NULL);   // standard constructor
    CWnd* m_pCenterOver;

// Dialog Data
    //{{AFX_DATA(CFindPartDlg)
    enum { IDD = IDD_FIND };
    CString    m_strFind;
    //}}AFX_DATA


// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CFindPartDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL
    virtual BOOL CheckAutoCenter() { return m_pCenterOver == NULL; }

// Implementation
protected:
    //{{AFX_MSG(CFindPartDlg)
    virtual BOOL OnInitDialog();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


CFindPartDlg::CFindPartDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CFindPartDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CFindPartDlg)
    m_strFind = _T("");
    //}}AFX_DATA_INIT
    m_pCenterOver = NULL;
}


void CFindPartDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CFindPartDlg)
    DDX_Text(pDX, IDC_EDIT1, m_strFind);
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFindPartDlg, CDialog)
    //{{AFX_MSG_MAP(CFindPartDlg)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CFindPartDlg::OnInitDialog() 
{
    CDialog::OnInitDialog();
    if (m_pCenterOver != NULL)
        CenterWindow(m_pCenterOver);    
    return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
static HTREEITEM FindTreeSubItem(CTreeCtrl& tree, HTREEITEM hItemCur, const char* szFind, int nTry)
{
    CString strFind = szFind;
    strFind.MakeLower();    // for compare

    while (1)
    {
        ASSERT(hItemCur != NULL);
        ASSERT(!tree.ItemHasChildren(hItemCur));
        CString strCmp = tree.GetItemText(hItemCur);
        strCmp.MakeLower();
        if (strCmp.Find(strFind) >= 0 && nTry > 0)
        {
            // found it
            return hItemCur;
        }
        nTry++;
        HTREEITEM hNext = tree.GetNextSiblingItem(hItemCur);
        if (hNext == NULL)
        {
            // go up the tree
            HTREEITEM hParent = tree.GetParentItem(hItemCur);
            if (hParent == NULL)
            {
                // no more
                return NULL;
            }
            hNext = tree.GetNextSiblingItem(hParent);
            if (hNext != NULL)
            {
                // got one up one level
                hParent = hNext;
                ASSERT(tree.ItemHasChildren(hParent));
                hNext = tree.GetChildItem(hParent);    // first child
            }
            else
            {
                // go up two levels, and back down
                hParent = tree.GetParentItem(hParent);
                ASSERT(hParent != NULL);
                hParent = tree.GetNextSiblingItem(hParent);
                if (hParent == NULL)
                    return NULL;
                ASSERT(tree.ItemHasChildren(hParent));
                hParent = tree.GetChildItem(hParent);    // first child
                ASSERT(tree.ItemHasChildren(hParent));
                hNext = tree.GetChildItem(hParent);    // first child
            }
        }
        hItemCur = hNext;
    }
}

void CEditor::OnFindPart() 
{
    CFindPartDlg dlg;

    // locate dialog over button
    dlg.m_pCenterOver = GetDlgItem(IDC_FINDPART);

    static CString s_strLastFind;
    dlg.m_strFind = s_strLastFind;
    s_strLastFind.Empty();
    if (dlg.DoModal() != IDOK)
        return;
    if (dlg.m_strFind.IsEmpty())
        return;

    // find in the parts listbox
    HTREEITEM hItemStart = m_partTree.GetSelectedItem();
    if (hItemStart == NULL)
        hItemStart = m_partTree.GetRootItem();
    while (m_partTree.ItemHasChildren(hItemStart))
        hItemStart = m_partTree.GetChildItem(hItemStart); // walk to first

    HTREEITEM hItem = FindTreeSubItem(m_partTree, hItemStart, dlg.m_strFind, 0);
    if (hItem != NULL)
    {
        m_partTree.SelectItem(hItem); // will enter ModePlace
        s_strLastFind = dlg.m_strFind;
    }
    else
    {
        // not found
        m_partTree.SelectItem(hItem);
        OnModeIdent();
        AfxMessageBox(IDS_NO_MORE_FOUND);
    }
}

/////////////////////////////////////////////////////////////////////////////
