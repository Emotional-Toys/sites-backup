// HouseDlg.cpp : implementation file
//

#include "stdafx.h"
#include "animalmap.h"
#include "HouseDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHouseDlg dialog


CHouseDlg::CHouseDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CHouseDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CHouseDlg)
    m_housesize = -1;
    m_housecolor = -1;
    //}}AFX_DATA_INIT
}


void CHouseDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CHouseDlg)
    DDX_CBIndex(pDX, IDC_HOUSESIZE, m_housesize);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHouseDlg, CDialog)
    //{{AFX_MSG_MAP(CHouseDlg)
        // NOTE: the ClassWizard will add message map macros here
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
