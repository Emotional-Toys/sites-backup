// emodlg.cpp
//  Emotion editing

#include "stdafx.h"
#include "animalmap.h"
#include "romsave.h"

#include "maindlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

class CEmoDlg : public CDialog
{
// Construction
public:
    CEmoDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    int m_emos[4];
    //{{AFX_DATA(CEmoDlg)
    enum { IDD = IDD_EMOEDIT };
    //}}AFX_DATA


// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CEmoDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:

    // Generated message map functions
    //{{AFX_MSG(CEmoDlg)
    virtual BOOL OnInitDialog();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////


CEmoDlg::CEmoDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CEmoDlg::IDD, pParent)
{
}

void CEmoDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CEmoDlg)
    //}}AFX_DATA_MAP
    DDX_CBIndex(pDX, IDC_DROPLIST_EMO1, m_emos[0]);
    DDX_CBIndex(pDX, IDC_DROPLIST_EMO2, m_emos[1]);
    DDX_CBIndex(pDX, IDC_DROPLIST_EMO3, m_emos[2]);
    DDX_CBIndex(pDX, IDC_DROPLIST_EMO4, m_emos[3]);
}

BEGIN_MESSAGE_MAP(CEmoDlg, CDialog)
    //{{AFX_MSG_MAP(CEmoDlg)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////

static const char* g_rgszEmotE[] =
{
"(nothing)",
" 1 anger",
" 2 shock",
" 3 laughter",
" 4 surprise",
" 5 rage",
" 6 distress",
" 7 fear",
" 8 sorrow",
" 9 blankness",
"10 joy",
"11 confusion",
"12 inspiration",
"13 happiness",
"14 thought",
"15 sadness",
"16 disappointment",
"17 scheming",
"18 fatigue",
"19 love",
"20 contentment",
"21 irritation",
"22 discontent",
"23 shyness",
"24 disbelief",
"25 agreement",
"26 approval",
"27 acceptance",
"28 exasperation",
"29 realization",
"30 (machine gun motion left-to-right)",
"31 (stabbing motion right-arm)",
"32 (machine gun motion right-to-left)",
"33 (throws hands in air, no SFX)",
"34 (strange posture, no SFX)",
"35 (slight shift, short plunk sound)",
"36 (like surprise)",
"37 (like confusion)",
"38 (flap arms + fairy dust music)",
"39 (fatigue-like)",
"40 (lie down on ground asleep, yawn)",
"41 (get out of hole)",
"42 (fall in a hole)",
"43 (blankness in-a-hole)",
"44 (realization in-a-hole)",
"45 (get out of hole #2)",
"46 (fall in hole)",
"47 (fall in hole and squirm)",
"48 (sitting on something)",
"49 (sitting on something, feet fly in air)",
"50 (smell underarm?)",
"51 (levitation)",
"52 (floating)",
"53 (end floating, SFX)",
"54 (more floating bits)",
"55 (more floating bits)",
"56 (more floating bits)",
"57 (quick surprise, floating)",
"58 (quick discontent-like)",
"59 (quick distress-like)",
};

struct SHORT_J_NAME
{
    wchar_t wchars[8];
};

static const SHORT_J_NAME g_rgnameEmoJ[] = // if NULL, use E version
{
    { 0 },
// Japanese names in UNICODE for standard ones
 { 0x304a, 0x3053, 0x308b, 0 },
 { 0x30b7, 0x30e7, 0x30c3, 0x30af, 0 },
 { 0x308f, 0x3089, 0x3046 , 0 },
 { 0x304a, 0x3069, 0x308d, 0x304f, 0 },
 { 0x3052, 0x304d, 0x3069, 0x3059, 0x308b, 0 },
 { 0x3042, 0x305b, 0x308b, 0 },
 { 0x30d6, 0x30eb, 0x30d6, 0x30eb, 0x30fb, 0x30fb, 0x30fb, 0 },
 { 0x306a, 0x304f, 0 },
 { 0x30d2, 0x30e5, 0x30fc , 0 },
 { 0x30cf, 0x30c3, 0x30d4, 0x30fc, 0 },
 { 0x306f, 0x3066, 0 },
 { 0x3072, 0x3089, 0x3081, 0x304d , 0 },
 { 0x3046, 0x304d, 0x3046, 0x304d, 0 },
 { 0x306a, 0x3084, 0x3080, 0 },
 { 0x304a, 0x3061, 0x3053, 0x3080 , 0 },
 { 0x3057, 0x3064, 0x308c, 0x3093, 0 },
 { 0x308f, 0x308b, 0x3060, 0x304f, 0x307f, 0 },
 { 0x306d, 0x307c, 0x3051, 0 },
 { 0x30e9, 0x30d6, 0 },
 { 0x307b, 0x307b, 0x3048, 0x3080, 0 },
 { 0x3075, 0x304d, 0x3052, 0x3093 , 0 },
 { 0x3053, 0x307e, 0x308b, 0 },
 { 0x30c6, 0x30ec, 0x308b, 0 },
 { 0x3072, 0x304f, 0 },
 { 0x3046, 0x306a, 0x305a, 0x304f , 0 },
 { 0x306f, 0x304f, 0x3057, 0x3085, 0 },
 { 0x30e4, 0x30ec, 0x30e4, 0x30ec, 0 },
 { 0x30bf, 0x30e1, 0x30a4, 0x30ad, 0 },
 { 0x30d3, 0x30c3, 0x30af, 0x30ea, 0 },
};




/////////////////////////////////////////////////////////////////////////////

void CMainDlg::OnEditEditEmotionsResident() 
{
    int offset = GetResidentDelta() + EORJ(0x21F8, 0x1C84);

    CEmoDlg dlg;
    int i;
    for (i = 0; i < 4; i++)
    {
        uint8 b = g_romsave.GetBufferB(offset + i);
        if (b == 0xFF)
            b = 0;  // nothing
        if (b > 59)
        {
            AfxMessageBox("using unknown emotion - editing not supported");
            return;
        }
        dlg.m_emos[i] = b; // zero=>nothing
    }
    if (dlg.DoModal() != IDOK)
        return;

    for (i = 0; i < 4; i++)
    {
        uint8 b = (uint8)dlg.m_emos[i];
        if (b == 0)
            b = 0xFF;
        g_romsave.WriteB(offset + i, b);
    }
}

////////////////////////////////////////////////////////////////////////

BOOL CEmoDlg::OnInitDialog() 
{
    for (int iBox = 0; iBox < 4; iBox++)
    {
        CComboBox& box = *(CComboBox*)GetDlgItem(IDC_DROPLIST_EMO1 + iBox);
        for (int iEmo = 0; iEmo <= 59; iEmo++)
        {
            const char* szE = g_rgszEmotE[iEmo];
            const SHORT_J_NAME* nameJ = NULL;
            if (g_bJpn && iEmo >= 1 && iEmo <= 29)
                nameJ = &g_rgnameEmoJ[iEmo];

            bool bAdded = false;
            if (nameJ != NULL && nameJ->wchars[0] != 0)
            {
                char szJIS[64];
                int cb = WideCharToMultiByte(CP_OEMCP, 0, nameJ->wchars, wcslen(nameJ->wchars), szJIS, 64, NULL, NULL);
                if (cb > 0)
                {
                    szJIS[cb] = '\0';
                    char szOut[128];
                    sprintf(szOut, "%2d %s", iEmo, szJIS);
                    box.AddString(szOut);    // shift-jis
                    bAdded = true;
                }
            }
            if (!bAdded)
                box.AddString(szE);
        }
    }
        
    CDialog::OnInitDialog(); // does data exchange
    
    return TRUE;
}

////////////////////////////////////////////////////////////////////////
