// facedlg.h : header file
//  Tweeking players face/hair/tan

/////////////////////////////////////////////////////////////////////////////
// CFaceDlg dialog

class CFaceDlg : public CDialog
{
// Construction
public:
    CFaceDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(CFaceDlg)
    enum { IDD = IDD_FACEDLG };
    int        m_faceType;
    int        m_hairColor;
    int        m_hairStyle;
    int        m_tanLevel;
    int        m_gender;
    //}}AFX_DATA


// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CFaceDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:

    // Generated message map functions
    //{{AFX_MSG(CFaceDlg)
        // NOTE: the ClassWizard will add member functions here
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
