// compress.cpp
// Custom compression used by 'animala' trainer

#include "stdafx.h"
#include "romsave.h"

/////////////////////////////////////////////////////////////////////////////

typedef struct
{
    uint8 tag[8];
    uint16 size;  // total size of data
    uint16 csum;    // 16 bit checksum of data (individual BYTEs)
} DOGSAVE_HDR;
#define SAVETAG_ENG "ANMLSAVE"
#define SAVETAG_JPN "ANMJSAVE"

#define CB_HDR  sizeof(uint16) /* 2 */
    // runs up to 16KB each
    // upper two bits:
    //  11 = fill FF
    //  10 = fill 00
    //  01 = reserved
    //  00 = data

#define CB_MINREP 4

static uint16 CalcSum16(const uint8* pb, int cb)
{
    uint16 sum = 0;
    while (cb--)
        sum += *pb++;
    return sum;
}

/////////////////////////////////////////////////////////////////////////////


int ExpandSave2(const uint8* pbIn, int cbInMax, uint8* pbOut, int cbOutExpected, int cbMirror)
{
    DOGSAVE_HDR* dshP = (DOGSAVE_HDR*)pbIn;
    if (memcmp(dshP->tag, SAVETAG_ENG, 8) != 0 && memcmp(dshP->tag, SAVETAG_JPN, 8) != 0)
    {
        return -1;
    }
    int cbIn = dshP->size;
    if (cbIn <= 0 || cbIn > cbInMax)
    {
        return -1;
    }
    if (dshP->csum != CalcSum16(pbIn + sizeof(DOGSAVE_HDR), cbIn))
    {
        TRACE("DOGSAVE CSUM ERROR %x %x\n", dshP->csum, CalcSum16(pbIn + sizeof(DOGSAVE_HDR), cbIn));
#if 0
        return -1;
#endif
    }
    pbIn += sizeof(DOGSAVE_HDR);

    int cbOutUsed = 0;
    while (cbIn > 0)
    {
        // get first uint8
        uint16 hdrv;
        memcpy(&hdrv, pbIn, CB_HDR);
        pbIn += CB_HDR;
        cbIn -= CB_HDR;

        int cb = hdrv & 0x3FFF;
        ASSERT(cb != 0);
        if (hdrv & 0x8000)
        {
            // constant fill
            uint8 bFill = (hdrv & 0x4000) ? 0xFF : 0x00;
            cbOutUsed += cb;
            if (cbOutUsed > cbOutExpected)
                return -1;
            memset(pbOut, bFill, cb);
            pbOut += cb;
        }
        else if (hdrv & 0x4000)
        {
            // mirror
            cbOutUsed += cb;
            if (cbOutUsed > cbOutExpected)
                return -1;
            memcpy(pbOut, pbOut-cbMirror, cb);
            pbOut += cb;
        }
        else
        {
            // data fill
            ASSERT((hdrv & 0x4000) == 0); // reserved bit
            ASSERT(cb <= cbIn);
            cbOutUsed += cb;
            if (cbOutUsed > cbOutExpected)
                return -1;
            memcpy(pbOut, pbIn, cb);
            pbOut += cb;
            pbIn += cb;
            cbIn -= cb;
        }
    }

    return cbOutUsed;
}



static int FindConstantSpan(const uint8* pb, int cbMax)
{
    uint8 b0 = pb[0];
    int n = 1;
    while (n < cbMax && pb[n] == b0)
        n++;
    return n;
}

static int FindDataMatch(const uint8* pbMatch, int cbMatch, const uint8* pb, int cbMax)
{
    // find
    int iStart;
    for (iStart = 0; iStart < cbMax-cbMatch; iStart++)
        if (memcmp(pb+iStart, pbMatch, cbMatch) == 0)
            return iStart;
    return -1;
}

static int FindMirrorSpan(const uint8* pb1, const uint8* pb2, int cbMax)
{
    int n = 0;
    while (n < cbMax && (*pb1++ == *pb2++))
        n++;
    return n;
}

int CompressSave2(const uint8* pbIn, int cbIn, uint8* pbOutStart, int cbOutMax, int cbMirror, bool bSaveJ)
{
    const uint8* pbMirrorMid = pbIn + cbMirror;
    const uint8* pbMirrorEnd = pbIn + cbMirror*2;

    uint8* pbOut = pbOutStart + sizeof(DOGSAVE_HDR);
    int cbOutUsed = sizeof(DOGSAVE_HDR);
    while (cbIn > 0)
    {
        int n;
        int cbMaxChunk = 0x3FFF; // keep count under 14 bits
        if (cbIn < cbMaxChunk)
            cbMaxChunk = cbIn;

        if ((*pbIn == 0 || *pbIn == 0xFF) &&
            (n = FindConstantSpan(pbIn, cbMaxChunk)) >= CB_MINREP)
        {
            // encode as a constant run
            cbOutUsed += CB_HDR; // just a header
            if (cbOutUsed <= cbOutMax)
            {
                ASSERT(n > 0 && n < 0x4000);
                uint16 hdrv = 0x8000 | (uint16)n;
                if (*pbIn == 0xFF)
                    hdrv |= 0x4000;
                memcpy(pbOut, &hdrv, CB_HDR);
                pbOut += CB_HDR;
            }
            pbIn += n;
            cbIn -= n;
        }
        else if (pbIn >= pbMirrorMid && pbIn + CB_MINREP <= pbMirrorEnd &&
            (n = FindMirrorSpan(pbIn - cbMirror, pbIn, pbMirrorEnd-pbIn)) >= CB_MINREP)
        {
            // encode as a duplicate run
            if (n >= 0x4000)
                n = 0x3FFF;
            cbOutUsed += CB_HDR; // just a header
            if (cbOutUsed <= cbOutMax)
            {
                ASSERT(n > 0 && n < 0x4000);
                uint16 hdrv = 0x4000 | (uint16)n;
                memcpy(pbOut, &hdrv, CB_HDR);
                pbOut += CB_HDR;
            }
            pbIn += n;
            cbIn -= n;
        }
        else
        {
            // data run
            static uint8 s_zeros[CB_MINREP] = { 0, 0, 0, 0 };
            static uint8 s_ffs[CB_MINREP] = { 0xff, 0xff, 0xff, 0xff };
            int n0 = FindDataMatch(s_zeros, 4, pbIn, cbMaxChunk);
            int n1 = FindDataMatch(s_ffs, 4, pbIn, cbMaxChunk);
            n = cbMaxChunk;
            if (n0 >= 0 && n0 < n)
                n = n0;
            if (n1 >= 0 && n1 < n)
                n = n1;

            cbOutUsed += CB_HDR + n;
            if (cbOutUsed <= cbOutMax)
            {
                ASSERT(n > 0 && n < 0x4000);
                uint16 hdrv = 0x0000 | (uint16)n;
                memcpy(pbOut, &hdrv, CB_HDR);
                pbOut += CB_HDR;
                memcpy(pbOut, pbIn, n);
                pbOut += n;
            }
            pbIn += n;
            cbIn -= n;
        }
    }

    if (cbOutUsed > cbOutMax)
    {
        // need too much space
        return -cbOutUsed;
    }

    // will fit - assuming under 64KB, save header
    DOGSAVE_HDR dsh;
    memcpy(dsh.tag, bSaveJ ? SAVETAG_JPN : SAVETAG_ENG, 8);
    dsh.size = (uint16)(cbOutUsed - sizeof(DOGSAVE_HDR));
    dsh.csum = CalcSum16(pbOutStart + sizeof(DOGSAVE_HDR), dsh.size);
    memcpy(pbOutStart, &dsh, sizeof(DOGSAVE_HDR));
    return cbOutUsed;
}


/////////////////////////////////////////////////////////////////////////////
