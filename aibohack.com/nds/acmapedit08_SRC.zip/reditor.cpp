// reditor.cpp
// CRiverEditor for river editing (and super river editing)
// Similar to CEditor used by all the others

#include "stdafx.h"
#include "AnimalMap.h"
#include "romsave.h"
#include "reditor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Edit

static void ResizeControl(CWnd* pWnd, int cx, int cy)
{
    CRect rcWindow, rcClient;
    pWnd->GetWindowRect(rcWindow);
    pWnd->GetClientRect(rcClient);
    int dx = cx - rcClient.Width();
    int dy = cy - rcClient.Height();
    pWnd->SetWindowPos(NULL, 0, 0,
        rcWindow.Width() + dx, rcWindow.Height() + dy,
        SWP_NOMOVE | SWP_NOZORDER);

}


////////////////////////////////////////////////////////////

struct TAG_DATA
{
    int id;    // or 0xFFFF for special heading
    const char* name;
    COLORREF color;
    const char* szWhere_DEPRECATED;
    HTREEITEM hItem;    // filled in from last use
};

TAG_DATA tagdataRiver[] =
{
#include "river.c_"
};

static TAG_DATA const* FindTagData(int idFind, TAG_DATA const* data)
{
    ASSERT(idFind != 0xFFFF);
    while (data->name != NULL)
    {
        if (data->id == idFind)
            return data;
        data++;
    }
    return NULL;
}

////////////////////////////////////////////////////////////
// Photo Control

BEGIN_MESSAGE_MAP(CRiverGrid, CWnd)
    //{{AFX_MSG_MAP(CRiverGrid)
    ON_WM_PAINT()
    ON_WM_LBUTTONDOWN()
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CRiverGrid::Init(CRiverEditor* pParent, int nIDC, uint8* array, int dim)
{
    m_parent = pParent;
    m_array = array;

    m_gridX = dim;
    m_gridY = dim;
    m_cxCell = 32; // hard coded!
    m_cyCell = 32;

    VERIFY(SubclassWindow(::GetDlgItem(pParent->m_hWnd, nIDC)));
    ResizeControl(this, m_cxCell * m_gridX, m_cyCell * m_gridY);
}

int CRiverGrid::CountTileCode(uint8 tileMatch)
{
    int n = 0;
    uint8* pbTile = m_array;
    for (int row = 0; row < m_gridY; row++)
    {
        for (int col = 0; col < m_gridX; col++)
        {
            uint8 tile = *pbTile++;
            if (tile == tileMatch)
                n++;
        }
    }
    return n;
}


void CRiverGrid::OnPaint()
{
    PAINTSTRUCT ps;
    CDC* pdc = BeginPaint(&ps);
    CRect rc;
    GetClientRect(&rc);

    pdc->SetBkMode(TRANSPARENT);

    pdc->SetTextColor(RGB(192, 192, 192));
    CBrush brWhite(RGB(255, 255, 255));    // back
    CBrush brBorder(RGB(192, 192, 192));
    CBrush brBorderDupe(RGB(255, 0, 0));
    CBrush brBrown(RGB(139, 115, 85));
    CBrush brDkBlue(RGB(0, 0, 128));
    CBrush brLtBlue(RGB(0, 0, 255));
    CBrush brLtGrey(RGB(128, 128, 128));
    CBrush brRedGrey(RGB(255, 128, 128));
    
    uint8* pbTile = m_array;
    CRect rect;

    int counts[0x100]; // index by tile code - many not valid
    memset(counts, 0, sizeof(counts));

    int nUnique = 0;

    //BLOCK: count
    {
        uint8* pbTile = m_array;
        for (int row = 0; row < m_gridY; row++)
        {
            for (int col = 0; col < m_gridX; col++)
            {
                uint8 tile = *pbTile++;
                if (counts[tile] == 0)
                    nUnique++;
                counts[tile]++;
            }
        }
    }

//    bool bTooComplex = (nUnique > 25);

    for (int row = 0; row < m_gridY; row++)
    {
        int yTop = m_cyCell * row;
        rect.top = yTop;
        rect.bottom = yTop + m_cyCell;

        for (int col = 0; col < m_gridX; col++)
        {
            uint8 tile = *pbTile++;
            // int nUsed = CountTileCode(tile);
            int nUsed = counts[tile];
            ASSERT(nUsed >= 1);

            int xLeft = m_cxCell * col;
            rect.left = xLeft;
            rect.right = xLeft + m_cxCell;

            COLORREF color = RGB(128, 0, 0);    // unknown - ERROR

            // tile based drawing
            extern const char* g_tileDirectory[];
            const char* pch = g_tileDirectory[tile];
            if (pch == NULL)
            {
                if (tile >= 0x14 && tile <= 0x17)
                {
                    // grass -- all clear
                    pdc->FillRect(rect, &brWhite);
                }
                else
                {
                    // Walls
                    CBrush br2(WEIRD1);
                    pdc->FillRect(rect, &br2);
                }
            }
            else
            {
                // draw mini tiles
                for (int dy = 0; dy < 16; dy++)
                {
                    // 2x2 pixel cells
                    CRect rect2;
                    rect2.top = rect.top + dy*2;
                    rect2.bottom = rect2.top + 2; 
                    for (int dx = 0; dx < 16; dx++)
                    {
                        rect2.left = rect.left + dx*2;
                        rect2.right = rect2.left + 2;
                        char ch = *pch++;
                        CBrush* pbr = &brWhite;
                        if (ch == 'W')
                            pbr = &brDkBlue;
                        else if (ch == 'S')
                            pbr = &brLtBlue;
                        else if (ch == 'P')
                            pbr = &brLtGrey;
                        else if (ch == 'B')
                            pbr = &brBrown;
                        else if (ch == 'H')
                            pbr = &brRedGrey;
                        else if (ch != ' ')
                            { ASSERT(false); }
                        pdc->FillRect(rect2, pbr);
                    }
                }
            }
            pdc->FrameRect(rect, &brBorder);

#if 1 // red warning
            if (nUsed > 1)
            {
                CRect rect2(rect);
                for (int i = 0; i < 3; i++)
                {
                    rect2.left += 1;
                    rect2.right -= 1;
                    rect2.top += 1;
                    rect2.bottom -= 1;
                    pdc->FrameRect(rect2, &brBorderDupe);
                }
            }
#endif
        }
    }


    EndPaint(&ps);
}


/////////////////////////////////////////////////////////////////////////////
// CRiverEditor dialog


CRiverEditor::CRiverEditor(CWnd* pParent, uint8* array, int dim)
    : CDialog(IDD_EDITOR_RIVER, pParent)
{
    m_array = array; // for OnInitDialog init
    m_dim = dim;

    m_bNoAutoPlace = false;
    m_bIdent = true;
    m_tilePlace = 0x4A; // straight down
}

void CRiverEditor::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CRiverEditor)
    DDX_Control(pDX, IDC_CURINFO, m_infoText);
    DDX_Control(pDX, IDC_TREE1, m_partTree);
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRiverEditor, CDialog)
    //{{AFX_MSG_MAP(CRiverEditor)
    ON_BN_CLICKED(IDC_IDENT, OnModeIdent)
    ON_BN_CLICKED(IDC_PLACE, OnModePlace)
    ON_WM_LBUTTONDOWN()
    ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnSelchangedTree)
    ON_WM_LBUTTONUP()
    ON_WM_MOUSEMOVE()
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRiverEditor message handlers

void CRiverEditor::OnOK() 
{
    CDialog::OnOK();
}


static void FillTree(CTreeCtrl& tree, HTREEITEM hTop, TAG_DATA* data)
{
    HTREEITEM hCat = NULL;
    while (data->name != NULL)
    {
        if (data->id == 0xFFFF)
        {
            hCat = tree.InsertItem(data->name, hTop);
            tree.SetItemData(hCat, 0xFFFF);
            data->hItem = NULL;
        }
        else
        {
            ASSERT(hCat != NULL);
            HTREEITEM hItem = tree.InsertItem(data->name, hCat);
            tree.SetItemData(hItem, data->id);
            data->hItem = hItem;
        }
        data++;
    }
}


BOOL CRiverEditor::OnInitDialog() 
{
    CDialog::OnInitDialog();

    m_grid.Init(this, IDC_GRID1, m_array, m_dim);

    // fill tree list with possible inputs
    HTREEITEM hTop = m_partTree.InsertItem("Map Parts");
    m_partTree.SetItemData(hTop, 0xFFFF);
    FillTree(m_partTree, hTop, tagdataRiver);
    OnModeIdent(); // start in identify mode
    
    return TRUE;
}

static HTREEITEM FindItemName(char* szOut, uint8 tile)
{
    szOut[0] = '\0';
    TAG_DATA const* data = FindTagData(tile, tagdataRiver);

    if (data != NULL)
    {
        // item in tree list - point to it
        strcpy(szOut, data->name);
        return data->hItem;
    }
    else if (szOut[0] == '\0')
    {
        sprintf(szOut, "Unknown tile $%02X", tile);
    }
    return NULL;
}


void CRiverEditor::OnModeIdent() 
{
    m_bIdent = true;
    m_infoText.SetWindowText("click on map to see what's there");
    m_partTree.SelectItem(NULL);

    CheckDlgButton(IDC_IDENT, TRUE);
    CheckDlgButton(IDC_PLACE, FALSE);
}

void CRiverEditor::OnModePlace()  // "Change"
{
    m_bIdent = false;
    char szItem[64];
    HTREEITEM hItem = FindItemName(szItem, m_tilePlace);
    char szT[64];
    sprintf(szT, "click on map to change to '%s'", szItem);
    m_infoText.SetWindowText(szT);
    m_partTree.SelectItem(hItem);

    CheckDlgButton(IDC_IDENT, FALSE);
    CheckDlgButton(IDC_PLACE, TRUE);
}


void CRiverEditor::OnGridClick(CRiverGrid* pFrom, int xGrid, int yGrid)
{
    ASSERT(m_grid.m_array == m_array);
    uint8* tilePtr = &m_array[yGrid * pFrom->m_gridX + xGrid];
    uint8 tile = *tilePtr;
    if (m_bIdent)
    {
        // Identify item clicked
        char szItem[64];
        HTREEITEM hItem = FindItemName(szItem, tile);
        char szT[64];
        sprintf(szT, "You clicked on: $%02X = %s", tile, szItem);
        m_infoText.SetWindowText(szT);

        // will hopefully scroll tree list into view
        m_bNoAutoPlace = true;
        m_partTree.SelectItem(hItem);
        m_bNoAutoPlace = false;

        m_tilePlace = tile;
    }
    else
    {
        // Change
        *tilePtr = m_tilePlace;
        pFrom->InvalidateRect(NULL, TRUE);

        // one shot only
        OnModeIdent();
    }
}

void CRiverEditor::OnLButtonDown(UINT nFlags, CPoint point) 
{
    // TRACE("Container Button Down %d %d\n", point.x, point.y);    
    ClientToScreen(&point);
    CRect rect;

    m_grid.GetWindowRect(rect);
    if (rect.PtInRect(point))
    {
        m_grid.ScreenToClient(&point);
        if (point.x >= 0 && point.x < m_grid.m_cxCell * m_grid.m_gridX &&
            point.y >= 0 && point.y < m_grid.m_cyCell * m_grid.m_gridY)
        {
            OnGridClick(&m_grid, point.x/m_grid.m_cxCell, point.y/m_grid.m_cyCell);
            return; // hit one
        }
    }
}

void CRiverEditor::OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
    NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

    HTREEITEM hItem = m_partTree.GetSelectedItem();
    if (!m_bNoAutoPlace && hItem != NULL)
    {
        DWORD code = m_partTree.GetItemData(hItem);
        if (code >= 0 && code < 0xFF)
        {
            // go into place mode
            m_tilePlace = (uint8)code;
            OnModePlace();
        }
    }
    *pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////
