// romsave.cpp
//  Utilities for manipulating the romsave (AKA gamesave)

#include "stdafx.h"
#include "romsave.h"

/////////////////////////////////////////////////////////////////////////////

ROMSAVE g_romsave;


/////////////////////////////////////////////////////////////////////////////

uint16 CalcSumW(const void* pv, int cb)
{
    ASSERT((((long)pv) & 1) == 0);
    ASSERT(cb > 0);
    ASSERT((cb & 1) == 0);
    const uint16* pw = (const uint16*)pv;
    uint16 sum = 0;
    while (cb > 0)
    {
        sum += *pw++;
        cb -= 2;
    }
    return sum;
}


uint8* ROMSAVE::GetBufferPtr(uint32 addr)
{
    return &m_buffer[addr];
}

uint8 ROMSAVE::GetBufferB(uint32 addr)
{
    ASSERT(addr >= 0 && addr <= FULL_SAVE_SIZE);
    return m_buffer[addr];
}

uint16 ROMSAVE::GetBufferW(uint32 addr)
{
    ASSERT(addr >= 0 && addr <= FULL_SAVE_SIZE);
    ASSERT((addr & 1) == 0);
    return *(uint16*)&m_buffer[addr];
}

uint32 ROMSAVE::GetBufferL(uint32 addr)
{
    ASSERT(addr >= 0 && addr <= FULL_SAVE_SIZE);
    ASSERT((addr & 3) == 0);
    return *(uint32*)&m_buffer[addr];
}


int ROMSAVE::WriteBufferB(uint32 addr, uint8 data)
{
    ASSERT(addr >= 0 && addr <= FULL_SAVE_SIZE);
    // set both copies to same value
    int addr2 = addr & 0xFFFFE;    // word aligned
    int sumBefore = CalcSumW(&m_buffer[addr2], 2);
    m_buffer[addr] = data;
    int sumAfter = CalcSumW(&m_buffer[addr2], 2);
    m_bModified = true;
    return sumAfter - sumBefore;
}

int ROMSAVE::WriteBufferW(uint32 addr, uint16 data)
{
    ASSERT(addr >= 0 && addr <= FULL_SAVE_SIZE);
    ASSERT((addr & 1) == 0);
    // set both copies to same value
    int sumBefore = CalcSumW(&m_buffer[addr], 2);
    *(uint16*)&m_buffer[addr] = data;
    int sumAfter = CalcSumW(&m_buffer[addr], 2);
    m_bModified = true;
    return sumAfter - sumBefore;
}

int ROMSAVE::WriteBufferL(uint32 addr, uint32 data)
{
    ASSERT(addr >= 0 && addr <= FULL_SAVE_SIZE);
    ASSERT((addr & 3) == 0);
    // set both copies to same value
    int sumBefore = CalcSumW(&m_buffer[addr], 4);
    *(uint32*)&m_buffer[addr] = data;
    int sumAfter = CalcSumW(&m_buffer[addr], 4);
    m_bModified = true;
    return sumAfter - sumBefore;
}

void ROMSAVE::WriteB(int offset, uint8 newVal)
{
    ASSERT(offset >= 0 && offset < GAMESIZE);
    WriteBufferW(OFF_CSUM, GetBufferW(OFF_CSUM) - WriteBufferB(offset, newVal));
    WriteBufferW(GAMESIZE + OFF_CSUM, GetBufferW(GAMESIZE + OFF_CSUM) - WriteBufferB(GAMESIZE + offset, newVal));
}

void ROMSAVE::WriteW(int offset, uint16 newVal)
{
    ASSERT(offset >= 0 && offset < GAMESIZE);
    WriteBufferW(OFF_CSUM, GetBufferW(OFF_CSUM) - WriteBufferW(offset, newVal));
    WriteBufferW(GAMESIZE + OFF_CSUM, GetBufferW(GAMESIZE + OFF_CSUM) - WriteBufferW(GAMESIZE + offset, newVal));
}

void ROMSAVE::WriteL(int offset, uint32 newVal)
{
    ASSERT(offset >= 0 && offset < GAMESIZE);
    WriteBufferW(OFF_CSUM, GetBufferW(OFF_CSUM) - WriteBufferL(offset, newVal));
    WriteBufferW(GAMESIZE + OFF_CSUM, GetBufferW(GAMESIZE + OFF_CSUM) - WriteBufferL(GAMESIZE + offset, newVal));
}


/////////////////////////////////////////////////////////////////////////////

// Two versions

VERINFO* g_verinfo;

// NOTE: this is an old way, newer code uses the EORJ macro
static VERINFO verInfoE =
{
    "Eng(U)",
    0x15FE0,
    0xC330, // right before main map
    // inventory, bank, points
    0x1AF4 + 0x3A,
    0x1AF4 + 0x3A + 0x6C2,
    0x1AF4 + 0x3A + 0x6E6,
    // WORLD MAP
    0xC354,
    0xE620,
    0xE354, // holes bitmap
};
static VERINFO verInfoJ =
{
    "Jpn(J)",
    0x12224,
    0xA32C,
    // inventory, bank, points
    0x16B2,
    0x1C7C,
    0x1CA0,
    // WORLD MAP
    0xA34A + 6,
    0xC6A0 - 0x84,
    0xC350, // holes bitmap
};

bool ROMSAVE::GuessVersion()
{
    // compare start
    const int cbCheck = 2+2+8;
    if (memcmp(g_romsave.GetBufferPtr(0), g_romsave.GetBufferPtr(GAMESIZE_ENG), cbCheck) == 0)
    {
        g_verinfo = &verInfoE;
        return true;
    }
    if (memcmp(g_romsave.GetBufferPtr(0), g_romsave.GetBufferPtr(GAMESIZE_JPN), cbCheck) == 0)
    {
        g_verinfo = &verInfoJ;
        return true;
    }
    
    return false;
}


int CALC_NOFFSET(int index)
{
    if (index >= 0 && index < 8)
        return EORJ(CALC_NOFFSET_E(index),CALC_NOFFSET_J(index));
    ASSERT(index == -1);
    if (!IS_ENGLISH() || index != -1)
    {
        AfxMessageBox("Internal Error"); // shouldn't happen
        return 0;
    }
    return NOFFSET_9TH_ENG; // special case for '9th' slot
}

/////////////////////////////////////////////////////////////////////////////i

static void Count1(ROMSAVE& romsave, int offset, int cw, int danger_counts[1+4])
{
    while (cw--)
    {
        uint16 code = romsave.GetBufferW(offset);
        if (code != 0xFFF1)
        {
            uint16 upper = code >> 12;
            if (upper == 0)
            {
                // allow terrain (no subfiltering)
                if (code >= 0xE3 && code <= 0x1FF /*MAX_TERRAIN_CODE plus extra */ )
                    danger_counts[3]++; // rocks or rock-like
                else if (code >= 0x66 && code <= 0x6D)
                    danger_counts[2]++; // special tree
                else
                    danger_counts[1]++;
            }
            else if (upper != 1 && upper != 3 && upper != 4)
            {
                // buildings (including 'mansion seeds')
                danger_counts[4]++;
            }
            else
            {
                danger_counts[0]++; // not dangerous AFAIK
            }
        }
        offset += 2;
    }
}

void ROMSAVE::CountDangerous(int danger_counts[1+4])
{
    danger_counts[0] = danger_counts[1] = danger_counts[2] = danger_counts[3] =  danger_counts[4] = 0;

    Count1(*this, OFFSET_DRAWER_BASE, 360, danger_counts);
    Count1(*this, OFFSET_NOOK_ITEMS, 37, danger_counts);
    Count1(*this, OFFSET_LOSTNFOUND, 15, danger_counts);
    Count1(*this, OFFSET_RECYCLER, 15, danger_counts);
    for (int iRes = 0; iRes < 4; iRes++)
        Count1(*this, OFFSET_INVENTORY1 +
            iRes * EORJ(PLAYER_SIZE_ENG, PLAYER_SIZE_JPN), 15, danger_counts);
}

/////////////////////////////////////////////////////////////////////////////i
