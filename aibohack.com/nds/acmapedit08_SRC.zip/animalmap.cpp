// AnimalMap 1.7 - open source release
// (c) 2005, 2006 DsPet, but released as FreeWare and Free-source
// Please don't sell any derived works
//
// If you want to add things, please retain original credits (and add your own)
// If you come up with something new, please email it to me (dspet@aibohack.com)
// See README.TXT for general overview

// Warning: source code comments are sparse

// AnimalMap.cpp
//  Main app, loading and verification
//  Saving is done in maindlg.cpp

#include "stdafx.h"
#include "AnimalMap.h"
#include "maindlg.h"

#include "romsave.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAnimalMapApp

BEGIN_MESSAGE_MAP(CAnimalMapApp, CWinApp)
    //{{AFX_MSG_MAP(CAnimalMapApp)
    //}}AFX_MSG
    ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAnimalMapApp construction

CAnimalMapApp::CAnimalMapApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CAnimalMapApp object

CAnimalMapApp theApp;
SAVE_INFO g_saveInfo;
bool g_bJpn; // true if Japanese version; false if US or EU version
bool g_bAdvancedUser = false;

/////////////////////////////////////////////////////////////////////////////
// CAnimalMapApp initialization

static BOOL LoadRomSave(const char* szPath)
{
    FILE* pf = fopen(szPath, "rb");
    if (pf == NULL)
    {
        CString str;
        str.Format("Can't open rom save file\n'%s'\nZero length or bogus path", szPath);
        AfxMessageBox(str);
        return FALSE;
    }

    g_saveInfo.m_path = szPath;

    fseek(pf, 0, SEEK_END);
    int cbFile = ftell(pf);
    fseek(pf, 0, SEEK_SET);
    uint8* pbFile = new uint8[cbFile];
    if (fread(pbFile, cbFile, 1, pf) != 1)
    {
        delete [] pbFile;
        AfxMessageBox("ERROR: Read error\n");
        return FALSE;
    }
    VERIFY(fclose(pf) == 0);

    if (memcmp(pbFile, "ANMLSAVE", 8) == 0 && cbFile >= 0x8000)
    {
        // "ANMLSAVE" format
        g_saveInfo.m_type = SAVE_INFO::ST_ANIMALSAVE_ENG;
        int n = ExpandSave2(pbFile, cbFile, g_romsave.GetBufferPtr(0), FULL_SAVE_SIZE, GAMESIZE_ENG);
        if (n != FULL_SAVE_SIZE)
        {
            delete [] pbFile;
            AfxMessageBox("ERROR: Bad ANIMALSAVE (E)\n");
            return FALSE;
        }
        if (cbFile == FULL_SAVE_SIZE + 1024)
        {
            // M3 packaged format
            g_saveInfo.m_type = SAVE_INFO::ST_ANIMALSAVE_ENG_M3;
            g_saveInfo.m_extra = new BYTE[1024];
            memcpy(g_saveInfo.m_extra, pbFile+FULL_SAVE_SIZE, 1024);
        }
    }
    else if (memcmp(pbFile, "ANMJSAVE", 8) == 0 && cbFile >= 0x8000)
    {
        // "ANMJSAVE" format
        g_saveInfo.m_type = SAVE_INFO::ST_ANIMALSAVE_JPN;
        int n = ExpandSave2(pbFile, cbFile, g_romsave.GetBufferPtr(0), FULL_SAVE_SIZE, GAMESIZE_JPN);
        if (n != FULL_SAVE_SIZE)
        {
            delete [] pbFile;
            AfxMessageBox("ERROR: Bad ANIMALSAVE (J)\n");
            return FALSE;
        }
        if (cbFile == FULL_SAVE_SIZE + 1024)
        {
            // M3 packaged format
            g_saveInfo.m_type = SAVE_INFO::ST_ANIMALSAVE_JPN_M3;
            g_saveInfo.m_extra = new BYTE[1024];
            memcpy(g_saveInfo.m_extra, pbFile+FULL_SAVE_SIZE, 1024);
        }
    }
    else if (cbFile == 500 + FULL_SAVE_SIZE)
    {
        // action replay .dss/.duc save header
        g_saveInfo.m_type = SAVE_INFO::ST_DSS;
        g_saveInfo.m_extra = new BYTE[500];
        memcpy(g_saveInfo.m_extra, pbFile, 500);
        memcpy(g_romsave.GetBufferPtr(0), pbFile+500, FULL_SAVE_SIZE);
    }
    else if (cbFile == FULL_SAVE_SIZE)
    {
        // raw save of entire cart
        g_saveInfo.m_type = SAVE_INFO::ST_RAW;
        memcpy(g_romsave.GetBufferPtr(0), pbFile, FULL_SAVE_SIZE);
    }
    else if (cbFile == FULL_SAVE_SIZE + 0x400 ||
        cbFile == FULL_SAVE_SIZE + 0x4000 ||
        cbFile == FULL_SAVE_SIZE + 0x40000)
    {
        // extra info (M3, EzFlash, M3Simply and others)
        g_saveInfo.m_type = SAVE_INFO::ST_PADDED;
        int cbPad = cbFile - FULL_SAVE_SIZE;
        g_saveInfo.m_extra = new BYTE[cbPad];
        g_saveInfo.m_extralen = cbPad;
        memcpy(g_romsave.GetBufferPtr(0), pbFile, FULL_SAVE_SIZE);
        memcpy(g_saveInfo.m_extra, pbFile+FULL_SAVE_SIZE, cbPad);
    }
    else
    {
        delete [] pbFile;
        AfxMessageBox(IDS_BAD_FORMAT);
        return FALSE;
    }
    delete [] pbFile;

    if (!g_romsave.GuessVersion())
    {
        AfxMessageBox("ERROR: can't determine version (E or J)\n"
            "Please try the backup again\n"
            "(if using a homebrew setup be sure there is a 64KB SRAM window)");
        return FALSE;
    }

    int sum1 = CalcSumW(g_romsave.GetBufferPtr(0), GAMESIZE);
    if (sum1 != 0)
    {
        AfxMessageBox(IDS_ERROR_CSUM_MIRROR);
        return FALSE;
    }
    int sum2 = CalcSumW(g_romsave.GetBufferPtr(GAMESIZE), GAMESIZE);
    if (sum2 != 0)
    {
        AfxMessageBox(IDS_ERROR_CSUM_MIRROR);
        return FALSE;
    }

    if (memcmp(g_romsave.GetBufferPtr(0), g_romsave.GetBufferPtr(GAMESIZE), OFF_CSUM) != 0)
    {
        AfxMessageBox(IDS_ERROR_CSUM_MIRROR);
        return FALSE;
    }

    return TRUE;
}

BOOL CAnimalMapApp::InitInstance()
{
// TRACE("MyLCID = $%x\n", GetUserDefaultLCID());
    g_bJpn = LOBYTE(GetUserDefaultLCID()) == LANG_JAPANESE;

    const char* szCmdLine = AfxGetApp()->m_lpCmdLine;
    // very dump command line parsing (only one allowed)
    if (strstr(szCmdLine, "-j") != NULL && !g_bJpn)
    {
        AfxMessageBox("Forcing Japanese UI\nMay not look correct");
        SetThreadLocale(0x411);
        g_bJpn = true;
    }
    else if (strstr(szCmdLine, "-e") != NULL && g_bJpn)
    {
        AfxMessageBox("Forcing English UI\nMay not look correct");
        SetThreadLocale(0x409);
        g_bJpn = false;
    }
    else if (strstr(szCmdLine, "-nowarn") != NULL)
    {
        g_bAdvancedUser = true;
    }
    else if (strstr(szCmdLine, "-advanced") != NULL)
    {
        g_bAdvancedUser = true;
    }

    const char* szFilter = "*.duc (Action Replay Uncompressed)|*.duc|*.sav (various)|*.sav|*.bin (raw save)|*.bin|*.dat (various)|*.dat|*.0 (g6)|*.0||";
    if (g_bJpn)
        szFilter = "*.duc (\x83\x7D\x83\x62\x83\x4E\x83\x58\x83\x68\x83\x89\x83\x43\x83\x75\x96\xB3\x88\xB3\x8F\x6B\x8C\x60\x8E\xAE)|*.duc|"
        "*.sav (\x83\x5A\x81\x5B\x83\x75\x83\x66\x81\x5B\x83\x5E)|*.sav|"
        "*.bin (\x72\x61\x77\x20\x73\x61\x76\x65)|*.bin|"
        "*.dat (\x4D\x33\x20\x73\x61\x76\x65)|*.dat||";


    CFileDialog opendlg(TRUE, "duc", "*.duc;*.sav", OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST, szFilter, NULL);

    if (opendlg.DoModal() != IDOK)
        return FALSE;
    
    if (!LoadRomSave(opendlg.GetPathName()))
        return FALSE;

    ASSERT(!g_romsave.GetModifiedFlag());

    CMainDlg dlg;
    m_pMainWnd = &dlg;
    dlg.DoModal(); // main user interface runs here
    // saving done in the main dialog

    return FALSE; // app done
}

/////////////////////////////////////////////////////////////////////////////
