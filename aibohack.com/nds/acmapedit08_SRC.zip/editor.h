// editor.h : CEditor and related stuff
//

/////////////////////////////////////////////////////////////////////////////
// Specific item codes for the world map and inventory

#define CODE_BLANK 0xFFF1
#define MAX_TERRAIN_CODE 0x110 /* actual limit unknown */

#define IsBuilding(code) (((code) & 0xFF00) == 0x5000)
    // includes buildings and signs
#define IsWarning(code) ((code & 0xFFF0) == 0xF030)

#define IsFlower0(code) ((code) >= 0x00 && (code) <= 0x1C)
#define IsStump(code) ((code) >= 0x2B && (code) <= 0x2E)||(code >= 0x62 && code <= 0x65)||(code >= 0xD0 && code <= 0xD3)||(code >= 0xFF && code <= 0x102)
#define IsWeed(code) ((code) >= 0x1D && (code) <= 0x24)
    // dandelions, puffs, clovers (lucky or not) and weeds
#define IsPattern(code) ((code) >= 0xA7 && (code) <= 0xC6)
#define IsRock(code) ((code) >= 0xE3 && (code) <= 0xFB)
#define IsFlower1(code) ((code) >= 0x6E && (code) <= 0x89)
    // parched - about to die
#define IsFlower2(code) ((code) >= 0x8A && (code) <= 0xA5)
    // parched - recently watered

// A5 is special - watered black rose


/////////////////////////////////////////////////////////////////////////////
// Grid Edit Control
// used for many of the editors

struct GRID_INFO
{
    uint16* array;
    int gridX;
    int gridY;

    int cxInset, cyInset;    // if non-zero - inset rectangle
    int xInset, yInset;
};

class CEditor;

class CGridCtrl : public CWnd
{
public:
    CGridCtrl();
    ~CGridCtrl() { }
    
    void Init(CEditor* pParent, int nIDC, GRID_INFO const& info, bool bBig);

protected:
    CEditor* m_parent;
public: // direct access from parent

    GRID_INFO m_info;
    int m_cxCell, m_cyCell;

    const uint8* m_tilemap;
    uint8* m_holemap;

    bool m_bBackdrop;
    
    //{{AFX_MSG(CGridCtrl)
    afx_msg void OnPaint();
    //}}AFX_MSG
    //    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// CEditor dialog

// CEditor class has many different editing modes
enum EDIT_MODE
{
    EM_WORLD, // world map, basic mode (can't move buildings)
    EM_ROOMS, // inside the main house
    EM_INVENTORY, // regular safe items in inventory
    EM_INVENTORY_DANGER1, // dangerous items in inventory
    EM_INVENTORY_DANGER2,
    EM_INVENTORY_DANGER3,
    EM_INVENTORY_DANGER4, // very dangerous
    EM_EQUIP, // Tool, things your wearing
// advanced
    EM_SUPERROOMS,    // ADVANCED, two levels in each room of house
    EM_NEIGHROOM, // neighbor room
    EM_WORLD_ADVANCED, // ADVANCED, allow unsafe editing, moving houses etc
    EM_BEDROOM, // edit bedroom, very limited
    EM_GIFTS, // Gifts inside letters
};


#define MAX_GRID 10
// main(8x8), N, E, W, Lvl2
// in super mode - two grids per room

class CEditor : public CDialog
{
// Construction
public:
    CEditor(CWnd* pParent, enum EDIT_MODE mode, GRID_INFO const* info, int nGrid);
    void SetTileMap(uint8* tilemap) { m_tilemap = tilemap; }
    void SetHoleMap(uint8* holemap) { m_holemap = holemap; }
protected:
    enum EDIT_MODE m_mode;

    //{{AFX_DATA(CEditor)
    enum { IDD = IDD_EDITOR_BEDROOM };
    CStatic    m_infoText;
    CTreeCtrl    m_partTree;
    //}}AFX_DATA

    GRID_INFO const* m_info;    // during init
    const uint8* m_tilemap;
    uint8* m_holemap; // 1 bit per cell

    // for main map editor
    CGridCtrl m_grids[MAX_GRID];
    int m_nGrids;
    // for editing state
    enum
    {
            ACTION_IDENT,
            ACTION_PLACE,    // delete if codePlace = CODE_BLANK
            ACTION_BURY,    // bury / unbury
    } m_action;

    uint16 m_codePlace;
    CGridCtrl* m_activeGrid;
    bool m_bNoAutoPlace;

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CEditor)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Called by CGridCtrl
public:
    void OnGridClick(CGridCtrl* pFrom, int xGrid, int yGrid);
// Implementation
protected:
    // Generated message map functions
    //{{AFX_MSG(CEditor)
    virtual void OnOK();
    virtual BOOL OnInitDialog();
    afx_msg void OnModeIdent();
    afx_msg void OnModePlace();
    afx_msg void OnModeDelete();
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult);
    afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnMouseMove(UINT nFlags, CPoint point);
    afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnRemoveWeeds();
    afx_msg void OnRemoveStrays();
    afx_msg void OnRemovePlants();
    afx_msg void OnRemoveRocks();
    afx_msg void OnToggleback();
    afx_msg void OnModeBuryUnbury();
    afx_msg void OnWaterFlowers1();
    afx_msg void OnWaterFlowers2();
    afx_msg void OnReplenishFruit();
    afx_msg void OnRemoveBuildings();
    afx_msg void OnFindPart();
    //}}AFX_MSG
//    afx_msg void OnToggleRotate();
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
