//  provides text encoding and decoding

bool FormatMangled_E(char* szOut, int offset, int cb);
bool FormatMangledArray_E(char* szOut, const uint8* pb, int cb);
bool Mangle_E(uint8* pbOut, const char* szIn, int cch);
bool FormatMangled_J(wchar_t* wszOut, int offset, int cb);

