// CRiverEditor
//  River editing is similar to CEditor,
//    but for editing 1 byte terrain/acre codes

// (one byte) TERRAIN CODES ARE NOT (two byte) ITEM CODES!
// That's why there are no such thing as 'waterfall seeds' or 'bridge seeds'

/////////////////////////////////////////////////////////////////////////////
// Grid Edit Control

class CRiverEditor;

class CRiverGrid : public CWnd
{
public:
    CRiverGrid() { m_array = NULL; }
    ~CRiverGrid() { }
    
    void Init(CRiverEditor* pParent, int nIDC, uint8* array, int dim);
    int CountTileCode(uint8 tileMatch);

protected:
    CRiverEditor* m_parent;
public: // direct access from parent

    uint8* m_array;
    int m_gridX, m_gridY; // hard coded 4x4 or 6x6 size
    int m_cxCell, m_cyCell;
    
    //{{AFX_MSG(CRiverGrid)
    afx_msg void OnPaint();
    //}}AFX_MSG
    // afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// CRiverEditor dialog

class CRiverEditor : public CDialog
{
// Construction
public:
    CRiverEditor(CWnd* pParent, uint8* array, int dim);

protected:
    //{{AFX_DATA(CRiverEditor)
    enum { IDD = IDD_EDITOR_WORLD };
    CStatic    m_infoText;
    CTreeCtrl    m_partTree;
    //}}AFX_DATA

    CRiverGrid m_grid;
    uint8* m_array;
    int m_dim;

    // for editing state
    bool m_bIdent;
    uint8 m_tilePlace;
    bool m_bNoAutoPlace;

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CRiverEditor)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Called by CRiverGrid
public:
    void OnGridClick(CRiverGrid* pFrom, int xGrid, int yGrid);
// Implementation
protected:
    // Generated message map functions
    //{{AFX_MSG(CRiverEditor)
    virtual void OnOK();
    virtual BOOL OnInitDialog();
    afx_msg void OnModeIdent();
    afx_msg void OnModePlace();
    afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult);
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
