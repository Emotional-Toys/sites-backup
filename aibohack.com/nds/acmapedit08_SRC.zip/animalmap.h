// AnimalMap.h : main header file

#pragma once

#include "resource.h" // user interface symbols (resource editor)

/////////////////////////////////////////////////////////////////////////////

class CAnimalMapApp : public CWinApp
{
public:
    CAnimalMapApp();

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CAnimalMapApp)
    public:
    virtual BOOL InitInstance();
    //}}AFX_VIRTUAL

// Implementation

    //{{AFX_MSG(CAnimalMapApp)
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// global where file came from

// ROMSAVE file saving
struct SAVE_INFO
{
    enum // format
    {
        ST_RAW, // 256K
        ST_ANIMALSAVE_ENG, // compressed using my algorithm, ENG size
        ST_ANIMALSAVE_JPN, // compressed using my algorithm, JPN size
        ST_DSS, // Action Replay DSS or DUC format. 500 BYTEs + 256K
        ST_PADDED, // 256K + padded (m_extralen bytes stored in m_extra)
        // same packaged in M3
        ST_ANIMALSAVE_ENG_M3,
        ST_ANIMALSAVE_JPN_M3,
    } m_type;

    CString m_path;
    BYTE* m_extra; // extra bytes for DSS or M3
    int m_extralen;
};
extern SAVE_INFO g_saveInfo;


extern bool g_bJpn; // true if japanese UI
    // use IS_ENGLISH to check language of the gamesave

extern bool g_bAdvancedUser; // don't warn on dangers (advanced user mode)

/////////////////////////////////////////////////////////////////////////////
