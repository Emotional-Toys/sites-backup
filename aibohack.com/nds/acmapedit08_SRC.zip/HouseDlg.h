// HouseDlg.h : header file
//  Tweeking House Size/Roof Color

/////////////////////////////////////////////////////////////////////////////
// CHouseDlg dialog

class CHouseDlg : public CDialog
{
// Construction
public:
    CHouseDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(CHouseDlg)
    enum { IDD = IDD_HOUSE };
    int        m_housesize;
    int        m_housecolor;
    //}}AFX_DATA


// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CHouseDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:

    // Generated message map functions
    //{{AFX_MSG(CHouseDlg)
        // NOTE: the ClassWizard will add member functions here
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
