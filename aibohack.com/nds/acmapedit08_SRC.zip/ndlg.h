// ndlg.h : Neighbor editing (NPCs)

/////////////////////////////////////////////////////////////////////////////
// CNeighborDlg dialog

class CNeighborDlg : public CDialog
{
// Construction
public:
    CNeighborDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(CNeighborDlg)
    enum { IDD = IDD_NEIGHBORS };

    //}}AFX_DATA


// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CNeighborDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation

protected:
    void FillInfo();

    // Generated message map functions
    //{{AFX_MSG(CNeighborDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnDone();
    //}}AFX_MSG
    void OnChangeNeigh(UINT id);
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CNeighInfo dialog

class CNeighInfo : public CDialog
{
// Construction
public:
    CNeighInfo(CWnd* pParent, int index);
        // index = 0->7 or -1 for 9th

// Dialog Data
    //{{AFX_DATA(CNeighInfo)
    enum { IDD = IDD_NEIGHEDIT };
    CString    m_editVal;
    int        m_species;
    int        m_personality;
    //}}AFX_DATA


// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CNeighInfo)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:
    int m_index;

    // Generated message map functions
    //{{AFX_MSG(CNeighInfo)
    afx_msg void OnNeighRoomEdit();
    virtual void OnOK();
    virtual BOOL OnInitDialog();
    afx_msg void OnSelchangeSpecies();
    afx_msg void OnNeighRelationEdit();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// CAskNameDlg dialog

class CAskNameDlg : public CDialog
{
// Construction
public:
    CAskNameDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(CAskNameDlg)
    enum { IDD = IDD_NAMEEDIT };
    CString    m_strEdit;
    //}}AFX_DATA


// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CAskNameDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:

    // Generated message map functions
    //{{AFX_MSG(CAskNameDlg)
        // NOTE: the ClassWizard will add member functions here
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CTownTypeDlg dialog

class CTownTypeDlg : public CDialog
{
// Construction
public:
    CTownTypeDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(CTownTypeDlg)
    enum { IDD = IDD_TOWNTYPE };
    int        m_typeZeroBased;
    //}}AFX_DATA


// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CTownTypeDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:

    // Generated message map functions
    //{{AFX_MSG(CTownTypeDlg)
        // NOTE: the ClassWizard will add member functions here
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CNeighRelDlg dialog

class CNeighRelDlg : public CDialog
{
// Construction
public:
    CNeighRelDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(CNeighRelDlg)
    enum { IDD = IDD_RELATIONSHIPS };
        // NOTE: the ClassWizard will add data members here
    //}}AFX_DATA

    int m_index;
    void FillInfo();

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CNeighRelDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:

    // Generated message map functions
    //{{AFX_MSG(CNeighRelDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnSave();
    //}}AFX_MSG
    void OnChangeRel(UINT id);
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

extern const char* GetSpeciesName_E(int species);
// for reporting 9th neighbor

/////////////////////////////////////////////////////////////////////////////
