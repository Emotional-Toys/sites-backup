// ndlg.cpp
// NPC related user interface

#include "stdafx.h"
#include "animalmap.h"
#include "romsave.h"
#include "ndlg.h"

#include "script.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNeighborDlg dialog

CNeighborDlg::CNeighborDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CNeighborDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CNeighborDlg)
    //}}AFX_DATA_INIT
}


void CNeighborDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CNeighborDlg)
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNeighborDlg, CDialog)
    //{{AFX_MSG_MAP(CNeighborDlg)
    ON_BN_CLICKED(IDC_SAVE, OnDone)
    ON_COMMAND_RANGE(IDC_CHANGE_NEIGH1, IDC_CHANGE_NEIGH8, OnChangeNeigh)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// main dialog options

#include "maindlg.h"


static void WriteByteArray(int offset, const uint8* pb, int cb)
{
    while (cb--)
        g_romsave.WriteB(offset++, *pb++);
}

bool CMainDlg::SpecialChangeName(const char* szTag, int ibPrototype)
{
    uint16 code = g_romsave.GetBufferW(ibPrototype);
    uint8 rgbOld[8];
    memcpy(rgbOld, g_romsave.GetBufferPtr(ibPrototype+2), 8);

    CString strT;
    char szOldName[256];

    bool bEditable = FormatMangledArray_E(szOldName, rgbOld, 8);
    strT.Format("OLD %s: [%04X] %s", szTag, code, szOldName);
    AfxMessageBox(strT);
    if (!bEditable)
    {
        AfxMessageBox("Using strange characters\nNOT EDITABLE");
        return false;
    }

    // need 5->8 characters in name for reasonably safe search/replace
    if (strlen(szOldName) < 5)
    {
        if (AfxMessageBox("Old name very short\nRisky, do you want to try it?", MB_YESNO) != IDYES)
            return false;
    }

    CAskNameDlg dlg;
    dlg.m_strEdit = szOldName;

    if (dlg.DoModal() != IDOK)
        return false;

    if (strlen(dlg.m_strEdit) < 5)
    {
        AfxMessageBox("New name too short\n(at least 5 chars please)");
        return false;
    }
    if (strlen(dlg.m_strEdit) > 8)
    {
        AfxMessageBox("New name too long\n(5 to 8 chars please)");
        return false;
    }

    uint8 rgbNew[8];
    if (!Mangle_E(rgbNew, dlg.m_strEdit, 8))
    {
        AfxMessageBox("string contains invalid characters");
        return false;
    }
    char szNewName[256];
    if (!FormatMangledArray_E(szNewName, rgbNew, 8))
    {
        AfxMessageBox("string contains invalid characters (2)");
        return false;
    }

    strT.Format("NEW %s: [%04X] %s\nAre you sure?", szTag, code, szNewName);
    if (AfxMessageBox(strT, MB_YESNO | MB_DEFBUTTON2) != IDYES)
        return false;

    // Binary search and replace for all occurances that look like the name
    int nChange = 0;
    for (int ib = 0; ib < g_verinfo->gameSaveSize-10; ib += 2)
    {
        if (g_romsave.GetBufferW(ib) == code &&
            memcmp(rgbOld, g_romsave.GetBufferPtr(ib+2), 8) == 0)
        {
            WriteByteArray(ib+2, rgbNew, 8);
            ib += 8;
            nChange++;
        }
    }
    strT.Format("Replaced %d strings\nPlease test thoroughly", nChange);
    AfxMessageBox(strT);
    return true;
}

void CMainDlg::OnSpecialChangetownname()
{
    ENGLISH_CHECK(); // town name, never ?
    SpecialChangeName("TOWN", 0x0002); // name at start
    FillOwnerInfo();
}

void CMainDlg::OnSpecialChangeResidentName() 
{
    ENGLISH_CHECK();    // string change, never for J version
    SpecialChangeName("NAME", 0x228C + GetResidentDelta());
    FillOwnerInfo();
}


void CMainDlg::OnSpecialChangetowntype() // town type 0 is probably A, but not confirmed
{
    int offset = EORJ(0x15B58, 0x11E7C);
    uint8 townType = g_romsave.GetBufferB(offset);
    if (townType < 0 || townType > 2)
    {
        AfxMessageBox("Unknown town type");
        return;
    }
    CTownTypeDlg dlg(this);
    dlg.m_typeZeroBased = townType;
    if (dlg.DoModal() == IDOK)
    {
        g_romsave.WriteB(offset, dlg.m_typeZeroBased);
    }
}

/////////////////////////////////////////////////////////////////////////////

struct EJ_NAME
{
    const char* szE;
    const char* szJ;
};
#define NUM_SPECIES 150
    // not including
    
static const EJ_NAME g_neighborNames[NUM_SPECIES] =
{
 { "Cyrano", "\x82\xB3\x82\xAD\x82\xE7\x82\xB6\x82\xDC" },
 { "Antonio", "\x83\x7D\x83\x52\x83\x67" },
 { "Pango", "\x83\x70\x83\x67\x83\x89" },
 { "Anabelle", "\x82\xA0\x82\xE9\x82\xDD" },
 { "Teddy", "\x82\xBD\x82\xA2\x82\xD6\x82\xA2\x82\xBD" },
 { "Pinky", "\x83\x5E\x83\x93\x83\x5E\x83\x93" },
 { "Curt", "\x83\x4B\x83\x93\x83\x65\x83\x63" },
 { "Chow", "\x83\x60\x83\x83\x83\x45\x83\x84\x83\x93" },
 { "Jay", "\x83\x63\x83\x6F\x83\x4E\x83\x8D" },
 { "Robin", "\x83\x70\x81\x5B\x83\x60\x83\x4E" },
 { "Anchovy", "\x83\x41\x83\x93\x83\x60\x83\x87\x83\x72" },
 { "Twiggy", "\x83\x73\x81\x5B\x83\x60\x83\x4E" },
 { "Jitters", "\x83\x57\x81\x5B\x83\x6A\x83\x87" },
 { "Angus", "\x83\x5A\x83\x8B\x83\x6F\x83\x93\x83\x65\x83\x58" }, // proper J name?
 { "Rodeo", "\x83\x8D\x83\x66\x83\x49" },
 { "Bob", "\x83\x6A\x83\x52\x83\x6F\x83\x93" },
 { "Mitzi", "\x83\x7D\x81\x5B\x83\x8B" },
 { "Rosie", "\x83\x75\x81\x5B\x83\x50" },
 { "Olivia", "\x83\x49\x83\x8A\x83\x72\x83\x41" },
 { "Kiki", "\x83\x4C\x83\x83\x83\x72\x83\x41" },
 { "Tangy", "\x83\x71\x83\x83\x83\x4E\x83\x70\x81\x5B" },
 { "Punchy", "\x83\x72\x83\x93\x83\x5E" },
 { "Purrl", "\x82\xBD\x82\xDC" },
 { "Moe", "\x83\x57\x83\x93\x83\x79\x83\x43" },
 { "Kabuki", "\x82\xA9\x82\xD4\x82\xAB\x82\xBF" },
 { "Kid Cat", "\x82\x50\x82\xB2\x82\xA4" },
 { "Monique", "\x83\x57\x83\x46\x81\x5B\x83\x93" },
 { "Tabby", "\x83\x67\x83\x89\x82\xB1" },
 { "Bluebear", "\x83\x4F\x83\x8B\x83\x7E\x83\x93" },
 { "Maple", "\x83\x81\x81\x5B\x83\x76\x83\x8B" },
 { "Poncho", "\x83\x7C\x83\x93\x83\x60\x83\x87" },
 { "Pudge", "\x82\xAB\x82\xF1\x82\xBC\x82\xA4" },
 { "Kody", "\x83\x41\x83\x43\x83\x5F\x83\x7A" },
 { "Stitches", "\x83\x70\x83\x62\x83\x60" },
 { "Goose", "\x83\x50\x83\x93\x83\x5E" },
 { "Benedict", "\x82\xD8\x82\xB5\x82\xDD\x82\xBF" },
 { "Egbert", "\x82\xB5\x82\xE0\x82\xE2\x82\xAF" },
 { "Patty", "\x83\x4A\x83\x8B\x83\x73" },
 { "Tipper", "\x82\xDC\x82\xAB\x82\xCE" },
 { "Alfonso", "\x83\x41\x83\x8B\x83\x78\x83\x8B\x83\x67" },
 { "Alli", "\x83\x4E\x83\x8D\x83\x52" },
 { "Goldie", "\x83\x4C\x83\x83\x83\x89\x83\x81\x83\x8B" },
 { "Butch", "\x83\x57\x83\x87\x83\x93" },
 { "Lucky", "\x83\x89\x83\x62\x83\x4C\x81\x5B" },
 { "Biskit", "\x83\x8D\x83\x72\x83\x93" },
 { "Bones", "\x83\x67\x83\x7E" },
 { "Portia", "\x83\x75\x83\x8C\x83\x93\x83\x5F" },
 { "Walker", "\x83\x78\x83\x93" },
 { "Daisy", "\x83\x6F\x83\x6A\x83\x89" },
 { "Bill", "\x83\x73\x81\x5B\x83\x5E\x83\x93" },
 { "Joey", "\x83\x8A\x83\x60\x83\x83\x81\x5B\x83\x68" },
 { "Pate", "\x83\x69\x83\x62\x83\x4C\x81\x5B" },
 { "Maelle", "\x83\x41\x83\x93\x83\x6B" },
 { "Deena", "\x82\xDC\x82\xE8\x82\xE0" },
 { "Pompom", "\x82\xCC\x82\xE8\x82\xC1\x82\xD8" },
 { "Mallary", "\x83\x58\x83\x7E\x83\x82\x83\x82" },
 { "Freckles", "\x83\x7D\x83\x4F\x83\x8D" },
 { "Derwin", "\x83\x7B\x83\x93" },
 { "Drake", "\x83\x74\x83\x48\x83\x41\x83\x4F\x83\x89" },
 { "Opal", "\x83\x49\x83\x70\x81\x5B\x83\x8B" },
 { "Dizzy", "\x83\x71\x83\x85\x81\x5B\x83\x57" },
 { "Big Top", "\x82\x52\x82\xB2\x82\xA4" },
 { "Eloise", "\x83\x47\x83\x8C\x83\x74\x83\x42\x83\x93" },
 { "Margie", "\x83\x54\x83\x8A\x81\x5B" },
 { "Lily", "\x83\x8C\x83\x43\x83\x6A\x81\x5B" },
 { "Ribbot", "\x83\x4B\x83\x60\x83\x83" },
 { "Frobert", "\x83\x52\x81\x5B\x83\x57\x83\x42" },
 { "Camofrog", "\x83\x74\x83\x8B\x83\x81\x83\x5E\x83\x8B" },
 { "Drift", "\x83\x68\x83\x4E" },
 { "Wart Jr.", "\x83\x54\x83\x80" },
 { "Puddles", "\x83\x60\x83\x87\x83\x4C" },
 { "Jeremiah", "\x83\x4E\x83\x8F\x83\x67\x83\x8D" },
 { "Chevre", "\x83\x86\x83\x4C" },
 { "Nan", "\x83\x58\x83\x7E" },
 { "Cesar", "\x83\x41\x83\x89\x83\x93" },
 { "Peewee", "\x83\x5F\x83\x93\x83\x78\x83\x8B" },
 { "Boone", "\x82\xDC\x82\xF1\x82\xBD\x82\xEB\x82\xA4" },
 { "Rocco", "\x83\x53\x83\x93\x83\x55\x83\x8C\x83\x58" },
 { "Buck", "\x83\x94\x83\x40\x83\x84\x83\x56\x83\x52\x83\x74" },
 { "Victoria", "\x83\x5A\x83\x93\x83\x67\x83\x41\x83\x8D\x81\x5B" },
 { "Savannah", "\x83\x54\x83\x6F\x83\x93\x83\x69" },
 { "Elmer", "\x83\x54\x83\x75\x83\x8C" },
 { "Roscoe", "\x83\x56\x83\x85\x83\x6F\x83\x8B\x83\x63" },
 { "Yuka", "\x83\x86\x81\x5B\x83\x4A\x83\x8A" },
 { "Alice", "\x83\x81\x83\x8B\x83\x7B\x83\x8B\x83\x93" },
 { "Melba", "\x83\x41\x83\x66\x83\x8C\x81\x5B\x83\x68" },
 { "Kitt", "\x83\x41\x83\x62\x83\x76\x83\x8A\x83\x50" },
 { "Mathilda", "\x83\x41\x83\x55\x83\x89\x83\x4E" },
 { "Bud", "\x83\x4F\x83\x89\x82\xB3\x82\xF1" },
 { "Elvis", "\x83\x4C\x83\x93\x83\x4F" },
 { "Dora", "\x82\xC6\x82\xDF" },
 { "Limberg", "\x82\xE7\x82\xC1\x82\xAB\x82\xE5" },
 { "Bella", "\x83\x43\x83\x55\x83\x78\x83\x89" },
 { "Bree", "\x83\x54\x83\x89" },
 { "Samson", "\x83\x73\x81\x5B\x83\x58" },
 { "Rod", "\x83\x57\x83\x83\x83\x93" },
 { "Octavian", "\x82\xA8\x82\xAD\x82\xBD\x82\xEB\x82\xA4" },
 { "Marina", "\x83\x5E\x83\x52\x83\x8A\x81\x5B\x83\x69" },
 { "Queenie", "\x83\x5E\x83\x4C\x83\x85" },
 { "Gladys", "\x82\xBF\x82\xC6\x82\xB9" },
 { "Apollo", "\x83\x41\x83\x7C\x83\x8D" },
 { "Amelia", "\x83\x41\x83\x93\x83\x66\x83\x58" },
 { "Pierce", "\x83\x5A\x83\x6F\x83\x58\x83\x60\x83\x83\x83\x93" },
 { "Aurora", "\x83\x49\x81\x5B\x83\x8D\x83\x89" },
 { "Roald", "\x83\x79\x83\x93\x83\x5E" },
 { "Cube", "\x83\x72\x83\x58" },
 { "Hopper", "\x83\x5F\x83\x8B\x83\x7D\x83\x93" },
 { "Friga", "\x83\x54\x83\x75\x83\x8A\x83\x69" },
 { "Gwen", "\x83\x7C\x81\x5B\x83\x89" },
 { "Curly", "\x83\x6E\x83\x80\x83\x4A\x83\x63" },
 { "Truffles", "\x83\x67\x83\x93\x83\x52" },
 { "Rasher", "\x83\x4F\x83\x8C\x83\x49" },
 { "Hugh", "\x83\x4E\x83\x62\x83\x60\x83\x83\x83\x6C" },
 { "Lucy", "\x83\x8B\x81\x5B\x83\x56\x81\x5B" },
 { "Bunnie", "\x83\x8A\x83\x8A\x83\x41\x83\x93" },
 { "Dotty", "\x83\x7D\x81\x5B\x83\x54" },
 { "Coco", "\x82\xE2\x82\xE6\x82\xA2" },
 { "Snake", "\x83\x82\x83\x82\x83\x60" },
 { "Gaston", "\x83\x82\x83\x54\x83\x4C\x83\x60" },
 { "Gabi", "\x83\x79\x83\x60\x83\x4A" },
 { "Pippy", "\x83\x8D\x83\x62\x83\x5E" },
 { "Tiffany", "\x83\x6F\x83\x59\x83\x8C\x81\x5B" },
 { "Genji", "\x83\x51\x83\x93\x83\x57" },
 { "Ruby", "\x83\x8B\x83\x69" },
 { "Tank", "\x82\xAD\x82\xE9\x82\xD4\x82\xB5" },
 { "Rhonda", "\x83\x86\x83\x81\x83\x52" },
 { "Vesta", "\x83\x81\x83\x8A\x83\x84\x83\x58" },
 { "Baabara", "\x83\x67\x83\x8D\x83\x8F" },
 { "Peanut", "\x82\xE0\x82\xE0\x82\xB1" },
 { "Blaire", "\x83\x56\x83\x8B\x83\x47\x83\x62\x83\x67" },
 { "Filbert", "\x83\x8A\x83\x62\x83\x4C\x81\x5B" },
 { "Pecan", "\x83\x8C\x83\x78\x83\x62\x83\x4A" },
 { "Nibbles", "\x83\x4B\x83\x8A\x83\x4B\x83\x8A" },
 { "Agent S", "\x82\x51\x82\xB2\x82\xA4" },
 { "Caroline", "\x83\x4C\x83\x83\x83\x8D\x83\x89\x83\x43\x83\x93" },
 { "Sally", "\x83\x89\x83\x89\x83\x7E\x81\x5B" },
 { "Static", "\x83\x58\x83\x70\x81\x5B\x83\x4E" },
 { "Mint", "\x83\x7E\x83\x93\x83\x67" },
 { "Rolf", "\x83\x60\x83\x87\x83\x82\x83\x89\x83\x93" },
 { "Rowan", "\x83\x53\x83\x81\x83\x58" },
 { "Chief", "\x83\x60\x81\x5B\x83\x74" },
 { "Lobo", "\x83\x75\x83\x93\x83\x57\x83\x8D\x83\x45" },
 { "Wolfgang", "\x83\x8D\x83\x7B" },
 { "Whitney", "\x83\x72\x83\x41\x83\x93\x83\x4A" },
 { "Champ", "\x82\xB3\x82\xE9\x82\xA8" },
 { "Nana", "\x83\x60\x83\x62\x83\x60" },
 { "Simon", "\x83\x47\x83\x65\x83\x4C\x83\x60" },
 { "Tammi", "\x83\x47\x83\x43\x83\x76\x83\x8A\x83\x8B" },
 { "Monty", "\x83\x54\x83\x8B\x83\x82\x83\x93\x83\x65\x83\x42" },
 { "Elise", "\x83\x82\x83\x93\x82\xB1" },
};

const char* GetSpeciesName_E(int species)
{
    if (species >= 0 && species < 150)
        return g_neighborNames[species].szE;
    return "???";
}

/////////////////////////////////////////////////////////////////////////////
// CNeighborDlg message handlers

static CString g_rgstrPersonalities[6];

static void LoadNeighborStrings()
{
    if (g_rgstrPersonalities[0].IsEmpty())
    {
        // load from resources
        for (int i = 0; i < 6; i++)
            g_rgstrPersonalities[i].LoadString(IDS_PERSONALITY0 + i);
    }
}

void CNeighborDlg::FillInfo()
{
    LoadNeighborStrings();
    InvalidateRect(NULL);    // erase all since we use Simple static text controls

    // town name first
    if (IS_ENGLISH()) // Town name decode
    {
        char szT[256];
        FormatMangled_E(szT, 0x2+2, 8);
        SetDlgItemText(IDC_STATIC_NAME0, szT);
    }
    else
    {
        wchar_t wszT[256];
        FormatMangled_J(wszT, 0x2+2, 6);
        SetDlgItemTextW(m_hWnd, IDC_STATIC_NAME0, wszT);
    }

    for (int in = 0; in < 8; in++)
    {
        int noffset = CALC_NOFFSET(in);

        const char* szName = "??";
        uint8 species = g_romsave.GetBufferB(noffset+NDELTA_SPECIES);

        if (species == 255)
        {
            // empty slot
            SetDlgItemText(IDC_STATIC_NEIGH1+in, "[empty]");
            GetDlgItem(IDC_CHANGE_NEIGH1+in)->EnableWindow(FALSE);
            if (GetDlgItem(IDC_STATIC2_NEIGH1+in) != NULL)
                SetDlgItemText(IDC_STATIC2_NEIGH1+in, "");
            continue;
        }
        if (species < NUM_SPECIES)
            szName = g_bJpn ? g_neighborNames[species].szJ :
                    g_neighborNames[species].szE;

        uint8 pers = g_romsave.GetBufferB(noffset+NDELTA_PERSONALITY);
        const char* szPersonality = "???";
        if (pers >= 0 && pers < 6)
            szPersonality = g_rgstrPersonalities[pers];
        char szT[256];
        sprintf(szT, "%s (%s)", szName, szPersonality);
        if (IS_ENGLISH())
        {
            char szCatch[256];    // catch phrase (could be 10?)
            FormatMangled_E(szCatch, noffset+0x86, 10);
            sprintf(szT+strlen(szT), " says \"%s\"", szCatch);
            // sprintf(szT+strlen(szT), ", layout=%d", g_romsave.GetBufferW(noffset+0x9A));
        }

        VERIFY(GetDlgItem(IDC_STATIC_NEIGH1+in) != NULL);
        SetDlgItemText(IDC_STATIC_NEIGH1+in, szT);


        if (GetDlgItem(IDC_STATIC2_NEIGH1+in) != NULL && IS_ENGLISH())
        {
            // UI and gamesave is english
            int nboffset = noffset - 0x658; // noffset AKA 'nxoffset', nboffset points to front part

            szT[0] = '\0';
            for (int iRel = 0; iRel < 8; iRel++)
            {
                int off = nboffset + iRel * 0x68;
                if (g_romsave.GetBufferW(off+0x14) == 2)
                    continue; // blank
                if (g_romsave.GetBufferW(off) == 0)
                    continue; // no town
                if (g_romsave.GetBufferW(off+0xA) == 0)
                    continue; // no town
                char szName[64];
                FormatMangled_E(szName, off+0xA+2, 8);
                if (szT[0] != '\0')
                    strcat(szT, ",");
                strcat(szT, szName);
            }

            CString str;
            if (szT[0] != '\0')
                str.Format("knows %s", szT);
            SetDlgItemText(IDC_STATIC2_NEIGH1+in, str);
        }
    }
}


BOOL CNeighborDlg::OnInitDialog() 
{
    CDialog::OnInitDialog();
    FillInfo();
    return TRUE;
}

void CNeighborDlg::OnDone() 
{
    EndDialog(IDOK);
}

void CNeighborDlg::OnChangeNeigh(UINT id) 
{
    LoadNeighborStrings();
    CNeighInfo dlg(this, id - IDC_CHANGE_NEIGH1);
    dlg.DoModal();
    FillInfo();
}


void CMainDlg::OnMovingNeighborInfo() 
{
    if (!IS_ENGLISH())
    {
        AfxMessageBox("Not supported - US/EU gamesave only");
        return;
    }
    if (g_romsave.GetBufferW(0x11438) == 0)
    {
        AfxMessageBox("No 9th neighbor moving");
        return;
    }
    LoadNeighborStrings();
    CNeighInfo dlg(this, -1);
    dlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CNeighInfo dialog


BEGIN_MESSAGE_MAP(CNeighInfo, CDialog)
    //{{AFX_MSG_MAP(CNeighInfo)
    ON_BN_CLICKED(IDC_NEIGHROOM, OnNeighRoomEdit)
    ON_CBN_SELCHANGE(IDC_DROPLIST_SPECIES, OnSelchangeSpecies)
    ON_BN_CLICKED(IDC_NEIGHRELATION, OnNeighRelationEdit)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

CNeighInfo::CNeighInfo(CWnd* pParent, int index)
    : CDialog(CNeighInfo::IDD, pParent)
{
    //{{AFX_DATA_INIT(CNeighInfo)
    m_editVal = _T("");
    m_species = -1;
    m_personality = -1;
    //}}AFX_DATA_INIT
    ASSERT((index >= 0 && index < 8) || index == -1);
    m_index = index;
}


void CNeighInfo::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CNeighInfo)
    DDX_Text(pDX, IDC_EDIT1, m_editVal);
    DDX_CBIndex(pDX, IDC_DROPLIST_SPECIES, m_species);
    DDX_CBIndex(pDX, IDC_DROPLIST_PERSONALITY, m_personality);
    //}}AFX_DATA_MAP
}

void CNeighInfo::OnOK() 
{
    UpdateData();

    int noffset = CALC_NOFFSET(m_index);
    if (m_index == -1)
        noffset = NOFFSET_9TH_ENG;

    if (IS_ENGLISH())
    {
        // Catch phrase validate
        char szCatch[256];
        if (FormatMangled_E(szCatch, noffset+0x86, 10) &&
            strcmp(szCatch, m_editVal) != 0)
        {
            if (strlen(m_editVal) < 3)
            {
                AfxMessageBox("too short");
                return;
            }
            if (strlen(m_editVal) > 10)
            {
                AfxMessageBox("too long");
                return;
            }
    
            uint8 rgb[10];
            if (!Mangle_E(rgb, m_editVal, 10))
            {
                AfxMessageBox("string contains invalid characters");
                return;
            }
            // save it
            int noffset = CALC_NOFFSET(m_index);
            if (m_index == -1)
                noffset = NOFFSET_9TH_ENG;

            for (int i = 0; i < 10; i++)
                g_romsave.WriteB(noffset+0x86+i, rgb[i]);
            // AfxMessageBox("Catch phrase changed");
        }
    }

    if (g_romsave.GetBufferB(noffset+NDELTA_SPECIES) != m_species)
    {
        g_romsave.WriteB(noffset+NDELTA_SPECIES, (uint8)m_species);
        // AfxMessageBox("Changing Species\nTest by talking to villagers");
    }

    if (g_romsave.GetBufferB(noffset+NDELTA_PERSONALITY) != m_personality)
    {
        g_romsave.WriteB(noffset+NDELTA_PERSONALITY, (uint8)m_personality);
        // AfxMessageBox("Changing personality $72");
    }

    CDialog::OnOK();
}

BOOL CNeighInfo::OnInitDialog() 
{
    int noffset = CALC_NOFFSET(m_index);
    if (m_index == -1)
        noffset = NOFFSET_9TH_ENG;

    if (IS_ENGLISH())
    {
        char szCatch[256];    // catch phrase
        if (FormatMangled_E(szCatch, noffset+0x86, 10))
            m_editVal = szCatch;
        else
            m_editVal = "(not editable)";
    }
    else
    {
        m_editVal = "(n/a)";
        GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);
        if (GetDlgItem(IDC_NEIGHRELATION) != NULL)
            GetDlgItem(IDC_NEIGHRELATION)->EnableWindow(FALSE);
    }

    CComboBox& box1 = *(CComboBox*)GetDlgItem(IDC_DROPLIST_SPECIES);
    // fill in strings
    int i;
    for (i = 0; i < NUM_SPECIES; i++)
        box1.AddString(g_bJpn ? g_neighborNames[i].szJ : g_neighborNames[i].szE);
        
    CComboBox& box2 = *(CComboBox*)GetDlgItem(IDC_DROPLIST_PERSONALITY);
    for (i = 0; i < 6; i++)
        box2.AddString(g_rgstrPersonalities[i]);

    m_personality = g_romsave.GetBufferB(noffset+NDELTA_PERSONALITY);
    m_species = g_romsave.GetBufferB(noffset+NDELTA_SPECIES);
    CDialog::OnInitDialog();    // does dialog-exchange

    return TRUE;
}


void CNeighInfo::OnSelchangeSpecies() 
{
    // or do nothing now
}


/////////////////////////////////////////////////////////////////////////////
// CNeighInfo message handlers

#include "editor.h"


void CNeighInfo::OnNeighRoomEdit() 
{
    int noffset = CALC_NOFFSET(m_index);
    if (m_index == -1)
        noffset = NOFFSET_9TH_ENG;

    uint16 wallfloor[2];
    uint16 layout[10];

    int i;
    for (i = 0; i < 10; i++)
        layout[i] = g_romsave.GetBufferW(noffset+NDELTA_ROOMCONTENT + i*2);
    for (i = 0; i < 2; i++)    // first 2 normal, 3rd blank, 4th upper left
        wallfloor[i] = g_romsave.GetBufferW(noffset+NDELTA_WALLRUG + i*2);

    GRID_INFO gis[2] =
    {
        { wallfloor, 2, 1 },
        { layout, 5, 2 },
    };
    CEditor dlg(this, EM_NEIGHROOM, gis, 2);

    if (dlg.DoModal() == IDOK)
    {
        // save it
        for (i = 0; i < 10; i++)
            g_romsave.WriteW(noffset+NDELTA_ROOMCONTENT + i*2, layout[i]);
        for (i = 0; i < 2; i++)
            g_romsave.WriteW(noffset+NDELTA_WALLRUG + i*2, wallfloor[i]);
    }
}

void CNeighInfo::OnNeighRelationEdit() 
{
    CNeighRelDlg dlg(this);
    dlg.m_index = m_index;
    dlg.DoModal();
}



/////////////////////////////////////////////////////////////////////////////
// CAskNameDlg dialog


CAskNameDlg::CAskNameDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CAskNameDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CAskNameDlg)
    m_strEdit = _T("");
    //}}AFX_DATA_INIT
}


void CAskNameDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CAskNameDlg)
    DDX_Text(pDX, IDC_EDIT1, m_strEdit);
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAskNameDlg, CDialog)
    //{{AFX_MSG_MAP(CAskNameDlg)
        // NOTE: the ClassWizard will add message map macros here
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTownTypeDlg dialog


CTownTypeDlg::CTownTypeDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CTownTypeDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CTownTypeDlg)
    m_typeZeroBased = -1;
    //}}AFX_DATA_INIT
}


void CTownTypeDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CTownTypeDlg)
    DDX_Radio(pDX, IDC_RADIO1, m_typeZeroBased);
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTownTypeDlg, CDialog)
    //{{AFX_MSG_MAP(CTownTypeDlg)
        // NOTE: the ClassWizard will add message map macros here
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Special search/replace
 
void CMainDlg::OnSpecialChangeGeneralName() 
{
    ENGLISH_CHECK(); // general string, never

    CAskNameDlg dlg;
    dlg.m_strEdit = "old_name";
    
    if (dlg.DoModal() != IDOK)
        return;
    if (strlen(dlg.m_strEdit) < 5)
    {
        AfxMessageBox("New name too short\n(at least 5 chars please)");
        return;
    }
    if (strlen(dlg.m_strEdit) > 8)
    {
        AfxMessageBox("New name too long\n(5 to 8 chars please)");
        return;
    }
    uint8 rgbOld[8];
    if (!Mangle_E(rgbOld, dlg.m_strEdit, 8))
    {
        AfxMessageBox("string contains invalid characters");
        return;
    }
    dlg.m_strEdit = "new_name";
    
    if (dlg.DoModal() != IDOK)
        return;
    if (strlen(dlg.m_strEdit) < 5)
    {
        AfxMessageBox("New name too short\n(at least 5 chars please)");
        return;
    }
    if (strlen(dlg.m_strEdit) > 8)
    {
        AfxMessageBox("New name too long\n(5 to 8 chars please)");
        return;
    }
    uint8 rgbNew[8];
    if (!Mangle_E(rgbNew, dlg.m_strEdit, 8))
    {
        AfxMessageBox("string contains invalid characters");
        return;
    }

    char szOldCheck[256];
    char szNewCheck[256];
    if (!FormatMangledArray_E(szOldCheck, rgbOld, 8) ||
        !FormatMangledArray_E(szNewCheck, rgbNew, 8))
    {
        AfxMessageBox("string contains invalid characters (2)");
        return;
    }

    CString strT;

    // Binary search and replace for all occurances that look like the name - 8 bytes only
    int nChange = 0;
    for (int ib = 0; ib < g_verinfo->gameSaveSize-8; ib += 2)
    {
        if (memcmp(rgbOld, g_romsave.GetBufferPtr(ib), 8) == 0)
        {
            strT.Format("IB $%05X\nChange '%s' -> '%s'?",
                        ib, szOldCheck, szNewCheck);
            if (AfxMessageBox(strT, MB_YESNO) == IDYES)
            {
                WriteByteArray(ib, rgbNew, 8);
                ib += 8;
                nChange++;
            }
        }
    }
    strT.Format("Replaced %d strings\nPlease test thoroughly", nChange);
    AfxMessageBox(strT);
}
/////////////////////////////////////////////////////////////////////////////
// CNeighRelDlg dialog


CNeighRelDlg::CNeighRelDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CNeighRelDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CNeighRelDlg)
        // NOTE: the ClassWizard will add member initialization here
    //}}AFX_DATA_INIT
}


void CNeighRelDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CNeighRelDlg)
        // NOTE: the ClassWizard will add DDX and DDV calls here
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNeighRelDlg, CDialog)
    //{{AFX_MSG_MAP(CNeighRelDlg)
    ON_BN_CLICKED(IDC_SAVE, OnSave)
    ON_COMMAND_RANGE(IDC_CHANGE_NEIGH1, IDC_CHANGE_NEIGH8, OnChangeRel)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CNeighRelDlg::OnInitDialog() 
{
    CDialog::OnInitDialog();
    FillInfo();
    return TRUE;
}

void CNeighRelDlg::FillInfo()
{
    InvalidateRect(NULL);    // erase all since we use Simple static text controls

    int noffset = CALC_NOFFSET(m_index);
    if (m_index == -1)
        noffset = NOFFSET_9TH_ENG;

    uint8 species = g_romsave.GetBufferB(noffset+NDELTA_SPECIES);
    if (species == 255 || species >= NUM_SPECIES)
    {
        AfxMessageBox("Internal error");
        EndDialog(IDCANCEL);
    }
    const char* szNpc = g_bJpn ? g_neighborNames[species].szJ : g_neighborNames[species].szE;
    SetDlgItemText(IDC_STATIC_NAME0, szNpc);

    if (!IS_ENGLISH())
    {
        AfxMessageBox("Not supported - US/EU gamesave only"); // should never happen
        EndDialog(IDCANCEL);
    }

    int nboffset = noffset - 0x658; // noffset AKA 'nxoffset', nboffset points to front part

    for (int iRel = 0; iRel < 8; iRel++)
    {
        SetDlgItemText(IDC_STATIC_NEIGH1+iRel, "");
        SetDlgItemText(IDC_STATIC2_NEIGH1+iRel, "");
        GetDlgItem(IDC_CHANGE_NEIGH1+iRel)->EnableWindow(FALSE);

        int off = nboffset + iRel * 0x68;
        if (g_romsave.GetBufferW(off+0x14) == 2)
            continue; // blank
        if (g_romsave.GetBufferW(off) == 0)
            continue; // no town
        if (g_romsave.GetBufferW(off+0xA) == 0)
            continue; // no town
        char szName[64];
        FormatMangled_E(szName, off+0xA+2, 8);
        char szTown[64];
        FormatMangled_E(szTown, off+0x0+2, 8);
        char szTown2[64];
        FormatMangled_E(szTown2, off+0x48+2, 8);

        CString str;
        str.Format("%s from %s", szName, szTown);
        if (strcmp(szTown, szTown2) != 0)
        {
            CString str2;
            str2.Format("/%s", szTown2);
            str += str2;
        }
        SetDlgItemText(IDC_STATIC_NEIGH1+iRel, str);

        char szNick[64];
        FormatMangled_E(szNick, off+0x16, 8);
        str.Format("nickname '%s'", szNick);
        SetDlgItemText(IDC_STATIC2_NEIGH1+iRel, str);
        GetDlgItem(IDC_CHANGE_NEIGH1+iRel)->EnableWindow(TRUE);
    }
}

void CNeighRelDlg::OnSave() 
{
    EndDialog(IDOK);    
}

void CNeighRelDlg::OnChangeRel(UINT id) 
{
    ENGLISH_CHECK(); // should be trapped earlier
    int noffset = CALC_NOFFSET(m_index);
    int nboffset = noffset - 0x658; // noffset AKA 'nxoffset', nboffset points to front part

    int iRel = id - IDC_CHANGE_NEIGH1;    // index to relationship, not neighbor
    ASSERT(iRel >= 0 && iRel < 8);
    int offRel = nboffset + iRel * 0x68;

    char szNick[64];
    FormatMangled_E(szNick, offRel+0x16, 8);

    CAskNameDlg dlg;
    dlg.m_strEdit = szNick;
    
    if (dlg.DoModal() != IDOK)
        return;
    
    if (strlen(dlg.m_strEdit) < 4)
    {
        AfxMessageBox("New name too short\n(at least 4 chars please)");
        return;
    }
    if (strlen(dlg.m_strEdit) > 8)
    {
        AfxMessageBox("New name too long\n(8 max)");
        return;
    }


    uint8 rgbNew[10];
    if (!Mangle_E(rgbNew, dlg.m_strEdit, 8))
    {
        AfxMessageBox("string contains invalid characters");
        return;
    }
    WriteByteArray(offRel+0x16, rgbNew, 8);

    // refresh
    FillInfo();
}

/////////////////////////////////////////////////////////////////////////////
