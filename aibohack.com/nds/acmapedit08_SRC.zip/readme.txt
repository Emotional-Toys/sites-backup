Animal Map - version 1.8 - open source Visual Studio release

-----------------------------------------------------------------

(c) 2005-2007 DsPet
Released as FreeWare and Open-source
Additional modifications thanks to Virus of Haxxor World

You can do anything you want with it, except please don't try to sell it
or anything derived from it.

If you want to add things, please retain original credits (and add your own)
If you come up with something new and cool, please email it to me
(dspet@aibohack.com)
Proper credit will be given for any new discoveries.

-----------------------------------------------------------------
How to build, with Visual C++ 6.0 (not free)

Visual C++ 6.0 is not free.
Open up the project (AnimalMap.dsw) in Visual C++, and build it.

-----------------------------------------------------------------
How to build, using free Visual C++ Express/Visual Studio

This project will compile with Visual Studio 2005 IDE (Aka Visual Studio 8)
or with the Visual C++ 2005 Express Edition IDE
However you need the MFC libraries from the full version of Visual Studio

Open up the project (AnimalMap.vcproj) in Visual Studio 2005, and build it.

If you don't have these tools already, you can get them for free:
Download a 90 day evaluation version of Visual Studio 2005 here
http://msdn2.microsoft.com/en-us/evalcenter/bb188238.aspx
Pick the "Visual Studio 2005 Professional Edition 90-Day Trial"
This will give you the full IDE, libraries, and other features.

After the 90 day evaluation period is over, you can use the libraries
and compile with the free Visual C++ 2005 Express Edition
(free, and never expires)


-----------------------------------------------------------------
If you don't have the proper tools to rebuild the project,
you can learn from the source code and the ROMSAVE format (romsave.txt).
This can be used for other tools, programmed in whatever programming language
you prefer.

The source code is not heavily documented, but most of it is simple.
The original reusable editor design is very clean. Many of the later features
were slapped on quickly, so the source code may look a little mixed up.
Please don't ask me questions about the source code.

The important parts are which bytes of data are changed in the ROMSAVE.
See ROMSAVE.TXT

If you want to explore new features, that is the place to start.

-----------------------------------------------------------------
Interesting source files:

animalmap.cpp - main file (does loading)
maindlg.cpp - most of the main features (including saving)

romsave.cpp - interface to the 256KB gamesave data

editor.cpp - main editor functionality
    (reused for many editors: inventory, world, room, lost+found, etc)
reditor.cpp - river editor
    (special case for the river acre tiles)

ndlg.cpp - neighbor (NPC) related dialogs
emodlg.cpp - emotion editor/dialog
facedlg.cpp - face/hair options/dialog
script.cpp - custom AC:WW character set conversion
compress.cpp - compression specific to my trainer save format

snowmen.cpp - Snowmen attribute editing - of limited use
ards.cpp - special generation of "AR DS" runtime codes

animalmap.rc - resources

-----------------------------------------------------------------
The main source files (".cpp") may include other source files,
usually for data tables. They will have a ".c_" or ".cj_" file extension.

items.cj_ - main items (English and Japanese)
features.cj_ - features/furniture (English and Japanese)

terrain.c_ - terrain items (used by world editor)
buildings.c_ - building types (used by advanced world editor)
danger1.c_, danger2.c_, danger3.c_, danger4.c_ - dangerous items

river.c_ - river tiles/acres (used by reditor.cpp)
tiles.c_ - river tiles/acres used for preview (used in world and river editors)

-----------------------------------------------------------------

NOTE: Japanese translated characters (most in .cj_ files) are stored in
hex code format. They are hex representation mostly in Shift-JIS,
but sometimes in Unicode.
There are no Shift-JIS or Unicode characters embedded in the source files
(ie. everything is ASCII characters in .cpp and .cj_ files)

The resources (AnimalMap.rc) are the exception. They contain Japanese
characters for the Japanese version of the user interface
(translation not done by me)

-----------------------------------------------------------------
Official release point:

http://aibohack.com/nds/ac_mapedit.htm

For AR DS codes and other discussions, check out Haxxor World
http://z13.invisionfree.com/Haxxor_World
("Cheats" forum, registration required)

-----------------------------------------------------------------
