// maindlg.cpp
// all the user interface and editing
// final validation and saving

#include "stdafx.h"
#include "AnimalMap.h"
#include "maindlg.h"

#include "romsave.h"
#include "editor.h"

#include "script.h" // text unmangle
#include "ndlg.h" // neighbor editing

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

class CAboutDlg : public CDialog
{
public:
    CAboutDlg();

// Dialog Data
    //{{AFX_DATA(CAboutDlg)
    enum { IDD = IDD_ABOUTBOX };
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CAboutDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:
    //{{AFX_MSG(CAboutDlg)
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
    //{{AFX_DATA_INIT(CAboutDlg)
    //}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CAboutDlg)
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
    //{{AFX_MSG_MAP(CAboutDlg)
        // No message handlers
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CMainDlg dialog

CMainDlg::CMainDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CMainDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CMainDlg)
    //}}AFX_DATA_INIT
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    m_bAdvanced = g_bAdvancedUser;
    m_iResident = 0;
    m_dangerLevel = 0;
}

void CMainDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CMainDlg)
    DDX_Control(pDX, IDC_OWNERCASH2, m_ownerBank);
    DDX_Control(pDX, IDC_ADVANCED_OR_BASIC, m_btnAdvancedOrBasic);
    DDX_Control(pDX, IDC_OWNERPTS, m_ownerPts);
    DDX_Control(pDX, IDC_OWNERCASH, m_ownerCash);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMainDlg, CDialog)
    //{{AFX_MSG_MAP(CMainDlg)
    ON_WM_SYSCOMMAND()
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_BN_CLICKED(IDC_MORE_MONEY, OnMoreMoney)
    ON_BN_CLICKED(IDC_MORE_POINTS, OnMorePoints)
    ON_BN_CLICKED(IDC_SAVE, OnSave)
    ON_BN_CLICKED(IDC_EDIT_INVENTORY1, OnEditInventory1)
    ON_BN_CLICKED(IDC_EDIT_WORLDMAP, OnEditWorldmap)
    ON_BN_CLICKED(IDC_EDIT_ROOMMAP, OnEditRoommap)
    ON_BN_CLICKED(IDC_EDIT_SUPERROOM, OnEditSuperroom)
    ON_BN_CLICKED(IDC_EDIT_RIVER, OnEditRiver)
    ON_BN_CLICKED(IDC_EDIT_WORLD_ADVANCED, OnEditWorldAdvanced)
    ON_BN_CLICKED(IDC_EDIT_NEIGHBOR, OnEditNeighbor)
    ON_BN_CLICKED(IDC_ADVANCED_OR_BASIC, OnAdvancedOrBasic)
    ON_BN_CLICKED(IDC_EDIT_GIFTS, OnEditGifts)
    ON_BN_CLICKED(IDC_EDIT_EQUIP, OnEditEquip)
    ON_COMMAND(ID_SPECIAL_FILLOUTCATALOG, OnSpecialFilloutcatalog)
    ON_COMMAND(ID_SPECIAL_FILLOUTMUSIC, OnSpecialFilloutmusic)
    ON_COMMAND(ID_SPECIAL_CHANGETOWNNAME, OnSpecialChangetownname)
    ON_COMMAND(ID_SPECIAL_CHANGEHOUSE, OnHouseInfo)
    ON_COMMAND(ID_SPECIAL_CHANGERESIDENTNAME, OnSpecialChangeResidentName)
    ON_COMMAND(ID_SPECIAL_CHANGEFORMATCOMPRESSEDSAV, OnSpecialChangeformatcompressedsav)
    ON_COMMAND(ID_SPECIAL_UNBURYALLWORLDMAPITEMS, OnSpecialUnburyallworldmapitems)
    ON_COMMAND(ID_EDIT_EDITLOSTFOUND, OnEditEditlostfound)
    ON_COMMAND(ID_EDIT_EDITRECYCLER, OnEditEditrecycler)
    ON_COMMAND(ID_EDIT_EDITRESIDENTDRAWERS, OnEditEditresidentDrawers)
    ON_COMMAND(ID_EDIT_EDITNOOKSTOREITEMS, OnEditEditnookstoreitems)
    ON_COMMAND(ID_EDIT_EDITRIVERSUPERMODE, OnEditSuperRiverMode)
    ON_COMMAND(ID_SPECIAL_CHANGETOWNTYPE, OnSpecialChangetowntype)
    ON_COMMAND(ID_EDIT_EDITEMOTIONSRESIDENT, OnEditEditEmotionsResident)
    ON_BN_CLICKED(IDC_MORE_MONEY2, OnMoreMoney2)
    ON_COMMAND(ID_SPECIAL_NEXTRESIDENT, OnSpecialNextResident)
    ON_COMMAND(ID_MOVINGNEIGHBOR, OnMovingNeighborInfo)
    ON_COMMAND(ID_EDIT_EDITBEDROOM, OnEditBedroom)
    ON_COMMAND(IDC_DANGER_LEVEL0, OnDangerLevel0)
    ON_COMMAND(IDC_DANGER_LEVEL1, OnDangerLevel1)
    ON_COMMAND(IDC_DANGER_LEVEL2, OnDangerLevel2)
    ON_COMMAND(IDC_DANGER_LEVEL3, OnDangerLevel3)
    ON_COMMAND(IDC_DANGER_LEVEL4, OnDangerLevel4)
    ON_COMMAND(ID_PLAYER_CHANGEFACE, OnPlayerChangeFaceEtc)
    ON_COMMAND(ID_ARDS_BRIDGES, OnArdsGenBridges)
    ON_COMMAND(ID_ARDS_SNAPSHOT, OnArdsSnapshot)
    ON_COMMAND(ID_ARDS_DIFF, OnArdsDiff)
    ON_COMMAND(ID_SNOWMEN, OnSnowmenTweek)
    //}}AFX_MSG_MAP
    //ON_COMMAND(ID_SPECIAL_CHANGEGENERALNAME, OnSpecialChangeGeneralName)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainDlg message handlers

void CMainDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
    if ((nID & 0xFFF0) == IDM_ABOUTBOX)
    {
        CAboutDlg dlgAbout;
        dlgAbout.DoModal();
    }
    else
    {
        CDialog::OnSysCommand(nID, lParam);
    }
}

void CMainDlg::OnPaint() 
{
    if (IsIconic())
    {
        CPaintDC dc(this);
        SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
        CDialog::OnPaint();
    }
}

HCURSOR CMainDlg::OnQueryDragIcon()
{
    return (HCURSOR) m_hIcon;
}

/////////////////////////////////////////////////////////////////////////////

BOOL CMainDlg::OnInitDialog()
{
    CDialog::OnInitDialog();
    ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
    ASSERT(IDM_ABOUTBOX < 0xF000);
    CMenu* pSysMenu = GetSystemMenu(FALSE);
    if (pSysMenu != NULL)
    {
        CString strAboutMenu;
        strAboutMenu.LoadString(IDS_ABOUTBOX);
        if (!strAboutMenu.IsEmpty())
        {
            pSysMenu->AppendMenu(MF_SEPARATOR);
            pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
        }
    }
    SetIcon(m_hIcon, TRUE);            // Set big icon
    SetIcon(m_hIcon, FALSE);        // Set small icon
    m_menuAdvanced.LoadMenu(IDR_SPECIAL_MENU);

    EnableButtons(m_bAdvanced);

    FillOwnerInfo();

    if (IS_ENGLISH())
    {
        CString strReport;
        if (g_romsave.GetBufferW(0x11438) != 0)
        {
            CString strT;
            char szTown1[64];
            char szTown2[64];
            FormatMangled_E(szTown1, 0x11438+2, 8);
            FormatMangled_E(szTown2, 0x1144C+2, 8);
            strT.Format("9th Neighbor moving in progress\n%s is moving from %s\n",
                GetSpeciesName_E(g_romsave.GetBufferB(0x11443)), szTown1);
            strReport += strT;
            if (strcmp(szTown1, szTown2) != 0)
            {
                strT.Format("  and town %s\n", szTown2);
                strReport += strT;
            }
        }
        if (!strReport.IsEmpty())
            AfxMessageBox(strReport);
    }

    if (!g_bAdvancedUser)
    {
        // anal warning mode for newbies
        int danger_counts[1+4];
        g_romsave.CountDangerous(danger_counts);
        CString strReport;
        if (danger_counts[4] > 0)
        {
            strReport.Format("Detected %d very dangerous items\n", danger_counts[4]);
            AfxMessageBox(strReport);
            OnDangerLevel4(); // ask question
            if (m_dangerLevel != 4)
                EndDialog(IDCANCEL);
        }
        else if (danger_counts[3] > 0)
        {
            // rocks
            strReport.Format("Detected %d potentially dangerous items\n", danger_counts[3]);
            AfxMessageBox(strReport);
            OnDangerLevel3(); // ask question
            if (m_dangerLevel != 3)
                EndDialog(IDCANCEL);
        }
        else if (danger_counts[2] > 0 || danger_counts[1] > 0)
        {
            strReport.Format("Detected %d mildly dangerous items",
                danger_counts[2] + danger_counts[1]);
            AfxMessageBox(strReport);
            // bump to appropriate level
            if (danger_counts[2] > 0)
                OnDangerLevel2();
            else
                OnDangerLevel1();
        }
        else
        {
            OnDangerLevel0();   // set checkmark, no warning
        }
    }
    else
    {
        OnDangerLevel4();   // advanced user
    }

    return TRUE;
}

void CMainDlg::EnableButtons(bool bAdv)
{
    this->m_btnAdvancedOrBasic.SetWindowText(bAdv ? "<<< Basic" : "Advanced >>>");
    GetDlgItem(IDC_EDIT_SUPERROOM)->ShowWindow(bAdv);
    GetDlgItem(IDC_EDIT_RIVER)->ShowWindow(bAdv);
    GetDlgItem(IDC_EDIT_WORLD_ADVANCED)->ShowWindow(bAdv);

    GetDlgItem(IDC_GROUP_BOX_ADVANCED)->ShowWindow(bAdv);

    if (bAdv)
        SetMenu(&m_menuAdvanced);
    else
        SetMenu(NULL); // no menu in basic mode

    if (!IS_ENGLISH()) // Disable buttons that don't work in J version
    {
	    CWnd* pbtn;
		if ((pbtn = GetDlgItem(IDC_EDIT_GIFTS)) != NULL)
			pbtn->ShowWindow(FALSE);
		if ((pbtn = GetDlgItem(IDC_EDIT_EQUIP)) != NULL)
			pbtn->ShowWindow(FALSE);

        if (bAdv)
        {
            m_menuAdvanced.EnableMenuItem(ID_SPECIAL_CHANGERESIDENTNAME, MF_DISABLED|MF_GRAYED);
            m_menuAdvanced.EnableMenuItem(ID_SPECIAL_CHANGETOWNNAME, MF_DISABLED|MF_GRAYED);
            m_menuAdvanced.EnableMenuItem(ID_SPECIAL_FILLOUTCATALOG, MF_DISABLED|MF_GRAYED);
            m_menuAdvanced.EnableMenuItem(ID_SPECIAL_FILLOUTMUSIC, MF_DISABLED|MF_GRAYED);
            m_menuAdvanced.EnableMenuItem(ID_MOVINGNEIGHBOR, MF_DISABLED|MF_GRAYED);
            m_menuAdvanced.EnableMenuItem(ID_EDIT_EDITBEDROOM, MF_DISABLED|MF_GRAYED);
            m_menuAdvanced.EnableMenuItem(ID_PLAYER_CHANGEFACE, MF_DISABLED|MF_GRAYED);
            m_menuAdvanced.EnableMenuItem(ID_SPECIAL_CHANGEHOUSE, MF_DISABLED|MF_GRAYED);
            m_menuAdvanced.EnableMenuItem(ID_SNOWMEN, MF_DISABLED|MF_GRAYED);
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Owner editing

void CMainDlg::FillOwnerInfo()
{
    char szT[128];
    int delta = GetResidentDelta();
    // int offset = OFFSET_INVENTORY1 + delta;

    uint32 cash = g_romsave.GetBufferL(OFFSET_MONEY1 + delta);
    sprintf(szT, "%d", cash);
    m_ownerCash.SetWindowText(szT);

    uint32 bank = g_romsave.GetBufferL(OFFSET_BANK1 + delta);
    sprintf(szT, "%d", bank);
    m_ownerBank.SetWindowText(szT);

    uint16 points = g_romsave.GetBufferW(OFFSET_POINTS1 + delta);
    sprintf(szT, "%d", points);
    m_ownerPts.SetWindowText(szT);
    
    // owner number/name on group box
    if (IS_ENGLISH())
    {
        int ibTaggedName = OFFSET_PLAYER_NAME + GetResidentDelta();
        sprintf(szT, "Resident #%d", 1+m_iResident);
        char szName[256];
        if (FormatMangled_E(szName, ibTaggedName+2, 8))
            sprintf(szT+strlen(szT), " [%s]", szName);
        SetDlgItemText(IDC_RESIDENT_TITLE, szT);
    }
    else
    {
        // Japanese format, display as Unicode
        wchar_t wszT[128];
        swprintf(wszT, L"Resident #%d", 1+m_iResident);
        int ibTaggedName = OFFSET_PLAYER_NAME + GetResidentDelta();
        wchar_t wszName[256];
        FormatMangled_J(wszName, ibTaggedName+2, 6);
        wcscat(wszT, L" [");
        wcscat(wszT, wszName);
        wcscat(wszT, L"]");
        ::SetDlgItemTextW(m_hWnd, IDC_RESIDENT_TITLE, wszT);
    }

    SetDlgItemText(IDC_TOWN_INFO, "");
    // Town info
    if (IS_ENGLISH())
    {
        // English-only donation
        FormatMangled_E(szT, 0x2+2, 8);
        SetDlgItemText(IDC_TOWN_NAME, szT);

        if (m_bAdvanced)
        {
            uint32 donate = g_romsave.GetBufferL(0x12008);
            sprintf(szT, "boondox: %ld", donate);
            SetDlgItemText(IDC_TOWN_INFO, szT);
        }
    }
    else
    {
        wchar_t wszT[256];
        FormatMangled_J(wszT, 0x2+2, 6);
        SetDlgItemTextW(m_hWnd, IDC_TOWN_NAME, wszT);
    }

    // title based on filename
    char szFname[_MAX_FNAME];
    _splitpath(g_saveInfo.m_path, NULL, NULL, szFname, NULL);

    CString title;
    title.Format(IDS_VERSION_FMT, szFname);

    if (g_saveInfo.m_type == SAVE_INFO::ST_DSS &&
        memcmp(g_saveInfo.m_extra, "ARDS000000000001", 16) == 0)
    {
        const char* szARName = (const char*)&g_saveInfo.m_extra[0x174];
        title += " ";
        title += szARName;
    }
    SetWindowText(title);

}

int CMainDlg::GetResidentDelta()
{
    ASSERT(m_iResident >= 0 && m_iResident <= 3);
    return m_iResident * EORJ(PLAYER_SIZE_ENG, PLAYER_SIZE_JPN);
}


#define MAX_MONEY  9999999
#define MAX_BANK 999999999
#define MAX_POINTS 50000

void CMainDlg::OnMoreMoney() 
{
    int delta = GetResidentDelta();
    uint32 old1 = g_romsave.GetBufferL(OFFSET_MONEY1 + delta);
    uint32 new1 = old1 + 100000;
    if (new1 > MAX_MONEY)
        new1 = MAX_MONEY;
    g_romsave.WriteL(OFFSET_MONEY1 + delta, new1);

    FillOwnerInfo();
}

void CMainDlg::OnMoreMoney2() 
{
    int delta = GetResidentDelta();
    uint32 old1 = g_romsave.GetBufferL(OFFSET_BANK1 + delta);
    uint32 new1 = old1 + 1000000;
    if (new1 > MAX_BANK)
        new1 = MAX_BANK;
    g_romsave.WriteL(OFFSET_BANK1 + delta, new1);

    FillOwnerInfo();
}

void CMainDlg::OnMorePoints() 
{
    int delta = GetResidentDelta();
    uint16 old1 = g_romsave.GetBufferW(OFFSET_POINTS1 + delta);
    uint16 new1 = old1;
    if (new1 < MAX_POINTS)
        new1 = MAX_POINTS;
    if (new1 > MAX_POINTS)
        new1 = MAX_POINTS;
    g_romsave.WriteW(OFFSET_POINTS1 + delta, new1);

    FillOwnerInfo();
}


/////////////////////////////////////////////////////////////////////////////

#define MAX_SRAM_SIZE 0x10000
BYTE g_sramBuffer[MAX_SRAM_SIZE];

static void widen(BYTE* pbOut, const char* sz, int cch)
{
    while (cch--)
    {
        // ASCII only
        *pbOut++ = *sz++;
        *pbOut++ = 0;
    }
}

void CMainDlg::OnSave() 
{
    // perform sanity check before saving
    if (CalcSumW(g_romsave.GetBufferPtr(0), GAMESIZE) != 0 ||
         CalcSumW(g_romsave.GetBufferPtr(GAMESIZE), GAMESIZE) != 0 ||
         memcmp(g_romsave.GetBufferPtr(0), g_romsave.GetBufferPtr(GAMESIZE), OFF_CSUM) != 0)
    {
        AfxMessageBox("Internal error - can not save (buffer mismatch)\n"
            "Please email dspet@aibohack.com");
        return;
    }

    if (g_saveInfo.m_type == SAVE_INFO::ST_ANIMALSAVE_ENG || g_saveInfo.m_type == SAVE_INFO::ST_ANIMALSAVE_ENG_M3)
    {
        // compress first, so file won't be wiped if it won't fit
        ASSERT(GAMESIZE == GAMESIZE_ENG);
        memset(g_sramBuffer, 0x55, MAX_SRAM_SIZE); // pre-erase
        int n = CompressSave2(g_romsave.GetBufferPtr(0), FULL_SAVE_SIZE, g_sramBuffer, MAX_SRAM_SIZE, GAMESIZE, false);
        if (n < 0)
        {
            AfxMessageBox("ERROR can not save as compressed ANMLSAVE\n"
                "Please email dspet@aibohack.com");
            return;
        }
        ASSERT(n > 0 && n <= MAX_SRAM_SIZE);
    }
    else if (g_saveInfo.m_type == SAVE_INFO::ST_ANIMALSAVE_JPN || g_saveInfo.m_type == SAVE_INFO::ST_ANIMALSAVE_JPN_M3)
    {
        ASSERT(GAMESIZE == GAMESIZE_JPN);
        memset(g_sramBuffer, 0x55, MAX_SRAM_SIZE); // pre-erase
        int n = CompressSave2(g_romsave.GetBufferPtr(0), FULL_SAVE_SIZE, g_sramBuffer, MAX_SRAM_SIZE, GAMESIZE, true);
        if (n < 0)
        {
            AfxMessageBox("ERROR can not save as compressed ANMLSAVE (J)\n"
                "Please email dspet@aibohack.com");
            return;
        }
        ASSERT(n > 0 && n <= MAX_SRAM_SIZE);
    }

    if (!g_romsave.GetModifiedFlag())
    {
        if (AfxMessageBox(IDS_NOTHING_CHANGED, MB_YESNOCANCEL) != IDYES)
            return;
    }

    CString strReport;

    if (g_saveInfo.m_type == SAVE_INFO::ST_DSS &&
        memcmp(g_saveInfo.m_extra, "ARDS000000000001", 16) == 0)
    {
        // Action Replay format

        char szName[20+1];
        memcpy(szName, (char*)&g_saveInfo.m_extra[0x174], 20);
        szName[20] = '\0';
        int cch = strlen(szName);
        // Ver### at the end will be bumped
        if (cch >= 1+6 &&
            memcmp(&szName[cch-6], "Ver", 3) == 0 &&
            isdigit(szName[cch-3]) &&
            isdigit(szName[cch-2]) &&
            isdigit(szName[cch-1]))
        {
            int nVer = atoi(&szName[cch-3]);
            nVer++;
            if (nVer <= 0 || nVer > 999)
                nVer = 1;
            sprintf(&szName[cch-3], "%03d", nVer);
            strReport.Format("\nNew ActionReplay name '%s'", szName);
            memcpy((char*)&g_saveInfo.m_extra[0x174], szName, 20);
            widen(&g_saveInfo.m_extra[0x50], szName, 20);
        }
        else if (cch <= 13)
        {
            // room for ' ' + 'Ver001'
            if (AfxMessageBox(IDS_ASK_START_VERSIONING, MB_YESNO) == IDYES)
            {
                sprintf(&szName[cch], " Ver%03d", 1);
                strReport.Format("\nNew ActionReplay name '%s'", szName);
                memcpy((char*)&g_saveInfo.m_extra[0x174], szName, 20);
                widen(&g_saveInfo.m_extra[0x50], szName, 20);
            }
        }
    }

    FILE* pfOut = fopen(g_saveInfo.m_path, "wb");
    if (pfOut == NULL)
    {
        AfxMessageBox("Can't open save file for writing");
        return;
    }

    int bErr = false;
    switch (g_saveInfo.m_type)
    {
    case SAVE_INFO::ST_DSS:
        ASSERT(g_saveInfo.m_extra != NULL);
        if (fwrite(g_saveInfo.m_extra, 500, 1, pfOut) != 1)
            bErr = true;
        // fall through to ST_RAW
    case SAVE_INFO::ST_RAW:
        if (fwrite(g_romsave.GetBufferPtr(0), FULL_SAVE_SIZE, 1, pfOut) != 1)
            bErr = true;
        break;

    case SAVE_INFO::ST_ANIMALSAVE_ENG:
    case SAVE_INFO::ST_ANIMALSAVE_JPN:
        // save entire 64KB (padded with $55)
        if (fwrite(g_sramBuffer, MAX_SRAM_SIZE, 1, pfOut) != 1)
            bErr = true;
        break;

    case SAVE_INFO::ST_ANIMALSAVE_ENG_M3:
    case SAVE_INFO::ST_ANIMALSAVE_JPN_M3:
        ASSERT(g_saveInfo.m_extra != NULL);
        // save 64KB bytes duplicate to 256KB, add extra M3 data
        {
            for (int iPart = 0; iPart < 4; iPart++)
            {
                if (fwrite(g_sramBuffer, MAX_SRAM_SIZE, 1, pfOut) != 1)
                    bErr = true;
            }
        }
        if (fwrite(g_saveInfo.m_extra, 1024, 1, pfOut) != 1)
            bErr = true;
        break;

    case SAVE_INFO::ST_PADDED:
        ASSERT(g_saveInfo.m_extra != NULL);
        ASSERT(g_saveInfo.m_extralen > 0);
        if (fwrite(g_romsave.GetBufferPtr(0), FULL_SAVE_SIZE, 1, pfOut) != 1)
            bErr = true;
        if (fwrite(g_saveInfo.m_extra, g_saveInfo.m_extralen, 1, pfOut) != 1)
            bErr = true;
        break;

    default:
        bErr = true;
        break;
    }

    if (fclose(pfOut) != 0)
        bErr = true;
    if (bErr)
    {
        AfxMessageBox("Failed when trying to save\n");
        return;
    }

    CString strT;
    strT.Format("%s saved", g_saveInfo.m_path);
    if (!strReport.IsEmpty())
        strT += strReport;
    
    AfxMessageBox(strT);
    EndDialog(IDC_SAVE);    
}

void CMainDlg::OnCancel() 
{
    if (g_romsave.GetModifiedFlag())
    {
        if (AfxMessageBox(IDS_ASK_LOSE_CHANGES, MB_YESNOCANCEL) != IDYES)
            return;
    }
    CDialog::OnCancel();
}


/////////////////////////////////////////////////////////////////////////////



void CMainDlg::OnEditWorldmap() 
{
    DoWorldEdit(false);
}

void CMainDlg::OnEditWorldAdvanced() 
{
    DoWorldEdit(true);
}

static int CountBits8(uint8 b)
{
    int n = 0;
    for (int i = 0; i < 8; i++)
        if (b & (1 << i))
            n++;
    return n;
}

void CMainDlg::DoWorldEdit(bool bAdvanced)
{
    
    uint16 map[64*64];
    // convert from 16x16 grid format to regular layout

    int neighborsPresent = 0;

    uint16* pw = map;


    int offsetBase = g_verinfo->offsetWorldMap;
    int iyCell;
    for (iyCell = 0; iyCell < 4; iyCell++)
    {
        for (int dy = 0; dy < 16; dy++)
        {
            for (int ixCell = 0; ixCell < 4; ixCell++)
            {
                int offset = offsetBase + (iyCell*256*4+ixCell*256 + dy*16) * 2;
                for (int dx = 0; dx < 16; dx++)
                {
                    uint16 val = g_romsave.GetBufferW(offset);
                    *pw++ = val;
                    offset += 2;
                    if (val >= 0x5001 && val <= 0x5008)
                        neighborsPresent |= (1 << (val - 0x5001));
                }
            }
        }
    }


#if 0
    // old version had acre grid only in advanced editor
    GRID_INFO giBasic = { map, 64, 64 };
    GRID_INFO giAdv = { map, 64, 64, -16, -16 }; // 16x16 cell grid
    CEditor editor(this, bAdvanced ? EM_WORLD_ADVANCED : EM_WORLD, bAdvanced ? &giAdv : &giBasic, 1);
#else
    // 16x16 acres in either version
    GRID_INFO giAcres = { map, 64, 64, -16, -16 }; // 16x16 cell grid
    CEditor editor(this, bAdvanced ? EM_WORLD_ADVANCED : EM_WORLD, &giAcres, 1);
#endif

    uint8 tilemap[4*4];    // 4*4 central area
    // BLOCK: background grid - core area only
    {
        int offset = g_verinfo->offsetTilemap + 6 + 1;
        for (int i = 0; i < 16; i++)
        {
            tilemap[i] = g_romsave.GetBufferB(offset);
            offset++;
            if ((i & 3) == 3)
                offset += 2;
        }
        editor.SetTileMap(tilemap);
    }

    uint8 holemap[0x200];    // 4K holes, organized by 16x16 tile
    ASSERT(OFFSET_BURY_BITMAP != 0);
    //BLOCK: bury bitmap is required
    {
        uint8* phole = holemap;
        int offset = OFFSET_BURY_BITMAP;
        for (iyCell = 0; iyCell < 4; iyCell++)
        {
            for (int dy = 0; dy < 16; dy++)
            {
                for (int ixCell = 0; ixCell < 4; ixCell++)
                {
                    // 16 cells per row = 2 bytes
                    int offset = OFFSET_BURY_BITMAP + (iyCell*16*4+ixCell*16 + dy)*2;
                    *phole++ = g_romsave.GetBufferB(offset);
                    *phole++ = g_romsave.GetBufferB(offset+1);
                }
            }
        }
        ASSERT(phole == &holemap[0x200]);
        editor.SetHoleMap(holemap);
    }

#define HOUSES_TO_TRACK    0x30
    struct HOUSE_INFO
    {
        int nFound;
        int xWorld, yWorld;
    } house_info[HOUSES_TO_TRACK]; // 0x5000 based
    memset(house_info, 0, sizeof(house_info));
    int rgnSnowmen[3];
    memset(rgnSnowmen, 0, sizeof(rgnSnowmen));

    if (editor.DoModal() == IDOK)
    {
        // save it, also accumulate neighbor info
        pw = map;
        int yWorld = 0;
        int iyCell;
        for (iyCell = 0; iyCell < 4; iyCell++)
        {
            for (int dy = 0; dy < 16; dy++)
            {
                int xWorld = 0;
                for (int ixCell = 0; ixCell < 4; ixCell++)
                {
                    int offset = offsetBase + (iyCell*256*4+ixCell*256 + dy*16) * 2;
                    for (int dx = 0; dx < 16; dx++)
                    {
                        uint16 valOld = g_romsave.GetBufferW(offset);
                        uint16 valNew = *pw++;
                        if (!bAdvanced && IsBuilding(valOld) != IsBuilding(valNew))
                        {
                            AfxMessageBox("ERROR: trying to destroy a house\nUse advanced world editor.");
                        }
                        else
                        {
                            g_romsave.WriteW(offset, valNew);
                        }
                        offset += 2;

                        if (valNew >= 0x5000 && valNew < 0x5000 + HOUSES_TO_TRACK)
                        {
                            HOUSE_INFO& hi = house_info[valNew - 0x5000];
                            if (hi.nFound++ == 0) // first one only
                            {
                                hi.xWorld = xWorld;
                                hi.yWorld = yWorld;
                            }
                        }

                        if (valNew >= 0xB001 && valNew <= 0xB003)
                            rgnSnowmen[valNew-0xB001]++;

                        xWorld++;
                    }
                }
                yWorld++;
            }
        }

        CString strReport;
        ASSERT(OFFSET_BURY_BITMAP != 0);
        // BLOCK: Bury bitmap is required
        {
            int nHoles = 0;
            uint8* phole = holemap;
            for (iyCell = 0; iyCell < 4; iyCell++)
            {
                for (int dy = 0; dy < 16; dy++)
                {
                    for (int ixCell = 0; ixCell < 4; ixCell++)
                    {
                        // 16 cells per row = 2 bytes
                        int offset = OFFSET_BURY_BITMAP + (iyCell*16*4+ixCell*16 + dy)*2;
                        uint8 b0 = *phole++;
                        uint8 b1 = *phole++;
                        g_romsave.WriteB(offset, b0);
                        g_romsave.WriteB(offset+1, b1);
                        nHoles += (CountBits8(b0) + CountBits8(b1));
                    }
                }
            }
            ASSERT(phole == &holemap[0x200]);
        }

        if (bAdvanced)
        {
            // Fix neighbors if necessary - english hard coded
            for (int in = 0; in < 8; in++)
            {
                CString str;
                HOUSE_INFO& hi = house_info[1+in];
                if (hi.nFound == 0)
                {
                    // not present
                    if (neighborsPresent & (1 << in))
                    {
                        str.Format("You deleted Neighbor #%d - May cause problems\n", 1+in);
                        strReport += str;
                    }
                }
                else
                {
                    int noffset = CALC_NOFFSET(in);
                    
                    if (!(neighborsPresent & (1 << in)))
                    {
                        str.Format("You added Neighbor #%d - May be ignored\n", 1+in);
                        strReport += str;
                    }
                    else if (hi.nFound > 2)
                    {
                        str.Format("Many duplicates for Neighbor #%d (%d total)\n", 1+in, hi.nFound);
                        strReport += str;
                    }

                    // check/patch first location
                    int x2 = g_romsave.GetBufferB(noffset+NDELTA_X2) - 0x10;
                    int y2 = g_romsave.GetBufferB(noffset+NDELTA_Y2) - 0x10;
                    if (x2 != hi.xWorld || y2 != hi.yWorld)
                    {
                        g_romsave.WriteB(noffset+NDELTA_X2, hi.xWorld + 0x10);
                        g_romsave.WriteB(noffset+NDELTA_Y2, hi.yWorld + 0x10);
                        str.Format("Patching location for Neighbor #%d\n", 1+in);
                        strReport += str;
                    }
                }
            }
        }
        if (house_info[0x21].nFound > 12)
        {
            CString str;
            str.Format("WARNING: %d automobiles on map (may not work)\n", house_info[0x21].nFound);
            strReport += str;
        }
        else if (house_info[0x21].nFound > 3)
        {
            CString str;
            str.Format("FYI: %d automobiles on map\n", house_info[0x21].nFound);
            strReport += str;
        }

        if (house_info[0x00].nFound < 1)
            strReport += "Warning: no town center\n";
        if (house_info[0x00].nFound < 1)
            strReport += "Warning: no bulletin board\n";
        if (house_info[0x0B].nFound < 1)
            strReport += "Warning: no gate house\n";
        if (house_info[0x0B].nFound > 1)
            strReport += "Warning: multiple gate houses\n";
        if (house_info[0x0B].nFound < 1)
            strReport += "Warning: no museum\n";

        for (int i = 0; i < 3; i++)
        {
            CString strNum;
            strNum.Format("#%d", 1+i);

            if (rgnSnowmen[i] > 1)
                strReport += "too many snowmen " + strNum + "\n";
            else if (rgnSnowmen[i] == 1 && IS_ENGLISH())
            {
                int ibBase = 0x15F96 + i * 6;
                if (g_romsave.GetBufferW(ibBase) == 0)
                    strReport += "snowman " + strNum + " melted\n";
            }
        }

        if (!strReport.IsEmpty())
        {
            CString str = "Fixing neighbor info:\n" + strReport;
            AfxMessageBox(str);
        }
        g_romsave.SetModifiedFlag(TRUE); // just in case
    }
    
}

static void GetRoomArray(uint16* array, int offset, int cx, int cy)
{
    int y;
    for (y = 0; y < cy; y++)
    {
        int x;
        for (x = 0; x < 16; x++)
        {
            if (x < cx)
                *array++ = g_romsave.GetBufferW(offset);
            offset += 2;
        }
        // later part is items on top...
    }
}

static void SetRoomArray(uint16 const* array, int offset, int cx, int cy)
{
    int y;
    for (y = 0; y < cy; y++)
    {
        int x;
        for (x = 0; x < 16; x++)
        {
            if (x < cx)
                g_romsave.WriteW(offset, *array++);
            offset += 2;
        }
    }
}


void CMainDlg::OnEditRoommap() 
{
    int offset = g_verinfo->offsetMainRoom;    // start of main 8x8 room
    uint16 main[8*8];
    GetRoomArray(main, g_verinfo->offsetMainRoom, 8, 8);
    offset += 0x450 + 0x42;
    uint16 north[6*6];    
    GetRoomArray(north, offset, 6, 6);
    offset += 0x450;
    uint16 east[6*6];    
    GetRoomArray(east, offset, 6, 6);
    offset += 0x450;
    uint16 west[6*6];    
    GetRoomArray(west, offset, 6, 6);
    offset += 0x450;
    uint16 level2[6*6];    
    GetRoomArray(level2, offset, 6, 6);

    GRID_INFO gis[5] =
    {
        { main, 8, 8 }, // assumes full expanded size
        { north, 6, 6 },
        { east, 6, 6 },
        { west, 6, 6 },
        { level2, 6, 6 }
    };

    CEditor editor(this, EM_ROOMS, gis, 5);
    if (editor.DoModal() == IDOK)
    {
        int offset = g_verinfo->offsetMainRoom;    // start of main 8x8 room
        SetRoomArray(main, g_verinfo->offsetMainRoom, 8, 8);
        offset += 0x450 + 0x42;
        SetRoomArray(north, offset, 6, 6);
        offset += 0x450;
        SetRoomArray(east, offset, 6, 6);
        offset += 0x450;
        SetRoomArray(west, offset, 6, 6);
        offset += 0x450;
        SetRoomArray(level2, offset, 6, 6);
        g_romsave.SetModifiedFlag(TRUE); // just in case
    }

}

static void GetRoomArray2(uint16* array, uint16* array2, int offset)
{
    int y;
    for (y = 0; y < 16; y++)
    {
        int x;
        for (x = 0; x < 16; x++)
        {
            *array++ = g_romsave.GetBufferW(offset);
            offset += 2;
        }
    }
    // second half
    for (y = 0; y < 16; y++)
    {
        int x;
        for (x = 0; x < 16; x++)
        {
            *array2++ = g_romsave.GetBufferW(offset);
            offset += 2;
        }
    }
}
static void SetRoomArray2(uint16 const* array, uint16 const* array2, int offset)
{
    int y;
    for (y = 0; y < 16; y++)
    {
        int x;
        for (x = 0; x < 16; x++)
        {
            g_romsave.WriteW(offset, *array++);
            offset += 2;
        }
    }
    // second half
    for (y = 0; y < 16; y++)
    {
        int x;
        for (x = 0; x < 16; x++)
        {
            g_romsave.WriteW(offset, *array2++);
            offset += 2;
        }
    }
}


void CMainDlg::OnEditSuperroom() 
{
// add two cells on each side of the rooms
    int offset = g_verinfo->offsetMainRoom - 0xC8;

    uint16 main[16*16];
    uint16 main2[16*16];
    GetRoomArray2(main, main2, offset);
    offset += 0x450;
    uint16 north[16*16];    
    uint16 north2[16*16];    
    GetRoomArray2(north, north2, offset);
    offset += 0x450;
    uint16 east[16*16];    
    uint16 east2[16*16];    
    GetRoomArray2(east, east2, offset);
    offset += 0x450;
    uint16 west[16*16];    
    uint16 west2[16*16];    
    GetRoomArray2(west, west2, offset);
    offset += 0x450;
    uint16 level21[16*16];    
    uint16 level22[16*16];    
    GetRoomArray2(level21, level22, offset);

    GRID_INFO gis[10] =
    {
        { main, 16, 16, 8, 8, 4, 6 },
        { main2, 16, 16, 8, 8, 4, 6 },
        { north, 16, 16, 6, 6, 5, 8 },
        { north2, 16, 16, 6, 6, 5, 8 },
        { east, 16, 16, 6, 6, 5, 8 },
        { east2, 16, 16, 6, 6, 5, 8 },
        { west, 16, 16, 6, 6, 5, 8 },
        { west2, 16, 16, 6, 6, 5, 8 },
        { level21, 16, 16, 6, 6, 5, 8 },
        { level22, 16, 16, 6, 6, 5, 8 }
    };

    CEditor editor(this, EM_SUPERROOMS, gis, 10);
    if (editor.DoModal() == IDOK)
    {
        offset = g_verinfo->offsetMainRoom - 0xC8;

        SetRoomArray2(main, main2, offset);
        offset += 0x450;
        SetRoomArray2(north, north2, offset);
        offset += 0x450;
        SetRoomArray2(east, east2, offset);
        offset += 0x450;
        SetRoomArray2(west, west2, offset);
        offset += 0x450;
        SetRoomArray2(level21, level22, offset);
        g_romsave.SetModifiedFlag(TRUE); // just in case
    }
    
}

#include "reditor.h"

void CMainDlg::OnEditRiver() 
{
    // 4x4 core area
    uint8 array[16];
    int offset = g_verinfo->offsetTilemap + 6 + 1;
    int i;
    for (i = 0; i < 16; i++)
    {
        array[i] = g_romsave.GetBufferB(offset);
        offset++;
        if ((i & 3) == 3)
            offset += 2;
    }

    CRiverEditor editor(this, array, 4);
    if (editor.DoModal() == IDOK)
    {
        // VERIFY(CalcSumW(g_romsave.GetBufferPtr(0), GAMESIZE) == 0);

        offset = g_verinfo->offsetTilemap + 6 + 1;
        for (i = 0; i < 16; i++)
        {
            g_romsave.WriteB(offset, array[i]);
            offset++;
            if ((i & 3) == 3)
                offset += 2;
        }

        // VERIFY(CalcSumW(g_romsave.GetBufferPtr(0), GAMESIZE) == 0);
        g_romsave.SetModifiedFlag(TRUE); // just in case
    }
}

void CMainDlg::OnEditSuperRiverMode() 
{
    // 6x6 full area
    uint8 array[6*6];
    int offset = g_verinfo->offsetTilemap;
    int i;
    for (i = 0; i < 6*6; i++)
    {
        array[i] = g_romsave.GetBufferB(offset);
        offset++;
    }

    CRiverEditor editor(this, array, 6);
    if (editor.DoModal() == IDOK)
    {
        VERIFY(CalcSumW(g_romsave.GetBufferPtr(0), GAMESIZE) == 0);

        offset = g_verinfo->offsetTilemap;
        for (i = 0; i < 6*6; i++)
        {
            g_romsave.WriteB(offset, array[i]);
            offset++;
        }

        VERIFY(CalcSumW(g_romsave.GetBufferPtr(0), GAMESIZE) == 0);
        g_romsave.SetModifiedFlag(TRUE); // just in case
    }
}

////////////////////////////////////////////////////

void CMainDlg::OnEditNeighbor() 
{
    CNeighborDlg launcher2(this);        // sub-dialog
    launcher2.DoModal();
        // ignore return
}

void CMainDlg::OnAdvancedOrBasic() 
{
    if (m_bAdvanced)
    {
        // go back to basic
        m_bAdvanced = false;
        EnableButtons(false);
        FillOwnerInfo();
        return;
    }

#ifndef _DEBUG
    static bool s_bWarned = false;
    if (!s_bWarned)
    {
        if (AfxMessageBox(IDS_ASK_START_ADVANCED, MB_YESNO) != IDYES)
            return;
        s_bWarned = true;
    }
#endif

    m_bAdvanced = true;
    EnableButtons(true);
    FillOwnerInfo();
}

void CMainDlg::OnSpecialChangeformatcompressedsav() 
{
    if (g_saveInfo.m_type == SAVE_INFO::ST_ANIMALSAVE_ENG ||
        g_saveInfo.m_type == SAVE_INFO::ST_ANIMALSAVE_JPN)
    {
        AfxMessageBox("Switching to raw .SAV\n"
            "Save the file then open with the Pattern Viewer");
        g_saveInfo.m_type = SAVE_INFO::ST_RAW;
        g_romsave.SetModifiedFlag(true);
    }
    else if (g_saveInfo.m_type == SAVE_INFO::ST_RAW)
    {
        AfxMessageBox("Switching RAW to compressed .SAV\n"
            "Save the file then upload to your homebrew SRAM");
        if (IS_ENGLISH()) // ANMLSAV? key
            g_saveInfo.m_type = SAVE_INFO::ST_ANIMALSAVE_ENG;
        else
            g_saveInfo.m_type = SAVE_INFO::ST_ANIMALSAVE_JPN;
        g_romsave.SetModifiedFlag(true);
    }
    else if (AfxMessageBox(IDS_FORMAT_WARNING, MB_YESNO | MB_DEFBUTTON2) == IDYES)
    {
        if (IS_ENGLISH()) // ANMLSAV? key
            g_saveInfo.m_type = SAVE_INFO::ST_ANIMALSAVE_ENG;
        else
            g_saveInfo.m_type = SAVE_INFO::ST_ANIMALSAVE_JPN;
        g_saveInfo.m_path += ".SAV";
        g_romsave.SetModifiedFlag(true);
    }
}

static int GetCatBit(int delta, int index)
{
    uint8 b = g_romsave.GetBufferB(0x1B54 + delta + index/8);
    return (b & (1 << (index&7))) != 0 ? 1 : 0;
}

static void SetCatBit(int delta, int index)
{
    uint8 b = g_romsave.GetBufferB(0x1B54 + delta + index/8);
    b |= (1 << (index&7));
    g_romsave.WriteB(0x1B54 + delta + index/8, b);
}
#if 0
// not used here
static void ClearCatBit(int delta, int index)
{
    uint8 b = g_romsave.GetBufferB(0x1B54 + delta + index/8);
    b &= ~(1 << (index&7));
    g_romsave.WriteB(0x1B54 + delta + index/8, b);
}
#endif


struct CATALOG_DATA
{
    const char* name;
    int index; // bit index (LS-bit first) based from 0x1B54 in English ROMSAVE
    int count, countSmaller;
};

#define NUM_CATALOGS 11

static const CATALOG_DATA g_catalogs[NUM_CATALOGS] =
{
    { "Furniture", 0, 569, 562 },
            // 7 gaps
    { "Shirts", 609, 256 },
    { "Umbrellas", 905, 32 },
    { "Hats/Glasses", 1001, 134, 130 },
            // not including: white veil ?? x 4
    { "Insects", 1193, 56 },
    { "Fish", 1249, 56 }, // FIX THIS
    { "Fossils" , 1347, 52 },
    { "'Oids", 1399, 127 },
    { "Wallpaper", 2048, 63 },
    { "Flooring", 2120, 63 },
    { "Paper", 2264, 64, 63 },
            // not including: "bottle paper"
            // total items in catalog 1,472
};


void CMainDlg::OnSpecialFilloutcatalog() 
{
    ENGLISH_CHECK(); // fill out catalog - too obscure

    int delta = GetResidentDelta();

    CString strReport;
    strReport = "Current Catalog:\n";
    int nTotal = 0;
    int iCat;
    for (iCat = 0; iCat < NUM_CATALOGS; iCat++)
    {
        CATALOG_DATA const& cd = g_catalogs[iCat];
        int n = 0;
        for (int i = cd.index; i < cd.index+cd.count; i++)
            n += GetCatBit(delta, i);
        CString str;
        str.Format("%s: %d / %d", cd.name, n, cd.count);
        strReport += str;
        if (cd.countSmaller != 0)
        {
            str.Format(" only %d can be ordered", cd.countSmaller);
            strReport += str;
        }

        strReport += "\n";
        nTotal += n;
    }
    strReport += "\nFill in catalog?";
    if (AfxMessageBox(strReport, MB_YESNO) != IDYES)
        return;
    if (nTotal == 1472)
    {
        AfxMessageBox("Your catalog is already filled!");
        return;
    }

    // fill in all bits
    for (iCat = 0; iCat < NUM_CATALOGS; iCat++)
    {
        CATALOG_DATA const& cd = g_catalogs[iCat];
        CString str;
        for (int i = cd.index; i < cd.index+cd.count; i++)
            SetCatBit(delta, i);
    }
}


static int GetMusicBit(int index)
{
    uint8 b = g_romsave.GetBufferB(0xFAEC + index/8);
    return (b & (1 << (index&7))) != 0 ? 1 : 0;
}

static void SetMusicBit(int index)
{
    uint8 b = g_romsave.GetBufferB(0xFAEC + index/8);
    b |= (1 << (index&7));
    g_romsave.WriteB(0xFAEC + index/8, b);
}
#if 0
// not used here
static void ClearMusicBit(int index)
{
    uint8 b = g_romsave.GetBufferB(0xFAEC + index/8);
    b &= ~(1 << (index&7));
    g_romsave.WriteB(0xFAEC + index/8, b);
}
#endif

struct MUSICLOG_DATA
{
    const char* name;
    int index;
    int count, countSmaller;
};

#define NUM_MUSICLOGS 1

static const MUSICLOG_DATA g_musiclogs[NUM_MUSICLOGS] =
{
    { "", 0, 70,},
};

void CMainDlg::OnSpecialFilloutmusic() 
{
    ENGLISH_CHECK();

    CString strReport;
    strReport = "Current Music:\n";
    int nTotal = 0;
    int iCat;
    for (iCat = 0; iCat < NUM_MUSICLOGS; iCat++)
    {
        MUSICLOG_DATA const& cd = g_musiclogs[iCat];
        int n = 0;
        for (int i = cd.index; i < cd.index+cd.count; i++)
            n += GetMusicBit(i);
        CString str;
        str.Format("%s %d / %d", cd.name, n, cd.count);
        strReport += str;
        if (cd.countSmaller != 0)
        {
            str.Format("", cd.countSmaller);
            strReport += str;
        }

        strReport += "\n";
        nTotal += n;
    }
    strReport += "\nFill in music?";
    if (AfxMessageBox(strReport, MB_YESNO) != IDYES)
        return;
    if (nTotal == 70)
    {
        AfxMessageBox("You already have all of the music!");
        return;
    }

    // fill in all bits
    for (iCat = 0; iCat < NUM_MUSICLOGS; iCat++)
    {
        MUSICLOG_DATA const& cd = g_musiclogs[iCat];
        CString str;
        for (int i = cd.index; i < cd.index+cd.count; i++)
            SetMusicBit(i);
            if (nTotal == 70)
        (AfxMessageBox("Music already filled."));
    }
}

// Change TownName/Resident name - in 'ndlg.cpp'

void CMainDlg::OnSpecialUnburyallworldmapitems() 
{
    int nbits = 0;

    for (int ib = OFFSET_BURY_BITMAP; ib < OFFSET_BURY_BITMAP + 0x200; ib++) // 4K bits
    {
        uint8 bOld = g_romsave.GetBufferB(ib);
        for (int i = 0; i < 8; i++)
            if (bOld & (1<<i))
                nbits++;
    
        g_romsave.WriteB(ib, 0);    // nothing burried
    }

    CString str;
    str.Format("Dug up %d holes", nbits);
    AfxMessageBox(str);
}


static void DoExtraInventory(CWnd* parent, int offset, int cx, int cy, int dangerLevel)
{
    uint16* inventory = new uint16[cy*cx];
    int iInventory;
    for (iInventory = 0; iInventory < cy*cx; iInventory++)
        inventory[iInventory] = g_romsave.GetBufferW(offset + iInventory*2);
    GRID_INFO gi = { inventory, cx, cy };
    CEditor editor(parent, (EDIT_MODE)(EM_INVENTORY + dangerLevel), &gi ,1);
    if (editor.DoModal() == IDOK)
    {
        // save it
        for (iInventory = 0; iInventory < cy*cx; iInventory++)
            g_romsave.WriteW(offset + iInventory*2, inventory[iInventory]);
    }
    delete [] inventory;
}

static void DoExtraGifts(CWnd* parent, int offset, int cx, int cy, int dangerLevel)
{
    ENGLISH_CHECK();

    uint16* gifts = new uint16[cy*cx];
    for (int iPlayer = 0; iPlayer < 10; iPlayer++)
        gifts[iPlayer] = g_romsave.GetBufferW(0xF4 * iPlayer + offset);
    GRID_INFO gi = { gifts, cx, cy };
    CEditor editor(parent, (EDIT_MODE)(EM_INVENTORY + dangerLevel), &gi ,1);
    if (editor.DoModal() == IDOK)
    {
        // save it
        for (int iPlayer = 0; iPlayer < 10; iPlayer++)
            g_romsave.WriteW(0xF4 * iPlayer + offset, gifts[iPlayer]);
    }
    delete [] gifts;
}

void CMainDlg::OnEditGifts() 
{
    DoExtraGifts(this, OFFSET_GIFTS + GetResidentDelta(), 2, 5, m_dangerLevel);
}

void CMainDlg::OnEditEquip() 
{
    ENGLISH_CHECK();
    
    uint16 equip[4];
    for (int iPlayer = 0; iPlayer < 4; iPlayer++)
        equip[iPlayer] = g_romsave.GetBufferW(0x02 * iPlayer + 0x2216 + GetResidentDelta());
    GRID_INFO gi = { equip, 1, 4 };
    CEditor editor(this, EM_EQUIP, &gi ,1);
    if (editor.DoModal() == IDOK)
    {
        for (int iPlayer = 0; iPlayer < 4; iPlayer++)
            g_romsave.WriteW(0x02 * iPlayer + 0x2216 + GetResidentDelta(), equip[iPlayer]);
    }
}

void CMainDlg::OnEditInventory1() 
{
    // E or J
    DoExtraInventory(this, OFFSET_INVENTORY1 + GetResidentDelta(), 5, 3, m_dangerLevel);
}



void CMainDlg::OnEditEditresidentDrawers() 
{
    int offset = OFFSET_DRAWER_BASE;
    offset += m_iResident * 180;    // 90 slots per player
    DoExtraInventory(this, offset, 5, 3*6, m_dangerLevel);
}

void CMainDlg::OnEditEditnookstoreitems() 
{
    // total size  ~37 - edit the first 32 only
    DoExtraInventory(this, OFFSET_NOOK_ITEMS, 8, 4, 0);
        // terrain items can't be sold
}

void CMainDlg::OnEditEditlostfound() 
{
    DoExtraInventory(this, OFFSET_LOSTNFOUND, 5, 3, m_dangerLevel);
}

void CMainDlg::OnEditEditrecycler() 
{
    DoExtraInventory(this, OFFSET_RECYCLER, 5, 3, m_dangerLevel);
}

void CMainDlg::OnEditBedroom() 
{
    ENGLISH_CHECK();
    
    uint16 beds[4];
    for (int iPlayer = 0; iPlayer < 4; iPlayer++)
        beds[iPlayer] = g_romsave.GetBufferW(0xC + 0x228C * iPlayer + 0x221E-0xC);
    GRID_INFO gi = { beds, 2, 2 };
    CEditor editor(this, EM_BEDROOM, &gi ,1);
    if (editor.DoModal() == IDOK)
    {
        for (int iPlayer = 0; iPlayer < 4; iPlayer++)
            g_romsave.WriteW(0xC + 0x228C * iPlayer + 0x221E-0xC, beds[iPlayer]);
    }
}

////////////////////////////////////////////////////////////////////////

void CMainDlg::OnSpecialNextResident() 
{
    int iStart = m_iResident;
    
    while (1)
    {
        m_iResident = (m_iResident+1) & 3;

        int ibTaggedName = GetResidentDelta() + OFFSET_PLAYER_NAME;
        if (g_romsave.GetBufferW(ibTaggedName) != 0)
            break;
    }
    if (m_iResident == iStart)
        AfxMessageBox(IDS_NO_NEXT_PLAYER);
    FillOwnerInfo();
}


#include "facedlg.h"

void CMainDlg::OnPlayerChangeFaceEtc() 
{
    ENGLISH_CHECK();

    int ibInfo = GetResidentDelta() + 0x02248;
    uint8 b0 = g_romsave.GetBufferB(ibInfo);
    uint8 b1 = g_romsave.GetBufferB(ibInfo+1);
    uint8 b2 = g_romsave.GetBufferB(ibInfo+78);

    CFaceDlg dlg;
    dlg.m_faceType = b0 & 15;
    dlg.m_hairStyle = (b0 >> 4) & 15;
    dlg.m_hairColor = b1 & 7; // 3 bits
    dlg.m_tanLevel = (b1 >> 4) & 3; // 2 bits
    dlg.m_gender = b2 & 15;
    b1 &= 0xC8;    // keep the other bits just to be safe
    b2 &= 0xC8;

    if (dlg.DoModal() == IDOK)
    {
        b0 = (dlg.m_hairStyle << 4) | dlg.m_faceType;
        g_romsave.WriteB(ibInfo, b0);
        b1 |= (dlg.m_tanLevel << 4) | dlg.m_hairColor;
        g_romsave.WriteB(ibInfo+1, b1);
        b2 |= dlg.m_gender;
        g_romsave.WriteB(ibInfo+78, b2);
    }
}


#include "housedlg.h"

void CMainDlg::OnHouseInfo() 
{
    ENGLISH_CHECK();

    int ibInfo = GetResidentDelta() + 0x00FAF8;
    uint8 b0 = g_romsave.GetBufferB(ibInfo);

    CHouseDlg dlg;
    dlg.m_housesize = b0 & 7;
    dlg.m_housecolor = (b0 >> 4) & 15;

    b0 &= 0x0;

    if (dlg.DoModal() == IDOK)
    {
        b0 = (dlg.m_housecolor << 4) | dlg.m_housesize;
        g_romsave.WriteB(ibInfo, b0);
    }
}


void CMainDlg::OnDangerLevel0() 
{
    m_dangerLevel = 0;    
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL0, MF_CHECKED);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL1, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL2, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL3, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL4, 0);
}

void CMainDlg::OnDangerLevel1() 
{
    if (m_dangerLevel < 1 && !g_bAdvancedUser)
        AfxMessageBox("Switching to danger mode 1\n\n"
        "You can now carry 'Glitched' flowers and full-grown trees\n"
        "You can drop them in a town, even on concrete. Do not drop them in your house!!\n"
        "Glitched patterns can be dropped when visiting a town, but they use the local town patterns\n"
        "Mild vandelism possible, but town owner can easily clean up their town with a shovel and axe\n"
        "\nPlay Nice!");

    m_dangerLevel = 1;
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL0, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL1, MF_CHECKED);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL2, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL3, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL4, 0);
}


void CMainDlg::OnDangerLevel2() 
{
    if (m_dangerLevel < 2 && !g_bAdvancedUser)
        AfxMessageBox("Switching to danger mode 2\n\n"
        "You can now carry 'Glitched' special trees\n"
        "You can drop full grown money/bell/furniture trees in a town, even on concrete. Do not drop them in your house!!\n"
        "Adding too many to a town may cause problems\n"
        "Some 'mischief' items can be hard to get rid of\n"
        "\nPlay Nice!");

    m_dangerLevel = 2;
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL0, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL1, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL2, MF_CHECKED);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL3, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL4, 0);
}

void CMainDlg::OnDangerLevel3() 
{
    if (m_dangerLevel < 3 && !g_bAdvancedUser)
    {
        AfxMessageBox("Switching to danger mode 3\n\n"
        "All warnings of danger mode 2, plus:\n"
        "You can drop rocks in a town, even on concrete. Do not drop them in your house!!\n"
        "Rocks can block off important buildings and can break towns\n"
        "Repair may require Action Replay\n"
        "\nPlay Nice!");

        if (AfxMessageBox("Do you promise not to harm others ?",
                MB_YESNOCANCEL) != IDYES)
            return;
    }

    m_dangerLevel = 3;
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL0, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL1, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL2, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL3, MF_CHECKED);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL4, 0);
}

void CMainDlg::OnDangerLevel4() 
{
    if (m_dangerLevel < 4 && !g_bAdvancedUser)
    {
        AfxMessageBox("Switching to danger mode 4!\n\n"
        "All warnings of danger mode 3, plus:\n"
        "You can drop 'building seeds' in a town\n"
        "Dropping in wrong place can easily break towns\n"
        "Repair may require Action Replay\n"
        "\nPlay Nice!");

        if (AfxMessageBox("Do you promise not to harm others ?",
                MB_YESNOCANCEL | MB_DEFBUTTON2) != IDYES)
            return;
    }
    m_dangerLevel = 4;
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL0, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL1, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL2, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL3, 0);
    m_menuAdvanced.CheckMenuItem(IDC_DANGER_LEVEL4, MF_CHECKED);
    
}

/////////////////////////////////////////////////////////////////////////////
