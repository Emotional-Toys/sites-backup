// facedlg.cpp : implementation file
//

#include "stdafx.h"
#include "animalmap.h"
#include "facedlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFaceDlg dialog


CFaceDlg::CFaceDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CFaceDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CFaceDlg)
    m_faceType = -1;
    m_hairColor = -1;
    m_hairStyle = -1;
    m_tanLevel = -1;
    m_gender = -1;
    //}}AFX_DATA_INIT
}


void CFaceDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CFaceDlg)
    DDX_CBIndex(pDX, IDC_FACETYPE, m_faceType);
    DDX_CBIndex(pDX, IDC_HAIRCOLOR, m_hairColor);
    DDX_CBIndex(pDX, IDC_HAIRSTYLE, m_hairStyle);
    DDX_CBIndex(pDX, IDC_TAN, m_tanLevel);
    DDX_CBIndex(pDX, IDC_GENDER, m_gender);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFaceDlg, CDialog)
    //{{AFX_MSG_MAP(CFaceDlg)
        // NOTE: the ClassWizard will add message map macros here
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
