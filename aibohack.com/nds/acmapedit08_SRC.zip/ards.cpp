// ards.cpp - code generation for ARDS
// Provides glue between the "AR MAX/DUO" gamesave editing world (static)
// and the "AR DS" RAM editing world (dynamic)

#include "stdafx.h"
#include "AnimalMap.h"
#include "maindlg.h"

#include "romsave.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

///////////////////////////////////////////////////////////////////////
// 3 versions supported, (#0) US original, (#1) EU, (#2) version 1.1
//  all "ENGLISH" gamesave compatible (not Japanese)
// Japanese version is not supported.
// Japanese versions are possible if someone wants to do the work.

#define ARDS_RAMBASE_US  0x021D6DD0
#define ARDS_RAMBASE_EU  0x021DA9F8
#define ARDS_RAMBASE_V11 0x021D7350

// some redundant info from gamesave

static bool IsBridgeTile(uint8 tile)
{
    // redundant with 'river.c_'
    // non-bridge version is one number before
    switch (tile)
    {
    case 0x2E: case 0x30: case 0x32: case 0x34: case 0x36: case 0x38:
    case 0x3A: case 0x3C: case 0x3E: case 0x40: case 0x42: case 0x44:
    case 0x4B: case 0x4D: case 0x4F: case 0x53: case 0x55: case 0x57:
    case 0x5B: case 0x5D: case 0x5F: case 0x63: case 0x65: case 0x67:
    case 0x6B: case 0x6D: case 0x6F: case 0x73: case 0x75: case 0x77:
    case 0x7B: case 0x7D: case 0x7F:
        return true;
    default:
        return false;
    }
}

/////////////////////////////////////////////////////////////////
// CLIPBOARD helpers (quick and dirty)

static bool CopyToClipboard(uint8* buffer, int cb)
{
    // copy data to clipboard
    HANDLE hmem = GlobalAlloc(GMEM_SHARE, cb+1);
    if (hmem == NULL)
        return false;
    BYTE* pbDst = (BYTE*)GlobalLock(hmem);
    memcpy(pbDst, buffer, cb);
    pbDst[cb] = 0x00;
    GlobalUnlock(hmem);

    HWND hwnd = CreateWindow("STATIC", "", WS_POPUP, 0, 0, 0, 0,
        NULL, NULL, AfxGetInstanceHandle(), NULL);
    if (hwnd == NULL)
        return false;
    if (!OpenClipboard(hwnd))
        return false;
    if (!EmptyClipboard())
        return false;
    if (!SetClipboardData(CF_TEXT, hmem))
        return false;
    if (!CloseClipboard())
        return false;
    DestroyWindow(hwnd);

    return true;
}

#define MAX_CLIPFILE 16000

static bool CopyFromListBoxToClipboard(CListBox& lb)
{
    uint8 buffer[MAX_CLIPFILE];
    int cb = 0;
    int nItem = lb.GetCount();
    for (int iItem = 0; iItem < nItem; iItem++)
    {
        if (cb+256 > MAX_CLIPFILE)
        {
            AfxMessageBox("ERROR: too much data for the clipboard\n"
                "Simplify and try again");
            return false;
        }
        int cb1 = lb.GetText(iItem, (char*)&buffer[cb]);
        cb += cb1;
        memcpy(&buffer[cb], "\r\n", 3);    // CR+LF + terminator just in case
        cb += 2;
    }
    return CopyToClipboard(buffer, cb);
}

#include <stdarg.h>

static void clip_printf(uint8* buffer, int& cbOut, const char* szFmt, ...)
{
    char szT[1024]; // max per line
    va_list va;
    va_start(va, szFmt);
    vsprintf(szT, szFmt, va);
    va_end(va);

    char* pch = szT;
    char ch;
    while ((ch = *pch++) != '\0')
    {
        ASSERT(cbOut < MAX_CLIPFILE - 2);
        if (ch == '\n')
            buffer[cbOut++] = '\r';
        buffer[cbOut++] = ch;
    }
    buffer[cbOut] = '\0'; // just in case
}


/////////////////////////////////////////////////////////////////

// static for convenience -- really member variables of CMainDlg
static uint8 g_snapshot[GAMESIZE_ENG];
static bool g_bHaveSnapshot;
static int s_last_version = -1;    // REVIEW: should be stored in the registry or an INI file

/////////////////////////////////////////////////////////////////////////////
// CArdsDlg dialog

class CArdsDlg : public CDialog
{
// Construction
public:
    CArdsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(CArdsDlg)
    enum { IDD = IDD_ARDSDLG_DIALOG };
    CListBox    m_previewList;
    CComboBox    m_dropListButtons;
    CString    m_summary;
    BOOL    m_bReverseDiff;
    int        m_mode;
    int        m_version;
    int        m_gensize;
    CString    m_codeName;
    //}}AFX_DATA

    bool m_bClipboardCopy;    // true after something useful done

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CArdsDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:

    CString m_xmlCode;
    void UpdatePreview();

    // Generated message map functions
    //{{AFX_MSG(CArdsDlg)
    virtual void OnOK();
    virtual void OnCancel();
    virtual BOOL OnInitDialog();
    afx_msg void OnChange1();
    afx_msg void OnPathBrowse();
    afx_msg void OnCopyToClipboard();
    afx_msg void OnDoneResnapshot();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

CArdsDlg::CArdsDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CArdsDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CArdsDlg)
    m_summary = _T("");
    m_bReverseDiff = FALSE;
    m_mode = -1;
    m_version = -1;
    m_gensize = -1;
    m_codeName = _T("");
    //}}AFX_DATA_INIT
    m_bClipboardCopy = false;
}


void CArdsDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CArdsDlg)
    DDX_Control(pDX, IDC_ARDS_CODE_PREVIEW, m_previewList);
    DDX_Control(pDX, IDC_ARDS_CONDITION, m_dropListButtons);
    DDX_Text(pDX, IDC_CHANGE_SUMMARY, m_summary);
    DDX_Check(pDX, IDC_DIFF_REVERSE, m_bReverseDiff);
    DDX_Radio(pDX, IDC_RADIO1, m_mode);
    DDX_Radio(pDX, IDC_RADIO4, m_version);
    DDX_Radio(pDX, IDC_RADIO7, m_gensize);
    DDX_Text(pDX, IDC_CODE_NAME, m_codeName);
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CArdsDlg, CDialog)
    //{{AFX_MSG_MAP(CArdsDlg)
    ON_BN_CLICKED(IDC_RADIO1, OnChange1)
    ON_BN_CLICKED(ID_COPY_TO_CLIPBOARD, OnCopyToClipboard)
    ON_BN_CLICKED(IDC_RADIO2, OnChange1)
    ON_BN_CLICKED(IDC_RADIO4, OnChange1)
    ON_BN_CLICKED(IDC_RADIO5, OnChange1)
    ON_BN_CLICKED(IDC_RADIO6, OnChange1)
    ON_BN_CLICKED(IDC_RADIO7, OnChange1)
    ON_BN_CLICKED(IDC_RADIO8, OnChange1)
    ON_BN_CLICKED(IDC_RADIO9, OnChange1)
    ON_BN_CLICKED(IDC_DIFF_REVERSE, OnChange1)
    ON_CBN_SELCHANGE(IDC_ARDS_CONDITION, OnChange1)
    ON_EN_CHANGE(IDC_CODE_NAME, OnChange1)
    ON_BN_CLICKED(IDC_DONE_RESNAPSHOT, OnDoneResnapshot)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()


struct BUTTON_INFO
{
    const char* name;
    int code;
};

static BUTTON_INFO g_buttonInfo[] =
{
    // use non-overlapping triggered by R or L shoulder
    { "None",        0 },
    { "Up+L",        0x01BF },
    { "Dwn+L",        0x017F },
    { "Lft+L",        0x01DF },
    { "Rgt+L",        0x01EF },
    { "Up+R",        0x02BF },
    { "Dwn+R",        0x027F },
    { "Lft+R",        0x02DF },
    { "Rgt+R",        0x02EF },
    { "Up+A+L",        0x01BE },
    { "Dwn+A+L",    0x017E },
    { "Lft+A+L",    0x01DE },
    { "Rgt+A+L",    0x01EE },
    { "Up+A+R",        0x02BE },
    { "Dwn+A+R",    0x027E },
    { "Lft+A+R",    0x02DE },
    { "Rgt+A+R",    0x02EE },
    { "Up+B+L",        0x01BD },
    { "Dwn+B+L",    0x017D },
    { "Lft+B+L",    0x01DD },
    { "Rgt+B+L",    0x01ED },
    { "Up+B+R",        0x02BD },
    { "Dwn+B+R",    0x027D },
    { "Lft+B+R",    0x02DD },
    { "Rgt+B+R",    0x02ED },
    // there are other combinations, but they may overlap
    //  eg: Shoulder "L+R" combos overlap separate "L" and "R" combos
};
#define NUM_BUTTONS (sizeof(g_buttonInfo)/sizeof(BUTTON_INFO))


BOOL CArdsDlg::OnInitDialog() 
{
    CDialog::OnInitDialog();

    for (int i = 0; i < NUM_BUTTONS; i++)
        m_dropListButtons.AddString(g_buttonInfo[i].name);
    m_dropListButtons.SetCurSel(0);    // none
    
    UpdatePreview();    
    return TRUE;
}


void CArdsDlg::UpdatePreview()
{
    // format the XML snip, store in listbox
    //  when the user is happy and copies to clipboard, this is the text we use
    UpdateData();   // get latest selections
    m_previewList.ResetContent();
    if (m_version == -1)
    {
        m_previewList.AddString("ERROR: Game version not set");
        return;
    }

    const char* vername = "US";
    int rambase = ARDS_RAMBASE_US;
    const char* gameid = "ADME 8f7851cb";
    if (m_version == 1)
    {
        vername = "EU";
        rambase = ARDS_RAMBASE_EU;
        gameid = "ADMP 53dbb069";
    }
    else if (m_version == 2)
    {
        vername = "V1.1";
        rambase = ARDS_RAMBASE_V11;
        gameid = "ADME 6c56b746";
    }

    CString str;

    if (m_mode == 1)
    {
        // for full version, emit header
        // this is not practical, but provides a cross check if they
        // don't know the version
        m_previewList.AddString("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        m_previewList.AddString("<codelist>");
        str.Format("<game><name>AC:WW tricks (%s)</name><gameid>%s</gameid>", vername, gameid);
        m_previewList.AddString(str);
    }

    int iButton = m_dropListButtons.GetCurSel();
        // 0 if none, otherwise a button combination

    CString str2;
    if (iButton > 0)
        str2.Format(" (%s)", g_buttonInfo[iButton].name);

    str.Format(" <cheat><name>%s%s</name>", (const char*)m_codeName, (const char*)str2);
    m_previewList.AddString(str);

    m_previewList.AddString("  <codes>");
    if (iButton > 0)
    {
        str.Format("   94000130 0000%04X", g_buttonInfo[iButton].code);
        m_previewList.AddString(str);
    }

    if (m_gensize == 0)
    {
        // bytes
        for (int ib = 0; ib < (GAMESIZE_ENG-4); ib++)
        {
            uint8 bNew = g_romsave.GetBufferB(ib);
            uint8 bOld = g_snapshot[ib];
            if (bNew != bOld)
            {
                str.Format("   2%07x 000000%02x\n\r", rambase+ib, m_bReverseDiff ? bOld : bNew);
                m_previewList.AddString(str);
            }
        }
    }
    else if (m_gensize == 1)
    {
        // uint16
        // REVIEW: add 32bit optimization ??
        uint16* pwSnap = (uint16*)g_snapshot;
        for (int iw = 0; iw < (GAMESIZE_ENG-4)/2; iw++)
        {
            int ib = iw*2;
            uint16 wNew = g_romsave.GetBufferW(ib);
            uint16 wOld = pwSnap[iw];
            if (wNew != wOld)
            {
                str.Format("   1%07x 0000%04x\n\r", rambase+ib, m_bReverseDiff ? wOld : wNew);
                m_previewList.AddString(str);
            }
        }
    }
    else
    {
        // uint32
        ASSERT(m_gensize == 2);

        uint32* plSnap = (uint32*)g_snapshot;
        for (int il = 0; il < (GAMESIZE_ENG-4)/4; il++)
        {
            int ib = il*4;
            uint32 lNew = g_romsave.GetBufferL(ib);
            uint32 lOld = plSnap[il];
            if (lNew != lOld)
            {
                str.Format("   0%07x %08x\n\r", rambase+ib, m_bReverseDiff ? lOld : lNew);
                m_previewList.AddString(str);
            }
        }
    }
    if (iButton > 0)
        m_previewList.AddString("   D2000000 00000000");
    m_previewList.AddString("  </codes>");
    m_previewList.AddString(" </cheat>");

    if (m_mode == 1)
    {
        m_previewList.AddString("</game></codelist>");
    }
}


void CArdsDlg::OnChange1() 
{
    // something interesting changed
    UpdateData();
    UpdatePreview();    
    
}

void CArdsDlg::OnCopyToClipboard() 
{
    UpdatePreview(); // just in case
    if (m_version == -1)
    {
        AfxMessageBox("Please pick a game version");
        return;
    }

    if (!CopyFromListBoxToClipboard(m_previewList))
    {
        AfxMessageBox("Error: not copied to clipboard");
        return;
    }
    // copied to the clipboard
    m_bClipboardCopy = true;
    
}

void CArdsDlg::OnDoneResnapshot() 
{
    if (!m_bClipboardCopy)
    {
        if (AfxMessageBox("Warning: nothing was copied to the clipboard\n"
            "Do you want to lose changes and rerun 'Snapshot'?", MB_YESNO) != IDYES)
        {
            return;
        }
    }

    static bool s_bWarn = false;    // warn once
    if (!s_bWarn)
    {
        AfxMessageBox("One time info: pressing this button will close this dialog and re-run 'Snapshot'\n"
            "you are ready to make the next change");
        s_bWarn = true; // just once
    }
                        
    // resnapshot
    EndDialog(IDC_DONE_RESNAPSHOT);
}

void CArdsDlg::OnOK() 
{
    // CDialog::OnOK(); -- no regular ok
}

void CArdsDlg::OnCancel()
{
    // Escape or close dialog
    if (m_bClipboardCopy)
    {
        AfxMessageBox("Your new code is copied to the clipboard\n"
            "Be sure to manually pick 'Snapshot' from the menu before starting the next code");
    }
    else
    {
        AfxMessageBox("Nothing copied to the clipboard, nothing changed");
    }

    CDialog::OnCancel();
}


//////////////////////////////////////////////////////////////////////////////////


void CMainDlg::OnArdsSnapshot() 
{
    ENGLISH_CHECK();

    // snapshot the entire ROMSAVE
    memcpy(g_snapshot, g_romsave.GetBufferPtr(0), GAMESIZE_ENG);
    g_bHaveSnapshot = true;
}


void CMainDlg::OnArdsDiff() 
{
    ENGLISH_CHECK();
    if (!g_bHaveSnapshot)
    {
        AfxMessageBox("Please 'Snapshot' first");
        return;
    }

    // count up number of diffs (as uint8/uint16/uint32)
    int cbDiff = 0;
    int cwDiff = 0;
    int clDiff = 0;
    for (int ib = 0; ib < (GAMESIZE_ENG-4); ib++)
    {
        if (g_romsave.GetBufferB(ib) != g_snapshot[ib])
            cbDiff++;
        if (ib & 1)
            continue;
        if (g_romsave.GetBufferW(ib) != *(uint16*)&g_snapshot[ib])
            cwDiff++;
        if (ib & 3)
            continue;
        if (g_romsave.GetBufferL(ib) != *(uint32*)&g_snapshot[ib])
            clDiff++;
    }

    if (cbDiff == 0)
    {
        AfxMessageBox("Nothing changed since last 'Snapshot'");
        return;
    }

    CArdsDlg dlg;
    dlg.m_summary.Format("%d bytes, %d uint16, %d uint32", cbDiff, cwDiff, clDiff);
    dlg.m_mode = 0;    // simple clipboard
    dlg.m_version = s_last_version;
    dlg.m_gensize = 1;    // uint16
    dlg.m_bReverseDiff = FALSE;
    dlg.m_codeName = "New Code";
    if (dlg.DoModal() == IDC_DONE_RESNAPSHOT)
        OnArdsSnapshot();
    s_last_version = dlg.m_version;    // save for next time

}


void CMainDlg::OnArdsGenBridges() 
{
    // older feature from the original preview version
    // generate common scripts for bridges

    ENGLISH_CHECK();

    int nBridge = 0;
    int bridges[3]; // save first 3 offsets
    int offset = g_verinfo->offsetTilemap;
    for (int itile = 0; itile < 6*6; itile++)
    {
        uint8 tile = g_romsave.GetBufferB(offset + itile);
        if (IsBridgeTile(tile))
        {
            if (nBridge < 3)
                bridges[nBridge] = itile;
            nBridge++;
        }
    }
    if (nBridge == 0)
    {
        AfxMessageBox("No bridges - no tricks available");
        return;
    }

    int version = s_last_version;
    if (version == -1)
    {
        AfxMessageBox("No version set, assuming US 1.0 game");
        version = 0;
    }

    if (nBridge > 3)
    {
        AfxMessageBox("More than 3 bridges\n"
            "Will generate codes for first 3\n"
            "BTW: mini-map will be weird");
        nBridge = 3;
    }

    int rambase = ARDS_RAMBASE_US;
    if (version == 1)
        rambase = ARDS_RAMBASE_EU;
    else if (version == 2)
        rambase = ARDS_RAMBASE_V11;
    int tilebase = rambase + 0xC330; // English gamesave


    uint8 buffer[MAX_CLIPFILE];
    int cbOut = 0;

    for (int iBridge = 1; iBridge <= nBridge; iBridge++)
    {
        // iBridge also 1 based
        const char* key_name = NULL;
        uint8 key = 0;
        if (iBridge == 1)
        {
            key_name = "Right";
            key = 0x10;
        }
        else if (iBridge == 2)
        {
            key_name = "Left";
            key = 0x20;
        }
        else if (iBridge == 3)
        {
            key_name = "Up";
            key = 0x40;
        }
        int ibTile = bridges[iBridge-1];
        uint8 tile = g_romsave.GetBufferB(g_verinfo->offsetTilemap + ibTile);
        if (!IsBridgeTile(tile))
        {
            AfxMessageBox("Internal Error: bridge tile\n"
                "please email DsPet");
        }
        uint8 tileWithBridge = tile;
        uint8 tileNoBridge = tile-1; // close enough
        uint32 addr = tilebase + ibTile;

        // 2 different tricks each
        for (int iTrick = 0; iTrick < 2; iTrick++)
        {
            const char* verb = NULL;
            const char* key_name2 = NULL;
            uint8 key2 = 0;
            if (iTrick == 0)
            {
                verb = "remove";
                key_name2 = "";
                key2 = 0;
            }
            else if (iTrick == 1)
            {
                verb = "add";
                key_name2 = "+A";
                key2 = 0x01;
            }

            clip_printf(buffer, cbOut, " <cheat>\n"
                "  <name>%s bridge %d (%s%s+R)</name>\n",
                verb, iBridge, key_name, key_name2);
            clip_printf(buffer, cbOut, "  <codes>94000130 000002%02x ",
                0xFF ^ (key | key2)); // R button down

            clip_printf(buffer, cbOut, "2%07x 000000%02x ", addr,
                (iTrick == 0) ? tileNoBridge : tileWithBridge);

            clip_printf(buffer, cbOut, "D2000000 00000000");
            clip_printf(buffer, cbOut, "</codes>\n"
                " </cheat>\n");
        }
    }
    if (CopyToClipboard(buffer, cbOut))
    {
        AfxMessageBox("Bridge tricks copied to clipboard\n"
            "Key combinations may overlap your own code");
    }
    else
    {
        AfxMessageBox("ERROR trying to copy to clipboard");
    }

}


///////////////////////////////////////////////////////////////////////
