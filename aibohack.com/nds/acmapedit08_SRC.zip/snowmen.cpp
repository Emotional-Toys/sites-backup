// snowmen head tweeking

#include "stdafx.h"
#include "AnimalMap.h"
#include "maindlg.h"

#include "romsave.h"
#include "editor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

#define NUM_SNOWMEN 3

#define CALC_SNOWMAN_OFFSET(index) (0x15F96 + (index) * 6)
    // English gamesaves only

// exact format and details of snowmen not known, but guess is:
    // 2 bytes date when snowman created, so game knows when it melts
    // 1 byte head/body size -- two nibbles
    // 1 byte head height and other stufff, including head tilt
    // 1 other byte
    // 1 byte always 1
    // all 6 bytes are 00 if no snowman
    // correlates to the Snowman code on the world map $B001, B002, B003
    //  can only be one of each, and will be invisible (all melted)
    //  if the extra data is zero.
    // That's why snowman 'seeds' rarely work as expected

/////////////////////////////////////////////////////////////////////////////
// CSnowmenDlg dialog


class CSnowmenDlg : public CDialog
{
// Construction
public:
    CSnowmenDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
    //{{AFX_DATA(CSnowmenDlg)
    enum { IDD = IDD_SNOWMEN_DLG };
    //}}AFX_DATA
    int        m_head1[NUM_SNOWMEN];
    int        m_head2[NUM_SNOWMEN];
    int        m_gap1[NUM_SNOWMEN];
    int        m_gap2[NUM_SNOWMEN];
    int        m_other[NUM_SNOWMEN];

        WORD m_times[NUM_SNOWMEN];
        int m_bValid[NUM_SNOWMEN];
        int m_ageGuess[NUM_SNOWMEN];
            // age in hours (2048 ticks per day)
    WORD m_timeBase;    // from resident

// Overrides
    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CSnowmenDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

// Implementation
protected:

    // Generated message map functions
    //{{AFX_MSG(CSnowmenDlg)
    afx_msg void OnRenew(UINT idc);
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
// CSnowmenDlg dialog


CSnowmenDlg::CSnowmenDlg(CWnd* pParent /*=NULL*/)
    : CDialog(CSnowmenDlg::IDD, pParent)
{
    //{{AFX_DATA_INIT(CSnowmenDlg)
    //}}AFX_DATA_INIT
    // using arrays for 3 version, assuming IDs contiguous
    memset(m_bValid, 0, sizeof(m_bValid));

    memset(m_head1, 0, sizeof(m_head1));
    memset(m_head2, 0, sizeof(m_head2));
    memset(m_gap1, 0, sizeof(m_gap1));
    memset(m_gap2, 0, sizeof(m_gap2));
    memset(m_other, 0, sizeof(m_other));
    memset(m_ageGuess, 0, sizeof(m_ageGuess));
}


void CSnowmenDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    for (int i = 0; i < NUM_SNOWMEN; i++)
    {
        // assumes edit controls are in linear order
        int idcBase = IDC_EDIT1 + i*5;
        //regardless of direction
        for (int idc = idcBase; idc < idcBase+5; idc++)
            GetDlgItem(idc)->EnableWindow(m_bValid[i]);
        if (m_bValid[i])
        {
            DDX_Text(pDX, idcBase + 0, m_head1[i]);
            DDV_MinMaxInt(pDX, m_head1[i], 0, 255);
            DDX_Text(pDX, idcBase + 1, m_head2[i]);
            DDV_MinMaxInt(pDX, m_head2[i], 0, 255);
            DDX_Text(pDX, idcBase + 2, m_gap1[i]);
            DDV_MinMaxInt(pDX, m_gap1[i], 0, 15);
            DDX_Text(pDX, idcBase + 3, m_gap2[i]);
            DDV_MinMaxInt(pDX, m_gap2[i], 0, 15);
            DDX_Text(pDX, idcBase + 4, m_other[i]);
            DDV_MinMaxInt(pDX, m_other[i], 0, 255);    // exact range unknown

            if (!pDX->m_bSaveAndValidate)
            {
                int idc = IDC_REPORT_TEXT1 + i;
                DDX_Text(pDX, idc, m_ageGuess[i]);
                GetDlgItem(idc)->EnableWindow(FALSE);
            }
        }
    }
    //{{AFX_DATA_MAP(CSnowmenDlg)
    //}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSnowmenDlg, CDialog)
    //{{AFX_MSG_MAP(CSnowmenDlg)
    ON_COMMAND_RANGE(IDC_BUTTON1, IDC_BUTTON3, OnRenew)
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////

void CMainDlg::OnSnowmenTweek() 
{
    ENGLISH_CHECK();
    int i;

    CSnowmenDlg dlg;
    dlg.m_timeBase = g_romsave.GetBufferW(0x2222+GetResidentDelta());
            // time last played
            // assuming the correct resident is selected
            // save for later calculations ('renew')
    int nValid = 0;
    for (i = 0; i < NUM_SNOWMEN; i++)
    {
        int ibBase = CALC_SNOWMAN_OFFSET(i);

        if (g_romsave.GetBufferW(ibBase+0) == 0 ||
            g_romsave.GetBufferB(ibBase+5) != 1)
        {
            // assume all the rest are zero
            dlg.m_bValid[i] = false;
        }
        else
        {
            BYTE head = g_romsave.GetBufferB(ibBase+2);
            dlg.m_head1[i] = (head >> 4) & 15;
            dlg.m_head2[i] = head & 15;
            BYTE gap = g_romsave.GetBufferB(ibBase+3);
            dlg.m_gap1[i] = (gap >> 4) & 15;
            dlg.m_gap2[i] = gap & 15;
            BYTE other = g_romsave.GetBufferB(ibBase+4);
            dlg.m_other[i] = other;

            WORD snowtime = g_romsave.GetBufferW(ibBase+0);
            dlg.m_times[i] = snowtime; // save in case reset/renew
            dlg.m_ageGuess[i] = -1;
            int delta = (int)dlg.m_timeBase - (int)snowtime;
            if (delta >= 0)
                dlg.m_ageGuess[i] = (delta * 24 + 85/2) / 2048;

            dlg.m_bValid[i] = true;
            nValid++;
        }
    }
    if (nValid == 0)
    {
        AfxMessageBox("ERROR: no unmelted snowmen\n"
            "Go play the game, and roll some balls in the snow\n"
            "Then come back here to change their attributes");
        return; // then don't tempt them
    }
    if (dlg.DoModal() == IDOK)
    {
        for (int i = 0; i < NUM_SNOWMEN; i++)
        {
            int ibBase = CALC_SNOWMAN_OFFSET(i);

            if (dlg.m_bValid[i] == -1)
                continue;    // skip

            // write new/changed attributes
            g_romsave.WriteW(ibBase+0, (WORD)dlg.m_times[i]);
            BYTE head = (dlg.m_head1[i] << 4) | dlg.m_head2[i];
            g_romsave.WriteB(ibBase+2, head);
            BYTE gap = (dlg.m_gap1[i] << 4) | dlg.m_gap2[i];
            g_romsave.WriteB(ibBase+3, gap);
            g_romsave.WriteB(ibBase+4, (BYTE)dlg.m_other[i]);
            g_romsave.WriteB(ibBase+5, (BYTE)1);
        }
    }
}


void CSnowmenDlg::OnRenew(UINT idc) 
{
    ASSERT(idc >= IDC_BUTTON1 && idc <= IDC_BUTTON3);
    int i = idc - IDC_BUTTON1;

    if (!m_bValid[i])
    {
        AfxMessageBox("OOPS: that was unexpected (snowmen)");
        return;
    }
    UpdateData(TRUE);    // move changed data into structure

    m_times[i] = m_timeBase;
    m_ageGuess[i] = 0;
    UpdateData(FALSE);    // and back again
}

/////////////////////////////////////////////////////////////////////////////
