// maindlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMainDlg dialog - the main app user interface

class CMainDlg : public CDialog
{
// Construction
public:
    CMainDlg(CWnd* pParent = NULL);

// Dialog Data
    //{{AFX_DATA(CMainDlg)
    enum { IDD = IDD_DOGTRAINW_DIALOG };
    CStatic    m_ownerBank;
    CButton    m_btnAdvancedOrBasic;
    CStatic    m_ownerPts;
    CStatic    m_ownerCash;
    //}}AFX_DATA

    // ClassWizard generated virtual function overrides
    //{{AFX_VIRTUAL(CMainDlg)
    protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
    //}}AFX_VIRTUAL

    void OnCancel();    // special exit trap

// Implementation
protected:
    HICON m_hIcon;
    bool m_bAdvanced;
    CMenu m_menuAdvanced;

    int m_iResident;    // 0 based, usually 0, 0->3 possible
    int m_dangerLevel; // 0 -> 4
    int GetResidentDelta();    // add to ROMIMAGE offset for 1st resident

    void EnableButtons(bool bAdvanced);

    void FillOwnerInfo();

    void DoWorldEdit(bool bAdvanced);

    bool SpecialChangeName(const char* szTag, int ibPrototype);

    // Generated message map functions
    //{{AFX_MSG(CMainDlg)
    virtual BOOL OnInitDialog();
    afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
    afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnMoreMoney();
    afx_msg void OnSave();
    afx_msg void OnEditInventory1();
    afx_msg void OnEditWorldmap();
    afx_msg void OnEditRoommap();
    afx_msg void OnEditSuperroom();
    afx_msg void OnEditRiver();
    afx_msg void OnEditWorldAdvanced();
    afx_msg void OnEditNeighbor();
    afx_msg void OnAdvancedOrBasic();
    afx_msg void OnSpecialFilloutcatalog();
    afx_msg void OnSpecialFilloutmusic();
    afx_msg void OnSpecialChangetownname();
    afx_msg void OnSpecialChangeResidentName();
    afx_msg void OnSpecialChangeformatcompressedsav();
    afx_msg void OnSpecialUnburyallworldmapitems();
    afx_msg void OnEditEditlostfound();
    afx_msg void OnEditEditrecycler();
    afx_msg void OnEditEditresidentDrawers();
    afx_msg void OnEditEditnookstoreitems();
    afx_msg void OnEditSuperRiverMode();
    afx_msg void OnSpecialChangetowntype();
    afx_msg void OnSpecialChangeGeneralName();
    afx_msg void OnEditEditEmotionsResident();
    afx_msg void OnMorePoints();
    afx_msg void OnMoreMoney2();
    afx_msg void OnSpecialNextResident();
    afx_msg void OnMovingNeighborInfo();
    afx_msg void OnEditBedroom();
    afx_msg void OnEditGifts();
    afx_msg void OnEditEquip();
    afx_msg void OnDangerLevel0();
    afx_msg void OnDangerLevel1();
    afx_msg void OnDangerLevel2();
    afx_msg void OnDangerLevel3();
    afx_msg void OnDangerLevel4();
    afx_msg void OnPlayerChangeFaceEtc();
    afx_msg void OnHouseInfo();
    afx_msg void OnArdsGenrock();
    afx_msg void OnArdsGenBridges();
    afx_msg void OnArdsSnapshot();
    afx_msg void OnArdsDiff();
    afx_msg void OnSnowmenTweek();
    //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
