// script.cpp
//  provides text encoding and decoding
//  Both English (and other languages) and Japanese character sets

// The game stores characters in their own format
// This module tries to convert between that format and regular ASCII/ANSI
//  Also handles Japanese
// This is not a one character to one character conversion

#include "stdafx.h"
#include "AnimalMap.h"
#include "romsave.h"
#include "script.h"

/////////////////////////////////////////////////////////////////////////////
// character map

struct MAP
{
    unsigned char code;
    char chShort;
    const char* szLong;
};

MAP special_map[] =
{
 { 0x41, 'o', "(OE)" },
 { 0x44, 'o', "(oe)" },
 { 0x47, 'A', "(A\\)" },
 { 0x48, 'A', "(A/)" },
 { 0x49, 'A', "(A^)" },
 { 0x4B, 'A', "(A:)" },
 { 0x4E, 'C', "(C,)" },
 { 0x4F, 'E', "(E\\)" },
 { 0x50, 'E', "(E/)" },
 { 0x51, 'E', "(E^)" },
 { 0x52, 'E', "(E:)" },
 { 0x53, 'I', "(I\\)" },
 { 0x54, 'I', "(I/)" },
 { 0x55, 'I', "(I^)" },
 { 0x56, 'I', "(I:)" },
 { 0x58, 'N', "(N~)" },
 { 0x59, 'O', "(O\\)" },
 { 0x5A, 'O', "(O/)" },
 { 0x5B, 'O', "(O^)" },
 { 0x5D, 'O', "(O:)" },
 { 0x5F, 'U', "(U\\)" },
 { 0x60, 'U', "(U/)" },
 { 0x61, 'U', "(U^)" },
 { 0x62, 'U', "(U:)" },
 { 0x65, 'B', "(beta)" },
 { 0x66, 'a', "(a\\)" },
 { 0x67, 'a', "(a/)" },
 { 0x68, 'a', "(a^)" },
 { 0x6A, 'a', "(a:)" },
 { 0x6D, 'c', "(c,)" },
 { 0x6E, 'e', "(e\\)" },
 { 0x6F, 'e', "(e/)" },
 { 0x70, 'e', "(e^)" },
 { 0x71, 'e', "(e:)" },
 { 0x72, 'i', "(i\\)" },
 { 0x73, 'i', "(i/)" },
 { 0x74, 'i', "(i^)" },
 { 0x75, 'i', "(i:)" },
 { 0x77, 'n', "(n~)" },
 { 0x78, 'o', "(o\\)" },
 { 0x79, 'o', "(o/)" },
 { 0x7A, 'o', "(o^)" },
 { 0x7C, 'o', "(o:)" },
 { 0x7E, 'u', "(u\\)" },
 { 0x7F, 'u', "(u/)" },
 { 0x80, 'u', "(u^)" },
 { 0x81, 'u', "(u:)" },
 { 0x85, ' ', }, // "(space)"
 { 0x86, ' ', "(breaking-space)" },
// ??
 { 0x87, '!' },
 { 0x87, 13, "(newline)" },
 { 0x8C, '&' },
 { 0x8D, '\'' }, // single quote
 { 0x8E, '(' },
 { 0x8F, ')' },
 { 0x91, '+' },
 { 0x92, ',' },
 { 0x93, '-' },
 { 0x94, '.' },
 { 0x96, ':' },
 { 0x97, ';' },
 { 0x98, '<' },
 { 0x99, '=' },
 { 0x9A, '>' },
 { 0x9B, '?' },
 { 0x9C, '@' },
 { 0x9D, '[' },
 { 0x9F, ']' },
 { 0xA1, '_' },
 { 0xA6, '~' },
 { 0xA7, 'E', "(euro)" },
 { 0xB1, '\'' },
 { 0xB3, '\"' },
 { 0xBB, 'i', "(i)" },
 { 0xBC, 'c', "(cent)" },
 { 0xBD, 'L', "pound" },
 { 0xD1, '.', "(middle-dot)" },
 { 0xD9, '?', "(upside-down-?)" },
 { 0xDA, '*', "(multiply)" },
 { 0xDB, '/', "(divide)" },
 { 0xDC, '=', "(tear)" },
 { 0xDD, '=', "(star)" },
 { 0xDE, '=', "(heart)" },
 { 0xDF, '=', "(note)" },
};

static char FindMangledChar(unsigned char b, char* szOut)
{
    if (szOut != NULL)
        szOut[0] = '\0';
    if (b >= 1 && b <= 26)
        return '@' + b;
    else if (b >= 27 && b <= 52) //0x34 inclusive
        return 70 + b;
    else if (b >= 53 && b <= 62) //0x3E inclusive
        return '0' + (b - 53);

    for (int i = 0; i < sizeof(special_map)/sizeof(MAP); i++)
    {
        MAP const& map = special_map[i];
        if (b == map.code)
        {
            if (szOut != NULL && map.szLong != NULL)
                strcpy(szOut, map.szLong);
            return map.chShort;
        }
    }

    if (b == 0)
        return 0;   // byte zero

    if (szOut != NULL)
        sprintf(szOut, "(unknown$%02X)", b);
    return (char)0xFF; // other
}
static uint8 MangleChar(char ch)
{
    // only single charactes
    if (ch >= 'A' && ch <= 'Z')
        return ch - '@';
    else if (ch >= 'a' && ch <= 'z')
        return ch - 70;
    else if (ch >= '0' && ch <= '9')
        return 53 + (ch - '0');

    for (int i = 0; i < sizeof(special_map)/sizeof(MAP); i++)
    {
        MAP const& map = special_map[i];
        if (map.szLong == NULL && ch == map.chShort)
            return map.code;
    }
    return 0;    // no match
}

bool FormatMangled_E(char* szOut, int offset, int cb)
    // return true if safe editable
{
    bool bSafe = true;

    while (cb--)
    {
        char szLong[32];
        char ch = FindMangledChar(g_romsave.GetBufferB(offset++), szLong);
        if (szLong[0] != '\0')
        {
            bSafe = false;
            strcpy(szOut, szLong);
            szOut += strlen(szOut);
        }
        else
        {
            *szOut++ = ch;
        }
    }
    *szOut = '\0';
    return bSafe;
}

bool FormatMangledArray_E(char* szOut, const uint8* pb, int cb)
    // return true if safe editable
{
    bool bSafe = true;

    while (cb--)
    {
        char szLong[32];
        char ch = FindMangledChar(*pb++, szLong);
        if (szLong[0] != '\0')
        {
            bSafe = false;
            strcpy(szOut, szLong);
            szOut += strlen(szOut);
        }
        else
        {
            *szOut++ = ch;
        }
    }
    *szOut = '\0';
    return bSafe;
}

bool Mangle_E(uint8* pbOut, const char* szIn, int cch)
    // return true if valid
{
    while (cch--)
    {
        uint8 b = 0;
        if (*szIn != '\0')
        {
            b = MangleChar(*szIn++);
            if (b == 0)
                return false;    //bogus
        }
        *pbOut++ = b;
    }
    return true;
}

/////////////////////////////////////////////////////////////////////////////
// Very minimal japanese support

// WARNING: I don't know Katakana or Hiragana
//  Guesses based on the pictures and the Unicode descriptions.
//  But verified by some Japanese users of AnimalMap, so they should be ok.

static wchar_t j_codes_1_based[] =
{
// 1->8
0x3042,
0x3044,
0x3046,
0x3048,
0x304A, // 1tick
0x304B, // 1tick
0x304D, // no ticks
0x304F, // no ticks
// 9->16
0x3051,
0x3053,
0x3055,
0x3057,
0x3059,
0x305B,
0x305D,
0x305F,
// 17..
0x3061,
0x3064,
0x3066,
0x3068,
0x306A,
0x306B,
0x306C,
0x306D,
0x306E,
0x306F,
0x3072,
0x3075, //???
0x3078,
0x307B,
0x307E,
0x307F,
// 3rd row part 1
0x3080,
0x3081,
0x3082,
0x3084,
0x3086,
0x3088,
0x3089,
0x308A,
0x308B,
0x308C,
0x308D,
0x308F,
0x3092,
0x3093,
0x304C, // double tick diacritics
0x304E,
// 4th row
0x3050,
0x3052,
0x3054,
0x3056,
0x3058,
0x305A,
0x305C,
0x305E,
0x3060,
0x3062,
0x3065,
0x3067,
0x3069,
0x3070,
0x3073,
0x3076,
// 2nd part, 1st row
0x3079,
0x307C,
0x3071, // with 'o' diacritic
0x3074,
0x3077,
0x307A,
0x307D,
// lower case start
0x3041,
0x3043,
0x3045,
0x3047,
0x3049,
0x3083, // 3 were missing
0x3085,
0x3087,
0x3063,
// katakana start (2nd row)
0x30A2,
0x30A4,
0x30A6,
0x30A8,
0x30AA,
0x30AB,
0x30AD,
0x30AF,
0x30B1,
0x30B3,
0x30B5,
0x30B7,
0x30B9,
0x30BB,
0x30BD,
0x30BF,
// 3rd row
0x30C1,
0x30C4, // capital?
0x30C6,
0x30C8,
0x30CA,
0x30CB,
0x30CC,
0x30CD,
0x30CE,
0x30CF,
0x30D2,
0x30D5,
0x30D8,
0x30DB,
0x30DE,
0x30DF,
// 4th row
0x30E0,
0x30E1,
0x30E2,
0x30E4,
0x30E6,
0x30E8,
0x30E9,
0x30EA,
0x30EB,
0x30EC,
0x30ED,
0x30EF,
0x30F2,
0x30F3,
0x30AC, // start diacritic
0x30AE,
// first row, 3rd part
0x30B0,
0x30B2,
0x30B4,
0x30B6,
0x30B8,
0x30BA,
0x30BC,
0x30BE,
0x30C0,
0x30C2,
0x30C5,
0x30C7,
0x30C9,
0x30D0,
0x30D3,
0x30D6,
// 2nd row
0x30D9,
0x30DC,
0x30D1, // first of 'o'
0x30D4,
0x30D7,
0x30DA,
0x30DD,
0x30A1, // lower case
0x30A3,
0x30A5,
0x30A7,
0x30A9,
0x30E3,
0x30E5,
0x30E7,
0x30C3,
// last kata row
0x30F4,
};

#define NUM_HIRAKATA (sizeof(j_codes_1_based)/sizeof(wchar_t))

static char j_special[] = "-~.o,!?.,[]()<>'\"_+=&@:;";
static const wchar_t* j_special2[] =
{
    L"(mul)", L"(div)", L"(tear)", L"(star)", L"(heart)", L"(note)"
};

bool FormatMangled_J(wchar_t* wszOut, int offset, int cb)
{
    bool bSafe = true;

    while (cb--)
    {
        wchar_t ch = '?';
        uint8 b = g_romsave.GetBufferB(offset++);
        if (b == 0)
            break; // end

        if (b >= 1 && b < 1+NUM_HIRAKATA)
            ch = j_codes_1_based[b-1];
        else if (b >= 0xA2 && b < 0xBC)
            ch = 'A' + (b - 0xA2);
        else if (b >= 0xBC && b < 0xD6)
            ch = 'a' + (b - 0xBC);
        else if (b >= 0xD6 && b < 0xE0)
            ch = '0' + (b - 0xD6);
        else if (b >= 0xE0)
            ch = ' '; // gap
        else if (b >= 0xE1)
        {
            ch = ' '; // line-breaking
            bSafe = false;
        }
        else if (b >= 0xE2 && b < 0xFA)
            ch = j_special[b-0xE2];
        else if (b >= 0xFA && b <= 0xFF)
        {
            wcscpy(wszOut, j_special2[b-0xFA]);
            wszOut += wcslen(wszOut);
            ch = '\0';
            bSafe = false;
        }
        else
            bSafe = false;

        if (ch != 0)
            *wszOut++ = ch;
    }
    *wszOut = 0;
    return bSafe;
}


/////////////////////////////////////////////////////////////////////////////
