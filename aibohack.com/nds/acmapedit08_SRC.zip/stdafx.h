// stdafx.h : include file for standard system include files,

#pragma once

// additional defines for Visual Studio 8
#define _CRT_SECURE_NO_DEPRECATE
#define _CRT_NON_CONFORMING_SWPRINTFS
#define WINVER 0x0400


#define VC_EXTRALEAN        // Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxcmn.h>            // MFC support for Windows Common Controls

