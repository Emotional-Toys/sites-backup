/////////////////////////////////////////////////////////////
// default RCodePlus Program
// version 7 (.01) for ERS-7 and RCODE-7 (Not RCodePlus)
// released with YART 7.01
// Features removed from RCodePlus (2x0/31x) version marked with '//REMOVED: '

// YART compatible
    // that's what the //{ //} things are for

// "Mini-Obey Cat 7" - VERY MINIMAL
// Mini Obey Cat provide a very basic personality
//  You can customize this using any text editor
//  Please read the comments in this file to figure out what is happening

// NOTES:
// - provides simple functionality using built-in motions and sounds
// - a LAN connection is helpful for debugging
// - works on ERS-7 model AIBOs

/////////////////////////////////////////////////////////////

:Main
    // This is where the program starts

    GLOBAL doPrint 0

    VLOAD doPrint
    IF AiboId != 0 THEN
        // LAN is connected, print status
        SET doPrint 1
    ENDIF

    //REMOVED: no debug mode

    IF doPrint != 0 THEN
        PRINT "RCODE Basic YART Program 7 [.01]"
        PRINT "Program will PRINT status information"
    ENDIF

    IF AiboType != 7 THEN
        PRINT "only works on ERS-7"
        HALT
    ENDIF

    PRINT "-"

    //REMOVED: no RCR_Init without RCodePlus - learning new names not supported
    //REMOVED: AP_Vocab, AP_VLang features - only 1 vocabulary for RCODE 7 (right now)
    //REMOVED: AP_DEVCTL for HFD - not needed

    //{ "Main/Startup(once)"
      PLAY ACTION LIE // lie down at start
      WAIT
    //}

    // clear globals and sensors

    CLR SENSORS
    LOCAL lastPink 0
    LOCAL lastBone 0
    LOCAL idleCount 0

    LOCAL postureOld -1
    LOCAL postureNow -1

    // Main Loop
    WHILE 1 = 1

        // Voice and sound
        // do not change the code here
        //  instead edit "????_Handler"

        IF AU_Voice > 0 THEN
            PUSH AU_Voice_ID
            //REMOVED: AP_Voice_Level, AP_Voice_Pitch, AP_Voice_Horz
            CALL Voice_Handler:1
            SET AU_Voice 0
            LET idleCount 0 
        ENDIF

        //REMOVED: no AP_Loud

        IF AU_AiboTone > 0 THEN
            PUSH AU_AiboTone_ID
            CALL AiboTone_Handler:1
            SET AU_AiboTone 0
            LET idleCount 0 
        ENDIF

        IF AU_AiboSound > 0 THEN
            PUSH AU_AiboSound_ID
            CALL AiboSound_Handler:1
            SET AU_AiboSound 0
            LET idleCount 0 
        ENDIF

        //REMOVED: no AP_Noise, AP_Rhythm

        IF Pink_Ball <> 0 THEN
            IF lastPink == 0 THEN
                PUSH Pink_Ball_H
                PUSH Pink_Ball_V
                PUSH Pink_Ball_D
                CALL PinkBall_Found_Handler:3
                SET lastPink 1
            ENDIF
            PUSH Pink_Ball_H
            PUSH Pink_Ball_V
            PUSH Pink_Ball_D
            CALL PinkBall_Any_Handler:3
            LET idleCount 0 
        ELSE
            IF lastPink != 0 THEN
                CALL PinkBall_Lost_Handler
                SET lastPink 0
                LET idleCount 0 
            ENDIF
        ENDIF

        // Bone just like ball
        IF AIBONE <> 0 THEN
            IF lastBone == 0 THEN
                PUSH AIBONE_H
                PUSH AIBONE_V
                PUSH AIBONE_D
                CALL Bone_Found_Handler:3
                SET lastBone 1
            ENDIF
            PUSH AIBONE_H
            PUSH AIBONE_V
            PUSH AIBONE_D
            CALL Bone_Any_Handler:3
            LET idleCount 0 
        ELSE
            IF lastBone != 0 THEN
                CALL Bone_Lost_Handler
                SET lastBone 0
                LET idleCount 0 
            ENDIF
        ENDIF

        // simple Face change only
        //REMOVED: AP_FaceDetect with nearness and direction
        //REMOVED: face lost logic
        IF Face <> 0 THEN
			CALL Face_Found_Handler
            SET Face 0
			LET idleCount 0 
        ENDIF

        //REMOVED: other colors (AP_COLORLVL)

        ////////////////////////////////
        // ERS-7 sensors

        IF Head_ON <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Head_ON"
            ENDIF
            //{ "Sensor/Head pressed"
              PLAY ACTION+ NUTS // NUTS.WAV + motion + leds
              WAIT
            //}
            SET Head_ON 0
            LET idleCount 0 
        ENDIF

        IF Jaw_ON <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Jaw_ON"
            ENDIF
            //{ "Sensor/Jaw pressed"
              PLAY ACTION+ LAUGH // LAUGH.WAV + motion + leds
              PLAY ACTION+ LAUGH // LAUGH.WAV + motion + leds
              WAIT
              WAIT
            //}
            SET Jaw_ON 0
            LET idleCount 0 
        ENDIF

        IF BackF_ON <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: BackF_ON"
            ENDIF
            //{ "Sensor/BackFront pressed"
              PLAY ACTION+ IYLMNSONG // IYLMNSONG.WAV + motion + leds
              PLAY ACTION STAND
              WAIT
            //}
            SET BackF_ON 0
            LET idleCount 0 
        ENDIF

        IF BackM_ON <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: BackM_ON"
            ENDIF
            //{ "Sensor/BackMiddle pressed"
              PLAY ACTION SIT
              PLAY ACTION+ TACOSSONG // TACOSSONG.WAV + motion + leds
            //}
            SET BackM_ON 0
            LET idleCount 0 
        ENDIF

        IF BackR_ON <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: BackR_ON"
            ENDIF
            //{ "Sensor/BackRear pressed"
              PLAY ACTION SIT
              PLAY ACTION+ TFKISSESSONG // TFKISSESSONG.WAV + motion + leds
            //}
            SET BackR_ON 0
            LET idleCount 0 
        ENDIF

        IF Back_Pat <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Back_Pat"
            ENDIF
            //{ "Sensor/Back Pat"
              PLAY ACTION+ NUTS // NUTS.WAV + motion + leds
              WAIT
            //}
            SET Back_Pat 0
            LET idleCount 0 
        ENDIF

        IF BackR_Hit <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: BackR_Hit"
            ENDIF
            //{ "Sensor/Back Rear Hit"
              PLAY ACTION+ NUTS3 // NUTS3.WAV + motion + leds
              WAIT
              PLAY ACTION L_PHYSI.M_EXCRETE.S_WIND // Posture_stand
              WAIT
            //}
            SET BackR_Hit 0
            LET idleCount 0 
        ENDIF

        IF Head_LONG <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Head_LONG"
            ENDIF
            //{ "Sensor/Head press long time"
              PLAY ACTION LIE
              WAIT
            //}
            SET Head_LONG 0
            LET idleCount 0 
        ENDIF

        IF BackFR_LONG <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: BackFR_LONG"
            ENDIF
            //{ "Sensor/BackFront+Rear long time"
              PLAY ACTION LIE
              WAIT
            //}
            SET BackFR_LONG 0
            LET idleCount 0 
        ENDIF

        IF BackF_Jaw_LONG <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: BackF_Jaw_LONG"
            ENDIF
            //{ "Sensor/BackFront+Jaw long time"
              PLAY ACTION LIE
              WAIT
            //}
            SET BackF_Jaw_LONG 0
            LET idleCount 0 
        ENDIF

        LET postureOld postureNow
        LET postureNow Posture1  // posture in case it has changed

        IF postureNow == 3 THEN
            // currently in the LIE DOWN position
            // front paws can be used for input
            IF postureOld <> 3 THEN
                IF doPrint <> 0 THEN
                    PRINT "postureNew=SLEEP - will respond to front paws"
                ENDIF
                SET RFLeg_ON 0 // clear old values
                SET LFLeg_ON 0
            ENDIF

            IF RFLeg_ON <> 0 THEN
                IF doPrint <> 0 THEN
                    PRINT "Sensor: Front RFLeg_ON (LIEDOWN)"
                ENDIF
                //{ "Sensor/RF Paw (sleep position)"
                  PLAY ACTION+ JESUS // JESUS.WAV + motion + leds
                  WAIT
                //}
                SET RFLeg_ON 0
                LET idleCount 0 
            ENDIF

            IF LFLeg_ON <> 0 THEN
                IF doPrint <> 0 THEN
                    PRINT "Sensor: Front LFLeg_ON (LIEDOWN)"
                ENDIF
                //{ "Sensor/LF Paw (sleep position)"
                  PLAY ACTION+ JESUSA // JESUSA.WAV + motion + leds
                  WAIT
                //}
                SET LFLeg_ON 0
                LET idleCount 0 
            ENDIF
        ENDIF


//TOADD: new Distance and Distance_Cliff logic
//TOADD: ? maybe something with brightness ?

        ADD idleCount 1
        IF idleCount > 100 THEN
            // 100 ticks (approx 10 seconds) with nothing happening
            IF doPrint <> 0 THEN
                PRINT "Idle: postureNow = %d" postureNow
            ENDIF
            IF postureNow == 1 THEN // STAND
                CALL DoSomethingRandom_Stand
            ENDIF
            IF postureNow == 2 THEN // SIT
                CALL DoSomethingRandom_Sit
            ENDIF
            IF postureNow == 3 THEN // LIE / SLEEP
                CALL DoSomethingRandom_Sleep
            ENDIF
            // otherwise walking or something else
            LET idleCount 0
        ENDIF

        WAIT 100
    WEND // end of main loop

EXIT

/////////////////////////////////////////////////////////////
// Random skits after 10 seconds of idleness

:DoSomethingRandom_Stand
    LOCAL randVal
    RND randVal 1 5
    IF randVal == 1 THEN
        //{ "Idle/Stand Random#1"
          PLAY ACTION+ STUPID // STUPID.WAV + motion + leds
          WAIT
        //}
    ENDIF
    IF randVal == 2 THEN
        //{ "Idle/Stand Random#2"
          PLAY ACTION+ TALKING // TALKING.WAV + motion + leds
          WAIT
        //}
    ENDIF
    IF randVal == 3 THEN
        //{ "Idle/Stand Random#3"
          PLAY ACTION+ JESUS // JESUS.WAV + motion + leds
          WAIT
        //}
    ENDIF
    IF randVal == 4 THEN
        //{ "Idle/Stand Random#4"
          PLAY ACTION+ JESUSA // JESUSA.WAV + motion + leds
          WAIT
        //}
    ENDIF
    IF randVal == 5 THEN
        //{ "Idle/Stand Random#5"
          PLAY ACTION+ QTRLESB // QTRLESB.WAV + motion + leds
          WAIT
        //}
    ENDIF
RETURN

:DoSomethingRandom_Sit
    LOCAL randVal
    RND randVal 1 5
    IF randVal == 1 THEN
        //{ "Idle/Sit Random#1"
          PLAY ACTION+ CHAOSLAUGH // CHAOSLAUGH.WAV + motion + leds
          PLAY ACTION+ CHAOSLAUGH // CHAOSLAUGH.WAV + motion + leds
          PLAY ACTION+ CHAOSLAUGH // CHAOSLAUGH.WAV + motion + leds
          WAIT
        //}
    ENDIF
    IF randVal == 2 THEN
        //{ "Idle/Sit Random#2"
          PLAY ACTION+ NOTGOTH // NOTGOTH.WAV + motion + leds
          WAIT
        //}
    ENDIF
    IF randVal == 3 THEN
        //{ "Idle/Sit Random#3"
          PLAY ACTION+ WENDYSONG // WENDYSONG.WAV + motion + leds
          WAIT
        //}
    ENDIF
    IF randVal == 4 THEN
        //{ "Idle/Sit Random#4"
        //}
    ENDIF
    IF randVal == 5 THEN
        //{ "Idle/Sit Random#5"
        //}
    ENDIF
RETURN

:DoSomethingRandom_Sleep // AKA "lie down"
    LOCAL randVal
    RND randVal 1 5
    IF randVal == 1 THEN
        //{ "Idle/Sleep Random#1"
          PLAY ACTION+ IYLMNSONG // IYLMNSONG.WAV + motion + leds
          WAIT
        //}
    ENDIF
    IF randVal == 2 THEN
        //{ "Idle/Sleep Random#2"
        //}
    ENDIF
    IF randVal == 3 THEN
        //{ "Idle/Sleep Random#3"
        //}
    ENDIF
    IF randVal == 4 THEN
        //{ "Idle/Sleep Random#4"
        //}
    ENDIF
    IF randVal == 5 THEN
        //{ "Idle/Sleep Random#5"
        //}
    ENDIF
RETURN


/////////////////////////////////////////////////////////////
// _Handler routines - YART compatible

:Voice_Handler
  ARG id

  IF doPrint <> 0 THEN
    PRINT "Voice_Handler: %d" id
  ENDIF

  IF id == 1 THEN
    //{ "AIBO voice command/'AIBO' or <dog's name>"
      PLAY ACTION+ TALKING // TALKING.WAV + motion + leds
      PLAY ACTION KICK 30 1000
      WAIT
    //}
  ENDIF
  IF id == 0x100 THEN
    //{ "AIBO voice command/<owner's name>"
      PLAY ACTION+ MASA // MASA.WAV + motion + leds
      PLAY ACTION KICK -30 1000
      WAIT
    //}
  ENDIF
  IF id == 2 THEN
    //{ "AIBO voice command/'What's your name?'"
      PLAY ACTION+ IAMCHAOS // IAMCHAOS.WAV + motion + leds
      PLAY ACTION KICK -30 1000 // Kick Right
      PLAY ACTION+ LAUGH // LAUGH.WAV + motion + leds
      PLAY ACTION+ LAUGH // LAUGH.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 3 THEN
    //{ "AIBO voice command/'Say hello'"
      PLAY ACTION+ IAMCHAOS // IAMCHAOS.WAV + motion + leds
      PLAY ACTION+ PISSED // PISSED.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 4 THEN
    //{ "AIBO voice command/'Shake paw'"
      PLAY ACTION KICK -30 1000
      WAIT
      PLAY ACTION+ BLACKASS // BLACKASS.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 5 THEN
    //{ "AIBO voice command/'Morning'"
      PLAY ACTION SIT
      PLAY ACTION L_PHYSI.M_SLEEPY.S_SLEEPY.sit // Posture_sit
      PLAY ACTION+ CARPET // CARPET.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 6 THEN
    //{ "AIBO voice command/'Hello'"
      PLAY ACTION+ TALKING // TALKING.WAV + motion + leds
      PLAY ACTION L_PHYSI.M_EXCRETE.S_HANG // Posture_stand
      PLAY ACTION L_PHYSI.M_EXCRETE.S_WIND // Posture_stand
    //}
  ENDIF
  IF id == 7 THEN
    //{ "AIBO voice command/'Good night'"
      PLAY ACTION+ JESUSA // JESUSA.WAV + motion + leds
      PLAY ACTION L_CHGPOS.M_SIT.S_QUICK.sit // Posture_sit
      WAIT
    //}
  ENDIF
  IF id == 8 THEN
    //{ "AIBO voice command/'See you'"
      PLAY ACTION+ BUTMOM // BUTMOM.WAV + motion + leds
      PLAY ACTION L_CHGPOS.M_STAND.S_QUICK.stand // Posture_stand
      WAIT
    //}
  ENDIF
  IF id == 9 THEN
    //{ "AIBO voice command/'How are you?'"
      PLAY ACTION+ PISSED // PISSED.WAV + motion + leds
      PLAY ACTION+ PISSED // PISSED.WAV + motion + leds
      PLAY ACTION L_REFLEX.M_ANGRY.S_LED // Posture_any
      PLAY ACTION STAND
      PLAY ACTION TURN 180 // Turn Around
      PLAY ACTION L_PHYSI.M_EXCRETE.S_WIND // Posture_stand
      WAIT
    //}
  ENDIF
  IF id == 10 THEN
    //{ "AIBO voice command/'Hey AIBO'"
      PLAY ACTION+ STUPID // STUPID.WAV + motion + leds
      PLAY ACTION+ BLACKASS // BLACKASS.WAV + motion + leds
      PLAY ACTION L_PHYSI.M_EXCRETE.S_WIND // Posture_stand
      WAIT
    //}
  ENDIF
  IF id == 11 THEN
    //{ "AIBO voice command/'Thanks'"
      PLAY ACTION+ TALKING // TALKING.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 12 THEN
    //{ "AIBO voice command/'Sorry'"
    //}
  ENDIF
  IF id == 13 THEN
    //{ "AIBO voice command/'Cheer up'"
      PLAY ACTION+ WENDYSONG // WENDYSONG.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 14 THEN
    //{ "AIBO voice command/'Banzai'"
    //}
  ENDIF
  IF id == 15 THEN
    //{ "AIBO voice command/'That's right'"
      PLAY ACTION+ SUCKEDASS // SUCKEDASS.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 16 THEN
    //{ "AIBO voice command/'That's wrong'"
      PLAY ACTION+ SUCKEDASS // SUCKEDASS.WAV + motion + leds
      PLAY ACTION SIT
      PLAY ACTION+ ITOLDONYOU // ITOLDONYOU.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 17 THEN
    //{ "AIBO voice command/'Good AIBO'"
      PLAY ACTION+ SUCKEDASS // SUCKEDASS.WAV + motion + leds
      PLAY ACTION L_PHYSI.M_EXCRETE.S_WIND // Posture_stand
      WAIT
    //}
  ENDIF
  IF id == 18 THEN
    //{ "AIBO voice command/'Don't do that'"
      PLAY ACTION+ BUTMOM // BUTMOM.WAV + motion + leds
      PLAY ACTION KICK -30 1000 // Kick Right
      WAIT
    //}
  ENDIF
  IF id == 19 THEN
    //{ "AIBO voice command/'Let's play!'"
      PLAY ACTION TURN 180 // Turn Around
      PLAY ACTION+ BLACKASS // BLACKASS.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 20 THEN
    //{ "AIBO voice command/'Sing a song'"
      PLAY ACTION+ OHOLYNIGHT // OHOLYNIGHT.WAV + motion + leds
      PLAY ACTION L_PHYSI.M_EXCRETE.S_WIND // Posture_stand
      WAIT
    //}
  ENDIF
  IF id == 21 THEN
    //{ "AIBO voice command/'Dance'"
      PLAY ACTION L_PHYSI.M_EXCRETE.S_HANG // Posture_stand
      PLAY ACTION+ TFKISSESSONG // TFKISSESSONG.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 22 THEN
    //{ "AIBO voice command/'Show time'"
    //}
  ENDIF
  IF id == 23 THEN
    //{ "AIBO voice command/'Pose for me'"
      PLAY ACTION L_INTENT.M_REJECT.S_REJECT.stand // Posture_stand
      WAIT
    //}
  ENDIF
  IF id == 24 THEN
    //{ "AIBO voice command/'Clown around'"
    //}
  ENDIF
  IF id == 25 THEN
    //{ "AIBO voice command/'Show off'"
    //}
  ENDIF
  IF id == 26 THEN
    //{ "AIBO voice command/'Say message'"
    //}
  ENDIF
  IF id == 27 THEN
    //{ "AIBO voice command/'Let's be secret'"
    //}
  ENDIF
  IF id == 28 THEN
    //{ "AIBO voice command/'Open sesame'"
    //}
  ENDIF
  IF id == 29 THEN
    //{ "AIBO voice command/'Happy day'"
    //}
  ENDIF
  IF id == 30 THEN
    //{ "AIBO voice command/'Stand up'"
      PLAY ACTION+ SLUT // SLUT.WAV + motion + leds
      PLAY ACTION SIT
      PLAY ACTION+ BLACKASS // BLACKASS.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 31 THEN
    //{ "AIBO voice command/'Lie down'"
      PLAY ACTION+ SLUT // SLUT.WAV + motion + leds
      PLAY ACTION STAND
      PLAY ACTION+ BLACKASS // BLACKASS.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 32 THEN
    //{ "AIBO voice command/'Sit down'"
      PLAY ACTION SIT
      PLAY ACTION+ CRAP // CRAP.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 33 THEN
    //{ "AIBO voice command/'Turn right'"
      PLAY ACTION TURN -90
      WAIT
    //}
  ENDIF
  IF id == 34 THEN
    //{ "AIBO voice command/'Turn left'"
      PLAY ACTION TURN 90
      WAIT
    //}
  ENDIF
  IF id == 35 THEN
    //{ "AIBO voice command/'Go forward'"
      PLAY ACTION+ IAMCHAOS // IAMCHAOS.WAV + motion + leds
      WAIT
      WAIT
    //}
  ENDIF
  IF id == 36 THEN
    //{ "AIBO voice command/'Go backward'"
      PLAY ACTION+ STUPID // STUPID.WAV + motion + leds
      PLAY ACTION TURN 180
      WAIT
    //}
  ENDIF
  IF id == 37 THEN
    //{ "AIBO voice command/'Go ahead'"
      PLAY ACTION L_INTENT.M_NOD.S_NOD // Posture_stand
      WAIT
      PLAY ACTION+ BLACKASS // BLACKASS.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 38 THEN
    //{ "AIBO voice command/'Stop'"
      PLAY ACTION L_PHYSI.M_EXCRETE.S_WIND // Posture_stand
      PLAY ACTION L_PHYSI.M_EXCRETE.S_HANG // Posture_stand
      PLAY ACTION+ CRAP // CRAP.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 39 THEN
    //{ "AIBO voice command/'Faster'"
    //}
  ENDIF
  IF id == 40 THEN
    //{ "AIBO voice command/'Slow down'"
    //}
  ENDIF
  IF id == 41 THEN
    //{ "AIBO voice command/'Pink ball'"
      PLAY ACTION+ QTRLESB // QTRLESB.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 42 THEN
    //{ "AIBO voice command/'Right leg kick'"
      PLAY ACTION KICK -30 1000
      WAIT
    //}
  ENDIF
  IF id == 43 THEN
    //{ "AIBO voice command/'Right leg touch'"
    //}
  ENDIF
  IF id == 44 THEN
    //{ "AIBO voice command/'Left leg kick'"
      PLAY ACTION KICK 30 1000
      WAIT
    //}
  ENDIF
  IF id == 45 THEN
    //{ "AIBO voice command/'Left leg touch'"
    //}
  ENDIF
  IF id == 46 THEN
    //{ "AIBO voice command/'Ready set go'"
      PLAY ACTION+ STUPID // STUPID.WAV + motion + leds
      PLAY ACTION+ SLUT // SLUT.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 47 THEN
    //{ "AIBO voice command/'You won'"
    //}
  ENDIF
  IF id == 48 THEN
    //{ "AIBO voice command/'You lost'"
      PLAY ACTION+ SUCKEDASS // SUCKEDASS.WAV + motion + leds
      WAIT
    //}
  ENDIF
  IF id == 49 THEN
    //{ "AIBO voice command/'Action one'"
    //}
  ENDIF
  IF id == 50 THEN
    //{ "AIBO voice command/'Action two'"
    //}
  ENDIF
  IF id == 51 THEN
    //{ "AIBO voice command/'Action three'"
    //}
  ENDIF
  IF id == 52 THEN
    //{ "AIBO voice command/'Action four'"
    //}
  ENDIF
  IF id == 53 THEN
    //{ "AIBO voice command/'Action five'"
    //}
  ENDIF
//REVIEW: extended vocabulary

RETURN

///////////////////////
//REMOVED: Loud_Handler

///////////////////////

:AiboTone_Handler
  ARG id

  IF doPrint <> 0 THEN
    PRINT "AiboTone_Handler: %d" id
  ENDIF

RETURN

///////////////////////

:AiboSound_Handler
  ARG id

  IF doPrint <> 0 THEN
    PRINT "AiboSound_Handler: %d" id
  ENDIF

  //{ "AIBO hears/another AIBO"
    PLAY ACTION+ STUPID // STUPID.WAV + motion + leds
    WAIT
    WAIT
  //}
RETURN

///////////////////////

//REMOVED: Noise_Handler, Rhythm_Handler

///////////////////////
// Pink Ball

:PinkBall_Found_Handler
  ARG hangle
  ARG vangle
  ARG dist

  IF doPrint <> 0 THEN
    PRINT "PinkBall_Found_Handler (%d %d) %d" hangle vangle dist
  ENDIF

  //{ "AIBO sees/Pink Ball (seen)"
    PLAY ACTION STAND
    WAIT
    PLAY ACTION WALK 0 100
    WAIT
    PLAY ACTION+ SLUT // SLUT.WAV + motion + leds
    WAIT
    PLAY ACTION+ BLACKASS // BLACKASS.WAV + motion + leds
    WAIT
    PLAY ACTION LIE
    WAIT
  //}
RETURN

:PinkBall_Lost_Handler
  IF doPrint <> 0 THEN
    PRINT "PinkBall_Lost_Handler (%d %d) %d" hangle vangle dist
  ENDIF
  //{ "AIBO sees/Pink Ball (lost)"
    PLAY ACTION SIT
    WAIT
  //}

RETURN

:PinkBall_Any_Handler // called quite often when tracking
  ARG hangle
  ARG vangle
  ARG dist

  //{ "AIBO sees/Pink Ball (tracking)"
  //}

RETURN

///////////////////////
// Bone

:Bone_Found_Handler
  ARG hangle
  ARG vangle
  ARG dist

  IF doPrint <> 0 THEN
    PRINT "Bone_Found_Handler (%d %d) %d" hangle vangle dist
  ENDIF

  //{ "AIBO sees/Bone (seen)"
    PLAY ACTION STAND
    WAIT
    PLAY ACTION WALK 0 -100
    WAIT
  //}
RETURN

:Bone_Lost_Handler
  IF doPrint <> 0 THEN
    PRINT "Bone_Lost_Handler (%d %d) %d" hangle vangle dist
  ENDIF
  //{ "AIBO sees/Bone (lost)"
    PLAY ACTION SIT
    PLAY ACTION+ SUCKEDASS // SUCKEDASS.WAV + motion + leds
    WAIT
  //}

RETURN

:Bone_Any_Handler // called quite often when tracking
  ARG hangle
  ARG vangle
  ARG dist

  //{ "AIBO sees/Bone (tracking)"
  //}

RETURN

///////////////////////
// Face

:Face_Found_Handler
  IF doPrint <> 0 THEN
	PRINT "Sensor: Saw your face"
  ENDIF
  //{ "AIBO sees/Human Face (seen)"
    PLAY ACTION+ TALKING // TALKING.WAV + motion + leds
    WAIT
    WAIT
  //}
RETURN

/////////////////////////////////////////////////////////////
//REMOVED: Fav/UnFav handlers
//REMOVED: 'RCR' RCode Runtime, #AP_INCLUDE

/////////////////////////////////////////////////////////////
