/////////////////////////////////////////////////////////////
// Exorcist Aibo (Linda Blair)
// 1.0-7
    // ERS-7 no flip over version (no RCodePlus)
        // lie down to flail, sit up otherwise
    // no S_ or X_ prefix anymore
    // similar to the 2x0 version

// most audio actions are WAV + head + mouth
// GROSS_, RUDE_ and REACT_ have additional legs flailing
//  uses version of YART_APG that handles *_LEG.MTN option

:Main
    PLAY ACTION+ OLDALTAR
	PLAY ACTION SIT
	WAIT

	SET NoFallDown 1
        // may not work
    
    // Seed random number
    SET seed2 Hour
    MUL seed2 60
    ADD seed2 Min
    MUL seed2 60
    ADD seed2 Sec
    SET Seed seed2

 GLOBAL duration 3
    // start short, get longer

 GLOBAL nasty 0

:ReInit
    SET Pink_Ball 0
	SET nasty 0

:MainLoop
	CALL DoNiceMood
	IF Pink_Ball <> 0 THEN
        ADD nasty 1
        IF nasty == 1 THEN
			PLAY ACTION+ STAYAWAY
		    CALL LookAtYou
        ENDIF
        IF nasty == 2 THEN
			PLAY ACTION+ GONNADIE
		    CALL LookAtYou
	        SET Warn 1
        ENDIF
        IF nasty > 2 THEN
			CALL BecomePossessed
            ADD duration 1 // for next time
            GO ReInit
        ENDIF
        SET Pink_Ball 0
	ENDIF // Pink

    CALL DoNiceWalkaboutRandom
	GO MainLoop

/////////////////////////////////////////

:BecomePossessed
    // first become possessed
	PLAY ACTION+ STAYAWAY
    WAIT
    WAIT 250

    PLAY ACTION+ AHAH
    WAIT

	PLAY ACTION+ TODEVIL
    WAIT

	//NOT: rotate head explicitly ??
    //NOT: PLAY ACTION+ HEAD1
    //NOT: WAIT

    PLAY ACTION LIE
    WAIT
	SET Warn 0
	PLAY ACTION+ MOAN1 // no flail
    WAIT

	PLAY ACTION+ VOICES2 // no flail
    WAIT

	PLAY ACTION+ KEEPAWAY
    WAIT

	PLAY ACTION+ GROSS_PUKE1 // flail
    WAIT

	PLAY ACTION+ GROSS_VOICES2 // flail
    WAIT

    FOR i 0 duration
	    CALL DoCreepyGross // flail
    NEXT

	// stand up again for dialogue
    PLAY ACTION SIT
    WAIT

	SET Warn 1
    FOR i 0 duration
	    CALL DoCaptainHowdy // no legs
        IF i == 2 THEN
            PLAY ACTION LIE
            WAIT
        ENDIF
        IF i == 4 THEN
            PLAY ACTION SIT
            WAIT
        ENDIF
        WAIT 250
    NEXT

	SET Warn 0
	PLAY ACTION+ VOICES2 // flail
    PLAY ACTION LIE
    WAIT

    FOR i 0 duration
	    CALL DoCreepyGrossRude // flail
        WAIT 100
    NEXT

// battle
	PLAY ACTION+ HOLY_WATER_INTRO
    CALL LookAtYou
    WAIT 250

    FOR i 0 duration
		//NOT_NEEDED: CALL FlipOver // in case human corrects posture
        CALL DoIncantation
        CALL DoIncantationReaction // flail
	    CALL DoCreepyGrossRude // flail
    NEXT

	PLAY ACTION+ REACT_ITBURNS2 // flail
    WAIT
    
	PLAY ACTION+ REACT_BURNING1
    WAIT

// finale
	PLAY ACTION+ FINAL_FIGHT
    WAIT


	SET Warn 1
	PLAY ACTION+ GROSS_MISC_SCREAMING
    WAIT
// recover
	PLAY ACTION+ LEAVING1
    WAIT

	PLAY ACTION STAND
    WAIT

	PLAY ACTION+ FINAL1
    WAIT
	PLAY ACTION+ FINAL2
    WAIT
	SET Warn 0

	PLAY ACTION SIT
    WAIT

 RETURN

////////////////////////////////////////////////////////////////

:LookAtYou
	LOCAL act
	RND act 1 4
	SWITCH act
		CASE 1:PLAY ACTION MOVE.HEAD.FAST 10 40
		CASE 2:PLAY ACTION MOVE.HEAD.FAST -10 40
		CASE 3:PLAY ACTION MOVE.HEAD.FAST 20 80
		CASE 4:PLAY ACTION MOVE.HEAD.FAST -20 80
    WAIT // wait for head move
 RETURN

////////////////////////////////////////////////////////////////
// Audio helpers
//  start random performance (no WAIT)

:StartRandomBabble
  GLOBAL randBabble
  LOCAL r
  DO
    RND r 1 7
  LOOP UNTIL r <> randBabble
  SET randBabble r
  SWITCH:r
    CASE 1:PLAY ACTION+ BAB1
    CASE 2:PLAY ACTION+ BAB2
    CASE 3:PLAY ACTION+ BAB3
    CASE 4:PLAY ACTION+ BAB4
    CASE 5:PLAY ACTION+ BAB5
    CASE 6:PLAY ACTION+ BAB6
    CASE 7:PLAY ACTION+ BAB7
RETURN

:StartRandomGlee
  GLOBAL randGlee
  LOCAL r
  DO
    RND r 1 3
  LOOP UNTIL r <> randGlee
  SET randGlee r
  SWITCH:r
    CASE 1:PLAY ACTION+ GLEE1
    CASE 2:PLAY ACTION+ GLEE2
    CASE 3:PLAY ACTION+ GLEE3
RETURN

:StartRandomLaugh // short laugh
  GLOBAL randLaugh
  LOCAL r
  DO
    RND r 1 2
  LOOP UNTIL r <> randLaugh
  SET randLaugh r
  SWITCH:r
    CASE 1:PLAY ACTION+ LAUGH1
    CASE 2:PLAY ACTION+ LAUGH2
    // LAUGH3 has a problem
RETURN

/////////////////////////////////////////////////////////////

:DoNiceMood // no legs
	LOCAL act
	RND act 1 3
    // audio only
	SWITCH act
		CASE 1:CALL StartRandomBabble
		CASE 2:CALL StartRandomGlee
		CASE 3:CALL StartRandomLaugh
    // no leg movements
    WAIT
 RETURN

:DoNiceWalkaboutRandom
	LOCAL act
	RND act 1 10

    IF act <> 1 THEN
        RETURN
    ENDIF
	// 1 in 10 chance of simple skits

	RND act 1 3
    IF act == 1 THEN
        PLAY ACTION STAND
        WAIT
		PLAY ACTION WALK 0 200
        WAIT
        PLAY ACTION SIT
        WAIT
    ENDIF
    IF act == 2 THEN
        PLAY ACTION STAND
        WAIT
		PLAY ACTION WALK 180 150 // backwards
        WAIT
        PLAY ACTION SIT
        WAIT
    ENDIF
    IF act == 3 THEN
        PLAY ACTION STAND
        WAIT
		PLAY ACTION WALK 0 100
        WAIT
        WAIT 1000

        //NOT: PLAY ACTION+ SHIT1
        //NOT: WAIT
		RND act 1 2
		SWITCH act
            CASE 1:PLAY ACTION+ SQUIRT
		    CASE 2:PLAY ACTION+ OLDMAN_GRUNT
	    WAIT
        

		PLAY ACTION WALK 0 100
        WAIT
		PLAY ACTION+ LAUGH2
		PLAY ACTION WALK 0 50
        WAIT

		PLAY ACTION+ LAUGH1
        PLAY ACTION SIT
        WAIT
    ENDIF
    // ELSE - no walking skit
 RETURN

/////////////////////////////////////////////////////////////

:DoCaptainHowdy // wav + head/mouth only
	LOCAL act
	RND act 1 10
	SWITCH act
		CASE 1:PLAY ACTION+ CH_AMEN
		CASE 2:PLAY ACTION+ CH_BRING_TOGETHER
		CASE 3:PLAY ACTION+ CH_DAYFOR
		CASE 4:PLAY ACTION+ CH_INTIME
		CASE 5:PLAY ACTION+ CH_LATIN1
		CASE 6:PLAY ACTION+ CH_LATIN2
		CASE 7:PLAY ACTION+ CH_LATIN3
		CASE 8:PLAY ACTION+ CH_STRAPS1
		CASE 9:PLAY ACTION+ CH_STRAPS2
		CASE 10:PLAY ACTION+ CH_MOTHER
    WAIT
 RETURN

:DoCreepyGross // + leg flail on ground
	LOCAL act
	RND act 1 8
	SWITCH act
		CASE 1:PLAY ACTION+ GROSS_EVILLAUGH1
		CASE 2:PLAY ACTION+ GROSS_PUKE1
		CASE 3:PLAY ACTION+ GROSS_GROWL1
		CASE 4:PLAY ACTION+ GROSS_MISC1
		CASE 5:PLAY ACTION+ GROSS_MISC_SCREAMING
		CASE 6:PLAY ACTION+ GROSS_MOAN1
		CASE 7:PLAY ACTION+ GROSS_VOICES2
		CASE 8:PLAY ACTION+ GROSS_VOICES_LONG
    WAIT
 RETURN

:DoCreepyGrossRude // + leg flail on ground
	LOCAL act
	RND act 1 10 // CHANGE THIS to "RND act 1 8" to get rid of ultra rude comments
	SWITCH act
		CASE 1:PLAY ACTION+ GROSS_EVILLAUGH1
		CASE 2:PLAY ACTION+ GROSS_PUKE1
		CASE 3:PLAY ACTION+ GROSS_GROWL1
		CASE 4:PLAY ACTION+ GROSS_MISC1
		CASE 5:PLAY ACTION+ GROSS_MISC_SCREAMING
		CASE 6:PLAY ACTION+ GROSS_MOAN1
		CASE 7:PLAY ACTION+ GROSS_VOICES2
		CASE 8:PLAY ACTION+ GROSS_VOICES_LONG
		CASE 9:PLAY ACTION+ RUDE_FUCKME2 // rude
		CASE 10:PLAY ACTION+ RUDE_RUDE1 // rude
    WAIT
 RETURN


:DoIncantation // no legs
	LOCAL act
	RND act 1 12
	SWITCH act
		CASE 1:PLAY ACTION+ DO_CASTOUT
		CASE 2:PLAY ACTION+ DO_CROSS
		CASE 3:PLAY ACTION+ DO_DEPART
		CASE 4:PLAY ACTION+ DO_GODHIMSELF
		CASE 5:PLAY ACTION+ DO_HOLY_LORD
		CASE 6:PLAY ACTION+ DO_HOLYWATER
		CASE 7:PLAY ACTION+ DO_LORDS_PRAYER
		CASE 8:PLAY ACTION+ DO_MAJESTIC
		CASE 9:PLAY ACTION+ DO_MISC1
		CASE 10:PLAY ACTION+ DO_PARDON
		CASE 11:PLAY ACTION+ DO_POWER_CHRIST
		CASE 12:PLAY ACTION+ DO_TRINITY
    WAIT // no gyration
 RETURN

:DoIncantationReaction // + leg flail on ground
	LOCAL act
	RND act 1 5
	SWITCH act
		CASE 1:PLAY ACTION+ REACT_HURT2
		CASE 2:PLAY ACTION+ REACT_HURT3
		CASE 3:PLAY ACTION+ REACT_HURT4
		CASE 4:PLAY ACTION+ REACT_ITBURNS2
		CASE 5:PLAY ACTION+ REACT_BURNING1
    WAIT
 RETURN


/////////////////////////////////////////////////////////////
