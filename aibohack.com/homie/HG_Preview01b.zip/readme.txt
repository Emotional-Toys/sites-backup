HomieGate

Please read installation and usage instructions on the website:

    http://aibohack.com/homie

--------------------------------------------

Program and source are free-ware.
Currently in Beta/Preview release.
Please email me if you want to add more features or more clients.

--------------------------------------------

Files in the distribution:
    Note: "(generated)" files are normally created by 'hg_config.exe'

Core files:
    hg_server.exe - main server program (run on HomieGate server PC)
    hg.ini - all the important settings
    hg_config.exe - simple configuration program for easy setup

    hg_client.exe - PC client. Run on same PC to test interface.

    hgdata_x10.txt - manually edited list of X10 commands

    hgdata_albums.txt (generated) - all the albums in your music collection
    hgdata_music.txt (generated) - all the tracks in your music collection

    hgdata_vcmds.xml (generated) - all voice commands
            (can examine with Internet Explorer)
    hgdata_vcmds.cfg (generated) - compiled version of all voice commands

    gsrc\*.g,*.gh - grammar files for voice commands
        gsrc\*.gh - essential glue (do not edit)
        gsrc\main.g - some simple voice commands
        gsrc\aibo.g, gsrc\aibo_skits.g - AIBO specific voice commands

        gsrc\music.g - general music player commands
        gsrc\albums.g (generated) - music albums (use FindMusic)

        gsrc\x10.g (generated) - X10 commands (edit hgdata_x10.txt)

        gsrc\qa_*.g - General Question-and-Answer - mostly from AliceBot
            gsrc\qa_dict.g - dictionary
            gsrc\qa_science.g - scientific terms
            gsrc\qa_robot.g - robot specific sayings
            gsrc\qa_self.g - limited self awareness
            gsrc\qa_other.g - other stuff

        (any other .g file in the gsrc\ directory will be included into
            the compiled grammar by 'hg_config.exe')

    tools\*.* - support tools
        tools\hg_mciplayer.exe - simple MCI player for music files
                (can be customized)
        tools\hg_compile.bat - batch file to compile the grammar files
        tools\gc.exe - grammar compiler (part of Voice SDK)

    AiboSkits\*.* - skits for Aibo performances

    PDA\*.* - PDA specific files
        hg_client_arm.exe - ARM PDA client. Runs on iPaq or Toshiba e740/750

Sample data files:
    (will be replaced by your own data, but do not delete completely,
        since special folders must have at least one file in them)

    Music\*.* - sample music files
        (you can place your music collection here or elsewhere)

        Music\Pop\Madonna - Like A Prayer\*.mp3
            Stripped down version of Madonna's 'Like a Prayer' album
            For illustration purposes only (short low quality clips)

        Music\TestWavs\*.wav
            Cartman's Poochoo song broken into four parts.
    
    PlayList\*.txt - music playlists.
        (New playlists are placed here as TXT files, with a date time stamp)

        PlayList\Madonna Backwards.txt - Madonna album in reverse order
        PlayList\PooChoo Playlist (test).txt - test sample

    VoiceMemo - voice memos
        (New voice memos are placed here as WAV files, with a date time stamp)

        VoiceMemo\Cartman Todo Note.wav - sample

--------------------------------------------
Installation/Uninstall:

    Please install this in the 'C:\Homie' folder on your PC
    You can move it later, but you will have to edit HG.INI

    All the files used are in the 'C:\Homie' folder.
    You may include data files from other folders.

    If you wish to un-install, just stop any currently running HG_* programs,
    and delete the folder.

--------------------------------------------

