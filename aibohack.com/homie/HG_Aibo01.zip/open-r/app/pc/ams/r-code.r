// simple test version of RCODE for AIBO polling
//REVIEW: later move into RCR_ routines

:Init
 // PRINT "HomieGate AIBO Protocol test program"
 // version .01

 // turn off LEDs from last time
 SET Warn 0
 SET Tail_B 0
 SET Tail_O 0
 SET Eye_L1 0
 SET Eye_L2 0
 SET Eye_L3 0
 SET Eye_R3 0
 SET Eye_R2 0
 SET Eye_R1 0

 LOCAL HG_signal_array 25
 AP_DIM HG_signal_array 1
 AP_SETW HG_signal_array 0 1 // want PC connect
        // name "HG_signal_array is not special

 GLOBAL HG_flag 0 // this name is special

 PLAY ACTION SIT
 WAIT

:Request1
 WHILE HG_flag == 0
  // PRINT "Waiting for PC socket connect"
  WAIT 1000
 WEND

 IF HG_flag != 1 THEN
  PRINT "ERROR - HG_flag = %d expected 1" HG_flag
 ENDIF

:State1 // fake autonmous
  // PRINT "Entering State 1 (brainboing for 'Say Message')"
  SET AP_Voice_Cmd 0
  SET Back_ON 0
  LOCAL brainbo 0
 SET Warn 1
 WHILE brainbo == 0
  IF AP_Voice_Cmd == 26 THEN // Say Message
   LET brainbo 1
  ENDIF
  IF AP_Voice_Cmd == 1 THEN // Aibo
   LET brainbo 1
  ENDIF
  IF Back_ON != 0 THEN
   LET brainbo 1
  ENDIF
  WAIT 10
 WEND
  // PRINT "Leaving State 1 - rest is quiet"
 SET Warn 0

 IF HG_flag != 1 THEN
  PRINT "ERROR - HG_flag = %d expected 1" HG_flag
 ENDIF

:Request2
  // PRINT "Entering Request 2"
 AP_SETW HG_signal_array 0 2 // want PC attention
  SET Tail_O 1

 WHILE HG_flag != 2
  WAIT 10
 WEND
  SET Tail_O 0

:State2
  // PRINT "Entering State 2"
    // beep
  SET Tail_B 1

:Request3
  // PRINT "Entering Request 3"
 AP_SETW HG_signal_array 0 3 // PC can start recording audio

 SET Tail_B 1
 LOCAL iEye 0
 WHILE HG_flag != 3
  // lame eye flash
  SWITCH:iEye
   CASE:0:SET Eye_L1 1
   CASE:1:SET Eye_L2 1
   CASE:2:SET Eye_L3 1
   CASE:3:SET Eye_R3 1
   CASE:4:SET Eye_R2 1
   CASE:5:SET Eye_R1 1
  WAIT 80
  SWITCH:iEye
   CASE:0:SET Eye_L1 0
   CASE:1:SET Eye_L2 0
   CASE:2:SET Eye_L3 0
   CASE:3:SET Eye_R3 0
   CASE:4:SET Eye_R2 0
   CASE:5:SET Eye_R1 0
  ADD iEye 1
  MOD iEye 6
 WEND
 SET Tail_B 0

:Request4
  // PRINT "Entering Request 4"
 AP_SETW HG_signal_array 0 4 // PC can do anything it wants to me
 WHILE 1 == 1
  IF HG_flag == 1 THEN
   // PRINT "Going back to State 1"
   AP_SETW HG_signal_array 0 1 // want PC connect
   GO State1 // back to auto
  ENDIF
  IF HG_flag == 2 THEN
   // PRINT "Going back to State 2"
   AP_SETW HG_signal_array 0 2 // want PC connect
   GO State2 // back to recording
  ENDIF
  WAIT 10
 WEND

EXIT
