/////////////////////////////////////////////////////////////
// Exorcist Aibo (Linda Blair)
// 1.0

// Audio actions contain no motions
// S_ are nice sounds from Baby AIBO
// X_ are nasty sounds from Exorcist movie (some very rude)

:Main
    PLAY ACTION X_OLDALTAR
	PLAY ACTION SIT
	WAIT

	SET NoFallDown 1 // do our own recovery
    
    GLOBAL LFLeg_PRESS
    GLOBAL RFLeg_PRESS
    GLOBAL Both_PRESS
    SET LFLeg_ON 0
    SET LFLeg_OFF 0
    SET RFLeg_ON 0
    SET RFLeg_OFF 0

    // Seed random number
    SET seed2 Hour
    MUL seed2 60
    ADD seed2 Min
    MUL seed2 60
    ADD seed2 Sec
    SET Seed seed2

 GLOBAL duration 3
    // start short, get longer

// GyrateHeadNice globals
 GLOBAL ticks_x 0
 GLOBAL ticks_y 0
 GLOBAL dir_x -45
 GLOBAL dir_y 20
 GLOBAL nasty 0

:ReInit
    SET Tail_U_ON 0
    SET Tail_D_ON 0
    SET Tail_R_ON 0
    SET Tail_L_ON 0
    SET Tail_U_LONG 0

    SET Horn_G 0
    SET Horn_O 0
    SET Horn_B 0
    SET Warn 0

    SET Pink_Ball 0
	SET nasty 0

:MainLoop
	CALL DoNiceMood
	IF Pink_Ball <> 0 THEN
        ADD nasty 1
        IF nasty == 1 THEN
			PLAY ACTION+ X_STAYAWAY
		    CALL LookAtYou
        ENDIF
        IF nasty == 2 THEN
			PLAY ACTION+ X_GONNADIE
		    CALL LookAtYou
	        SET Warn 1
        ENDIF
        IF nasty > 2 THEN
			CALL BecomePossessed
            ADD duration 1 // for next time
            GO ReInit
        ENDIF
        SET Pink_Ball 0
	ENDIF // Pink

    CALL DoNiceWalkaboutRandom
	GO MainLoop

/////////////////////////////////////////

:BecomePossessed
    // first become possessed
	PLAY ACTION+ X_STAYAWAY
    CALL GyrateHeadNice
    WAIT 250

    PLAY ACTION+ X_AHAH
    CALL GyrateHeadNice

	// rotate head explicitly
	PLAY ACTION+ X_TODEVIL
    WAIT 6000 // "please mother ..."
    PLAY ACTION+ HEAD1
    WAIT

	PLAY ACTION+ X_MOAN1
	PLAY ACTION+ FLIP_B // over its back
    WAIT
	SET Warn 0

	PLAY ACTION+ X_VOICES2
	PLAY ACTION+ ONBACK_TRY_ROLL_L // flail
    CALL GyrateHeadEvil

	CALL FlipOver // just in case

	PLAY ACTION+ X_KEEPAWAY
	PLAY ACTION+ ONBACK_SPAZ_PAWS
    CALL GyrateHeadEvil

	PLAY ACTION+ X_PUKE1
    CALL StartUpsideDownLegSkit
    CALL GyrateHeadEvil

	PLAY ACTION+ X_VOICES2
    CALL StartUpsideDownLegSkit
    CALL GyrateHeadEvil

    FOR i 0 duration
		CALL FlipOver // in case human corrects posture
	    CALL DoCreepyGross // gross sounds
    NEXT

	// stand up again for dialogue
	CALL RecoverToNormal

	SET Warn 1
    FOR i 0 duration
	    CALL DoCaptainHowdy // no legs
        IF i == 2 THEN
            PLAY ACTION LIE
            WAIT
        ENDIF
        IF i == 4 THEN
            PLAY ACTION SIT
            WAIT
        ENDIF
        WAIT 250
    NEXT

	SET Warn 0
	PLAY ACTION+ X_VOICES2
	PLAY ACTION+ FLIP_B // over its back
    WAIT

    FOR i 0 duration
		CALL FlipOver // in case human corrects posture
	    CALL DoCreepyGrossRude
        WAIT 100
    NEXT

// battle
	PLAY ACTION+ X_HOLY_WATER_INTRO
    CALL LookAtYou
    WAIT 250

    FOR i 0 duration
		CALL FlipOver // in case human corrects posture
        CALL DoIncantation
        CALL DoIncantationReaction
	    CALL DoCreepyGrossRude
    NEXT

	PLAY ACTION+ X_ITBURNS2
    CALL StartUpsideDownLegSkit
    CALL GyrateHeadEvil
    
	PLAY ACTION+ X_BURNING1
    CALL StartUpsideDownLegSkit
    CALL GyrateHeadEvil

// finale
	PLAY ACTION+ X_FINAL_FIGHT
    CALL StartUpsideDownLegSkit
    CALL GyrateHeadEvil

// recover

	SET Warn 1
	PLAY ACTION+ X_MISC_SCREAMING
    CALL StartUpsideDownLegSkit
    CALL GyrateHeadEvil
	PLAY ACTION+ X_LEAVING1
    CALL StartUpsideDownLegSkit
    CALL GyrateHeadEvil

	CALL RecoverToNormal

	PLAY ACTION+ X_FINAL1
    CALL GyrateHeadNice
	PLAY ACTION+ X_FINAL2
    CALL GyrateHeadNice
	SET Warn 0

 RETURN

////////////////////////////////////////////////////////////////

:LookAtYou
	LOCAL act
	RND act 1 4
	SWITCH act
		CASE 1:PLAY ACTION MOVE.HEAD.FAST 10 40
		CASE 2:PLAY ACTION MOVE.HEAD.FAST -10 40
		CASE 3:PLAY ACTION MOVE.HEAD.FAST 20 80
		CASE 4:PLAY ACTION MOVE.HEAD.FAST -20 80
    WAIT
 RETURN

////////////////////////////////////////////////////////////////
// Head gyrate adapted from pre-YART CARTMAN

:GyrateHeadNice
    SET Horn_G 1
    SET Horn_O 0
    SET Horn_B 0

 WHILE Wait <> 0 // waiting for sound to be over
  ADD ticks_x 1
  ADD ticks_y 1
  IF ticks_x > 19 THEN
     PLAY ACTION MOVE.HEAD.FAST dir_x dir_y
	 WAIT MOTION_ALL
     IF dir_x > 0 THEN
         RND dir_x -50 -20
     ELSE
         RND dir_x 20 50
     ENDIF
     LET ticks_x 0
  ENDIF
  IF ticks_y > 10 THEN
     PLAY ACTION MOVE.HEAD.FAST dir_x dir_y
	 WAIT MOTION_ALL
     IF dir_y > 0 THEN
         RND dir_y -30 -10
     ELSE
         RND dir_y 10 30
     ENDIF
     LET ticks_y 0
  ENDIF
  WAIT 100
 WEND
RETURN


///////////////
:GyrateHeadEvil

    SET Horn_G 0
    SET Horn_O 1

 WHILE Wait <> 0 // waiting for sound to be over
  ADD ticks_x 1
  ADD ticks_y 1
  IF ticks_x > 10 THEN
     PLAY ACTION MOVE.HEAD.FAST dir_x dir_y
	 WAIT MOTION_ALL
     IF dir_x > 0 THEN
         RND dir_x -90 -10
     ELSE
         RND dir_x 10 90
     ENDIF
     LET ticks_x 0
  ENDIF
  IF ticks_y > 5 THEN
     PLAY ACTION MOVE.HEAD.FAST dir_x dir_y
	 WAIT MOTION_ALL
     IF dir_y > 0 THEN
         RND dir_y -40 -5
         SET Horn_B 1
     ELSE
         RND dir_y 5 60
         SET Horn_B 0
     ENDIF
     LET ticks_y 0
  ENDIF
  WAIT 50 // a bit faster
 WEND
RETURN


////////////////////////////////////////////////////////////////
// Audio helpers
//  start random performance (no WAIT)

:StartRandomBabble
  GLOBAL randBabble
  LOCAL r
  DO
    RND r 1 7
  LOOP UNTIL r <> randBabble
  SET randBabble r
  SWITCH:r
    CASE 1:PLAY ACTION+ S_BAB1
    CASE 2:PLAY ACTION+ S_BAB2
    CASE 3:PLAY ACTION+ S_BAB3
    CASE 4:PLAY ACTION+ S_BAB4
    CASE 5:PLAY ACTION+ S_BAB5
    CASE 6:PLAY ACTION+ S_BAB6
    CASE 7:PLAY ACTION+ S_BAB7
RETURN

:StartRandomGlee
  GLOBAL randGlee
  LOCAL r
  DO
    RND r 1 3
  LOOP UNTIL r <> randGlee
  SET randGlee r
  SWITCH:r
    CASE 1:PLAY ACTION+ S_GLEE1
    CASE 2:PLAY ACTION+ S_GLEE2
    CASE 3:PLAY ACTION+ S_GLEE3
RETURN

:StartRandomLaugh // short laugh
  GLOBAL randLaugh
  LOCAL r
  DO
    RND r 1 3
  LOOP UNTIL r <> randLaugh
  SET randLaugh r
  SWITCH:r
    CASE 1:PLAY ACTION+ S_LAUGH1
    CASE 2:PLAY ACTION+ S_LAUGH2
    CASE 3:PLAY ACTION+ S_LAUGH3
RETURN

/////////////////////////////////////////////////////////////

:DoNiceMood
	LOCAL act
	RND act 1 3
    // audio only
	SWITCH act
		CASE 1:CALL StartRandomBabble
		CASE 2:CALL StartRandomGlee
		CASE 3:CALL StartRandomLaugh
    // no leg movements
	CALL GyrateHeadNice // does waiting
 RETURN

:DoNiceWalkaboutRandom
	LOCAL act
	RND act 1 10

    IF act <> 1 THEN
        RETURN
    ENDIF
	// 1 in 10 chance of simple skits

	RND act 1 3
    IF act == 1 THEN
        PLAY ACTION STAND
        WAIT
		PLAY ACTION WALK 0 200
        WAIT
        PLAY ACTION SIT
        WAIT
    ENDIF
    IF act == 2 THEN
        PLAY ACTION STAND
        WAIT
		PLAY ACTION WALK 180 150 // backwards
        WAIT
        PLAY ACTION SIT
        WAIT
    ENDIF
    IF act == 3 THEN
        PLAY ACTION STAND
        WAIT
		PLAY ACTION WALK 0 100
        WAIT
        WAIT 1000

        PLAY ACTION+ SHIT1
        WAIT
		RND act 1 2
		SWITCH act
            CASE 1:PLAY ACTION+ S_GROSSSQUIRT
		    CASE 2:PLAY ACTION+ S_OLDMAN_GRUNT
		CALL GyrateHeadNice // for either

		PLAY ACTION WALK 0 100
        WAIT
		PLAY ACTION+ S_LAUGH2
		PLAY ACTION WALK 0 50
        WAIT

		PLAY ACTION+ S_LAUGH1
        PLAY ACTION SIT
        WAIT
    ENDIF
    // ELSE - no walking skit
 RETURN

/////////////////////////////////////////////////////////////

:DoCaptainHowdy
	LOCAL act
	RND act 1 10
	SWITCH act
		CASE 1:PLAY ACTION+ X_AMEN
		CASE 2:PLAY ACTION+ X_BRING_TOGETHER
		CASE 3:PLAY ACTION+ X_DAYFOR
		CASE 4:PLAY ACTION+ X_INTIME
		CASE 5:PLAY ACTION+ X_LATIN1
		CASE 6:PLAY ACTION+ X_LATIN2
		CASE 7:PLAY ACTION+ X_LATIN3
		CASE 8:PLAY ACTION+ X_STRAPS1
		CASE 9:PLAY ACTION+ X_STRAPS2
		CASE 10:PLAY ACTION+ X_MOTHER
	CALL GyrateHeadNice
 RETURN

:DoCreepyGross
	LOCAL act
	RND act 1 8
	SWITCH act
		CASE 1:PLAY ACTION+ X_EVILLAUGH1
		CASE 2:PLAY ACTION+ X_PUKE1
		CASE 3:PLAY ACTION+ X_GROWL1
		CASE 4:PLAY ACTION+ X_MISC1
		CASE 5:PLAY ACTION+ X_MISC_SCREAMING
		CASE 6:PLAY ACTION+ X_MOAN1
		CASE 7:PLAY ACTION+ X_VOICES2
		CASE 8:PLAY ACTION+ X_VOICES_LONG
    CALL StartUpsideDownLegSkit
    CALL GyrateHeadEvil
 RETURN

:DoCreepyGrossRude
	LOCAL act
	RND act 1 10
	SWITCH act
		CASE 1:PLAY ACTION+ X_EVILLAUGH1
		CASE 2:PLAY ACTION+ X_PUKE1
		CASE 3:PLAY ACTION+ X_GROWL1
		CASE 4:PLAY ACTION+ X_MISC1
		CASE 5:PLAY ACTION+ X_MISC_SCREAMING
		CASE 6:PLAY ACTION+ X_MOAN1
		CASE 7:PLAY ACTION+ X_VOICES2
		CASE 8:PLAY ACTION+ X_VOICES_LONG
		CASE 9:PLAY ACTION+ X_FUCKME2 // rude
		CASE 10:PLAY ACTION+ X_RUDE1 // rude
    CALL StartUpsideDownLegSkit
    CALL GyrateHeadEvil
 RETURN


:DoIncantation
	LOCAL act
	RND act 1 12
	SWITCH act
		CASE 1:PLAY ACTION+ X_DO_CASTOUT
		CASE 2:PLAY ACTION+ X_DO_CROSS
		CASE 3:PLAY ACTION+ X_DO_DEPART
		CASE 4:PLAY ACTION+ X_DO_GODHIMSELF
		CASE 5:PLAY ACTION+ X_DO_HOLY_LORD
		CASE 6:PLAY ACTION+ X_DO_HOLYWATER
		CASE 7:PLAY ACTION+ X_DO_LORDS_PRAYER
		CASE 8:PLAY ACTION+ X_DO_MAJESTIC
		CASE 9:PLAY ACTION+ X_DO_MISC1
		CASE 10:PLAY ACTION+ X_DO_PARDON
		CASE 11:PLAY ACTION+ X_DO_POWER_CHRIST
		CASE 12:PLAY ACTION+ X_DO_TRINITY
    WAIT // no gyration
 RETURN

:DoIncantationReaction
	LOCAL act
	RND act 1 5
	SWITCH act
		CASE 1:PLAY ACTION+ X_HURT2
		CASE 2:PLAY ACTION+ X_HURT3
		CASE 3:PLAY ACTION+ X_HURT4
		CASE 4:PLAY ACTION+ X_ITBURNS2
		CASE 5:PLAY ACTION+ X_BURNING1
    CALL StartUpsideDownLegSkit
    CALL GyrateHeadEvil
 RETURN

:StartUpsideDownLegSkit
	LOCAL act
	RND act 1 17
	SWITCH act
	  CASE 1:PLAY ACTION+ ONBACK_BRIDGE // shaked
	  CASE 2:PLAY ACTION+ ONBACK_CARE1 // arms in air
	  CASE 3:PLAY ACTION+ ONBACK_FRONT_PAW_PLAY // little play
	  CASE 4:PLAY ACTION+ ONBACK_SPREAD // 
	  CASE 5:PLAY ACTION+ ONBACK_SHAKE // after spread
	  CASE 6:PLAY ACTION+ ONBACK_GIVEPAW
	  CASE 7:PLAY ACTION+ ONBACK_ONESIDE1 // on back
	  CASE 8:PLAY ACTION+ ONBACK_ONESIDE2 // on back
	  CASE 9:PLAY ACTION+ ONBACK_PUNCH2
	  CASE 10:PLAY ACTION+ ONBACK_PUNCH
	  CASE 11:PLAY ACTION+ ONBACK_ROT1
	  CASE 12:PLAY ACTION+ ONBACK_ROT3
	  CASE 13:PLAY ACTION+ ONBACK_SPAZ_PAWS
	  CASE 14:PLAY ACTION+ ONBACK_TRY_ROLL_L // flail
	  CASE 15:PLAY ACTION+ ONBACK_TRY_ROLL_R // flail
	  CASE 16:PLAY ACTION+ ONBACK_GETUP_FASTL
	  CASE 17:PLAY ACTION+ ONBACK_GETUP_FASTR
 RETURN

/////////////////////////////////////////////////////////////
:FlipOver
	LOCAL xaccel
    LOCAL yaccel
    AP_GETACCEL xaccel yaccel
    IF yaccel > 100 THEN
        RETURN  // already on his back
    ENDIF

    PLAY ACTION SIT
    WAIT

	PLAY ACTION+ FLIP_B // over its back
    WAIT

	LOCAL xaccel
    LOCAL yaccel
    AP_GETACCEL xaccel yaccel
    IF yaccel > 100 THEN
        RETURN  // on his back
    ENDIF

	PLAY ACTION+ X_DAYFOR // before retry
    WAIT
    GO FlipOver

/////////////////////////////////////////////////////////////

:RecoverToNormal
	LOCAL xaccel
    LOCAL yaccel

	PLAY ACTION+ FALL_B // most general
    WAIT
    WAIT 500

    AP_GETACCEL xaccel yaccel
    IF yaccel < 100 THEN
        RETURN  // recovered
    ENDIF
	PLAY ACTION X_OLDALTAR // make noise before trying again
        // no wait
	GO RecoverToNormal

RETURN

/////////////////////////////////////////////////////////////
