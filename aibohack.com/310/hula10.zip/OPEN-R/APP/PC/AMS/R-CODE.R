:1000	// Main:START
GO:1002
:1002	// Main:STAND
PLAY:ACTION:STAND
WAIT
SET:Head_ON:0
GO:1004
:1003	// Main:CuteDance
PLAY:ACTION+:Cute
GO:1002
:1004	// Main:VOICE_RECOG
CALL:1008
CASE:1:GO:1003
CASE:2:GO:1005
CASE:3:GO:1006
CASE:4:GO:1007
EXIT
:1005	// Main:HulaDance
PLAY:ACTION+:Hula
GO:1002
:1006	// Main:ElvisDance
PLAY:ACTION+:Elvis
GO:1002
:1007	// Main:HamsterDance
PLAY:ACTION+:hamster
GO:1002
EXIT
:1008	// Check_sensor:ENTRY
GO:1012
:1009	// Check_sensor:Cute
RET:1
:1010	// Check_sensor:VOICE_ID?
WAIT:1
IF_1ST:AU_Voice:=:1:1014
GO:1011
:1011	// Check_sensor:WAIT_1SEC
WAIT:1000
GO:1010
:1012	// Check_sensor:INIT
SET:AU_Voice:0
GO:1010
:1013	// Check_sensor:Hula
RET:2
:1014	// Check_sensor:CuteDance
WAIT:1
IF_1ST:AU_Voice_ID:=:20:1009
GO:1015
:1015	// Check_sensor:Showtime
WAIT:1
IF_1ST:AU_Voice_ID:=:22:1013
GO:1017
:1016	// Check_sensor:UN_RECOGNIZE
PLAY:ACTION:SIT
WAIT
GO:1012
:1017	// Check_sensor:Dance
WAIT:1
IF_1ST:AU_Voice_ID:=:21:1019
GO:1018
:1018	// Check_sensor:Play
WAIT:1
IF_1ST:AU_Voice_ID:=:19:1020
GO:1016
:1019	// Check_sensor:Elvis
RET:3
:1020	// Check_sensor:Hamster
RET:4
EXIT
