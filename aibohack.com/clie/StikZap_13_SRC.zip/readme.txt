StikZap how it works:

http://www.aibohack.com/clie/stikzap.htm

====================================================
Background and Terminology:

GEEK WARNING: lots of geeky terminology to follow.
If you don't understand jargon like "logical" versus "physical" then you
should stop reading here.

The Sony memory stick stores data in 512 byte "physical" pages.
These are organized in blocks.
Typically there are 16 physical pages are in a physical block (8KB).

The memory stick physical blocks start from index 0 and go up to the
maximum physical size of the memory stick (somewhere near 8MB for most sticks)

Physical block number 0 contains low level format information.
Physical block number 2 contains important info for AIBO pink memory sticks (see below)

A few extra physical blocks are reserved to reduce wear-and-tear.

----
The Palm OS organizes a storage device into "logical sectors".
Each logical sector is 512 bytes. Logical sectors start from index 0.

They are also organized into logical blocks. 16 sectors in a block (8KB).

Coincidentally,
The size of a logical sector is the same as a physical page (512 bytes)
The size of a logical block is the same as a physical block (16 pages = 16 sectors = 8KB)

However,
Logical sector #0 is not the same as physical page #0.
Logical block #0 is not the same as physical block #0.


====================================================
Trickery:

The tricky part depends on how the CLIE Palm OS logical blocks are turned into
memory stick physical blocks.

The CLIE memory stick driver has a lookup table from logical blocks to
physical blocks.
There are 16 bits for each logical block (containing the physical block number)

StikZap mucks around with this table for reading and writing.
See source code and comments in source code for more details
(called pwTable in the source code)

BTW: in the ARM version there is another table (called pbTwoBits)
It contains the block state.
It is 2 bits per physical block and tells whether a physical block
is currently used, free, recently freed or special/reserved.
Not implemented for the non-ARM version, but doesn't appear to matter.

====================================================
AIBO specific stuff:

Physical block 0 contains low-level structure of the memory stick.
Physical block 1 is not used.
Physical block 2 contains decryption key information
 for the Aibo pink memory sticks (only the first 2 pages, 1KB)
Physical block 3 is where the logical blocks start.

Physical blocks 0, 1 and 2 are special/reserved and not used by the
 regular Palm operating system

====================================================
How do I port this to my PC stick reader, or other (non-CLIE) PDA ?

Answer: you can't

Read the above.
It works on the CLIE because the memory stick driver is loaded into the
memory of the PDA, and the StikZap program can muck around with the
logical to physical mapping table.

Other devices have the memory stick driver packaged in the stick reader
or adapter. The memory stick protocol and data tables are implemented
in small embedded processors and custom chips on the device itself.
After that PCs or other PDAs see a memory stick as a logical device,
packaged as a generic FAT volume.
The physical level is not directly accessible.

====================================================
Legal notice etc

StikZap does not circumvent the copy protection mechanism of the Sony software.
All copy protection technology remains intact.
There is no "encryption" technology involved.
It is simply a low-level stick reader and writer.

The keys provided in the open source version only include the generic
stick types (PMS and AiboMind 1/2/3).
The release version of the tool has the full database (but only lets you
'zap' the generic stick types). This is intentional to encourage people
to make their own 'fair use' backups for other copyrighted sticks.

====================================================

