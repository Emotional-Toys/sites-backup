// use old style Armlet
// used for access for OS5 Memory Stick library pointer

#include "PACEInterface.h"
#include <size_t.h>
#include <cstddef>

#include "endianutils.h"

//////////////////////////////////////////////////////

#pragma thumb off
#pragma PIC   on
    // must be on to take address of our routines

// for TH/UX/NZ? series
static asm UInt32 _GetPtr_MSLIB_OS5()
{
	ldr r0, [r9]
    ldr	r0, [r0, #896]
	bx lr
}

///////////////////////////////////////////////////////////

static unsigned long MyRun(UInt32* pl)
{
    UInt32 dev = ByteSwap32(pl[0]);

	UInt32* plInternals = (UInt32*)_GetPtr_MSLIB_OS5();
    // all OS5 ARM appear to load it the same place
	pl[0] = ByteSwap32((UInt32)plInternals);

    return 0;
}

//////////////////////////////////////////////////////

extern "C"
unsigned long ARMlet_Main(
	const void *emulStateP, 
	void *userData68KP, 
	Call68KFuncType *call68KFuncP);

unsigned long ARMlet_Main(
	const void *emulStateP, 
	void *userData68KP, 
	Call68KFuncType *call68KFuncP)
{
    return MyRun((UInt32*)userData68KP);
}


//////////////////////////////////////////////////////
