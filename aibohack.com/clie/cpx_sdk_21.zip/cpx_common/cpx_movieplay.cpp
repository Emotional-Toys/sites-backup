#include <PalmOS.h>
#define NULL	0

#include <SonyCLIE.h>
#include <SonySystemResources.h>

/////////////////////////////////////////////////////
// Please see the general ..\README.TXT for build info,
// legal disclaimers etc.
// 
// (c) 2003 CliePet

// WARNING: only change this file if you *REALLY* know what you are doing
// If you do improve this code, please email the improved version to me
//   cliepet@aibohack.com
/////////////////////////////////////////////////////

// NOTE: this file is usually included from other projects

// high level C++ interface
#include "../cpx_common/cpx_movieplay.h"

// interface to Sony libraries
#ifndef _CPX_MMLIB_
#include "../cpx_common/cpx_mmlib.h"
#endif


/////////////////////////////////////////////////////
// Alerts
   // use sparingly, especially with camera preview running

static void CpxAlert(const char* szAlert)
{
    ErrAlertCustom(0, (char*)szAlert, NULL, NULL);
}

static void CpxAlert(const char* szAlert, Err err)
{
    char szT[128];
    StrPrintF(szT, "%s (err=$%x)", szAlert, err);
    CpxAlert(szT);
}

/////////////////////////////////////////////////////

#define CAM_STREAM_TYPE 1
#define PLAY_STREAM_TYPE 0

CpxMoviePlayer::CpxMoviePlayer()
{
    // no virtual functions, just binary data
    MemSet(this, sizeof(CpxMoviePlayer), 0);
}

bool CpxMoviePlayer::Open()
{
    Err errFind;
    errFind = SysLibFind(sonySysLibNameMM, &m_mmLib);
	if (errFind != 0)
    {
		if (errFind != sysErrLibNotFound)
	        return false;
	    if (SysLibLoad(sonySysFileTMMLib, sonySysFileCMMLib, &m_mmLib) != 0)
	        return false;
        m_mmLibLoadedByMe = true;
    }

	// not needed - SysLibOpen(m_mmLib);

    return true; // ok
}

void CpxMoviePlayer::Close()
{
	if (m_session != 0)
    {
		CpxAlert("WARNING: Closing down CpxMoviePlayer with active session");
		MMLib_SessionDelete(m_mmLib, m_session);
    }

	// not needed -- SysLibClose(m_mmLib);
	if (m_mmLibLoadedByMe)
		SysLibRemove(m_mmLib);
}

/////////////////////////////////////////////////////
// Camera

#pragma warn_a5_access on // no globals
static void MyMoviePlayerCallback(const MMLib_Event* event, void* userData) 
{
    // REVIEW: should cleanup in some critical cases
}
#pragma warn_a5_access reset


UInt32 CpxMoviePlayer::GetRecordingStreamID(UInt8 expectedType)
{
    UInt32 iter = 0;
    UInt32 streamID;
    if (MMLib_EnumerateStreams(m_mmLib, m_session, &iter, &streamID) != 0)
        return NULL;

    // 10009 is different than VoiceRec or still camera
    UInt8 bType = 0xFF;
    UInt32 l1 = 0;
    if (MMLib_GetStreamProp(m_mmLib, streamID, 0x10009L, &bType, &l1) != 0)
        return NULL;
#if 0
    if (bType != expectedType)
        return NULL;
#else
    // DEBUG
    if (bType != expectedType)
    {
	    char szT[64];
	    StrPrintF(szT, "type = %d (%d)", bType, expectedType);
	    CpxAlert(szT);
    }
#endif
    return streamID;
}

bool CpxMoviePlayer::StopMoviePlayer()
{
	if (MMLib_SessionUnRegisterCallback(m_mmLib, m_session, MyMoviePlayerCallback, 0) != 0)
        return false;

    if (MMLib_SessionDelete(m_mmLib, m_session) != 0)
        return false;
    m_session = 0;

    return true;
}

/////////////////////////////////////////////////////
// Playback

bool CpxMoviePlayer::PrepareMoviePlayer(
	UInt16 volRef, const char* pathName, int& errno)
{
    errno = PreparePlay2(volRef, pathName);
    return (errno == 0);
}

int CpxMoviePlayer::PreparePlay2(UInt16 volRef, const char* pathName)
{
    if (m_session != 0)
        return __LINE__;

    if (MMLib_SpecialOpen(m_mmLib) != 0)
        return __LINE__;

    if (MMLib_SessionCreate(m_mmLib, &m_session) != 0)
        return __LINE__;

    if (MMLib_SessionRegisterCallback(m_mmLib, m_session, MyMoviePlayerCallback, 0, 0) != 0)
        return __LINE__;

    // add one source (from media)
    char szSrc[256];
    if (volRef == 0xFFFF)
    {
        // storage heap
        StrPrintF(szSrc, "file:///%s?db=sonyfilestream",
            pathName);
    }
    else
    {
        // VFS file
	    StrPrintF(szSrc, "file:///%s?volref=%d",
	        pathName, volRef);
    }

    if (MMLib_AddSource(m_mmLib, m_session, szSrc, 0, 1) != 0)
        return __LINE__;

	if (MMLib_CreateStreams(m_mmLib, m_session, 2000L) != 0)
        return __LINE__;

    UInt32 camID = GetRecordingStreamID(PLAY_STREAM_TYPE);
    if (camID == NULL)
		return __LINE__;

    UInt16 data[4];
    data[0] = data[1] = data[2] = data[3] = 0;
    data[0] = 1000;
    if (MMLib_SetStreamProp(m_mmLib, camID, 0x1000bL, data, 0) != 0)
		return __LINE__;

    data[0] = 0;
    RectangleType rect;
    rect.topLeft.x = 0;
    rect.topLeft.y = 25;
    rect.extent.x = 320;
    rect.extent.y = 240;
    if (MMLib_SetStreamProp(m_mmLib, camID, 0x10006L, &rect, 0) != 0)
        return __LINE__;

    return 0; // ok
}

bool CpxMoviePlayer::SetPlayerRect(RectangleType* rectP)
{
    // rest of PropertyStart
    UInt32 streamID = GetRecordingStreamID(PLAY_STREAM_TYPE);
    if (streamID == NULL)
		return false;

    if (MMLib_SetStreamProp(m_mmLib, streamID, 0x10006L, rectP, 0) != 0)
        return false;

    return true;
}

bool CpxMoviePlayer::StartPlayerPreview()
{
    if (m_session == 0)
        return false;
    UInt32 camID = GetRecordingStreamID(PLAY_STREAM_TYPE);
    if (camID == NULL)
		return false;

    if (MMLib_SessionControl(m_mmLib, m_session, 'rfrs') != 0)
    {
        return false;
    }
    return true;
}


bool CpxMoviePlayer::StartPlayerPlayback()
{
    if (m_session == 0)
        return false;
    UInt32 camID = GetRecordingStreamID(PLAY_STREAM_TYPE);
    if (camID == NULL)
		return false;

    if (MMLib_SessionControl(m_mmLib, m_session, 'srun') != 0)
    {
        return false;
    }
    return true;
}

/////////////////////////////////////////////////////

