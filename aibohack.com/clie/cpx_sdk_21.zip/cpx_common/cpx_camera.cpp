#include <PalmOS.h>
#define NULL	0

#include <SonyCLIE.h>
#include <SonySystemResources.h>

/////////////////////////////////////////////////////
// Please see the general ..\README.TXT for build info,
// legal disclaimers etc.
// 
// (c) 2003-2004 CliePet

// WARNING: only change this file if you *REALLY* know what you are doing
// If you do improve this code, please email the improved version to me
//   cliepet@aibohack.com
/////////////////////////////////////////////////////

// NOTE: this file is usually included from other projects

// high level C++ interface
#include "../cpx_common/cpx_camera.h"

// interface to Sony libraries
#ifndef _CPX_MMLIB_
#include "../cpx_common/cpx_mmlib.h"
#endif

/////////////////////////////////////////////////////
// Alerts
   // use sparingly, especially with camera preview running

static void CpxAlert(const char* szAlert)
{
    ErrAlertCustom(0, (char*)szAlert, NULL, NULL);
}

static void CpxAlert(const char* szAlert, Err err)
{
    char szT[128];
    StrPrintF(szT, "%s (err=$%x)", szAlert, err);
    CpxAlert(szT);
}

/////////////////////////////////////////////////////

CpxCamera::CpxCamera()
{
    // no virtual functions, just binary data
    MemSet(this, sizeof(CpxCamera), 0);
}

bool CpxCamera::Open()
{
    Err errFind;
    errFind = SysLibFind(sonySysLibNameMM, &m_mmLib);
	if (errFind != 0)
    {
		if (errFind != sysErrLibNotFound)
	        return false;
	    if (SysLibLoad(sonySysFileTMMLib, sonySysFileCMMLib, &m_mmLib) != 0)
	        return false;
        m_mmLibLoadedByMe = true;
    }

	// not needed - SysLibOpen(m_mmLib);

#if 0
    // Does this work?
    if (!PurgeBackgroundPending())
        return false;
#endif

    return true; // ok
}

void CpxCamera::Close()
{
	if (m_session != 0)
    {
		CpxAlert("WARNING: Closing down CpxCamera with active session");
		MMLib_SessionDelete(m_mmLib, m_session);
    }

	// not needed -- SysLibClose(m_mmLib);
	if (m_mmLibLoadedByMe)
		SysLibRemove(m_mmLib);
}

/////////////////////////////////////////////////////
// Camera

#pragma warn_a5_access on // no globals
static void MyCamCallback(const MMLib_Event* event, void* userData) 
{
    // REVIEW: should cleanup in some critical cases
#ifdef LATER
	switch (event->eventCode)
    {
	    case mmEvtPrefetchFailed :
		case mmEvtSessionStreamsChanged :
			MMLib_SessionClose(userData->m_mmLib, event->sessionRef);
            break;
    }
#endif
}
#pragma warn_a5_access reset

bool CpxCamera::PrepareCamera(UInt16 formID, int& errno)
{
    errno = PrepareCamera2(formID);
    return (errno == 0);
}

int CpxCamera::PrepareCamera2(UInt16 formID)
{
    if (m_session != 0)
        return __LINE__;

    // MMLibOpen (regular SysLibOpen/Close not used)
    if (MMLib_SpecialOpen(m_mmLib) != 0)
        return __LINE__;

    if (MMLib_SessionCreate(m_mmLib, &m_session) != 0)
        return __LINE__;

    // capture still, preview video
    if (MMLib_AddSource(m_mmLib, m_session, "device:///camera", 6, 3) != 0)
        return __LINE__;

	if (MMLib_SetSessionProp(m_mmLib, m_session, 0x1000AL /*form id*/, &formID, 0) != 0)
        return __LINE__;

    if (MMLib_SessionRegisterCallback(m_mmLib, m_session, MyCamCallback, 0, 0) != 0)
        return __LINE__;

	if (MMLib_CreateStreams(m_mmLib, m_session, 0L) != 0)
        return __LINE__;

    UInt32 streamID = GetRecordingStreamID(3);
    if (streamID == NULL)
		return __LINE__;

    // set defaults
    UInt16 zoom = 100; // optional
    MMLib_SetStreamProp(m_mmLib, streamID, 0x30034L, &zoom, 2);

    UInt8 effect = 0;
    if (MMLib_SetStreamProp(m_mmLib, streamID, 0x30016L, &effect, 1) != 0)
		return __LINE__;
    UInt8 white_bal = 0;
    if (MMLib_SetStreamProp(m_mmLib, streamID, 0x30017L, &white_bal, 1) != 0)
		return __LINE__;
    UInt8 exposure = 2; // 0.0
    if (MMLib_SetStreamProp(m_mmLib, streamID, 0x30012L, &exposure, 1) != 0)
		return __LINE__;

    // parts of PropertyStart
    UInt32 lArg2B = 0; // actually 3 bytes
    if (MMLib_SetStreamProp(m_mmLib, streamID, 0x3002BL /*rot&scale*/, &lArg2B, 0) != 0)
        return __LINE__;

    UInt8 camres = 7; // safe default (320x240)
    if (MMLib_SetStreamProp(m_mmLib, streamID, 0x3002CL /*still size*/, &camres, 0) != 0)
        return __LINE__;

    return 0; // ok
}

bool CpxCamera::SetPreviewRect(RectangleType* rectP)
{
    // rest of PropertyStart
    UInt32 streamID = GetRecordingStreamID(3);
    if (streamID == NULL)
		return false;

    if (MMLib_SetStreamProp(m_mmLib, streamID, 0x10006L /*dest rect*/, rectP, 0) != 0)
        return false;

    return true;
}

UInt32 CpxCamera::GetRecordingStreamID(UInt8 expectedType)
{
    UInt32 iter = 0;
    UInt32 streamID;
    if (MMLib_EnumerateStreams(m_mmLib, m_session, &iter, &streamID) != 0)
        return NULL;

    UInt8 bType = 0xFF;
    UInt32 l1 = 0;
    if (MMLib_GetStreamProp(m_mmLib, streamID, 0x1000CL /*av type*/, &bType, &l1) != 0)
        return NULL;
    if (bType != expectedType)
        return NULL;
    return streamID;
}

/////////////////////////////////////////////////////
// Camera properties

bool CpxCamera::SetCamProperty1(UInt32 prop, UInt8 val)
{
    UInt32 streamID = GetRecordingStreamID(3);
    if (streamID == NULL)
		return false;
    if (MMLib_SetStreamProp(m_mmLib, streamID, prop, &val, 1) != 0)
        return false;
    return true;
}

bool CpxCamera::SetCamProperty2(UInt32 prop, UInt16 val)
{
    UInt32 streamID = GetRecordingStreamID(3);
    if (streamID == NULL)
		return false;
    if (MMLib_SetStreamProp(m_mmLib, streamID, prop, &val, 2) != 0)
        return false;
    return true;
}

bool CpxCamera::SetCamLightNX80(UInt8 bOn)
{
    return (MMLib_SetDeviceProp(m_mmLib, 0L,
        0x30015L, &bOn, 1) == 0);
        // documented as flip-vert
}

/////////////////////////////////////////////////////
// Camera Preview

bool CpxCamera::StartPreview()
{
    if (MMLib_SessionControl(m_mmLib, m_session, 'srun') != 0)
    {
        return false;
    }
    return true;
}

bool CpxCamera::StopPreview()
{
    if (MMLib_SessionControl(m_mmLib, m_session, 'stop') != 0)
    {
        return false;
    }
    return true;
}

/////////////////////////////////////////////////////
// Camera Capture

bool CpxCamera::CaptureToFile(UInt8 camres, UInt32 fileHandle)
{
    UInt32 streamID = GetRecordingStreamID(3);
    if (streamID == NULL)
		return false;

    // camera still size
    if (MMLib_SetStreamProp(m_mmLib, streamID, 0x3002CL /*still size*/, &camres, 0) != 0)
        return false;

    // save to memory stick
    struct LIBF_INFO
    {
        UInt32 tag;
        UInt32 fh;
    } li;

    li.tag = 'libf';
    li.fh = fileHandle;
		// REVIEW_FUTURE: saving to stream (storage heap)
            // is also supported (tag = 'strm')
            // + pointer to some mystery STRM data structure

	if (MMLib_SetSessionProp(m_mmLib, m_session, 0x30006L /*sink dem*/, &li, 8) != 0)
        return false;

    if (MMLib_SessionControl(m_mmLib, m_session, 'sgrb') != 0)
        return false; // common if unsupported format

    return true;
}

bool CpxCamera::StopCamera()
{
	if (MMLib_SessionUnRegisterCallback(m_mmLib, m_session, MyCamCallback, 0) != 0)
        return false;

    if (MMLib_SessionDelete(m_mmLib, m_session) != 0)
        return false;
    m_session = 0;

    return true;
}

/////////////////////////////////////////////////////

