// cpx_sndextn.h
// CliePet Extension
// Adapted SndExtn interface
//  to help make your programs compatible with older CLIE models
// stripped down re-packaging (c) 2003 CliePet
// member and original function names (c) Sony

// Release .01
//  adapted from old SonySndLib.h
//  just the bare essentials for playback

struct Cpx_SndPcmOptionsType
{
	UInt16 amplitude, pan;
	Boolean	interruptible;
	UInt8 reserved;
	UInt32 dwStartMilliSec, dwEndMilliSec;
};

extern UInt32 SndExtn_GetAPIVersion(UInt16 refNum)
	SYS_TRAP(sysLibTrapCustom + 0); // a805
extern Err SndExtn_PlayPcm(UInt16 refNum,
    void* chanPNull, UInt8 cmd1, UInt8* pcmP,
    void* formatNull, Cpx_SndPcmOptionsType* optionsP,
	void* callbacksP, Boolean bNoWaitMustBeFalse)
		SYS_TRAP(sysLibTrapCustom + 2); // a807

extern Err SndExtn_EnableSystemSound(UInt16 refNum, Boolean bOn, SndSysBeepType type)
		SYS_TRAP(sysLibTrapCustom + 7); // a80c


