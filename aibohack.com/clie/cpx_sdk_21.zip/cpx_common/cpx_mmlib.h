// cpx_mmlib.h
// CliePet Extension
// Reverse Engineered MMLib interface
//  to help make your programs compatible with older CLIE models
//  with some cleanup thanks to Sony CLIE Developer support
// (c) 2003-2004 CliePet

// Release 2.01

//////////////////////////////////////////////////////////////////////
// DO NOT USE THIS HEADER DIRECTLY
// Use the CpxCamera/CpxVoiceRecorder helper classes instead
// WARNING: this file includes guesswork!
//////////////////////////////////////////////////////////////////////
// Init

#define _CPX_MMLIB_

// MMLib open/close, but using non-standard trap numbers
extern Err MMLib_SpecialOpen(UInt16 libRefNum)
		SYS_TRAP(0xa828);
extern Err MMLib_SpecialClose(UInt16 libRefNum)
	SYS_TRAP(0xa829);

//////////////////////////////////////////////////////////////////////
// Devices

extern Err MMLib_EnumerateDevices(UInt16 libRefNum,
    UInt8 code, UInt32* p1, UInt32* p2)
		SYS_TRAP(0xa820);

extern Err MMLib_GetDeviceProperty(UInt16 libRefNum,
    UInt32 context, UInt32 flag2,
    void* dataP, UInt32* sizeP)
		SYS_TRAP(0xa822);

extern Err MMLib_SetDeviceProp(UInt16 libRefNum,
    UInt32 zero, UInt32 prop, void* pRet, UInt32 size)
		SYS_TRAP(0xa821);

//////////////////////////////////////////////////////////////////////
// Session control

#define SessionHandle UInt32

extern Err MMLib_GetBackgroundPlay(UInt16 libRefNum, UInt32* iterHandleP, SessionHandle* sessionHandleP)
		SYS_TRAP(0xa80b);	// currently active background session

extern Err MMLib_SessionCreate(UInt16 libRefNum, SessionHandle* pSession)
		SYS_TRAP(0xa809);
extern Err MMLib_SessionDelete(UInt16 libRefNum, SessionHandle session) // formerly SessionClose
	SYS_TRAP(0xa80a);

typedef struct
{
    SessionHandle session;
    UInt32 eventCode;
	void * dataP;
	UInt32 dataSize;
} MMLib_Event;

typedef void (*SessionCallbackProc)(const MMLib_Event* event, void* userdata);

extern Err MMLib_SessionRegisterCallback(UInt16 libRefNum,
    SessionHandle session,
    SessionCallbackProc pfnCallback, UInt32 flags1, UInt16 flags2)
		SYS_TRAP(0xa80c);
extern Err MMLib_SessionUnRegisterCallback(UInt16 libRefNum,
    SessionHandle session, SessionCallbackProc pfnCallback, UInt32 flags) // formerly CloseCallback
	SYS_TRAP(0xa80d);

extern Err MMLib_GetSessionProp(UInt16 libRefNum, SessionHandle session,
    UInt32 code, UInt32* pRet, UInt32* pRet2)
		SYS_TRAP(0xa819);
extern Err MMLib_SetSessionProp(UInt16 libRefNum, SessionHandle session,
    UInt32 prop, void* dataP, UInt32 size)
		SYS_TRAP(0xa818);

//////////////////////////////////////////////////////////////////////
// Source

extern Err MMLib_AddSource(UInt16 libRefNum, SessionHandle session,
    const char* szMicUrl, UInt8 flagval2, UInt8 flagval1)
		SYS_TRAP(0xa810);

//////////////////////////////////////////////////////////////////////
// Destination

typedef union
{
	UInt16 raw_values[32]; // bigger than needed
	struct // more detailed fields - bare minimum
    {
        UInt16 pad[4];
        UInt16 audioCodec;
        UInt8 audioChannelCount;
        UInt8 pad2;
        UInt32 audioBitRate;
        UInt16 videoCodec;
        UInt16 pad3[3];
        UInt32 videoFrameRate;
        UInt16 width, height;
        UInt32 videoBitRate;
    } avfmt; // encoded AV format
} MMLib_Format;

extern Err MMLib_FormatInit(UInt16 libRefNum, UInt8 mmType, MMLib_Format* fmtP)
		SYS_TRAP(0xa81e);
extern Err MMLib_AddDest(UInt16 libRefNum, SessionHandle session,
    const char* name, UInt8 mmType, UInt8 dataFmt, MMLib_Format* fmtP)
		SYS_TRAP(0xa811);

//////////////////////////////////////////////////////////////////////
// Streams

extern Err MMLib_CreateStreams(UInt16 libRefNum, SessionHandle session,
    UInt32 flag)
		SYS_TRAP(0xa813);

extern Err MMLib_EnumerateStreams(UInt16 libRefNum, SessionHandle session,
    UInt32* handle14P, UInt32* streamIdP)
		SYS_TRAP(0xa814);

extern Err MMLib_GetStreamProp(UInt16 libRefNum, UInt32 streamID,
    UInt32 flags1000C, UInt8* retTypeP, UInt32* retAnotherStructureMaybe)
		SYS_TRAP(0xa806);

extern Err MMLib_SetStreamProp(UInt16 libRefNum, UInt32 streamID,
    UInt32 prop, void* dataP, UInt32 size)
		SYS_TRAP(0xa805);       // first custom trap
        
//////////////////////////////////////////////////////////////////////
// Session control

extern Err MMLib_SessionControl(UInt16 libRefNum, SessionHandle session,
    UInt32 control)
		SYS_TRAP(0xa815);
    // mic: 'srun', 'stop' ('paus' may also work)
    // camera: 'srun', 'sgrb'

//////////////////////////////////////////////////////////////////////

#if 0 // NOT_USED
extern Err MMLib_GetSupportedImageSizes(UInt16 libRefNum,
        UInt32 zero, UInt32 prop30016, UInt32* pM4, UInt8* pM5, UInt32* pM10)
    SYS_TRAP(0xa824);
#endif

//////////////////////////////////////////////////////////////////////
// Movie Playback

extern Err MMLib_GetSessionControl(UInt16 libRefNum, SessionHandle session,
    UInt32* controlP)
		SYS_TRAP(0xa817);

extern Err MMLib_Trap16(UInt16 libRefNum, SessionHandle session,
    UInt32 lVal, UInt8 bVal)
		SYS_TRAP(0xa816);

//////////////////////////////////////////////////////////////////////

