#include <PalmOS.h>
#define NULL	0

#include <SonyCLIE.h>
#include <SonySystemResources.h>

/////////////////////////////////////////////////////
// Please see the general ..\README.TXT for build info,
// legal disclaimers etc.
// (c) 2003-2004 CliePet

// WARNING: only change this file if you *REALLY* know what you are doing
// If you do improve this code, please email the improved version to me
//   cliepet@aibohack.com
/////////////////////////////////////////////////////

// NOTE: this file is usually included from other projects

// high level C++ interface
#include "../cpx_common/cpx_voicerec.h"

// interface to Sony libraries
#ifndef _CPX_MMLIB_
#include "../cpx_common/cpx_mmlib.h"
#endif
#include "../cpx_common/cpx_sndextn.h"

/////////////////////////////////////////////////////
// Alerts
   // use sparingly, especially with camera preview running

static void CpxAlert(const char* szAlert)
{
    ErrAlertCustom(0, (char*)szAlert, NULL, NULL);
}

static void CpxAlert(const char* szAlert, Err err)
{
    char szT[128];
    StrPrintF(szT, "%s (err=$%x)", szAlert, err);
    CpxAlert(szT);
}

/////////////////////////////////////////////////////

CpxVoiceRecorder::CpxVoiceRecorder()
{
    // no virtual functions, just binary data
    MemSet(this, sizeof(CpxVoiceRecorder), 0);
}

bool CpxVoiceRecorder::Open()
{
    Err errFind;

#if 0
// MX test version
#undef sonySysLibNameMM
#define sonySysLibNameMM "Sony MX Library"
#undef sonySysFileCMMLib
#define sonySysFileCMMLib 'APxx'
    CpxAlert("MX");
#endif

    errFind = SysLibFind(sonySysLibNameMM, &m_mmLib);
	if (errFind != 0)
    {
		if (errFind != sysErrLibNotFound)
	        return false;
	    if (SysLibLoad(sonySysFileTMMLib, sonySysFileCMMLib, &m_mmLib) != 0)
	        return false;
        m_mmLibLoadedByMe = true;
    }

	// not needed - SysLibOpen(m_mmLib);

    // SndExtn
    errFind = SysLibFind(sonySysLibNameSound, &m_sndLib);
	if (errFind != 0)
    {
		if (errFind != sysErrLibNotFound)
	        return false;
	    if (SysLibLoad(sonySysFileTSoundLib,
		  sonySysFileCSoundLib, &m_sndLib) != 0)
	        return false;
        m_sndLibLoadedByMe = true;
    }
	if (SysLibOpen(m_sndLib) != 0)
        return false;

    if (SndExtn_GetAPIVersion(m_sndLib) != 2)
        return false;

    return true;   // ok
}

void CpxVoiceRecorder::Close()
{
	if (m_session != 0)
    {
		CpxAlert("WARNING: Closing down CpxVoiceRecorder with active session");
		MMLib_SessionDelete(m_mmLib, m_session);
    }

    // final shutdown
	SysLibClose(m_sndLib);
	if (m_sndLibLoadedByMe)
		SysLibRemove(m_sndLib);

	// not needed -- SysLibClose(m_mmLib);
	if (m_mmLibLoadedByMe)
		SysLibRemove(m_mmLib);
}

/////////////////////////////////////////////////////
// Voice Recording

#pragma warn_a5_access on // no globals
static void MyVoiceCallback(const MMLib_Event* event, void* userData) 
{
    // REVIEW: should cleanup in some critical cases
}
#pragma warn_a5_access reset

bool CpxVoiceRecorder::PrepareForRecording(const char* szStream, UInt32 rate, UInt8 micSens, int& errno)
{
    errno = PrepareForRecording2(szStream, rate, micSens);
    return (errno == 0);
}

int CpxVoiceRecorder::PrepareForRecording2(const char* szStream, UInt32 rate, UInt8 micSens)
{
    if (m_session != 0)
        return __LINE__; // session already active

    if (MMLib_SpecialOpen(m_mmLib) != 0)
        return __LINE__;

    Err err = MMLib_SessionCreate(m_mmLib, &m_session);
    if (err != 0)
    {
        CpxAlert("SessionCreate", err);
        return __LINE__;
    }

    if (MMLib_SessionRegisterCallback(m_mmLib, m_session, MyVoiceCallback, 0, 0) != 0)
        return __LINE__;

    UInt32 val;

    val = rate; // 11025, 22050 and 44100 work
	if (MMLib_SetSessionProp(m_mmLib, m_session, 0x30019L /*mic sample rate*/, &val, 4) != 0)
        return __LINE__;

    val = 16; // this works (8 or 32 do not)
	if (MMLib_SetSessionProp(m_mmLib, m_session, 0x3001BL /*mic bits*/, &val, 4) != 0)
        return __LINE__;
    val = 1; // this works (0, 2 do not)
	if (MMLib_SetSessionProp(m_mmLib, m_session, 0x3001CL /*channels*/, &val, 4) != 0)
        return __LINE__;

    // audio, no preview
    if (MMLib_AddSource(m_mmLib, m_session, "device:///mic", 2, 1) != 0)
        return __LINE__;

    // Set destination

	MMLib_Format format;
    if (MMLib_FormatInit(m_mmLib, 0x82 /*encoded audio*/, &format) != 0)
        return __LINE__;
    format.avfmt.audioCodec = 0xA11; // ADPCM_IMA (the only WAV format supported)

    // save to stream is supported
    // REVIEW_FUTURE: saving to file is also possible
    char szDest[256];
    StrPrintF(szDest, "file:///%s?db=sonyfilestream", szStream);

#ifdef LATER
    if (use_filename_instead)
	    StrPrintF(szDest, "file:///%s?volref=%d", szFullPath, volRef);
        // szFullPath should start with '/'
#endif

    // audio, 10=WAV format
    if (MMLib_AddDest(m_mmLib, m_session, szDest, 2, 10, &format) != 0)
        return __LINE__;

	if (MMLib_CreateStreams(m_mmLib, m_session, 0L) != 0)
        return __LINE__;

    UInt32 streamID = GetRecordingStreamID(2);
    if (streamID == NULL)
		return __LINE__;

    // set mic sensitivity (byte arg, but size=4)
    if (MMLib_SetStreamProp(m_mmLib, streamID, 0x3001AL /*mic sens*/, &micSens, 4) != 0)
        return __LINE__;

    return 0; // ok
}

UInt32 CpxVoiceRecorder::GetRecordingStreamID(UInt8 expectedType)
{
    UInt32 handle14 = 0;
    UInt32 streamID;
    if (MMLib_EnumerateStreams(m_mmLib, m_session, &handle14, &streamID) != 0)
        return NULL;

    UInt8 bType = 0xFF;
    UInt32 l1 = 0;
    if (MMLib_GetStreamProp(m_mmLib, streamID, 0x1000CL /*av type*/, &bType, &l1) != 0)
        return NULL;
    if (bType != expectedType)
        return NULL;
    return streamID;
}

static void DoStdBeep(UInt16 msDuration)
{
    SndCommandType sc;
    sc.cmd = sndCmdFreqDurationAmp;
    sc.param1 = 1600;
    sc.param2 = msDuration;
    sc.param3 = 21;
	if (SndDoCmd(NULL, &sc, false) != 0)
        CpxAlert("SndDoCmd returned error");
}


bool CpxVoiceRecorder::StartRecording(bool bStdBeep)
{
    if (bStdBeep)
	    DoStdBeep(50);

    if (MMLib_SessionControl(m_mmLib, m_session, 'srun') != 0)
        return false;
    return true;
}

UInt32 CpxVoiceRecorder::GetRecordingTime()
{
    UInt32 recTime;
    if (MMLib_GetSessionProp(m_mmLib, m_session, 0x10003L /*cur time*/, &recTime, NULL) != 0)
        return 0;
    return recTime;
}

bool CpxVoiceRecorder::StopRecording(bool bStdBeep)
{
    if (m_session == 0)
        return false;

    // don't stop until at least 1 second recorded
    if (GetRecordingTime() < 1000)
    {
        while (GetRecordingTime() < 1200)
            ;
    }

    // paus works for the NZ
    if (MMLib_SessionControl(m_mmLib, m_session, 'paus') != 0)
    {
	    // stop works on the UX
	    if (MMLib_SessionControl(m_mmLib, m_session, 'stop') != 0)
	        CpxAlert("WARNING: did not stop properly");
    }

    bool bOK = true;
	if (MMLib_SessionUnRegisterCallback(m_mmLib, m_session, MyVoiceCallback, 0) != 0)
    {
        CpxAlert("ERROR: close callback failed");
        bOK = false;
    }

    if (MMLib_SessionDelete(m_mmLib, m_session) != 0)
    {
        CpxAlert("ERROR: close session failed\n"
            "(soft reset recommended)");
        bOK = false;
    }

    Err err = MMLib_SpecialClose(m_mmLib);

#if 0
    if (err != 0)
        CpxAlert("FinishUp failed", err);
#endif

    if (bStdBeep)
	    DoStdBeep(300);

    m_session = 0;
    return bOK;
}

/////////////////////////////////////////////////////
// Audio Playback

bool CpxVoiceRecorder::PlayWave(const UInt8* pbWave, UInt16 amplitude)
{
	Cpx_SndPcmOptionsType options;
	options.amplitude = amplitude;
//REVIEW: test this
	options.pan = 0;
	options.interruptible = false;  // safe default
	options.dwStartMilliSec = 0;
	options.dwEndMilliSec = 0xFFFFFFFFL;

    if (SndExtn_PlayPcm(m_sndLib, NULL, 1 /*play*/,
      (UInt8*)pbWave, NULL, &options, NULL, false) != 0)
        return false;

    return true;
}

void CpxVoiceRecorder::EnableSystemSounds(bool bOn)
{
    for (int i = 1; i < 7; i++)
        SndExtn_EnableSystemSound(m_sndLib, bOn, (SndSysBeepType)i);
}

/////////////////////////////////////////////////////
