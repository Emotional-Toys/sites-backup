
/////////////////////////////////////////////////////

//REVIEW_TODO: test amplitude on PlayWave

class CpxVoiceRecorder
{
public:

 //////////////////////////////////////////////////////
 // General

    CpxVoiceRecorder();

    bool Open();
    void Close();

 //////////////////////////////////////////////////////
 // Audio Playback (SndExtn)
	bool PlayWave(const UInt8* pbWave, UInt16 amplitude);
    void EnableSystemSounds(bool bOn);

 //////////////////////////////////////////////////////
 // Voice/Audio Recording (MMLib)
 // NOTE: currently very unreliable !!!!
    bool PrepareForRecording(const char* dbStreamName,
        UInt32 rate, UInt8 micSens, int& errno);
        // dbStreamName = name of stream to create
            // NOTE: not a filename
        // rate = sampling rate
            // 11025, 22050 and 44100 supported
        // micSens for UX only
            // 0 high, 1 low
            // use 0 for all other devices

    bool StartRecording(bool bStdBeep);
        // your program can do other things while
        // recording is going on
    bool StopRecording(bool bStdBeep);


 //////////////////////////////////////////////////////
 // Implementation follows

protected:
	UInt32 GetRecordingStreamID(UInt8 expectedType);
	bool PurgeBackgroundPending();
    int PrepareForRecording2(const char* szStream,
        UInt32 rate, UInt8 micSens);

	UInt32 GetRecordingTime();

    // MMLib library
	UInt16 m_mmLib;
	bool m_mmLibLoadedByMe;
    // SndExtn library
	UInt16 m_sndLib;
	bool m_sndLibLoadedByMe;

    // currently active session
    UInt32 m_session; // SessionHandle
};

/////////////////////////////////////////////////////
