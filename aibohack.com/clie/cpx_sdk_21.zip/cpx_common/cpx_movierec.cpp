#include <PalmOS.h>
#define NULL	0

#include <SonyCLIE.h>
#include <SonySystemResources.h>

/////////////////////////////////////////////////////
// Please see the general ..\README.TXT for build info,
// legal disclaimers etc.
// 
// (c) 2003 CliePet

// WARNING: only change this file if you *REALLY* know what you are doing
// If you do improve this code, please email the improved version to me
//   cliepet@aibohack.com
/////////////////////////////////////////////////////

// NOTE: this file is usually included from other projects

// high level C++ interface
#include "../cpx_common/cpx_movierec.h"

// interface to Sony libraries
#ifndef _CPX_MMLIB_
#include "../cpx_common/cpx_mmlib.h"
#endif


/////////////////////////////////////////////////////
// Alerts
   // use sparingly, especially with camera preview running

static void CpxAlert(const char* szAlert)
{
    ErrAlertCustom(0, (char*)szAlert, NULL, NULL);
}

static void CpxAlert(const char* szAlert, Err err)
{
    char szT[128];
    StrPrintF(szT, "%s (err=$%x)", szAlert, err);
    CpxAlert(szT);
}

/////////////////////////////////////////////////////

#define CAM_STREAM_TYPE 1
#define MIC_STREAM_TYPE 2

CpxMovieRecorder::CpxMovieRecorder()
{
    // no virtual functions, just binary data
    MemSet(this, sizeof(CpxMovieRecorder), 0);
}

bool CpxMovieRecorder::Open()
{
    Err errFind;
    errFind = SysLibFind(sonySysLibNameMM, &m_mmLib);
	if (errFind != 0)
    {
		if (errFind != sysErrLibNotFound)
	        return false;
	    if (SysLibLoad(sonySysFileTMMLib, sonySysFileCMMLib, &m_mmLib) != 0)
	        return false;
        m_mmLibLoadedByMe = true;
    }

	// not needed - SysLibOpen(m_mmLib);

#if 0
    // Does this work?
    if (!PurgeBackgroundPending())
        return false;
#endif

    return true; // ok
}

void CpxMovieRecorder::Close()
{
	if (m_session != 0)
    {
		CpxAlert("WARNING: Closing down CpxMovieRecorder with active session");
		MMLib_SessionDelete(m_mmLib, m_session);
    }

	// not needed -- SysLibClose(m_mmLib);
	if (m_mmLibLoadedByMe)
		SysLibRemove(m_mmLib);
}

/////////////////////////////////////////////////////
// Camera

#pragma warn_a5_access on // no globals
static void MyMovieCallback(const MMLib_Event* event, void* userData) 
{
    // REVIEW: should cleanup in some critical cases
}
#pragma warn_a5_access reset

bool CpxMovieRecorder::PrepareMovieRecorder(MovieRecordParams const& params, int& errno)
{
    errno = PrepareRec2(params);
    return (errno == 0);
}

int CpxMovieRecorder::PrepareRec2(MovieRecordParams const& params)
{
    if (m_session != 0)
        return __LINE__;

    if (MMLib_SpecialOpen(m_mmLib) != 0)
        return __LINE__;

    if (MMLib_SessionCreate(m_mmLib, &m_session) != 0)
        return __LINE__;
    if (MMLib_SessionRegisterCallback(m_mmLib, m_session, MyMovieCallback, 0, 0) != 0)
        return __LINE__;

    // add two sources
    if (MMLib_AddSource(m_mmLib, m_session, "device:///camera", 3, 3) != 0)
        return __LINE__;

    UInt16 formID = params.formID;
	if (MMLib_SetSessionProp(m_mmLib, m_session, 0x1000AL, &formID, 0) != 0)
        return __LINE__;
    if (MMLib_AddSource(m_mmLib, m_session, "device:///mic", 2, 2) != 0)
        return __LINE__;

    // Set destination
    MMLib_Format dest;
    if (MMLib_FormatInit(m_mmLib, 0x84 /*encoded audio+video*/, &dest) != 0)
        return __LINE__;
    dest.avfmt.audioCodec = 0x300; // MPEG4 AAC
    dest.avfmt.audioChannelCount = 1;
    dest.avfmt.videoCodec = 0x300; // MPEG4, Profile0
    dest.avfmt.audioBitRate = 32000;
    dest.avfmt.videoBitRate = (long)params.vidRate * 1000;

#ifdef MOVIE_EXTRA
    // experimental features
	dest.avfmt.audioCodec = params.audioCodec;
	dest.avfmt.audioChannelCount = params.audioChannelCount;
	dest.avfmt.audioBitRate = params.audioBitRate;
	dest.avfmt.videoCodec = params.videoCodec;
    if (params.videoFrameRate != 0)
		dest.avfmt.videoFrameRate = params.videoFrameRate;
    if (params.width != 0)
		dest.avfmt.width = params.width;
    if (params.height != 0)
		dest.avfmt.height = params.height;
#endif

    char szDest[256];
    if (params.volRef == 0xFFFF)
    {
        // storage heap
        StrPrintF(szDest, "file:///%s?db=sonyfilestream",
            params.pathName);
    }
    else
    {
        // VFS file
	    StrPrintF(szDest, "file:///%s?volref=%d",
	        params.pathName, params.volRef);
    }

    // capture audio+video, quicktime codec
    if (MMLib_AddDest(m_mmLib, m_session, szDest, 4, 8, &dest) != 0)
        return __LINE__;

#if 0
    UInt32 val = 15000; // 15 sec ?
    if (MMLib_SetSessionProp(m_mmLib, m_session, 0x30005L /*dest limit time*/, &val, 4) != 0)
		return __LINE__;
#endif

//REVIEW: ?? 
    // set frame rate (for UX)
    UInt8 framerate = 1;
            // 1 for 256+32
            // 2 for 192+32 or 96+32
    m_bOlder = true;
    if (MMLib_SetSessionProp(m_mmLib, m_session, 0x30012L, &framerate, 0) != 0)
        m_bOlder = true;
    if (MMLib_SetSessionProp(m_mmLib, m_session, 0x30014L, &framerate, 0) != 0)
        m_bOlder = true;

	if (MMLib_CreateStreams(m_mmLib, m_session, 0L) != 0)
        return __LINE__;

    UInt32 camID = GetRecordingStreamID(CAM_STREAM_TYPE);
    if (camID == NULL)
		return __LINE__;

    if (MMLib_SetStreamProp(m_mmLib, camID, 0x1000BL, &formID, 0) != 0)
		return __LINE__;

    struct { Int16 rot; UInt8 scale; } rotscale;
    rotscale.rot = 0;
    rotscale.scale = 1; // double (REVIEW)
    if (MMLib_SetStreamProp(m_mmLib, camID, 0x3002BL /*set rot&scale*/, &rotscale, 0) != 0)
        return __LINE__;

    RectangleType rect;
    rect.topLeft.x = 0;
    rect.topLeft.y = 25;
    rect.extent.x = 320;
    rect.extent.y = 240;
    if (MMLib_SetStreamProp(m_mmLib, camID, 0x10006L /*set dest rect*/, &rect, 0) != 0)
        return __LINE__;

    // set defaults
    UInt8 effect = 0;
    if (MMLib_SetStreamProp(m_mmLib, camID, 0x30016L, &effect, 1) != 0)
		return __LINE__;
    UInt8 white_bal = 0;
    if (MMLib_SetStreamProp(m_mmLib, camID, 0x30017L, &white_bal, 1) != 0)
		return __LINE__;
    UInt8 exposure = 2; // 0.0
    if (MMLib_SetStreamProp(m_mmLib, camID, 0x30012L, &exposure, 1) != 0)
		return __LINE__;

    UInt16 zoom = 100; // optional
    MMLib_SetStreamProp(m_mmLib, camID, 0x30034L, &zoom, 0);

#ifdef LATER
    UInt32 micID = GetRecordingStreamID(MIC_STREAM_TYPE);
    if (micID == NULL)
		return __LINE__;
    UInt8 micSens = 0;  // high
    if (MMLib_SetStreamProp(m_mmLib, micID, 0x3001AL, &micSens, 0) != 0)
        return __LINE__;
#endif

    return 0; // ok
}

bool CpxMovieRecorder::SetPreviewRect(RectangleType* rectP)
{
    // rest of PropertyStart
    UInt32 streamID = GetRecordingStreamID(CAM_STREAM_TYPE);
    if (streamID == NULL)
		return false;

    if (MMLib_SetStreamProp(m_mmLib, streamID, 0x10006L, rectP, 0) != 0)
        return false;

    return true;
}

UInt32 CpxMovieRecorder::GetRecordingStreamID(UInt8 expectedType)
{
    UInt32 iter = 0;
    UInt32 streamID;
    if (MMLib_EnumerateStreams(m_mmLib, m_session, &iter, &streamID) != 0)
        return NULL;

    // REVIEW: dubious test - 0x1000C = avtype, 0x10009 = preview mode
    UInt8 bType = 0xFF;
    UInt32 l1 = 0;
    if (MMLib_GetStreamProp(m_mmLib, streamID, 0x10009L /*type*/, &bType, &l1) != 0)
        return NULL;
    if (bType != expectedType)
        return NULL;
    return streamID;
}

/////////////////////////////////////////////////////
// Camera properties

bool CpxMovieRecorder::SetCamProperty1(UInt32 prop, UInt8 val)
{
    UInt32 streamID = GetRecordingStreamID(CAM_STREAM_TYPE);
    if (streamID == NULL)
		return false;
    if (MMLib_SetStreamProp(m_mmLib, streamID, prop, &val, 1) != 0)
        return false;
    return true;
}

bool CpxMovieRecorder::SetCamProperty2(UInt32 prop, UInt16 val)
{
    UInt32 streamID = GetRecordingStreamID(CAM_STREAM_TYPE);
    if (streamID == NULL)
		return false;
    if (MMLib_SetStreamProp(m_mmLib, streamID, prop, &val, 2) != 0)
        return false;
    return true;
}

bool CpxMovieRecorder::SetCamLightNX80(UInt8 bOn)
{
    return (MMLib_SetDeviceProp(m_mmLib, 0L,
        0x30015L, &bOn, 1) == 0);
}

/////////////////////////////////////////////////////
// Camera Preview

bool CpxMovieRecorder::StartPreview()
{
    if (MMLib_SessionControl(m_mmLib, m_session, 'prun') != 0)
        return false;
    return true;
}

bool CpxMovieRecorder::StopPreview()
{
    if (MMLib_SessionControl(m_mmLib, m_session, 'stop') != 0)
        return false;
    return true;
}

/////////////////////////////////////////////////////
// Movie Capture

bool CpxMovieRecorder::StartRecording()
{
    UInt32 val = 3000; // ? REVIEW
    if (MMLib_SetSessionProp(m_mmLib, m_session, 0x30005L /*dest time limit*/, &val, 4) != 0)
		return false;

    if (MMLib_SessionControl(m_mmLib, m_session, 'srun') != 0)
        return false;
    return true;
}

Int32 CpxMovieRecorder::GetRecordingTime()
{
    UInt32 recTime;
    if (MMLib_GetSessionProp(m_mmLib, m_session,
      0x10003L, &recTime, NULL) != 0)
        return -1;
    return (Int32)recTime;
}

bool CpxMovieRecorder::StopRecording()
{
    if (MMLib_SessionControl(m_mmLib, m_session, 'stop') != 0)
        return false;
    return true;
}

/////////////////////////////////////////////////////

bool CpxMovieRecorder::StopMovieRecorder()
{
	if (MMLib_SessionUnRegisterCallback(m_mmLib, m_session, MyMovieCallback, 0) != 0)
        return false;

    if (MMLib_SessionDelete(m_mmLib, m_session) != 0)
        return false;
    m_session = 0;

    return true;
}

/////////////////////////////////////////////////////

