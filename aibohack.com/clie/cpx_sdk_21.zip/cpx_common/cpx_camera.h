
/////////////////////////////////////////////////////
// NX70V/NX73/NX80/UX Camera modes

enum CamResEnum
{
    CamRes_160x120 = 3, // for the UX and NX7x

		// common for UX, NX70/73 and NX80
    CamRes_320x240 = 7,
    CamRes_320x480 = 8,
    CamRes_640x480 = 10,

    CamRes_1280x960 = 13 // for the NX80 only
    
	// NZ90 modes not supported [camera is too weird]
};


/////////////////////////////////////////////////////

class CpxCamera
{
public:

 //////////////////////////////////////////////////////
 // General

    CpxCamera();

    bool Open();
    void Close();

 //////////////////////////////////////////////////////
 // General Camera (MMLib)

    bool PrepareCamera(UInt16 formID, int& errno);
    bool StopCamera();

 // Camera Preview
	bool SetPreviewRect(RectangleType* rectP);
        // can call later to move the rectangle
    bool StartPreview();
    bool StopPreview(); // and can be restarted later

 // Camera Still Capture
    bool CaptureToFile(UInt8 camres, UInt32 fileHandle);
        // fileHandle is for a file created on a VFS volume
        // saving to the storage heap is not (yet) supported

 // Camera Properties
    // standard
    bool SetExposure(UInt8 exposure)
            { return SetCamProperty1(0x30012L, exposure); }
        // 2 = default (0=-2.0, 1=-1.0, 3=+1.0, 4=+2.0)

    bool SetEffect(UInt8 effect)
            { return SetCamProperty1(0x30016L, effect); }
    bool SetWhiteBalance(UInt8 wb)
            { return SetCamProperty1(0x30017L, wb); }

    // not-standard (not supported by all cameras)
    bool SetZoomUX(UInt16 zoom)
            { return SetCamProperty2(0x30034L, zoom); }
    bool SetZoomNX70(UInt16 zoom)
            { return SetCamProperty2(0x30018L, zoom); }
            // only partly tested
            // REVIEW someone with an NX70
                //  needs to do some experimentation

    bool SetCamLightNX80(UInt8 bOn);


 //////////////////////////////////////////////////////
 // Implementation follows

protected:
    int PrepareCamera2(UInt16 formID);   // return errno
	UInt32 GetRecordingStreamID(UInt8 expectedType);

    bool SetCamProperty1(UInt32 prop, UInt8 val);
    bool SetCamProperty2(UInt32 prop, UInt16 val);

    // MMLib library
	UInt16 m_mmLib;
	bool m_mmLibLoadedByMe;

    // currently active session
    UInt32 m_session; // SessionHandle
};

/////////////////////////////////////////////////////
