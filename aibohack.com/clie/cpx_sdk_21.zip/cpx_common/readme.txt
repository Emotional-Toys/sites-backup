CPX Helpers - SDK release 2.1

See the general ..\README.TXT for build info, legal disclaimers etc.

Files:

api.txt - API documentation (minimal)
cpx_camera.h, cpx_camera.cpp - camera helper
cpx_voicerec.h, cpx_voicerec.cpp - voice record helper
cpx_movieplay.h, cpx_movieplay.cpp - movie player
cpx_movierec.h, cpx_movierec.cpp - movie recorder

ADVANCED IMPLEMENTATION:
cpx_mmlib.h, cpx_sndextn.h - low level interface to Sony libs


