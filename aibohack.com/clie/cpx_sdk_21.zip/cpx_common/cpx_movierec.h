
/////////////////////////////////////////////////////

struct MovieRecordParams
{
    // user interface for preview
    UInt16 formID;
    // where to store movie
	UInt16 volRef; // if 0xFFFF, then pathName is streamname
    const char* pathName;
    // format
    UInt16 vidRate;  // 96, 192 or 256 (kbps)
        // audio is always 32kbps
#ifdef MOVIE_EXTRA
	UInt16 audioCodec;
	UInt8 audioChannelCount;
	UInt32 audioBitRate;
	UInt16 videoCodec;
	UInt32 videoFrameRate;
	UInt16 width, height;
#endif
};

class CpxMovieRecorder
{
public:

 //////////////////////////////////////////////////////
 // General

    CpxMovieRecorder();

    bool Open();
    void Close();

 //////////////////////////////////////////////////////
 // General Prep for Recording

	bool PrepareMovieRecorder(MovieRecordParams const& params, int& errno);
    bool StopMovieRecorder();

 // Camera Preview
	bool SetPreviewRect(RectangleType* rectP);
        // can call later to move the rectangle
    bool StartPreview();
    bool StopPreview(); // and can be restarted later

 // Movie Recording
    bool StartRecording();
    bool StopRecording();

	Int32 GetRecordingTime();

 // Camera Properties
    // standard
    bool SetExposure(UInt8 exposure)
            { return SetCamProperty1(0x30012L, exposure); }
        // 2 = default (0=-2.0, 1=-1.0, 3=+1.0, 4=+2.0)

    bool SetEffect(UInt8 effect)
            { return SetCamProperty1(0x30016L, effect); }
    bool SetWhiteBalance(UInt8 wb)
            { return SetCamProperty1(0x30017L, wb); }

    // not-standard (not supported by all cameras)
    bool SetZoomUX(UInt16 zoom)
            { return SetCamProperty2(0x30034L, zoom); }
    bool SetCamLightNX80(UInt8 bOn);

    bool HasActiveSession() { return m_session != 0; }

 //////////////////////////////////////////////////////
 // Implementation follows

protected:
	// return errno versions
	int PrepareRec2(MovieRecordParams const& params);
	UInt32 GetRecordingStreamID(UInt8 expectedType);

    bool SetCamProperty1(UInt32 prop, UInt8 val);
    bool SetCamProperty2(UInt32 prop, UInt16 val);

    // MMLib library
	UInt16 m_mmLib;
	bool m_mmLibLoadedByMe;

    // currently active session
    UInt32 m_session; // SessionHandle
    bool m_bOlder; // true for NX/NZ, false for UX
};

/////////////////////////////////////////////////////
