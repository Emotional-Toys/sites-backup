
/////////////////////////////////////////////////////

class CpxMoviePlayer
{
public:

 //////////////////////////////////////////////////////
 // General

    CpxMoviePlayer();

    bool Open();
    void Close();

 //////////////////////////////////////////////////////
 // General Prep for Playing
	bool PrepareMoviePlayer(UInt16 volRef,
            const char* pathName, int& errno);
    bool StopMoviePlayer();

 // Movie Playing
	bool SetPlayerRect(RectangleType* rectP);
    bool StartPlayerPreview();
    bool StartPlayerPlayback();

 //////////////////////////////////////////////////////
 // Implementation follows

protected:
	// return errno versions
	int PreparePlay2(UInt16 volRef, const char* pathName);
	UInt32 GetRecordingStreamID(UInt8 expectedType);

    // MMLib library
	UInt16 m_mmLib;
	bool m_mmLibLoadedByMe;

    // currently active session
    UInt32 m_session; // SessionHandle
};

/////////////////////////////////////////////////////
