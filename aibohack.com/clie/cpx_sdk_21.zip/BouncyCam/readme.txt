BouncyCam 2.1
[no changes in functionality since .5, just updated to newer API]

See the general ..\README.TXT for build info, legal disclaimers etc.

Simple sample that starts camera in preview mode,
then moves the preview window around the screen.

