#include <PalmOS.h>
#define NULL	0
#include <SonyCLIE.h>
#include <SonySystemResources.h>

#include "resource.h"

///////////////////////////////////

#include "cpx_helper.h"

CpxCamera g_camera;

///////////////////////////////////
// general reporting

#define sprintf StrPrintF

static void Alert(const char* szAlert)
{
    ErrAlertCustom(0, (char*)szAlert, NULL, NULL);
}

/////////////////////////////////////////
// Main record and play

static UInt8 g_effect = 0; // for cycling camera effect

// bouncy game state - just stuck in a bunch of globals

// current bouncy window location and size
static int xBounce = 20;
static int yBounce = 20;
static int cxBounce = 120;
static int cyBounce = 90;

// motion
static int moveDelay = 2; // 100ths of a sec
static int dxBounce = -3;
static int dyBounce = -3;

// pulsating window size
static int pulsate = 2; // pulsate velocity (0 => off)
static int cxPulseMin = 30;
static int cxPulseMax = 200;

// max screen size (updated at init)
static int cxScreenMax = 320;
static int cyScreenMax = 320;

static bool DoAnimateMove()
{
	RectangleType rect;
    rect.topLeft.x = xBounce;
    rect.topLeft.y = yBounce;
    rect.extent.x = cxBounce;
    rect.extent.y = cyBounce;

    if (!g_camera.SetPreviewRect(&rect))
    {
        Alert("Set Preview Rect failed");
        return false;
    }

    // figure out next position to move to
    if (pulsate != 0)
    {
	    cxBounce += pulsate;
	    if (cxBounce > cxPulseMax)
	    {
	    	cxBounce = cxPulseMax;
	    	if (pulsate > 0)
	    	    pulsate = -pulsate;
	  	}
	  	else if (cxBounce < cxPulseMin)
	  	{
	  		cxBounce = cxPulseMin;
	  		if (pulsate < 0)
	    	    pulsate = -pulsate;
	  	}
        // we pulsate the width (cx) and calculate
        //  the height (cy) by a fixed aspect ratio
		cyBounce = cxBounce * 3 / 4;	// 4:3 aspect ratio
    }

    xBounce += dxBounce;
    if (xBounce <= 0)
    {
        xBounce = 0;
        dxBounce = -dxBounce;
    }
    else if (xBounce + cxBounce >= cxScreenMax)
    {
        xBounce = cxScreenMax - cxBounce;
        dxBounce = -dxBounce;
    }

    yBounce += dyBounce;
    if (yBounce <= 0)
    {
        yBounce = 0;
        dyBounce = -dyBounce;
    }
    else if (yBounce + cyBounce >= cyScreenMax)
    {
        yBounce = cyScreenMax - cyBounce;
        dyBounce = -dyBounce;
    }

    return true;
}

static void DoCycleEffect()
{
    g_effect++;
    if (g_effect > 9 || !g_camera.SetEffect(g_effect))
    {
    	// went too far for this camera - back to normal
        g_effect = 0;
	    g_camera.SetEffect(g_effect);
    }
}

static bool BeginAnimate()
{
	int errno;
    if (!g_camera.PrepareCamera(MainForm, errno))
    {
	    char szReport[256];
        sprintf(szReport, "PrepareCamera failed (%d)", errno);
        Alert(szReport);
        return false;
    }
    DoAnimateMove();
    
    if (!g_camera.StartPreview())
    {
        Alert("Start Preview failed");
        return false;
    }
    return true;
}


static void DoCleanup()
{
	if (!g_camera.StopCamera())
		Alert("Stop Camera failed");
}


/////////////////////////////////////////

static bool MainFormDoCommand(UInt16 cmd)
{
    // ID order is assumed
    if (cmd >= cmdBounce0 && cmd <= cmdBounce9)
    {
        dxBounce = dyBounce = (cmd - cmdBounce0);
        return true;
    }
    else if (cmd >= cmdPulsate0 && cmd <= cmdPulsate9)
    {
        pulsate = (cmd - cmdPulsate0);
        return true;
    }

	switch (cmd)
	{
    case cmdSizes0: // small to large
        cxPulseMin = 20;
        cxPulseMax = 320;
        break;
    case cmdSizes1: // small to medium
        cxPulseMin = 20;
        cxPulseMax = 120;
        break;
    case cmdSizes2: // medium to large
        cxPulseMin = 120;
        cxPulseMax = 320;
        break;

    // standard camera settings (like MyCam)
	case cmdZoom1:
		if (!g_camera.SetZoomUX(100))
			Alert("SetZoom not supported");
		break;
	case cmdZoom2:
		if (!g_camera.SetZoomUX(200))
			Alert("SetZoom not supported");
		break;
	case cmdZoom3:
        if (!g_camera.SetZoomUX(300))
			Alert("SetZoom not supported");
		break;

    case cmdWB0:
    case cmdWB1:
    case cmdWB2:
    case cmdWB3:
        if (!g_camera.SetWhiteBalance(cmd - cmdWB0))
			Alert("SetWhiteBalance error");
		break;

	case cmdExposure0:
	case cmdExposure1:
	case cmdExposure2: // normal
	case cmdExposure3:
	case cmdExposure4:
        if (!g_camera.SetExposure(cmd - cmdExposure0))
			Alert("SetExposure error");
        break;

	case cmdEffect0:
	case cmdEffect1:
	case cmdEffect2:
	case cmdEffect3:
	case cmdEffect4:
        if (!g_camera.SetEffect(cmd - cmdEffect0))
			Alert("SetEffect error");
		break;

	case cmdCamLight1:
		if (!g_camera.SetCamLightNX80(1))
			Alert("SetCamLight not supported");
		break;
	case cmdCamLight0:
		if (!g_camera.SetCamLightNX80(0))
			Alert("SetCamLight not supported");
		break;

    default:
        return false;   // not handled
	}
    return true;    // handled
}

static Boolean MainFormHandleEvent(EventType * eventP)
{
    FormType * frmP;
	static WinHandle s_myWindowH = NULL;
    switch (eventP->eType) 
    {
    case menuEvent:
        return MainFormDoCommand(eventP->data.menu.itemID);
        break;

    case ctlSelectEvent:
        // form controls map to menu items
        return MainFormDoCommand(eventP->data.ctlSelect.controlID);
        break;

    case frmOpenEvent:
        frmP = FrmGetActiveForm();
        FrmDrawForm(frmP);
		s_myWindowH = FrmGetWindowHandle(frmP);
	    if (!BeginAnimate())
	        Alert("Failed to animate");
        break;
        
    case frmUpdateEvent:
        break;

    // stop preview if our main window is inactive
    // necessary for menus to be drawn properly when window is bouncing around
	case winExitEvent:
		if (eventP->data.winExit.exitWindow == s_myWindowH)
			g_camera.StopPreview();
        break;

	case winEnterEvent:
		if (eventP->data.winEnter.enterWindow == s_myWindowH)
			g_camera.StartPreview();
        break;

    default:
        return false;   // not handled
    }
	return true; // handled
}

static Boolean AppHandleEvent(EventType * eventP)
{
    UInt16 formId;
    FormType * frmP;

    if (eventP->eType == frmLoadEvent)
    {
        formId = eventP->data.frmLoad.formID;
        frmP = FrmInitForm(formId);
        FrmSetActiveForm(frmP);

        switch (formId)
        {
        case MainForm:
            FrmSetEventHandler(frmP, MainFormHandleEvent);
            break;

        default:
            break;

        }
        return true;
    }
	else if (eventP->eType == penDownEvent)
	{
		// pen touch (before form handler sees it)
        DoCycleEffect();
        return true;
    }
    return false;
}

///////////////////////////////////
// Silk and HiRes helpers

UInt16 g_libSilk = (UInt16)-1;

static void EnableSilk(bool bOn)
{
    if (g_libSilk == (UInt16)-1)
        return;

    // enable resizing for us
	VskSetState(g_libSilk, vskStateEnable, vskResizeHorizontally);
	VskSetState(g_libSilk, vskStateEnable, vskResizeVertically);
    if (bOn)
		VskSetState(g_libSilk, vskStateResize, vskResizeMax);
	else
		VskSetState(g_libSilk, vskStateResize, vskResizeMin);

    // then disable for the user
	VskSetState(g_libSilk, vskStateEnable, vskResizeDisable);
}

static void OpenSilk() // adapted from CLIE SDK docs
{
	Err err = errNone;

	err = SysLibFind(sonySysLibNameSilk, &g_libSilk);
	if (err != 0)
        return; // should already be loaded (don't load it)

	UInt32 vskVersion;
	err = FtrGet(sonySysFtrCreator, sonySysFtrNumVskVersion, &vskVersion);
	if (err != 0)
        return; // need version 2 or greater

	if (VskOpen(g_libSilk) != 0)
        return; // error
    EnableSilk(false); // start off minimized
}


static void CloseSilk()
{
    if (g_libSilk != (UInt16)-1)
	    VskClose(g_libSilk);
}


///////////////////////////////////


UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    if (cmd != sysAppLaunchCmdNormalLaunch)
        return sysErrParamErr;

    if (!g_camera.Open())
    {
        Alert("Helper Open failed");
        return 0;
    }

    OpenSilk(); // before HR init
    EnableSilk(false);

    // switch to hi-res
	UInt32 depth = 16;
	WinScreenMode(winScreenModeSet, NULL, NULL, &depth, NULL);

    short cx, cy;
    WinGetDisplayExtent(&cx, &cy);
    cxScreenMax = cx*2;
    cyScreenMax = cy*2;

    // bring up form
	FrmGotoForm(MainForm);
	
    while (1)
    {
	    EventType event;
	    UInt16 error;

        EvtGetEvent(&event, moveDelay);
        if (event.eType == nilEvent)
			DoAnimateMove();
        else if (SysHandleEvent(&event))
            ;  // handled by the system
        else if (MenuHandleEvent(0, &event, &error))
            ; // handled by menu
        else if (AppHandleEvent(&event))
            ; // handled by general app handler
        else
			FrmDispatchEvent(&event); // last case

        if (event.eType == appStopEvent)
            break;
    }
    DoCleanup();

	FrmCloseAllForms();
	
    CloseSilk();
    g_camera.Close();
		
    return errNone;
}
