#define	MainForm	1001
#define	MainStatusTextLabel	1002

#define Largeicons12and8bitsAppIconFamily         1000
#define Smallicons12and8bitsAppIconFamily         1001

#define MainMenuBar 1001

// ID order is assumed

#define	cmdWB0	2001
#define	cmdWB1	2002
#define	cmdWB2	2003
#define	cmdWB3	2004
#define	cmdEffect0	2005
#define	cmdEffect1	2006
#define	cmdEffect2	2007
#define	cmdEffect3	2008
#define	cmdEffect4	2009
#define	cmdExposure0	2010
#define	cmdExposure1	2011
#define	cmdExposure2	2012
#define	cmdExposure3	2013
#define	cmdExposure4	2014
#define	cmdZoom1 2015
#define	cmdZoom2 2016
#define	cmdZoom3 2017
#define	cmdCamLight1	2018
#define	cmdCamLight0	2019

// ID order is assumed
#define cmdBounce0	3010
#define cmdBounce3	3013
#define cmdBounce6	3016
#define cmdBounce9	3019
#define cmdPulsate0	3020
#define cmdPulsate3	3023
#define cmdPulsate6	3026
#define cmdPulsate9	3029
#define cmdSizes0	3030
#define cmdSizes1	3031
#define cmdSizes2	3032

