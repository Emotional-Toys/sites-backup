MyCam 2.1

See the general ..\README.TXT for build info, legal disclaimers etc.

NOTE: Not meant as a replacement of the CLIECamera app !
This is an experimental/demo program.

The NX80 will capture 1280x960 but not 160x120.
The NX7x and UX will capture at 160x120 but not 1280x960
The NZ90 will not capture at all.

Limited NZ90 support. Preview works, but not image capture.
On the NZ90, the camera settings menus are labelled wrong.

Some camera settings may not work on your model.
All are driven from menus.
The older keyboard commands are no longer supported.

The capture saves a .JPG to the root of the first VFS volume that is found.
The internal media of the UX is intentionally skipped.
The file name starts a "/TEST01.JPG" and gets bumped up from there.
This renumbering is reset to "01" when the program restarts.

Remember this is a test app.
You will want to change the way data is stored for your particular application.
