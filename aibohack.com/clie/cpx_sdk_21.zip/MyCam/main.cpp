// MyCam
// simple camera app with preview (320x240)

#include <PalmOS.h>
#define NULL	0
#include <SonyCLIE.h>
#include <SonySystemResources.h>
#include <VFSMgr.h>
#include <StringMgr.h>

#include "resource.h"

///////////////////////////////////

#include "cpx_helper.h"

CpxCamera g_camera;
    // helper glue, used for camera preview and capture

// preview rectangle drawn on main screen
RectangleType g_previewRect = { 0, 32, 320, 240 };
    // fills most of the screen
    // buttons on the bottom

///////////////////////////////////
// general reporting

static void Alert(const char* szAlert)
{
    ErrAlertCustom(0, (char*)szAlert, NULL, NULL);
}
#define sprintf StrPrintF

/////////////////////////////////////////
// Capture & file saving

static UInt16 FindFirstSaveVolume()
{
    UInt16 volRefNum;
	UInt32 volIterator = expIteratorStart;
    // iterate unt
	while (VFSVolumeEnumerate(&volRefNum, &volIterator) == 0)
    {
		VolumeInfoType vi;
		if (VFSVolumeInfo(volRefNum, &vi) == 0 &&
          vi.mediaType != 'Tffs') // ignore the internal NAND media on the UX50
			return volRefNum; // first memory stick
    }
    return 0; // none
}

static int g_fileNum = 1;
    // not saved, reset to 1 every time test program is run

static void DoCapture(UInt8 camres)
{
	UInt16 volRefNum = FindFirstSaveVolume();
    if (volRefNum == 0)
    {
        Alert("Please insert a memory stick and try again");
        return;
    }

    UInt16 mode = vfsModeWrite | vfsModeCreate | vfsModeTruncate;
    char szPath[64];
    sprintf(szPath, "/TEST%02d.JPG", g_fileNum);

	FileRef fileRef;
	Err err = VFSFileOpen(volRefNum, szPath, mode, &fileRef);
    if (err != 0)
    {
        Alert("File create error");
        return;
    }
	
    if (!g_camera.CaptureToFile(camres, fileRef))
    {
        Alert("Capture failed !\nUnsupported resolution\n or other error");
		VFSFileClose(fileRef);
        return;
    }

	if (VFSFileClose(fileRef) != 0)
    {
        Alert("File close error");
        return;
    }
    // it worked, bump file number
    g_fileNum++;

    FrmCustomAlert(SavedAlert, szPath, NULL, NULL);
}


/////////////////////////////////////////
// Very simple main form user interface

static bool MainFormDoCommand(UInt16 cmd)
{
	switch (cmd)
	{
	case cmdCapture1:
		DoCapture(CamRes_160x120); // .3 Mpixel cam
		break;
	case cmdCapture2:
		DoCapture(CamRes_320x240);
		break;
	case cmdCapture3:
		DoCapture(CamRes_320x480);
		break;
	case cmdCapture4:
		DoCapture(CamRes_640x480);
		break;
	case cmdCapture5:
		DoCapture(CamRes_1280x960); // NX80 only
		break;
	
	case cmdZoom1:
		if (!g_camera.SetZoomUX(100))
			Alert("SetZoom not supported");
		break;
	case cmdZoom2:
		if (!g_camera.SetZoomUX(200))
			Alert("SetZoom not supported");
		break;
	case cmdZoom3:
        if (!g_camera.SetZoomUX(300))
			Alert("SetZoom not supported");
		break;

    case cmdWB0:
    case cmdWB1:
    case cmdWB2:
    case cmdWB3:
        if (!g_camera.SetWhiteBalance(cmd - cmdWB0))
			Alert("SetWhiteBalance error");
		break;

	case cmdExposure0:
	case cmdExposure1:
	case cmdExposure2: // normal
	case cmdExposure3:
	case cmdExposure4:
        if (!g_camera.SetExposure(cmd - cmdExposure0))
			Alert("SetExposure error");
        break;

	case cmdEffect0:
	case cmdEffect1:
	case cmdEffect2:
	case cmdEffect3:
	case cmdEffect4:
        if (!g_camera.SetEffect(cmd - cmdEffect0))
			Alert("SetEffect error");
		break;

	case cmdCamLight1:
		if (!g_camera.SetCamLightNX80(1))
			Alert("SetCamLight not supported");
		break;
	case cmdCamLight0:
		if (!g_camera.SetCamLightNX80(0))
			Alert("SetCamLight not supported");
		break;

    default:
        return false;   // not handled
	}
    return true;    // handled
}

static void StartCameraAndPreview()
{
    // call once main form is visible
	int errno;
    if (g_camera.PrepareCamera(MainForm /*formid*/, errno))
    {
	    g_camera.SetPreviewRect(&g_previewRect);
	    if (!g_camera.StartPreview())
	        Alert("Start Preview failed");
    }
    else
    {
    	char szReport[128];
        sprintf(szReport, "PrepareCamera failed (%d)", errno);
        Alert(szReport);
        Alert("Soft reset and please try again");
    }
}

static Boolean MainFormHandleEvent(EventType * eventP)
{
    Boolean handled = false;
    FormType * frmP;

    switch (eventP->eType) 
    {
    case menuEvent:
        return MainFormDoCommand(eventP->data.menu.itemID);
        break;

    case ctlSelectEvent:
        // form controls map to menu items
        return MainFormDoCommand(eventP->data.ctlSelect.controlID);
        break;

    case frmOpenEvent:
        frmP = FrmGetActiveForm();
        // MainFormInit(frmP);
        FrmDrawForm(frmP);
        StartCameraAndPreview();

        break;
        
    case frmUpdateEvent:
        break;

    default:
        return false;   // not handled
    }

    return true;
}

static Boolean AppHandleEvent(EventType * eventP)
{
    UInt16 formId;
    FormType * frmP;

    if (eventP->eType == frmLoadEvent)
    {
        formId = eventP->data.frmLoad.formID;
        frmP = FrmInitForm(formId);
        FrmSetActiveForm(frmP);

        switch (formId)
        {
        case MainForm:
            FrmSetEventHandler(frmP, MainFormHandleEvent);
            break;

        default:
            break;
        }
        return true;
    }
    return false;
}

/////////////////////////////////////////
// Main app init
// Main form *MUST* be in hires mode
// Silk use is optional.

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    if (cmd != sysAppLaunchCmdNormalLaunch)
        return sysErrParamErr;

    if (!g_camera.Open())
    {
        Alert("Camera Helper Open failed\nSoft reset and please try again");
        return 0;
    }

    // switch to 16 bit (hires mode)
	UInt32 depth = 16;
	WinScreenMode(winScreenModeSet, NULL, NULL, &depth, NULL);

	FrmGotoForm(MainForm);
	    // NOTE: preview enabling after form is up and running

	EventType event;
    do 
    {
		UInt16 error;
		EvtGetEvent(&event, evtWaitForever);
        if (!SysHandleEvent(&event))
	        if (!MenuHandleEvent(0, &event, &error))
		        if (!AppHandleEvent(&event))
					FrmDispatchEvent(&event); // last case
    } while (event.eType != appStopEvent);

	if (!g_camera.StopCamera())
		Alert("Stop Camera failed");

	FrmCloseAllForms();
    g_camera.Close();

    return errNone;
}
