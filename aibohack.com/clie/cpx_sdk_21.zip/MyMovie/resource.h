#define	MainForm	1001
#define	MainStatusTextLabel	1002
#define SavedAlert 1003

#define Largeicons12and8bitsAppIconFamily         1000
#define Smallicons12and8bitsAppIconFamily         1001

#define	cmdPre 1006
#define	cmdCap 1007
#define	cmdStop 1008
#define	cmdPlayPre 1009
#define	cmdPlay 1010

#define MainMenuBar 1001

#define	cmdWB0	2001
#define	cmdWB1	2002
#define	cmdWB2	2003
#define	cmdWB3	2004
#define	cmdEffect0	2005
#define	cmdEffect1	2006
#define	cmdEffect2	2007
#define	cmdEffect3	2008
#define	cmdEffect4	2009
#define	cmdExposure0	2010
#define	cmdExposure1	2011
#define	cmdExposure2	2012
#define	cmdExposure3	2013
#define	cmdExposure4	2014
#define	cmdZoom1 2015
#define	cmdZoom2 2016
#define	cmdZoom3 2017
#define	cmdCamLight1	2018
#define	cmdCamLight0	2019
