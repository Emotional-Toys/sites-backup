#include "../cpx_common/cpx_movieplay.cpp"
