MyMovie 2.1 - Movie recording and playback demo

See the general ..\README.TXT for build info, legal disclaimers etc.

In this example, two separate Cpx helper classes are used.

CpxMovieRecorder and CpxMoviePlayer

The main feature is implemented in 'DoCaptureAndReview'
which captures a video clip, then plays it back.

Movie capture size is hard-coded in the system (160x112)

