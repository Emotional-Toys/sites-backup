// MyMove
// simple movie recorder app

#include <PalmOS.h>
#define NULL	0
#include <SonyCLIE.h>
#include <SonySystemResources.h>
#include <VFSMgr.h>
#include <StringMgr.h>

#include "resource.h"

///////////////////////////////////

#include "cpx_helper.h"

CpxMovieRecorder g_recorder;
    // helper glue, used for camera preview, movie recording
CpxMoviePlayer g_player;
    // helper glue, used for movie playback 

// preview rectangle drawn on main screen
RectangleType g_previewRect = { 0, 25, 320, 240 };
    // fills most of the screen
    // buttons on the bottom

static bool g_bPlaying = false;
    // REVIEW: move into CpxMovie

///////////////////////////////////
// general reporting

static void Alert(const char* szAlert)
{
    ErrAlertCustom(0, (char*)szAlert, NULL, NULL);
}
#define sprintf StrPrintF

/////////////////////////////////////////
// Capture & file saving

static UInt16 FindFirstSaveVolume()
{
    UInt16 volRefNum;
	UInt32 volIterator = expIteratorStart;
    // iterate unt
	while (VFSVolumeEnumerate(&volRefNum, &volIterator) == 0)
    {
		VolumeInfoType vi;
		if (VFSVolumeInfo(volRefNum, &vi) == 0 &&
          vi.mediaType != 'Tffs') // ignore the internal NAND media on the UX50
			return volRefNum; // first memory stick
    }
    return 0; // none
}

static int g_fileNum = 0;

static bool GetMovieFile(UInt16& volRefNum,
    const char*& path)
{
	static char s_path[64];
	volRefNum = FindFirstSaveVolume();
    if (volRefNum == 0)
    {
        Alert("Please insert a memory stick and try again");
        return false;
    }
    sprintf(s_path, "/TEST%02d.MOV", g_fileNum);
    path = s_path;
	return true;
}


static bool RecordPrep()
{
    if (g_recorder.HasActiveSession())
    {
        Alert("Session already active");
        return false;
    }

    g_fileNum++; // bump file number

    UInt16 volRefNum;
    const char* path;
	if (!GetMovieFile(volRefNum, path))
		return false;

	int errno;
	MovieRecordParams params;
	params.formID = MainForm;
	params.volRef = volRefNum;
	params.pathName = path;
	params.vidRate = 96;	// 96Kbps video, 32Kbps audio hard coded
    if (!g_recorder.PrepareMovieRecorder(params, errno))
    {
    	char szReport[128];
        sprintf(szReport, "PrepareMovieRecorder failed (%d)", errno);
        Alert(szReport);
        Alert("Soft reset and please try again");
        return false;
    }

    g_recorder.SetPreviewRect(&g_previewRect); // may not work the first time (see IdleHandler)
    if (!g_recorder.StartPreview())
    {
        Alert("Start Preview failed");
        return false;
    }
    return true;
}

static void DoCaptureAndReview()
{
    if (!g_recorder.HasActiveSession())
    {
        Alert("Session not active");
        return;
    }
    if (g_bPlaying)
    {
        Alert("Still playing");
        return;
    }
    // in recorder preview mode

    if (!g_recorder.StartRecording())
    {
        Alert("Start Recording error");
        return;
    }
    Alert("Recording..."); // wait until OK

    if (!g_recorder.StopRecording())
    {
        Alert("Stop Recording error");
        return;
    }

	if (!g_recorder.StopMovieRecorder())
    {
		Alert("Stop MovieRecorder failed");
        return;
    }

    // kick into play preview mode
    UInt16 volRefNum;
    const char* path;
	if (!GetMovieFile(volRefNum, path))
		return;

	int errno;
    if (!g_player.PrepareMoviePlayer(volRefNum, path, errno))
    {
    	char szReport[128];
        sprintf(szReport, "PrepareMoviePlayer failed (%d)", errno);
        Alert(szReport);
        Alert("Soft reset and please try again");
        return;
    }

    // does this work now ?
    g_player.SetPlayerRect(&g_previewRect);
    if (!g_player.StartPlayerPreview())
    {
        Alert("Start Player Preview failed");
        return;
    }

    g_player.SetPlayerRect(&g_previewRect); // try again
    if (!g_player.StartPlayerPlayback())
    {
        Alert("Start Playback failed");
        return;
    }

    Alert("playing..."); 
    if (!g_player.StartPlayerPlayback())
    {
        Alert("Start Playback failed");
        return;
    }

	if (!g_player.StopMoviePlayer())
    {
		Alert("Stop MoviePlayer failed");
        return;
    }

    if (!RecordPrep())
        return;
    // back to record preview mode
}


/////////////////////////////////////////
// Very simple main form user interface

static bool MainFormDoCommand(UInt16 cmd)
{
	switch (cmd)
	{
	case cmdCap:
		DoCaptureAndReview();
		break;
	
	case cmdZoom1:
		if (!g_recorder.SetZoomUX(100))
			Alert("SetZoom not supported");
		break;
	case cmdZoom2:
		if (!g_recorder.SetZoomUX(200))
			Alert("SetZoom not supported");
		break;
	case cmdZoom3:
        if (!g_recorder.SetZoomUX(300))
			Alert("SetZoom not supported");
		break;

    case cmdWB0:
    case cmdWB1:
    case cmdWB2:
    case cmdWB3:
        if (!g_recorder.SetWhiteBalance(cmd - cmdWB0))
			Alert("SetWhiteBalance error");
		break;

	case cmdExposure0:
	case cmdExposure1:
	case cmdExposure2: // normal
	case cmdExposure3:
	case cmdExposure4:
        if (!g_recorder.SetExposure(cmd - cmdExposure0))
			Alert("SetExposure error");
        break;

	case cmdEffect0:
	case cmdEffect1:
	case cmdEffect2:
	case cmdEffect3:
	case cmdEffect4:
        if (!g_recorder.SetEffect(cmd - cmdEffect0))
			Alert("SetEffect error");
		break;

	case cmdCamLight1:
		if (!g_recorder.SetCamLightNX80(1))
			Alert("SetCamLight not supported");
		break;
	case cmdCamLight0:
		if (!g_recorder.SetCamLightNX80(0))
			Alert("SetCamLight not supported");
		break;

    default:
        return false;   // not handled
	}
    return true;    // handled
}

static Boolean MainFormHandleEvent(EventType * eventP)
{
    Boolean handled = false;
    FormType * frmP;

    switch (eventP->eType) 
    {
    case menuEvent:
        return MainFormDoCommand(eventP->data.menu.itemID);
        break;

    case ctlSelectEvent:
        // form controls map to menu items
        return MainFormDoCommand(eventP->data.ctlSelect.controlID);
        break;

    case frmOpenEvent:
        frmP = FrmGetActiveForm();
        // MainFormInit(frmP);
        FrmDrawForm(frmP);
	    RecordPrep(); // after form is visible
        break;
        
    case frmUpdateEvent:
        break;

    default:
        return false;   // not handled
    }

    return true;
}

static Boolean AppHandleEvent(EventType * eventP)
{
    UInt16 formId;
    FormType * frmP;

    if (eventP->eType == frmLoadEvent)
    {
        formId = eventP->data.frmLoad.formID;
        frmP = FrmInitForm(formId);
        FrmSetActiveForm(frmP);

        switch (formId)
        {
        case MainForm:
            FrmSetEventHandler(frmP, MainFormHandleEvent);
            break;

        default:
            break;

        }
        return true;
    }
    return false;
}

/////////////////////////////////////////
// Main app init
// Main form *MUST* be in hires mode
// Silk use is optional.


UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    if (cmd != sysAppLaunchCmdNormalLaunch)
        return sysErrParamErr;

    if (!g_recorder.Open() || !g_player.Open())
    {
        Alert("Camera Helper Open failed\nSoft reset and please try again");
        return 0;
    }

    // switch to hi res
	UInt32 depth = 16;
	WinScreenMode(winScreenModeSet, NULL, NULL, &depth, NULL);

    // bring up form, do record prep when visible
	FrmGotoForm(MainForm);

	EventType event;
    do 
    {
		UInt16 error;
		EvtGetEvent(&event, evtWaitForever);
        if (!SysHandleEvent(&event))
	        if (!MenuHandleEvent(0, &event, &error))
		        if (!AppHandleEvent(&event))
					FrmDispatchEvent(&event); // last case
    } while (event.eType != appStopEvent);

	g_recorder.StopMovieRecorder();

	FrmCloseAllForms();
    g_player.Close();
    g_recorder.Close();
		
    return errNone;
}
