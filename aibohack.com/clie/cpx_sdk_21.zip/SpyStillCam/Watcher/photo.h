////////////////////////////////////////////////////////////
// photo control


// CLIE camera max preview size
#define CX_FULLIMAGE 320
#define CY_FULLIMAGE 240

#define CB_FULLIMAGE (CX_FULLIMAGE*CY_FULLIMAGE*3)

class CPhotoCtrl : public CWnd
{
public:
	CPhotoCtrl() { m_rgbImage = NULL; m_bImageValid = true; }
	~CPhotoCtrl() { delete [] m_rgbImage; }
	
	void Init(CDialog* pParent, int nIDC);

    BYTE* GetBuffer()
		{ return m_rgbImage; }
    void SetValid(bool bValid)
        { m_bImageValid = bValid; if (bValid) InvalidateRect(NULL); }

protected:
	bool m_bImageValid;
	BYTE* m_rgbImage;

	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
};


////////////////////////////////////////////////////////////
