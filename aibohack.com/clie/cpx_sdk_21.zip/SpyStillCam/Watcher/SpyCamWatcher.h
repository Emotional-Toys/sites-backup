// SpyStillCamWatcher.h
//

////////////////////////////////////////////////////////////
// MFC (Visual C++) application

#define VC_EXTRALEAN
#include <afxwin.h> // core 
#include "resource.h" // main symbols

#include "spycamglue.h" // spy cam LAN
#include "../spy_protocol.h"

////////////////////////////////////////////////////////////
// CMainApp:

class CMainApp : public CWinApp
{
public:
	CMainApp() {}
	virtual BOOL InitInstance();
};

// CMainApp and other globals
// keep state in globals for simplicity

extern CMainApp theApp;

extern SPYCAM_TELEMETRY theSpyCam;

////////////////////////////////////////////////////////////
// UI glue

CDialog* NewSimpleDialog();

////////////////////////////////////////////////////////////
// Customizable

