//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SpyCamWatcher.rc
//
#define IDI_MAIN                        100
#define IDD_MAIN_SIMPLE                 102
#define IDD_NEWURL                      130
#define IDD_CONNECTING                  131
#define IDCONNECT_SMALL                 199
#define IDC_EXIT                        1005
#define IDC_CUSTOM_PHOTO                1011
#define IDC_EDIT1                       1014
#define IDC_EDIT2                       1015
#define IDC_STATUS                      1015
#define IDC_EDIT3                       1016
#define IDC_EDIT4                       1017
#define IDC_GETFRAME                    1038
#define IDC_POLL1FPS                    1039
#define IDC_POLLFAST                    1040
#define IDC_POLLHALFFPS                 1041
#define IDC_WB0                         1042
#define IDC_WB1                         1043
#define IDC_WB2                         1044
#define IDC_WB3                         1045
#define IDC_EFFECT0                     1046
#define IDC_EFFECT1                     1047
#define IDC_EFFECT2                     1048
#define IDC_EFFECT3                     1049
#define IDC_ZOOM1                       1050
#define IDC_ZOOM2                       1051
#define IDC_ZOOM3                       1052
#define IDC_EXP0                        1053
#define IDC_EFFECT4                     1054
#define IDC_EXP1                        1055
#define IDC_EXP2                        1056
#define IDC_QUAL1                       1057
#define IDC_QUAL2                       1058
#define IDC_QUAL3                       1059
#define IDC_EXP3                        1060
#define IDC_EXP4                        1061
#define IDC_CAMLIGHT_OFF                1062
#define IDC_CAMLIGHT_ON                 1063
#define IDC_QUAL4                       1064
#define IDC_QUAL5                       1065

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
