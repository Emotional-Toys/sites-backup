#define BUILD_WINDOWS
    // CLIE as a client not fully supported

////////////////////////////////////////////////////////////
// Basic types

typedef unsigned char       byte;


////////////////////////////////////////////////////////////
// Abstract AIBO socket connection (either Telemetry or RCODE)

class GENERIC_CONNECTION
{
protected:

#ifdef BUILD_CLIE
    Int16 m_hSocket; // NetSocketRef
#else
    unsigned int m_hSocket; // SOCKET
#endif

    bool SimpleConnect(const byte ipAddr[4], int port, char* szErr);
public:
    static bool ParseIPAddrString(byte ipAddr[4], const char* szIPAddr);

	bool Disconnect(); // return false on error
    GENERIC_CONNECTION() { m_hSocket = (unsigned int)~0; } // invalid socket
    ~GENERIC_CONNECTION() { Disconnect(); }

public:
	void PurgeReply();
	void PurgeReplyVerbose(); // for debugging
	bool PurgeOne(byte& bRet);
	bool SendCommandBytes(const byte* pb, int cb);
	bool ReceiveReply(byte* pbReply, int cbReply);

	bool IsConnected() { return m_hSocket != 0xFFFFFFFF; }
		bool IsOpen() { return IsConnected(); } // old name
};

////////////////////////////////////////////////////////////
// Telemetry port is used for getting images

class SPYCAM_TELEMETRY : public GENERIC_CONNECTION
{
public:
    bool Connect(const byte ipAddr[4], char* szErr = 0);
    bool Connect(const char* szIPAddr, char* szErr = 0);


    ////////////////////////////////////////////////////
    // low level access

	bool SendCommandByte(byte bCmd)
        { return SendCommandBytes(&bCmd, 1); }

};

////////////////////////////////////////////////////////////
