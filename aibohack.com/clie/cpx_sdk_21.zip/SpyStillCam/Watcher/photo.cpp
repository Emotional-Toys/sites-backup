// photo.cpp - CPhotoCtrl

#include "SpyCamWatcher.h"
#include "photo.h"

////////////////////////////////////////////////////////////

static void ResizeControl(CWnd* pWnd, int cx, int cy)
{
	CRect rcWindow, rcClient;
	pWnd->GetWindowRect(rcWindow);
	pWnd->GetClientRect(rcClient);
	int dx = cx - rcClient.Width();
	int dy = cy - rcClient.Height();
	pWnd->SetWindowPos(NULL, 0, 0,
		rcWindow.Width() + dx, rcWindow.Height() + dy,
		SWP_NOMOVE | SWP_NOZORDER);
}

////////////////////////////////////////////////////////////
// Photo Control

BEGIN_MESSAGE_MAP(CPhotoCtrl, CWnd)
	//{{AFX_MSG_MAP(CPhotoCtrl)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CPhotoCtrl::Init(CDialog* pParent, int nIDC)
{
	VERIFY(SubclassWindow(::GetDlgItem(pParent->m_hWnd, nIDC)));
	ResizeControl(this, CX_FULLIMAGE, CY_FULLIMAGE);

	m_rgbImage = new BYTE[CB_FULLIMAGE];
	m_bImageValid = false;
}

void CPhotoCtrl::OnPaint()
{
	PAINTSTRUCT ps;
	CDC* pdc = BeginPaint(&ps);
	CRect rc;
	GetClientRect(&rc);

	int cx = CX_FULLIMAGE;
	int cy = CY_FULLIMAGE;

	// photo paint
	rc.left = (rc.Width() - cx) / 2;
	rc.top = (rc.Height() - cy) / 2;
	rc.right = rc.left + cx;
	rc.bottom = rc.top + cy;

	if (!m_bImageValid)
	{
		CBrush br2(RGB(0,0,128));
		pdc->FillRect(&rc, &br2);
	}
	else
	{
		BITMAPINFO bmi;
		memset(&bmi, 0, sizeof(bmi));
		bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmi.bmiHeader.biWidth = cx;
		bmi.bmiHeader.biHeight = cy;	// bottom-up bitmap (from JPEG)
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 24;
		bmi.bmiHeader.biCompression = BI_RGB;
		
		SetDIBitsToDevice(pdc->m_hDC, rc.left, rc.top, cx, cy,
			0, 0, 0, cy, m_rgbImage,
			&bmi, DIB_RGB_COLORS);
	}

	EndPaint(&ps);
}

////////////////////////////////////////////////////////////
