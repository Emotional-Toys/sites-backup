// Simple.cpp - simple user interface
//

#include "SpyCamWatcher.h"
#include "photo.h"		// photo control

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// CSimpleDlg dialog

class CSimpleDlg : public CDialog
{
// Construction
public:
	CSimpleDlg(CWnd* pParent);	// standard constructor

// Implementation
protected:
	HICON m_hIcon;	// icon to draw

	CPhotoCtrl m_photoCtrl;	// photo control

	bool GetAndUpdateImage();
	void SetVidSize(enum VidSize sizeNew);

	// Generated message map functions
	//{{AFX_MSG(CSimpleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnGetframe();
	afx_msg void OnPoll1fps();
	afx_msg void OnWb0();
	afx_msg void OnWb1();
	afx_msg void OnWb2();
	afx_msg void OnWb3();
	afx_msg void OnEffect0();
	afx_msg void OnEffect1();
	afx_msg void OnEffect2();
	afx_msg void OnEffect3();
	afx_msg void OnEffect4();
	afx_msg void OnZoom1();
	afx_msg void OnZoom2();
	afx_msg void OnZoom3();
	afx_msg void OnPollfast();
	afx_msg void OnPollhalffps();
	afx_msg void OnExp0();
	afx_msg void OnExp1();
	afx_msg void OnExp2();
	afx_msg void OnExp3();
	afx_msg void OnExp4();
	afx_msg void OnCamlightOff();
	afx_msg void OnCamlightOn();
	afx_msg void OnQual1();
	afx_msg void OnQual2();
	afx_msg void OnQual3();
	afx_msg void OnQual4();
	afx_msg void OnQual5();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


CSimpleDlg::CSimpleDlg(CWnd* pParent)
	: CDialog(IDD_MAIN_SIMPLE, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDI_MAIN);
}

CDialog* NewSimpleDialog()
{
    return new CSimpleDlg(NULL);
}


BEGIN_MESSAGE_MAP(CSimpleDlg, CDialog)
	//{{AFX_MSG_MAP(CSimpleDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_GETFRAME, OnGetframe)
	ON_BN_CLICKED(IDC_POLL1FPS, OnPoll1fps)
	ON_BN_CLICKED(IDC_WB0, OnWb0)
	ON_BN_CLICKED(IDC_WB1, OnWb1)
	ON_BN_CLICKED(IDC_WB2, OnWb2)
	ON_BN_CLICKED(IDC_WB3, OnWb3)
	ON_BN_CLICKED(IDC_EFFECT0, OnEffect0)
	ON_BN_CLICKED(IDC_EFFECT1, OnEffect1)
	ON_BN_CLICKED(IDC_EFFECT2, OnEffect2)
	ON_BN_CLICKED(IDC_EFFECT3, OnEffect3)
	ON_BN_CLICKED(IDC_EFFECT4, OnEffect4)
	ON_BN_CLICKED(IDC_ZOOM1, OnZoom1)
	ON_BN_CLICKED(IDC_ZOOM2, OnZoom2)
	ON_BN_CLICKED(IDC_ZOOM3, OnZoom3)
	ON_BN_CLICKED(IDC_POLLFAST, OnPollfast)
	ON_BN_CLICKED(IDC_POLLHALFFPS, OnPollhalffps)
	ON_BN_CLICKED(IDC_EXP0, OnExp0)
	ON_BN_CLICKED(IDC_EXP1, OnExp1)
	ON_BN_CLICKED(IDC_EXP2, OnExp2)
	ON_BN_CLICKED(IDC_EXP3, OnExp3)
	ON_BN_CLICKED(IDC_EXP4, OnExp4)
	ON_BN_CLICKED(IDC_CAMLIGHT_OFF, OnCamlightOff)
	ON_BN_CLICKED(IDC_CAMLIGHT_ON, OnCamlightOn)
	ON_BN_CLICKED(IDC_QUAL1, OnQual1)
	ON_BN_CLICKED(IDC_QUAL2, OnQual2)
	ON_BN_CLICKED(IDC_QUAL3, OnQual3)
	ON_BN_CLICKED(IDC_QUAL4, OnQual4)
	ON_BN_CLICKED(IDC_QUAL5, OnQual5)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimpleDlg message handlers


BOOL CSimpleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// User Interface glue

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_photoCtrl.Init(this, IDC_CUSTOM_PHOTO);

	SetTimer(1, 1000, NULL);	// slow to start

	return TRUE;
}

void CSimpleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CSimpleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/////////////////////////////////////////////////////////////////////////////
// User interface Glue

void CSimpleDlg::OnOK() 
{
	// do nothing (make them hit EXIT button)
}

void CSimpleDlg::OnCancel() 
{
	// do nothing (make them hit EXIT button)
}

void CSimpleDlg::OnExit() 
{
	KillTimer(1); // no more interruptions
	EndDialog(IDOK);
}

void CSimpleDlg::OnTimer(UINT nIDEvent) 
{
	static bool bPending = false;
	if (bPending)
		return; // for debugging, allow alerts and prompts

	bPending = true;
	if (!GetAndUpdateImage())
    {
        static int g_errors = 0;
        g_errors++;
        char szT[64];
        sprintf(szT, "%d polling errors", g_errors);
        SetDlgItemText(IDC_STATUS, szT);
    }
	bPending = false;
}

void CSimpleDlg::OnGetframe()	// Manual polling
{
	KillTimer(1);
	if (!GetAndUpdateImage())
		AfxMessageBox("Update problem, please try again");
}

void CSimpleDlg::OnPoll1fps() 
{
	SetTimer(1, 1000, NULL);	// 1fps max
}


void CSimpleDlg::OnPollhalffps() 
{
	SetTimer(1, 2000, NULL);	// .5fps max

}

void CSimpleDlg::OnPollfast() 
{
	SetTimer(1, 100, NULL);	// max 10fps, limited by bandwidth
}

////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
// Protocol specific

// do the actual getting, and JPEG decompress

#include "djpeg_lib/djpeg.h"
#pragma comment(lib, "djpeg_lib/djpeg_lib.lib")


bool CSimpleDlg::GetAndUpdateImage()
{
	theSpyCam.PurgeReply();
	if (!theSpyCam.SendCommandByte(SPYCMD_GETJPG))
	{
	    TRACE("Send vid error\n");
	    return false;
	}
	byte data[MAX_JPEG];	// large data

	// first get length
	WORD cbData;
	if (!theSpyCam.ReceiveReply((BYTE*)&cbData, 2))	// INTEL byte order
	{
		TRACE("Receive jpg size error\n");
		Sleep(100);
		theSpyCam.PurgeReply();
		return false;
	}
	if (cbData <= 10 || cbData > MAX_JPEG)
	{
		TRACE("Receive jpg size error2\n");
		Sleep(100);
		theSpyCam.PurgeReply();
		return false;
	}
	if (!theSpyCam.ReceiveReply(data, cbData))
	{
		TRACE("Receive jpg data error\n");
		Sleep(100);
		theSpyCam.PurgeReply();
		return false;
	}

	// expand JPG to BMP compatible format
	m_photoCtrl.SetValid(false);
	byte* pbImage = m_photoCtrl.GetBuffer();

	if (!do_djpeg_aibo(data, cbData, pbImage))
        TRACE("do_djpeg_aibo error\n");

	m_photoCtrl.SetValid(true);
	return true;
}



////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////

static void SendCamCtl(BYTE bCmd)
{
	if (!theSpyCam.SendCommandByte(bCmd))
        AfxMessageBox("Error sending command to CLIE");
}

void CSimpleDlg::OnWb0() 
{
    SendCamCtl(SPYCMD_SETWB_0);
}

void CSimpleDlg::OnWb1() 
{
    SendCamCtl(SPYCMD_SETWB_1);
}

void CSimpleDlg::OnWb2() 
{
    SendCamCtl(SPYCMD_SETWB_2);
}

void CSimpleDlg::OnWb3() 
{
    SendCamCtl(SPYCMD_SETWB_3);
}

void CSimpleDlg::OnEffect0() 
{
    SendCamCtl(SPYCMD_SETEFFECT_0);
}

void CSimpleDlg::OnEffect1() 
{
    SendCamCtl(SPYCMD_SETEFFECT_1);
}

void CSimpleDlg::OnEffect2() 
{
    SendCamCtl(SPYCMD_SETEFFECT_2);
}

void CSimpleDlg::OnEffect3() 
{
    SendCamCtl(SPYCMD_SETEFFECT_3);
}

void CSimpleDlg::OnEffect4() 
{
    SendCamCtl(SPYCMD_SETEFFECT_4);
}

void CSimpleDlg::OnZoom1() 
{
    SendCamCtl(SPYCMD_SETZOOM_1);
}

void CSimpleDlg::OnZoom2() 
{
    SendCamCtl(SPYCMD_SETZOOM_2);
}

void CSimpleDlg::OnZoom3() 
{
    SendCamCtl(SPYCMD_SETZOOM_3);
}





void CSimpleDlg::OnExp0() 
{
    SendCamCtl(SPYCMD_SETEXP_0);
}

void CSimpleDlg::OnExp1() 
{
    SendCamCtl(SPYCMD_SETEXP_1);
}

void CSimpleDlg::OnExp2() 
{
    SendCamCtl(SPYCMD_SETEXP_2);
}

void CSimpleDlg::OnExp3() 
{
    SendCamCtl(SPYCMD_SETEXP_3);
}

void CSimpleDlg::OnExp4() 
{
    SendCamCtl(SPYCMD_SETEXP_4);
}

void CSimpleDlg::OnCamlightOff() 
{
    SendCamCtl(SPYCMD_SETCAMLIGHT_0);
}

void CSimpleDlg::OnCamlightOn() 
{
    SendCamCtl(SPYCMD_SETCAMLIGHT_1);
}

////////////////////////

// 10, 30, 50, 70, 90

void CSimpleDlg::OnQual1() 
{
	SendCamCtl(SPYCMD_SETQUAL_10);
}

void CSimpleDlg::OnQual2() 
{
	SendCamCtl(SPYCMD_SETQUAL_30);
}

void CSimpleDlg::OnQual3() 
{
	SendCamCtl(SPYCMD_SETQUAL_50);
}

void CSimpleDlg::OnQual4() 
{
	SendCamCtl(SPYCMD_SETQUAL_70);
}

void CSimpleDlg::OnQual5() 
{
	SendCamCtl(SPYCMD_SETQUAL_90);
}

////////////////////////

