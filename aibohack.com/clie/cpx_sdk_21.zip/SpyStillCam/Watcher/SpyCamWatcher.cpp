// SpyCamWatcher.cpp
//

#include "SpyCamWatcher.h"
#include "urldlg.h"		// url helper dialog

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// Globals

CMainApp theApp;

SPYCAM_TELEMETRY theSpyCam;

////////////////////////////////////////////////////////////
// CMainDlg dialog

BOOL CMainApp::InitInstance()
{
	SetRegistryKey("CliePet Example");

	byte ipAddr[4];
	//BLOCK: find ip address	
	{
		// Get last saved IP address
		CString strIP = AfxGetApp()->GetProfileString("Settings", "IPADDR", "");
		if (!GENERIC_CONNECTION::ParseIPAddrString(ipAddr, strIP))
		{
			// default
			ipAddr[0] = 10;
			ipAddr[1] = 0;
			ipAddr[2] = 1;
			ipAddr[3] = 100;
		}

		CUrlDlg askUrlDlg;
		memcpy(askUrlDlg.m_ipAddr, ipAddr, sizeof(ipAddr)); // initial value
        
		int id = askUrlDlg.DoModal();
		if (id != IDOK)
			return FALSE;

		memcpy(ipAddr, askUrlDlg.m_ipAddr, sizeof(ipAddr));	// use this ip address
	}	

	//BLOCK: attempt connection
	{
		CConnectingStatusDlg statusDlg;
		statusDlg.Begin();

		if (!theSpyCam.Connect(ipAddr))
		{
			statusDlg.End();
			AfxMessageBox("Failed to connect to CLIE\n(is SpyCam running on CLIE?)");
			return FALSE;
		}
		TRACE("TELEMETRY socket connected\n");
		statusDlg.End();
	}

	//BLOCK: success - save IP address for later use
	{
		char szIP[64];
		wsprintf(szIP, "%d.%d.%d.%d", ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3]);
		WriteProfileString("Settings", "IPADDR", szIP);
	}

    // pick one of three UI dialogs
	CDialog* pDlg = NewSimpleDialog();
	m_pMainWnd = pDlg;

	pDlg->DoModal();	// runs the main user interface
    delete pDlg;

	// cleanup
	theSpyCam.Disconnect();

	return FALSE;	// done
}

////////////////////////////////////////////////////////////

