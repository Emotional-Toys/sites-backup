// UrlDlg.cpp : implementation file
//

#include "SpyCamWatcher.h"
#include "UrlDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// CUrlDlg dialog


BEGIN_MESSAGE_MAP(CUrlDlg, CDialog)
	//{{AFX_MSG_MAP(CUrlDlg)
	ON_BN_CLICKED(IDCONNECT_SMALL, OnSmall)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



CUrlDlg::CUrlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_NEWURL, pParent)
{
    memset(m_ipAddr, 0, sizeof(m_ipAddr));
}


void CUrlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_ipAddr[0]);
	DDV_MinMaxByte(pDX, m_ipAddr[0], 0, 255);
	DDX_Text(pDX, IDC_EDIT2, m_ipAddr[1]);
	DDV_MinMaxByte(pDX, m_ipAddr[1], 0, 255);
	DDX_Text(pDX, IDC_EDIT3, m_ipAddr[2]);
	DDV_MinMaxByte(pDX, m_ipAddr[2], 0, 255);
	DDX_Text(pDX, IDC_EDIT4, m_ipAddr[3]);
	DDV_MinMaxByte(pDX, m_ipAddr[3], 0, 255);

}


void CUrlDlg::OnSmall() 
{
	EndDialog(IDCONNECT_SMALL);	
}

////////////////////////////////////////////////////////////
// CConnectingStatusDlg dialog

CConnectingStatusDlg::CConnectingStatusDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_CONNECTING, pParent)
{
}

void CConnectingStatusDlg::Begin()
{
	Create(IDD_CONNECTING);
	ShowWindow(SW_SHOW);
	UpdateWindow();
}

void CConnectingStatusDlg::End()
{
	DestroyWindow();
}

////////////////////////////////////////////////////////////

