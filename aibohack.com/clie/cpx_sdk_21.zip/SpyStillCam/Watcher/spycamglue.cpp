#ifndef HEADERS_INCLUDED
#include "SpyCamWatcher.h"
#endif

////////////////////////////////////////////////
// Platform independent routines

bool SPYCAM_TELEMETRY::Connect(const byte ipAddr[4],
    char* szErr)
{
	if (!SimpleConnect(ipAddr, SPY_PORT, szErr))
        return false;

    if (!SendCommandByte(SPYCMD_GETVER))
    {
        Disconnect();
        return false;
    }

    byte bVer;
	if (!ReceiveReply(&bVer, 1))
    {
        if (szErr != NULL)
        	strcpy(szErr, "Bad version reply");
        Disconnect();
        return false;
    }
	const byte bVerExpected = SPY_PROTOCOL_VERSION;
	if (bVer != bVerExpected)
	{
        if (szErr != NULL)
        	strcpy(szErr, "Mismatched version");
        Disconnect();
        return false;
	}
    return true;
}

bool SPYCAM_TELEMETRY::Connect(const char* szIPAddr,
    char* szErr)
{
    byte ipAddr[4];
    return ParseIPAddrString(ipAddr, szIPAddr) &&
        Connect(ipAddr, szErr);
}


//////////////////////////////////////////////////////////////
// BUILD_WINDOWS

#include <winsock.h>
#include <stdio.h> // for sscanf/sprintf

#pragma comment(lib, "wsock32.lib")
#include <assert.h>

///////////////////////////////////////////////////////////

static int g_bInit = false;

static void _cdecl _cleanup()
{
	WSACleanup();
}

bool GENERIC_CONNECTION::SimpleConnect(const byte ipAddr[4], int port,
        char* szErr /* = NULL */)
{
    if (!g_bInit)
    {
		WSADATA wsaData;
        if (WSAStartup(MAKEWORD(1,1), &wsaData) != 0)
        {
		    if (szErr != NULL)
		        strcpy(szErr, "WSAStartup failed");
			return false;
        }
        atexit(_cleanup);
        g_bInit = true;
    }

	// Create a TCP/IP socket that is bound to the server.
	SOCKET hSock;
	if ((hSock = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
    {
	    if (szErr != NULL)
	        strcpy(szErr, "socket alloc failed");
		return false;
    }

	// Fill out the server socket's address information.
	SOCKADDR_IN sinDest;
	sinDest.sin_family = AF_INET;
	sinDest.sin_addr.S_un.S_un_b.s_b1 = ipAddr[0];
    sinDest.sin_addr.S_un.S_un_b.s_b2 = ipAddr[1];
    sinDest.sin_addr.S_un.S_un_b.s_b3 = ipAddr[2];
    sinDest.sin_addr.S_un.S_un_b.s_b4 = ipAddr[3];
	sinDest.sin_port = htons(port);       // Convert to network ordering.
	
	// Establish a connection to the server socket.
	if (connect(hSock, (PSOCKADDR) &sinDest, sizeof(sinDest)) == SOCKET_ERROR) 
	{
        // connect failed - usually when AIBO is not found
		closesocket(hSock);
	    if (szErr != NULL)
	        strcpy(szErr, "connect failed - AIBO not found");
        return false;
	}

    // turn socket into non-blocking
    u_long arg = 1;
    ioctlsocket(hSock, FIONBIO, &arg); // non-blocking

    // connected
    assert(m_hSocket == INVALID_SOCKET);
    m_hSocket = hSock;
	return true;
}

/*static*/ bool GENERIC_CONNECTION::ParseIPAddrString(byte ipAddr[4],
    const char* szIPAddr)
{
    int b1, b2, b3, b4;
    if (sscanf(szIPAddr, "%d.%d.%d.%d", &b1, &b2, &b3, &b4) != 4)
        return false;
    ipAddr[0] = b1;
    ipAddr[1] = b2;
    ipAddr[2] = b3;
    ipAddr[3] = b4;
    return true;
}


bool GENERIC_CONNECTION::Disconnect()
{
    if (m_hSocket != INVALID_SOCKET)
    {
		shutdown(m_hSocket, 0x01);
		shutdown(m_hSocket, 0x00);
		closesocket(m_hSocket);
		m_hSocket = INVALID_SOCKET;
    }
    return true;
}

bool GENERIC_CONNECTION::PurgeOne(byte& bRet)
{
    // socket must be non-blocking
	return (recv(m_hSocket, (char*)&bRet, 1, 0) == 1);
}

void GENERIC_CONNECTION::PurgeReply()
{
    // socket must be non-blocking
	assert(m_hSocket != INVALID_SOCKET);
    byte b;
	while (recv(m_hSocket, (char*)&b, 1, 0) == 1)
        ;  // eat a byte
}

#ifdef TRACE
void GENERIC_CONNECTION::PurgeReplyVerbose()
{
    // socket must be non-blocking
	assert(m_hSocket != INVALID_SOCKET);
    bool bHadSomething = false;
    byte b;
	while (recv(m_hSocket, (char*)&b, 1, 0) == 1)
    {
        // eat a byte (but report it)
        if (!bHadSomething)
            TRACE("FLUSH: ");
        bHadSomething = true;
        TRACE("%02X ", b);
    }
	if (bHadSomething)
		TRACE("\n");
}
#endif

bool GENERIC_CONNECTION::SendCommandBytes(const byte* pb, int cb)
{
	assert(m_hSocket != INVALID_SOCKET);
	if (send(m_hSocket, (LPCSTR)pb, cb, 0) == SOCKET_ERROR) 
        return false;
    return true;
}

///////////////////////////////////////////////////////////

bool GENERIC_CONNECTION::ReceiveReply(byte* pbReply, int cbReply)
{
	assert(m_hSocket != INVALID_SOCKET);

	int nEmpty = 0;
	int cbGot = 0;
	while (cbGot < cbReply)
	{
		int n = recv(m_hSocket,
            (char*)&pbReply[cbGot], cbReply-cbGot, 0);
		if (n > 0)
		{
            // got something
			assert(n <= cbReply - cbGot);
			cbGot += n;
            nEmpty = 0;
		}
		else if (n == 0)
		{
            // socket has been closed
            return false;
        }
        else
        {
            assert(n == SOCKET_ERROR);
            int err = WSAGetLastError();
			if (err != WSAEWOULDBLOCK)
	            return false; // actual error

            // wait a little, and try again
            Sleep(25);
            nEmpty++;

			if (nEmpty > 100)
			{
#if 0
				if (AfxMessageBox("No response\nContinue waiting?", MB_YESNO | MB_APPLMODAL) != IDYES)
					return false;	// timeout
				nEmpty = 0;
#else
				return false;	// just give up
#endif
			}
        }
	}
	return true;
}


///////////////////////////////////////////////////////////
