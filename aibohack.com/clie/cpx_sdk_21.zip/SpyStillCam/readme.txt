SpyStillCam 2.1

============================================
SpyStillCam turns on the preview window, starts up WiFi
and then starts listening on port 51009 (SPY_PORT).

When a client (SpyCamWatcher) connects, it will send
single byte commands to the SpyStillCam program.
See spy_protocol.h for the protocol commands.

The most frequent is getting a JPG compressed image.

Also command line SpyGrab is supported.

============================================
Release notes:

Version 2.1
    Major cleanup - now called 'SpyStillCam'
    Now compresses using JPG

Version .5
    Minor cleanup for SDK release

Version .2
    Will keep CLIE alive (cradle or battery)
    Still no real video compression
    4 bit B&W option not yet implemented

    Supports 3 resolutions (SpyCamWatcher will scale up)
    Variable polling speed (SpyCamWatcher)

    Leaves WiFi connected on exit
    Handles more cases of reconnect
    Shows CLIE IP address [in some cases]

    Added exposure settings, and correct initial values
    Protocol version 4

    NX80 camera light - not sure if it works
    Source code released too (but still changing a lot)

Version .1
    First version
    Full 320x240, no compression
    Protocol version 3

============================================
