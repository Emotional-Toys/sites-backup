// netlibS
// NetLib helper for CLIE acting as a server
//  accepting connections from another CLIE or a PC or ...
/////////////////////////////////////////////////////////

bool OpenNetLib();
bool IsConnected();
void CloseNetLib(bool bCloseWiFi);

bool ConnectAndListen(char* szErr, int port);
bool GetOurIPAddress(char* szAddr);
void ReconnectNetConnections();

bool IsConnectedToClient();
bool WaitForNewConnection(int timeDelay);

// when active
UInt8 GetByteFromClient();
        // 0 if none, 0xFF if error
        // otherwise protocol specific byte
bool SendToClient(const UInt8* pbData, int cb);
	    // less than 32K

/////////////////////////////////////////////////////////
