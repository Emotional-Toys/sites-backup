#include "../cpx_common/cpx_camera.cpp"
