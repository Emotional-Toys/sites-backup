#include "spygrab.h"

SPYCAM_TELEMETRY theSpyCam;

void PrUsage()
{
	printf("usage: spygrap ipAddress nFrames [format]\n");
}

int main(int argc, char* argv[])
{
    if (argc != 3 && argc != 4)
    {
        PrUsage();
        return 0;
    }
    const char* ipAddr = argv[1];
    int nFrames = atoi(argv[2]);
    const char* szFmt = "clie_%03d.jpg";
    if (argc > 3)
        szFmt = argv[3];
    if (nFrames < 1)
    {
        PrUsage();
        return 0;
    }

    printf("Looking for CLIE at %s ...", ipAddr);
	if (!theSpyCam.Connect(ipAddr))
    {
        printf("failed!\n");
        printf("(is SpyCam running on CLIE?)\n");
        return -1;
    }
    printf("connected\n");

	byte data[MAX_JPEG];	// large data
    // 1 based
    for (int iFrame = 1; iFrame <= nFrames; iFrame++)
    {
        printf("Getting frame %d ...", iFrame);
		theSpyCam.PurgeReply();
		if (!theSpyCam.SendCommandByte(SPYCMD_GETJPG))
		{
		    printf("get Jpg error\n");
            break;
		}

		// first get length
		WORD cbData;
		if (!theSpyCam.ReceiveReply((BYTE*)&cbData, 2))
		{
		    printf("receive Jpg size error\n");
            break;
		}
		if (cbData <= 10 || cbData > MAX_JPEG)
		{
		    printf("receive Jpg size error2\n");
            break;
		}
		if (!theSpyCam.ReceiveReply(data, cbData))
		{
			printf("receive jpg data error\n");
            break;
		}
        char szFile[_MAX_PATH];
        sprintf(szFile, szFmt, iFrame);
        printf("saving to '%s'", szFile);

        FILE* pf = fopen(szFile, "wb");
        if (pf == NULL)
        {
            printf(" error failed to create file\n");
            break;
        }
        if (fwrite(data, cbData, 1, pf) != 1 ||
            fclose(pf) != 0)
        {
            printf(" error failed to write file\n");
            break;
        }
        printf(" complete\n");
	}
    int iRet = 0;
    if (iFrame <= nFrames)
        iRet = -1; // error

	theSpyCam.Disconnect();

    return iRet;
}

