#define VC_EXTRALEAN
#include <windows.h> // core 
#include <stdio.h>

#include "../watcher/spycamglue.h" // spy cam LAN
#include "../spy_protocol.h"

