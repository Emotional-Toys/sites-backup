#include "spygrab.h"

#define HEADERS_INCLUDED
#include "..\watcher\spycamglue.cpp"

