// Spy(Still)Cam
// 320x240 simple preview camera app
// will compress current image to JPG and send via WiFi
// (to SpyCamWatcher app)

#include <PalmOS.h>
#define NULL	0
#include <SonyCLIE.h>
#include <SonySystemResources.h>
#include <VFSMgr.h>
#include <StringMgr.h>

#include "resource.h"

///////////////////////////////////
// network interface (SpyCam acts as a server)

#include "netlibS.h"

#include "spy_protocol.h"

///////////////////////////////////

#include "cpx_helper.h"

CpxCamera g_camera; // helper glue

// preview rectangle drawn on main screen
RectangleType g_previewRect =
	{ 0, 60, 320, 240 };    // always full screen

static UInt16 g_libJpeg;
UInt8 g_quality = 50;

///////////////////////////////////
// general reporting

static void Alert(const char* szAlert)
{
    g_camera.StopPreview(); // turn off preview before any popup alerts
    ErrAlertCustom(0, (char*)szAlert, NULL, NULL);
    g_camera.StartPreview();
}
#define sprintf StrPrintF

static ControlType* GetControl(FormType* frm, UInt16 id)
{
	ControlType* ctrl = (ControlType*)FrmGetObjectPtr(frm,
        FrmGetObjectIndex(frm, id));
    if (ctrl == NULL)
        Alert("FATAL: missing UI control");
    return ctrl;
}

static void SetStatus(const char* szIn)
{
    static char szInfo[64]; 
    StrCopy(szInfo, szIn); // store in static buffer

    FormType* frm = FrmGetActiveForm();
	ControlType* text = GetControl(frm, MainStatusLabel);
	CtlSetLabel(text, szInfo);
	FrmDrawForm(frm); // flashy, but it gets your attention
            // only call after first drawn
}

static void MainFormInitAndDraw(FormType* frm)
{
    // display IP address (guess)
	static char szAddrLabel[64] = "use Prefs for IP address";
    char szAddr[16];
    if (GetOurIPAddress(szAddr))
        sprintf(szAddrLabel, "Possible IP address: %s", szAddr);
	ControlType* text = GetControl(frm, MainAddrLabel);
	CtlSetLabel(text, szAddrLabel);

	FrmDrawForm(frm);
    // do camera stuff after form initialized

   	char szReport[128];
	int errno;
    if (!g_camera.PrepareCamera(MainForm, errno))
    {
        sprintf(szReport, "PrepareCamera failed (%d)", errno);
        Alert(szReport);
        Alert("Soft reset\nand please try again");
        return;
    }
    g_camera.SetPreviewRect(&g_previewRect);
    if (!g_camera.StartPreview())
    {
        Alert("Start Preview failed");
        return;
    }
}

/////////////////////////////////////////
// Very simple main form user interface

static Boolean MainFormHandleEvent(EventType * eventP)
{
    Boolean handled = false;
    FormType * frmP;

    switch (eventP->eType) 
        {
        case menuEvent:
            // no menus - all done remotely
            // return MainFormDoCommand(eventP->data.menu.itemID);
            break;

        case ctlSelectEvent:
            // form controls map to menu items
			// switch (eventP->data.ctlSelect.controlID)
            break;

        case frmOpenEvent:
            frmP = FrmGetActiveForm();
            MainFormInitAndDraw(frmP);
            handled = true;
            break;
            
        case frmUpdateEvent:
            break;

        default:
            break;
        }
    
    return handled;
}

static Boolean AppHandleEvent(EventType * eventP)
{
    UInt16 formId;
    FormType * frmP;

    if (eventP->eType == frmLoadEvent)
    {
        formId = eventP->data.frmLoad.formID;
        frmP = FrmInitForm(formId);
        FrmSetActiveForm(frmP);

        switch (formId)
        {
        case MainForm:
            FrmSetEventHandler(frmP, MainFormHandleEvent);
            break;

        default:
            break;

        }
        return true;
    }
    // no keyboard commands either - all done remotely
	
    return false;
}

/////////////////////////////////////////
// Watcher video, JPG compression and send

static void SnapAndSendVideoJpeg()
{
    MemPtr pData;
    UInt32 cbData;
	Err err = jpegUtilLibEncodeImageFromWindow(
		g_libJpeg,
        false, NULL, NULL, NULL,    // not EXIF
        g_quality, &g_previewRect,
        0, /*no file*/
        &pData, &cbData, NULL);
		    // buffer is allocated by system, we don't free it

	if (err != 0)
	{
		SetStatus("JPG compress error");
		return;
	}
	if (cbData < 0 || cbData> MAX_JPEG)
	{
		SetStatus("JPG compress size error");
		return;
	}
    UInt8 b2Size[2];
    b2Size[0] = cbData & 255;
    b2Size[1] = (cbData >> 8) & 255;
	if (!SendToClient(b2Size, 2))
    {
        SetStatus("Send data size failed");
        return;
    }
	if (!SendToClient((UInt8*)pData, (int)cbData))
        SetStatus("Send data failed");
}

/////////////////////////////////////////
// Watcher commands

// SpyCam is meant as a stand-alone program,
//  so don't use Alert when running,
//  use SetStatus

static void HandleWatcherCommand(UInt8 bCmd)
{
    if (bCmd == 0xFF)
    {
        SetStatus("not connected");
    }
    else if (bCmd == SPYCMD_GETVER)
    {
        UInt8 bVer = SPY_PROTOCOL_VERSION;
        if (!SendToClient(&bVer, 1))
            SetStatus("send ver error");
    }
    else if (bCmd == SPYCMD_GETJPG)
    {
        SnapAndSendVideoJpeg();
    }
    else if (bCmd >= SPYCMD_SETQUAL_10 && bCmd <= SPYCMD_SETQUAL_90)
    {
        g_quality = 10 + (bCmd - SPYCMD_SETQUAL_10) * 10;
    }
    else if (bCmd >= SPYCMD_SETWB_0 && bCmd <= SPYCMD_SETWB_3)
    {
        g_camera.SetWhiteBalance(bCmd - SPYCMD_SETWB_0);
    }
    else if (bCmd >= SPYCMD_SETEFFECT_0 && bCmd <= SPYCMD_SETEFFECT_4)
    {
        g_camera.SetEffect(bCmd - SPYCMD_SETEFFECT_0);
    }
    else if (bCmd >= SPYCMD_SETEXP_0 && bCmd <= SPYCMD_SETEXP_4)
    {
        g_camera.SetExposure(bCmd - SPYCMD_SETEXP_0);
    }
    else if (bCmd >= SPYCMD_SETZOOM_1 && bCmd <= SPYCMD_SETZOOM_3)
    {
        g_camera.SetZoomUX(100*(1 + bCmd - SPYCMD_SETZOOM_1)); // 100, 200, 300
    }
    else if (bCmd >= SPYCMD_SETCAMLIGHT_0 && bCmd <= SPYCMD_SETCAMLIGHT_1)
    {
        UInt8 bOn = bCmd - SPYCMD_SETCAMLIGHT_0;
        if (!g_camera.SetCamLightNX80(bOn))
            SetStatus("SetCamLight failed");
    }
    else
    {
        char szT[64];
        sprintf(szT, "unknown watcher command $%x", bCmd);
        SetStatus(szT);
    }
}

/////////////////////////////////////////
// Main app init
// Main form *MUST* be in hires mode
// Silk use is optional.

// called at most every tick (1/100 sec)
static void HandleIdleMain()
{
    // frequent background operations (when connected)
    if (IsConnectedToClient())
    {
		UInt8 bCmd = GetByteFromClient();
	    if (bCmd != 0)
	        HandleWatcherCommand(bCmd);
    }

    static int g_idleCount = 40;
    g_idleCount++;
    if (g_idleCount < 50)
        return;
    
    // less frequent initialization goes here:

//	g_camera.SetPreviewRect(&g_previewRect);
    EvtResetAutoOffTimer(); // keep the PDA on
	ReconnectNetConnections();

    if (!IsConnectedToClient())
    {
	    // semi-blocking wait for 1 second
        WaitForNewConnection(1*100);
        if (IsConnectedToClient())
	        SetStatus("Connected");
    }

}

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    if (cmd != sysAppLaunchCmdNormalLaunch)
        return sysErrParamErr;

    if (!g_camera.Open())
    {
		Alert("Helper Open failed");
        return 0;
    }

    // switch to hires
	UInt32 depth = 16;
	if (WinScreenMode(winScreenModeSet, NULL, NULL, &depth, NULL) != 0)
    {
        Alert("Capture program needs hires");
        g_camera.Close();
        return 0;
    }


    // open JPEG library
	if (SysLibFind(sonySysLibNameJpegUtil, &g_libJpeg) != 0 &&
		SysLibLoad(sonySysFileTJpegUtilLib, sonySysFileCJpegUtilLib, &g_libJpeg) != 0)
    {
        Alert("Needs jpeg util library");
        g_camera.Close();
        return 0;
    }
	jpegUtilLibOpen(g_libJpeg);

    if (!OpenNetLib())
    {
        Alert("WiFi failure (WL100 missing?)");
        g_camera.Close();
        return false;
    }

   	char szReport[128];
    if (!ConnectAndListen(szReport, SPY_PORT))
    {
        Alert(szReport);
        Alert("Check net connections\nsoft reset\nand please try again");
        return 0;
    }

    // bring up form, camera init done after form drawn
	FrmGotoForm(MainForm);

    while (1)
    {
	    EventType event;
	    UInt16 error;

		EvtGetEvent(&event, 1); // battery burning app
        if (event.eType == nilEvent)
		    HandleIdleMain();
        else if (SysHandleEvent(&event))
            ;  // handled by the system
        else if (MenuHandleEvent(0, &event, &error))
            ; // handled by menu
        else if (AppHandleEvent(&event))
            ; // handled by general app handler
        else
			FrmDispatchEvent(&event); // last case

        if (event.eType == appStopEvent)
            break;
    }

	if (!g_camera.StopCamera())
		Alert("Stop Camera failed");

    CloseNetLib(false);     // leave WiFi open

	FrmCloseAllForms();
    g_camera.Close();
	jpegUtilLibOpen(g_libJpeg);
    return errNone;
}
