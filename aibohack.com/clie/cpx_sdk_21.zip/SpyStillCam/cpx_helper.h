#include "../cpx_common/cpx_camera.h"

