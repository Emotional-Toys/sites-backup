#include <PalmOS.h>
#include "netlibs.h"

#define INVALID_SOCKET ((NetSocketRef)~0)
#define SOCKET NetSocketRef
#define Sleep(nMS)    SysTaskDelay(nMS / 10)

static UInt16 g_netLib = 0;
static SOCKET g_serverSocket = INVALID_SOCKET;
static SOCKET g_clientSocket = INVALID_SOCKET;

#define sprintf StrPrintF


///////////////////////////

#define SOCK_TIMEOUT_NEVER   -1
#define SOCK_TIMEOUT_NOWAIT  0	/* return immediately */
#define SOCK_TIMEOUT_SHORT     1
#define SOCK_TIMEOUT1		1*100
#define SOCK_TIMEOUT2		2*100
#define SOCK_TIMEOUT_LONG   20*100


bool OpenNetLib()
{
    if (g_netLib == 0)
    {
	    if (SysLibFind("Net.lib", &g_netLib) != 0)
        {
		    if (SysLibLoad('libr', sysFileCINetLib, &g_netLib) != 0)
		        return false;
        }
    }

    // open or re-open
    UInt16 netIFErr1;
    Err err = NetLibOpen(g_netLib, &netIFErr1);
    if (err != 0 && err != netErrAlreadyOpen)
        return false;

    ReconnectNetConnections();

    return true;
}

void ReconnectNetConnections()
{
    UInt16 netIFErr1;
    // try to open any closed connections
    UInt8 bResult;
    NetLibConnectionRefresh(g_netLib,
        true, &bResult, &netIFErr1);
    // ignore errors
}


void CloseNetLib(bool bCloseWiFi)
{
    if (g_netLib != 0)
    {   
		Err err; // ignored
        if (g_clientSocket != INVALID_SOCKET)
        {
			NetLibSocketClose(g_netLib, g_clientSocket, SOCK_TIMEOUT1, &err);
			g_clientSocket = INVALID_SOCKET;
        }
        if (g_serverSocket != INVALID_SOCKET)
	    {
			NetLibSocketClose(g_netLib, g_serverSocket, SOCK_TIMEOUT1, &err);
			g_serverSocket = INVALID_SOCKET;
	    }
        if (bCloseWiFi)
        {
			NetLibClose(g_netLib, true); // immediate
        }
        // else leave the WiFi connection open
            // but don't use it anymore

        g_netLib = 0;
    }
}



/////////////////////////////////////////////////////////
// server specific

bool ConnectAndListen(char* szErr, int port)
{
    if (g_serverSocket != INVALID_SOCKET)
		return false;

    Err err;
	SOCKET hSock = NetLibSocketOpen(g_netLib, netSocketAddrINET,
        netSocketTypeStream, // TCP/IP to be general
        0, SOCK_TIMEOUT_NEVER, &err);
    if (hSock == INVALID_SOCKET)
    {
	    sprintf(szErr, "SocketOpen failed, err=$%x", err);
        return false;
    }

    // bind
    NetSocketAddrINType inaddr;
	inaddr.family = netSocketAddrINET;
	inaddr.port = NetHToNS(port);
	inaddr.addr = NetHToNL(0); // any
	if (NetLibSocketBind(g_netLib, hSock,
        (NetSocketAddrType*)&inaddr, sizeof(inaddr),
        SOCK_TIMEOUT_NEVER, &err) != 0)
    {
		sprintf(szErr, "Bind failed, err=$%x", err);
		NetLibSocketClose(g_netLib, hSock, SOCK_TIMEOUT1, &err);
        return false;
    }

    // set into listen mode, waiting for someone to connect

	// Establish a connection to the server socket.
	if (NetLibSocketListen(g_netLib, hSock,
        1, /* only one at a time */
        SOCK_TIMEOUT_NEVER, &err) != 0)
	{
        if (err == netErrTimeout)
		    sprintf(szErr, "Listen timeout");
        else if (err == netErrNoInterfaces)
		    sprintf(szErr, "WiFi card not connected\n(use Prefs or reset)");
        else
		    sprintf(szErr, "Listen failed, err=$%x", err);
		NetLibSocketClose(g_netLib, hSock, SOCK_TIMEOUT1, &err);
        return false;
	}

    g_serverSocket = hSock;
    return true;
}

// new brute force
bool GetOurIPAddress(char* szAddr)
{
    UInt16 index = 0;
	UInt32 addr = 0;
    while (1)
    {
		UInt32 ifCreator;
		UInt16 ifInstance;
	    Err err = NetLibIFGet(g_netLib, index, &ifCreator, &ifInstance);
        if (err == netErrInvalidInterface)
            break;
        index++;
        if (err != 0)
            continue;
        // see if it has a current or recommended IP Address

		UInt16 size = sizeof(addr);
	    // check actual for DHCP
		if (NetLibIFSettingGet(g_netLib, ifCreator, ifInstance, netIFSettingActualIPAddr, &addr, &size) == 0 && size == sizeof(addr) && addr != 0)
            break;

		if (NetLibIFSettingGet(g_netLib, ifCreator, ifInstance, netIFSettingReqIPAddr, &addr, &size) == 0 && size == sizeof(addr) && addr != 0)
            break;
    }

    if (addr == 0)
        return false;

	NetLibAddrINToA(g_netLib, addr, szAddr);
    return true;
}


bool IsConnectedToClient()
{
    return g_clientSocket != INVALID_SOCKET;
}

bool WaitForNewConnection(int timeDelay)
{
    if (g_clientSocket != INVALID_SOCKET)
        return false; // already connected

    NetSocketAddrType watchaddr;
    Int16 size = sizeof(watchaddr);
	Err err;
	
	SOCKET sock2 = NetLibSocketAccept(g_netLib, g_serverSocket,
        &watchaddr, &size, timeDelay, &err);
    if (sock2 == INVALID_SOCKET)
        return false;

    g_clientSocket = sock2;
    return true;
}

UInt8 GetByteFromClient()
{
    if (g_clientSocket == INVALID_SOCKET)
        return 0;

    // single byte read
    UInt8 data;
    Err err;
	int n = NetLibReceive(g_netLib, g_clientSocket,
        &data, 1,
		0, 0, 0, SOCK_TIMEOUT_NOWAIT, &err);

    if (n == 1)
        return data;
    else if (n == -1 && err == netErrTimeout)
        return 0;

    // otherwise error
	NetLibSocketClose(g_netLib, g_clientSocket, SOCK_TIMEOUT1, &err);
	g_clientSocket = INVALID_SOCKET;
    return 0xFF;
}

/////////////////////////////////////////////////////////

#define MAX_NSIZE 32500

static bool _SendBytes(SOCKET sock, const UInt8* pb, UInt32 cb)
{
    long cbSent = 0;
    while (cb > 0)
    {
        int cbNow = MAX_NSIZE;
        if (cb < (long)MAX_NSIZE)
            cbNow = (int)cb;

	    Err err;
		int cbActual = NetLibSend(g_netLib, sock,
          (void*)pb, (UInt16)cbNow,
          0, 0, 0, SOCK_TIMEOUT_LONG, &err);
                // can take time if backed up
        if (cbActual <= 0 || cbActual > cbNow)
	        return false;

        // may be less than cbNow
        pb += cbActual;
        cb -= cbActual;
        cbSent += cbActual;
    }
    return true;
}

bool SendToClient(const UInt8* pbData, int cb)
{
	return _SendBytes(g_clientSocket, pbData, cb);
}

/////////////////////////////////////////////////////////
