#define	MainForm	1001
#define	MainStatusLabel	1002
#define	MainAddrLabel	1003

#define Largeicons12and8bitsAppIconFamily         1000
#define Smallicons12and8bitsAppIconFamily         1001
