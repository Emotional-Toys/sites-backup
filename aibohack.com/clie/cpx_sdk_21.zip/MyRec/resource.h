#define	MainForm	1001
#define	MainStatusTextLabel	1002

#define Largeicons12and8bitsAppIconFamily         1000
#define Smallicons12and8bitsAppIconFamily         1001

#define	cmdRecord	1003
#define	cmdPlay	1004
#define	cmdDelete	1005
#define	cmdSave	1006
#define	cmdInfo	1007
#define	listRateSelect	1008
#define	listMicSelect	1009
#define	listBuffSelect	1010
