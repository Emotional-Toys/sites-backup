MyRec 2.1 - semi-working sample

See the general ..\README.TXT for build info, legal disclaimers etc.

WARNING: Voice Recording Functionality is very unreliable!

The first time after a soft reset, you should record fine.
After that, recording may or may not be valid.

-----
Usage:
	Select one of the three buffers (test1, test2, test3)

    Select the sampling rate, and mic level

    Press the "Record" button
    Say something
    Press "OK"

    This records the data into the CLIE RAM
        (the storage heap)

    Press the "Play" button and cross your fingers.
        If it says "PlayWave error", then you have hit
        the known bug.
        Try recording again, or soft reset.

    "Save" will save to the first MS/CF volume
        [not the internal UX Media]
    Files are stored in /TEST1.WAV etc
    NOTE: if "Play" fails, then the saved .WAV file will
        not play either.

    When done with MyRec, delete the 3 buffers,
        and soft-reset your CLIE.


-----
Future work:
    Find the #$@!@#! bug causing the inconsistent results
    Support direct record to memory stick (easy)
    Recording volume and other polish features

