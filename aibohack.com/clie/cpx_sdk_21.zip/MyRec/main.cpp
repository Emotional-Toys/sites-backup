#include <PalmOS.h>
#define NULL	0

#include <VFSMgr.h>
// #include <AppLaunchCmd.h>

#include <StringMgr.h>

#include "resource.h"

///////////////////////////////////

#include "cpx_helper.h"

CpxVoiceRecorder g_voiceRecorder;

///////////////////////////////////
// general reporting

#define sprintf StrPrintF

static void Alert(const char* strAlert)
{
    ErrAlertCustom(0, (char*)strAlert, NULL, NULL);
}

/////////////////////////////////////////
// Main record and play


static const UInt16 g_cardNo = 0;   // first card for temp data
// global settings
static char g_streamName[32] = "test1";
static UInt32 g_rate = 22050;
static UInt8 g_micsens = 1;
static UInt16 g_volume = 200;

static ListType* GetListItem(FormType* frm, UInt16 objectID)
{
    void* p = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, objectID));
    if (p == NULL)
        Alert("Internal error: bad list control");
    return (ListType*)p; // assume it is a list type
}

static void PrepareSettings()
{
    FormType* frm = FrmGetActiveForm();
    ListType* list;

    // get buffer, rate and micsens settings from list controls
    list = GetListItem(frm, listBuffSelect);
    StrCopy(g_streamName, LstGetSelectionText(list, LstGetSelection(list)));

    list = GetListItem(frm, listRateSelect);
    Char* strRate = LstGetSelectionText(list, LstGetSelection(list));
    g_rate = StrAToI(strRate);

    list = GetListItem(frm, listMicSelect);
    g_micsens = LstGetSelection(list);
}

static void DoRecord()
{
    int errno;
    if (!g_voiceRecorder.PrepareForRecording(g_streamName,
        g_rate, g_micsens, errno))
    {
	    char strReport[256];
        sprintf(strReport, "PrepareForRecording failed (%d)", errno);
        Alert(strReport);
        return;
    }

    if (!g_voiceRecorder.StartRecording(true))
    {
        Alert("Start Recording failed");
        return;
    }

	Alert("Recording..."); // until ok

	if (!g_voiceRecorder.StopRecording(true))
		Alert("Stop Recording failed");

	// recorded data is in the storage heap
}

static UInt32 Swap32(UInt32 n)
{
    return ((((UInt32) n) << 24) & 0xFF000000) |
    ((((UInt32) n) <<  8) & 0x00FF0000) |
    ((((UInt32) n) >>  8) & 0x0000FF00) |
    ((((UInt32) n) >> 24) & 0x000000FF);
}


// Uses FileStreaming functions instead
#define typeStream 'strm'
#define ctorStream 'SmDK'   // what the Sony system uses

static void DoInfo()
{
    Err err;
    FileHand fh = FileOpen(g_cardNo, g_streamName,
        typeStream, ctorStream, fileModeReadOnly, &err);
    if (fh == 0)
    {
        Alert("No stream database\nRecord something first!");
        return;
    }
    Int32 cbWave;
    if (FileTell(fh, &cbWave, &err) == -1)
        Alert("FileTell error");

    UInt8 header[64];
    if (FileRead(fh, header, sizeof(header), 1, &err) != 1 ||
	  MemCmp(header, "RIFF", 4) != 0 &&
      MemCmp(header + 8, "WAVEfmt ", 8) != 0)
    {
        Alert("Does not look like a WAVE");
    }
    else
    {
        // give a report
        if (header[0x14] != 0x11)
            Alert("NOT ADPCM!");

	    char strReport[256];
		sprintf(strReport, "stream='%s'\n"
            "%ld wave bytes\n"
            "rate=%ld, bits=%d",
	        g_streamName, cbWave,
			Swap32(*(UInt32*)&header[0x18]),
            header[0x22]);
		Alert(strReport);
    }
    FileClose(fh);
}

static void DoDelete()
{
    if (FileDelete(g_cardNo, g_streamName) != 0)
    {
        Alert("No stream database to delete");
        return;
    }
	Alert("Stream data deleted");
}

static UInt16 FindFirstSaveVolume()
{
    UInt16 volRefNum;
	UInt32 volIterator = expIteratorStart;
    // iterate unt
	while (VFSVolumeEnumerate(&volRefNum, &volIterator) == 0)
    {
		VolumeInfoType vi;
		if (VFSVolumeInfo(volRefNum, &vi) == 0 &&
          vi.mediaType != 'Tffs') // ignore the internal NAND media on the UX50
			return volRefNum; // first memory stick
    }
    return 0; // none
}

static void DoSave()
{
    // save the recording to the first VFS volume
    UInt16 volRef = FindFirstSaveVolume();
    if (volRef == 0)
    {
        Alert("No memory stick to save to");
        return;
    }

    Err err;
    FileHand fh = FileOpen(g_cardNo, g_streamName,
        typeStream, ctorStream, fileModeReadOnly, &err);
    if (fh == 0)
    {
        Alert("No stream database\nRecord something first!");
        return;
    }

    // use stream name as the filename (stored in root of memory stick)
    char fileName[256];
    sprintf(fileName, "%s.wav", g_streamName);

	FileRef fileRef;
    if (VFSFileOpen(volRef, fileName,
		vfsModeWrite | vfsModeCreate | vfsModeTruncate | vfsModeExclusive,
        &fileRef) != 0)
    {
        Alert("Failed to open file for writing");
        Alert(fileName);
        return;
    }

	UInt32 cbTotal = 0;
	
    UInt8 buffer[1024];
    Int32 cbRead;
    while ((cbRead = FileRead(fh, buffer, 1, sizeof(buffer), &err)) > 0)
    {
		UInt32 cbWrote = 0;
	    if (VFSFileWrite(fileRef, cbRead, buffer, &cbWrote) != 0 ||
            (long)cbWrote != cbRead)
        {
            Alert("Write error!");
            break;
        }
        cbTotal += cbWrote;
    }
	if (VFSFileClose(fileRef) != 0)
        Alert("Failed to close file");
    FileClose(fh);

    char strReport[256];
    sprintf(strReport, "Saved %ld bytes to file %s\n(on the first MS/CF volume)",
            cbTotal, fileName);
    Alert(strReport);
}


/////////////////////////////////////////
// a little messy since the SndExtn library needs the WAVE file in one
//  big memory chunk (with a RIFF WAVE header)
// we copy the database records into temporary feature memory

const UInt32 g_appCreator = 'APmr';

static UInt8* TempBufferNew(UInt32 cbRequest)
{
	FtrPtrFree(g_appCreator, 0); // nuke old
    UInt8* heapP;
	if (FtrPtrNew(g_appCreator, 0, cbRequest, (void**)&heapP) != 0)
        return NULL;
    return heapP;
}

static void TempBufferFree()
{
	FtrPtrFree(g_appCreator, 0); // nuke temp buffer
}

/////////////////////////////////////////

static void DoPlaySync()
{
    Err err;
    FileHand fh = FileOpen(g_cardNo, g_streamName,
        typeStream, ctorStream, fileModeReadOnly, &err);
    if (fh == 0)
    {
        Alert("No stream database\nRecord something first!");
        return;
    }

    Int32 cbWave;
    FileTell(fh, &cbWave, &err);

    // allocate feature memory for cbTotal
	UInt8* pbWave = TempBufferNew(cbWave);
    if (pbWave == NULL)
    {
        Alert("Error: not enough contiguous memory");
        return;
    }

    // copy from database records to feature memory
    long cbTotal = 0;
    int nErr = 0;

    UInt8 buffer[1024];
    Int32 cbRead;
    while ((cbRead = FileRead(fh, buffer, 1, sizeof(buffer), &err)) > 0)
    {
		if (DmWrite(pbWave, cbTotal, buffer, cbRead) != 0)
            nErr++; // don't count errors
        cbTotal += cbRead;
    }

    FileClose(fh);

    if (cbTotal != cbWave)
		Alert("Internal error: too little data");
    if (nErr > 0)
		Alert("Internal error: DmWrite error(s)");

    // play using SndExtn API
    if (!g_voiceRecorder.PlayWave(pbWave, g_volume))
        Alert("PlayWave failed");

	TempBufferFree(); // delete feature memory
}

/////////////////////////////////////////

static Boolean MainFormHandleEvent(EventType * eventP)
{
    Boolean handled = false;
    FormType * frmP;

    switch (eventP->eType) 
        {
        case menuEvent:
            // return MainFormDoCommand(eventP->data.menu.itemID);
            break;

        case ctlSelectEvent:
            // form controls map to menu items
            switch (eventP->data.ctlSelect.controlID)
            {
            case cmdRecord:
                PrepareSettings();
		        // all quiet while recording
                DoRecord();
                DoInfo(); // report after record complete
                break;
            case cmdInfo:
                PrepareSettings();
                DoInfo();
                break;
            case cmdPlay:
                PrepareSettings();
                DoPlaySync();
                break;
            case cmdDelete:
                PrepareSettings();
                DoDelete();
                break;
            case cmdSave:
                PrepareSettings();
                DoSave();
                break;
            }
			handled = true;
            break;

        case frmOpenEvent:
            frmP = FrmGetActiveForm();
            // MainFormInit(frmP);
            FrmDrawForm(frmP);
            handled = true;
            break;
            
        case frmUpdateEvent:
            break;

        default:
            break;
        }
    
    return handled;
}

static Boolean AppHandleEvent(EventType * eventP)
{
    UInt16 formId;
    FormType * frmP;

    if (eventP->eType == frmLoadEvent)
    {
        formId = eventP->data.frmLoad.formID;
        frmP = FrmInitForm(formId);
        FrmSetActiveForm(frmP);

        switch (formId)
        {
        case MainForm:
            FrmSetEventHandler(frmP, MainFormHandleEvent);
            break;

        default:
            break;

        }
        return true;
    }

    return false;
}


UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    if (cmd != sysAppLaunchCmdNormalLaunch)
        return sysErrParamErr;

    if (!g_voiceRecorder.Open())
    {
       	Alert("Helper Open failed");
        return 0;
    }

    // bring up form
	FrmGotoForm(MainForm);

    while (1)
    {
	    EventType event;
	    UInt16 error;

        EvtGetEvent(&event, evtWaitForever);
        if (SysHandleEvent(&event))
            ;  // handled by the system
        else if (MenuHandleEvent(0, &event, &error))
            ; // handled by menu
        else if (AppHandleEvent(&event))
            ; // handled by general app handler
        else
			FrmDispatchEvent(&event); // last case

        if (event.eType == appStopEvent)
            break;
    }

	FrmCloseAllForms();
	
    g_voiceRecorder.Close();
		
    return errNone;
}
