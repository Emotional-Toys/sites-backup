RotVZ by CliePet

HIGHLY EXPERIMENTAL

Backup your PDA first
Only run on a VZ90

-----------

Install both PRCs on the VZ90, using HotSync or any other means
Soft reset the PDA.

AppLaunchRotExt is a hacked version that disables the automatic switching.
When installed you must manually change the orientation.
To change the rotation, use RotVZ

-----------

To uninstall, use FileZ to find 'AppLaunchRotExt' in RAM (not the ROM version).
Change the type from 'aext' to 'axxx'.
Save the changes. Then soft reset.
Then return to FileZ and delete the 'axxx' from RAM (can cause a MemoryMgr crash, just press the soft reset button again)
AppLaunchRotExt will be back to the ROM version.

RotVZ can be deleted like any other application.
