#include <pspkernel.h>
#include <pspdebug.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspsircs.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define printf	pspDebugScreenPrintf

typedef enum { false, true } bool;
