#include "std.h"
#include "roboir.h"

#include "rawir.h"

//////////////////////////////////////////////////////////////////////
// Robosapien IR encoding
    // from http://www.aibohack.com/robosap/ir_codes.htm


void send_robosapien(u8 cmd)
{
    u32 raw_buffer[2+8*2+2]; // actual size used

printf("[$%x] ", cmd);

	if ((cmd & 0x80) == 0)
		printf("WARNING: Robosapien commands should have high bit set\n");

    // basic timing is 1/1200 sec = 33.3 ticks
	// start bit is 266 ticks - use two slots

    int iL = 0;
    raw_buffer[iL++] = IR_SIGNAL_ON(266/2); // start bit
    raw_buffer[iL++] = IR_SIGNAL_ON(266/2);
    int i;
    for (i = 0; i < 8; i++)
    {
        if (cmd & (0x80 >> i))
	        raw_buffer[iL++] = IR_SIGNAL_OFF(133); // long high bit
        else
	        raw_buffer[iL++] = IR_SIGNAL_OFF(33); // short high bit
        raw_buffer[iL++] = IR_SIGNAL_ON(33); // low bit
    }
    raw_buffer[iL++] = IR_SIGNAL_OFF(266/2); // extra long stop bit
    raw_buffer[iL++] = IR_SIGNAL_OFF(266/2);
    assert(iL <= sizeof(raw_buffer)/sizeof(u32));

	RAW_IR_DATA irdata;
    irdata.timing_val = 40/2; // 40kHz (actually 39.2kHz)
    irdata.raw_buffer = raw_buffer;
    irdata.raw_count = iL;
    
    int err = SendRawIR(&irdata, 1);
    if (err != 0)
        printf("send_robosapien $%x failed\n", cmd);
}

//////////////////////////////////////////////////////////////////////
// ICybie IR encoding
    // from http://www.aibohack.com/icybie, ICSDK2

void send_icybie(u16 code16)
{
    // basic timing is ~1/900 sec = 44.4 ticks

    u32 raw_buffer[2*16+4]; // actual size used

printf("[$%04x] ", code16);

	// no start bit - 16 bits sent, first values act like start bits
        // normally 00xx

    int iL = 0;
    int i;
    for (i = 0; i < 16; i++)
    {
        if (code16 & (0x8000 >> i))
        {
            // "1" bit - long/short
	        raw_buffer[iL++] = IR_SIGNAL_ON(133);
	        raw_buffer[iL++] = IR_SIGNAL_OFF(44);
        }
        else
        {
            // "0" bit - short/long
	        raw_buffer[iL++] = IR_SIGNAL_ON(44);
	        raw_buffer[iL++] = IR_SIGNAL_OFF(133);
        }
    }
    // pad stop bits - longer than needed
    for (i = 0; i < 4; i++)
        raw_buffer[iL++] = IR_SIGNAL_OFF(255);
    assert(iL <= sizeof(raw_buffer)/sizeof(u32));

	RAW_IR_DATA irdata;
    irdata.timing_val = 40/2; // 40kHz (actually 39.2kHz)
    irdata.raw_buffer = raw_buffer;
    irdata.raw_count = iL;
    
    int err = SendRawIR(&irdata, 3); // normal remote sends code 3 times
    if (err != 0)
        printf("send_icybie $%x failed\n", code16);
}

//////////////////////////////////////////////////////////////////////
// Perhaps later: RoboPet, RoboSapienV2
//////////////////////////////////////////////////////////////////////
