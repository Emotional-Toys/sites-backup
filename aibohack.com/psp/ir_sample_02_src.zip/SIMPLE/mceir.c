// Media Center IR (RC6 remote)

#include "std.h"
#include "mceir.h"

#include "rawir.h"

//////////////////////////////////////////////////////////////////////
// all messages sent with RC6 "6A" mode
	// LEAD + 1110 + TR_BIT_0
    // 16 bit device code: 0x800F
    // first byte of 0bX1000100
	    // X toggles between 0 and 1

#define MCE_DEVICE_CODE 0x800F
#define MCE_FIRSTBYTE_A 0xC4
#define MCE_FIRSTBYTE_B 0x44

// see 'mceir.h' for codes (last byte of message)

//////////////////////////////////////////////////////////////////////
// RC6 - mode 6A 
//   from - http://www.xs4all.nl/~sbp/knowledge/ir/rc6.htm

// timing_val = 18
//  carrier freq = 36kHz
//  1 tick = 22.5us
// ~20 ticks for basic time unit (444.44 us)

#define TIME_1 20
#define TIME_2 (TIME_1*2)
#define TIME_6 (TIME_1*6)

#define OPTIMIZE

// Manchester data encoding
static int AddDataBit0(u32* raw_buffer, int iL)
{
#ifdef OPTIMIZE
    if (!IR_SIGNAL_IS_ON(raw_buffer[iL-1]))
	    raw_buffer[iL-1] += TIME_1; // merge it
    else
	    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_1);
#else
	    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_1);
#endif
    raw_buffer[iL++] = IR_SIGNAL_ON(TIME_1);
    return iL;
}

static int AddDataBit1(u32* raw_buffer, int iL)
{
#ifdef OPTIMIZE
    if (IR_SIGNAL_IS_ON(raw_buffer[iL-1]))
	    raw_buffer[iL-1] += TIME_1; // merge it
    else
	    raw_buffer[iL++] = IR_SIGNAL_ON(TIME_1);
#else
    raw_buffer[iL++] = IR_SIGNAL_ON(TIME_1);
#endif
    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_1);
    return iL;
}

static int AddDataByte(u32* raw_buffer, int iL, u8 bData)
    // return new 'iL'
{
    int i;
    for (i = 0; i < 8; i++)
    {
        if (bData & (0x80 >> i))
			iL = AddDataBit1(raw_buffer, iL);
        else
			iL = AddDataBit0(raw_buffer, iL);
    }
    return iL;
}

void send_media_center(u8 code)
{
    static bool s_bFlip = false;
    u32 raw_buffer[100]; // big enough for worst case

printf("[RC6:$%x] ", code);
    int iL = 0;

    // leader
    raw_buffer[iL++] = IR_SIGNAL_ON(TIME_6);
    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_2);
    // DATA 1110 (lead bit, mode 6)
    raw_buffer[iL++] = IR_SIGNAL_ON(TIME_1);
    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_1); // "1"
    raw_buffer[iL++] = IR_SIGNAL_ON(TIME_1);
    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_1); // "1"
    raw_buffer[iL++] = IR_SIGNAL_ON(TIME_1);
#ifdef OPTIMIZE
    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_1+TIME_1); // finish "1" and start "0"
#else
    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_1); // "1"
    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_1); // start "0"
#endif
    raw_buffer[iL++] = IR_SIGNAL_ON(TIME_1); // finish "0"
    // trail bit 0
    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_2);
    raw_buffer[iL++] = IR_SIGNAL_ON(TIME_2);

    // send customer code as two bytes
	iL = AddDataByte(raw_buffer, iL, (MCE_DEVICE_CODE>>8) & 0xFF);
	iL = AddDataByte(raw_buffer, iL, MCE_DEVICE_CODE & 0xFF);

    // flip the code prefix so receiver can detect double press vs. reflection
	iL = AddDataByte(raw_buffer, iL,
        s_bFlip ? MCE_FIRSTBYTE_A : MCE_FIRSTBYTE_B);
    s_bFlip = !s_bFlip;

    // the interesting part
	iL = AddDataByte(raw_buffer, iL, code);

    // stop bit
    raw_buffer[iL++] = IR_SIGNAL_OFF(TIME_6);
    raw_buffer[iL++] = IR_SIGNAL_OFF(50); // overkill

    assert(iL <= sizeof(raw_buffer)/sizeof(u32));

	RAW_IR_DATA irdata;
    irdata.timing_val = 36/2; // 36kHz carrier
    irdata.raw_buffer = raw_buffer;
    irdata.raw_count = iL;

    int err = SendRawIR(&irdata, 8); // repeat 8 times
    if (err != 0)
        printf("send_media_center $%x failed\n", code);
}

//////////////////////////////////////////////////////////////////////
