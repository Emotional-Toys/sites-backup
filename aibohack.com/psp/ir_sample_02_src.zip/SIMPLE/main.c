// irtest
//   Raw IR send routine
//    one mode uses RoboSapien IR encoding
//    another mode uses ICybie IR encoding
//    a third mode uses RC-6 (6A) remote control, common for MediaCenter remotes

#include "std.h"

// Kernel mode access required for hardware hacks
PSP_MODULE_INFO("Robo IR", 0x1000, 1, 1); // KMEM access for ir hacks
PSP_MAIN_THREAD_ATTR(0); // Kernel thread

#include "stdexit.c_" // standard exit code

static u32 PollButtons(u32* buttonsShiftPtr)
{
	static u32 s_buttonsLastPoll = 0;

	SceCtrlData pad;
	sceCtrlReadBufferPositive(&pad, 1);
    u32 buttonsNew = pad.Buttons & ~s_buttonsLastPoll;
	s_buttonsLastPoll = pad.Buttons;
    if (buttonsShiftPtr != NULL)
	    *buttonsShiftPtr = s_buttonsLastPoll & ~buttonsNew;
        // first time shift button is pressed it comes through normally
    return buttonsNew;
}

// test modes
static void DoRobosapienMode(bool bReverse);
static void DoICybieMode();
static void DoRC6Mode();

int main(void)
{
	SetupCallbacks();

	sceCtrlSetSamplingCycle(0);
	sceCtrlSetSamplingMode(PSP_CTRL_MODE_DIGITAL);

    while (1)
    {
        // main mode
		pspDebugScreenInit();
		printf("Robo IR\n\n");
        printf("Press TRIANGLE to exit\n");
        printf("Press CIRCLE for RoboSapien (normal)\n");
        printf("Press SQUARE for RoboSapien (reverse)\n");
        printf("Press CROSS for ICybie\n");

		u32 buttons;
        while ((buttons = PollButtons(NULL)) == 0)
			sceDisplayWaitVblankStart(); // slow things down a little

		if (buttons & PSP_CTRL_TRIANGLE)
            break;
		if (buttons & PSP_CTRL_CIRCLE)
			DoRobosapienMode(false);
		else if (buttons & PSP_CTRL_SQUARE)
            DoRobosapienMode(true);
		else if (buttons & PSP_CTRL_CROSS)
            DoICybieMode();
		else if (buttons & PSP_CTRL_START)
            DoRC6Mode();
        // when modes exit - redraw the instructions
    }
    printf("\nGoodbye\n");
    sceKernelExitGame();
	return 0;
}

//////////////////////////////////////////////////////////////////////
// Robot modes

#include "roboir.h"

static void DoRobosapienMode(bool bReverse)
{
	pspDebugScreenInit();
    printf("RoboSapien Mode\n");
    printf("Face in %s direction as robot\n", bReverse ? "opposite" : "same");
    printf("Press TRIANGLE to exit\n");

    printf("Press SQUARE to stop\n");
    printf("Press UP/DOWN to walk\n");
    printf("Press LEFT/RIGHT to turn\n");

    printf("Hold LTrigger or RTrigger to select arm, then\n");
    printf("   press UP/DOWN/LEFT/RIGHT or CIRCLE/SQUARE/CROSS for arm actions\n");
    printf("Hold SQUARE and press UP/DOWN/LEFT/RIGHT for more Left arm\n");
    printf("Hold CIRCLE and press UP/DOWN/LEFT/RIGHT for more Right arm\n");
    printf("Hold both triggers and press UP/DOWN/LEFT/RIGHT for body rocking\n");
    printf("Hold SELECT and press UP/DOWN/LEFT/RIGHT for skits\n");
    printf("Hold START and press UP/DOWN/LEFT/RIGHT for more skits\n");

    u8 flip = bReverse ? 0x08 : 0;
        // XOR with certain byte codes for right<->left flip


    while (1)
    {
        u32 buttonsShift;
		u32 buttons = PollButtons(&buttonsShift);
		if (buttons & PSP_CTRL_TRIANGLE)
            break;

        if ((buttonsShift & (PSP_CTRL_LTRIGGER|PSP_CTRL_RTRIGGER)) ==
			(PSP_CTRL_LTRIGGER|PSP_CTRL_RTRIGGER))
        {
            // both triggers for body rocking
			if (buttons & PSP_CTRL_UP)
				send_robosapien(ROBOSAP_LEAN_FORWARD);
			else if (buttons & PSP_CTRL_DOWN)
				send_robosapien(ROBOSAP_LEAN_BACKWARD);
			else if (buttons & PSP_CTRL_LEFT)
				send_robosapien(ROBOSAP_TILT_BODY_LEFT ^ flip);
			else if (buttons & PSP_CTRL_RIGHT)
				send_robosapien(ROBOSAP_TILT_BODY_RIGHT ^ flip);
        }
        else if (buttonsShift & PSP_CTRL_LTRIGGER)
        {
            // LTrigger for left arm
			if (buttons & PSP_CTRL_UP)
				send_robosapien(ROBOSAP_LEFT_ARM_UP ^ flip);
			else if (buttons & PSP_CTRL_DOWN)
				send_robosapien(ROBOSAP_LEFT_ARM_DOWN ^ flip);
			else if (buttons & PSP_CTRL_LEFT)
				send_robosapien(ROBOSAP_LEFT_ARM_OUT ^ flip); // larm out!
			else if (buttons & PSP_CTRL_RIGHT)
				send_robosapien(ROBOSAP_LEFT_ARM_IN ^ flip);
            else if (buttons & PSP_CTRL_CROSS)
				send_robosapien(ROBOSAP_LEFT_HAND_THUMP ^ flip);
            else if (buttons & PSP_CTRL_SQUARE)
				send_robosapien(ROBOSAP_LEFT_HAND_PICKUP ^ flip);
            else if (buttons & PSP_CTRL_CIRCLE)
				send_robosapien(ROBOSAP_LEFT_HAND_THROW ^ flip);
        }
        else if (buttonsShift & PSP_CTRL_RTRIGGER)
        {
            // RTrigger for right arm
			if (buttons & PSP_CTRL_UP)
				send_robosapien(ROBOSAP_RIGHT_ARM_UP ^ flip);
			else if (buttons & PSP_CTRL_DOWN)
				send_robosapien(ROBOSAP_RIGHT_ARM_DOWN ^ flip);
			else if (buttons & PSP_CTRL_LEFT)
				send_robosapien(ROBOSAP_RIGHT_ARM_IN ^ flip);
			else if (buttons & PSP_CTRL_RIGHT)
				send_robosapien(ROBOSAP_RIGHT_ARM_OUT ^ flip); // rarm out!
            else if (buttons & PSP_CTRL_CROSS)
				send_robosapien(ROBOSAP_RIGHT_HAND_THUMP ^ flip);
            else if (buttons & PSP_CTRL_SQUARE)
				send_robosapien(ROBOSAP_RIGHT_HAND_PICKUP ^ flip);
            else if (buttons & PSP_CTRL_CIRCLE)
				send_robosapien(ROBOSAP_RIGHT_HAND_THROW ^ flip);
        }
        else if (buttonsShift & PSP_CTRL_SQUARE)
        {
            // hold SQUARE - more left arm
			if (buttons & PSP_CTRL_UP)
                send_robosapien(ROBOSAP_LEFT_HAND_SWEEP ^ flip);
			else if (buttons & PSP_CTRL_DOWN)
                send_robosapien(ROBOSAP_LEFT_HAND_STRIKE_1 ^ flip);
			else if (buttons & PSP_CTRL_LEFT)
                send_robosapien(ROBOSAP_LEFT_HAND_STRIKE_2 ^ flip);
			else if (buttons & PSP_CTRL_RIGHT)
                send_robosapien(ROBOSAP_LEFT_HAND_STRIKE_3 ^ flip);
        }
        else if (buttonsShift & PSP_CTRL_CIRCLE)
        {
            // hold CIRCLE - more right arm
			if (buttons & PSP_CTRL_UP)
                send_robosapien(ROBOSAP_RIGHT_HAND_SWEEP ^ flip);
			else if (buttons & PSP_CTRL_DOWN)
                send_robosapien(ROBOSAP_RIGHT_HAND_STRIKE_1 ^ flip);
			else if (buttons & PSP_CTRL_LEFT)
                send_robosapien(ROBOSAP_RIGHT_HAND_STRIKE_2 ^ flip);
			else if (buttons & PSP_CTRL_RIGHT)
                send_robosapien(ROBOSAP_RIGHT_HAND_STRIKE_3 ^ flip);
        }
        else if (buttonsShift & PSP_CTRL_SELECT)
        {
            // skits
			if (buttons & PSP_CTRL_UP)
                send_robosapien(ROBOSAP_BURP);
			else if (buttons & PSP_CTRL_DOWN)
                send_robosapien(ROBOSAP_HIGH_5);
			else if (buttons & PSP_CTRL_LEFT)
                send_robosapien(ROBOSAP_BULLDOZER);
			else if (buttons & PSP_CTRL_RIGHT)
                send_robosapien(ROBOSAP_OOPS);
        }
        else if (buttonsShift & PSP_CTRL_START)
        {
            // more skits
			if (buttons & PSP_CTRL_UP)
                send_robosapien(ROBOSAP_WHISTLE);
			else if (buttons & PSP_CTRL_DOWN)
                send_robosapien(ROBOSAP_TALKBACK);
			else if (buttons & PSP_CTRL_LEFT)
                send_robosapien(ROBOSAP_ROAR);
			else if (buttons & PSP_CTRL_RIGHT)
                send_robosapien(ROBOSAP_WAKEUP);
        }
        else
        {
            // no trigger buttons pressed - walk
			if (buttons & PSP_CTRL_SQUARE)
				send_robosapien(ROBOSAP_STOP); // STOP !
			else if (buttons & PSP_CTRL_UP)
				send_robosapien(ROBOSAP_WALK_FORWARD);
			else if (buttons & PSP_CTRL_DOWN)
				send_robosapien(ROBOSAP_WALK_BACKWARD);
			else if (buttons & PSP_CTRL_LEFT)
				send_robosapien(ROBOSAP_TURN_LEFT);
			else if (buttons & PSP_CTRL_RIGHT)
				send_robosapien(ROBOSAP_TURN_RIGHT);
        }
		sceDisplayWaitVblankStart(); // slow things down a little
    }
    printf("Exiting Robosapien Mode\n");
}



static void DoICybieMode()
{
	pspDebugScreenInit();
    printf("ICybie Mode\n");

    printf("Press CROSS or CIRCLE for Large Button (Stop/Enter)\n");
    printf("Press START for Small Button (power down)\n");
    printf("Press TRIANGLE to exit\n");
    printf("Press UP for button 1 - BOW\n");
    printf("Press DOWN for button 2 - SIT DOWN\n");
    printf("Press LEFT for button 3 - HEAD SHAKE\n");
    printf("Press RIGHT for button 4 - enter TRICK MODE\n");
    printf("Hold LTrigger and press UP for button 5 - PEE\n");
    printf("Hold LTrigger and press DOWN for button 6 - WAG TAIL\n");
    printf("Hold LTrigger and press LEFT for button 7 - STAY\n");
    printf("Hold LTrigger and press RIGHT for button 8 - enter GUARD MODE\n");
    printf("Hold RTrigger and press UP for button 9 - enter LISTEN MODE\n");
    printf("Hold RTrigger and press DOWN for button 10 - enter ADVANCED PLAY MODE\n");
    printf("Hold RTrigger and press LEFT for button 11 - enter TRAIN VOICE MODE\n");
    printf("Hold RTrigger and press RIGHT for button 12 - exit MODE\n");

	while (1)
	{
		u32 buttonsShift;
		u32 buttons = PollButtons(&buttonsShift);
		if (buttons & PSP_CTRL_TRIANGLE)
            break;
        if (buttons & (PSP_CTRL_CROSS | PSP_CTRL_CIRCLE))
        {
			send_icybie(ICYBIE_REMOTE_LARGE);
        }
        else if (buttons & PSP_CTRL_START)
        {
			send_icybie(ICYBIE_REMOTE_SMALL);
        }
        else if (buttonsShift & PSP_CTRL_LTRIGGER)
        {
            // LTrigger: 5->8
			if (buttons & PSP_CTRL_UP)
	            send_icybie(ICYBIE_REMOTE5);
			else if (buttons & PSP_CTRL_DOWN)
	            send_icybie(ICYBIE_REMOTE6);
			else if (buttons & PSP_CTRL_LEFT)
	            send_icybie(ICYBIE_REMOTE7);
			else if (buttons & PSP_CTRL_RIGHT)
	            send_icybie(ICYBIE_REMOTE8);
        }
        else if (buttonsShift & PSP_CTRL_RTRIGGER)
        {
            // LTrigger: 9->12
			if (buttons & PSP_CTRL_UP)
	            send_icybie(ICYBIE_REMOTE9);
			else if (buttons & PSP_CTRL_DOWN)
	            send_icybie(ICYBIE_REMOTE10);
			else if (buttons & PSP_CTRL_LEFT)
	            send_icybie(ICYBIE_REMOTE11);
			else if (buttons & PSP_CTRL_RIGHT)
	            send_icybie(ICYBIE_REMOTE12);
        }
        else
        {
            // no trigger: 1->4
			if (buttons & PSP_CTRL_UP)
	            send_icybie(ICYBIE_REMOTE1);
			else if (buttons & PSP_CTRL_DOWN)
	            send_icybie(ICYBIE_REMOTE2);
			else if (buttons & PSP_CTRL_LEFT)
	            send_icybie(ICYBIE_REMOTE3);
			else if (buttons & PSP_CTRL_RIGHT)
	            send_icybie(ICYBIE_REMOTE4);
        }
    }
    printf("Exiting ICybie Mode\n");
}

//////////////////////////////////////////////////////////////////////
// Media Center mode

#include "mceir.h"

static void DoRC6Mode()
{
	pspDebugScreenInit();
    printf("RC6 - Media Center Mode\n");

    printf("Press TRIANGLE to exit\n");
    printf("Press START to start Media Center\n");
    printf("Press SELECT for BACK\n");
    printf("Press UP/DOWN for volume up/down\n");
    printf("Press LEFT/RIGHT for channel down/up\n");
    printf("Hold RTrigger and press LEFT/RIGHT/UP/DOWN for menu navigate\n");
    printf("Hold RTrigger and press CROSS or CIRCLE for OK\n");
    printf("Hold RTrigger and press SQUARE for Enter\n");
    printf("Hold LTrigger and press CROSS for LiveTV\n");
    printf("Hold LTrigger and press CIRCLE for RecordedTV\n");
    printf("Hold LTrigger and press SQUARE for GUIDE\n");
    printf("Hold LTrigger and press START for DVD Menu\n");

	while (1)
	{
		u32 buttonsShift;
		u32 buttons = PollButtons(&buttonsShift);

		if (buttons & PSP_CTRL_TRIANGLE)
            break;
        if (buttonsShift & PSP_CTRL_RTRIGGER)
        {
            // R Trigger for menu navigate
	        if (buttons & PSP_CTRL_UP)
                send_media_center(MCE_BUTTON_UP);
	        else if (buttons & PSP_CTRL_DOWN)
                send_media_center(MCE_BUTTON_DOWN);
	        else if (buttons & PSP_CTRL_LEFT)
                send_media_center(MCE_BUTTON_LEFT);
	        else if (buttons & PSP_CTRL_RIGHT)
                send_media_center(MCE_BUTTON_RIGHT);
	        else if (buttons & PSP_CTRL_CROSS)
                send_media_center(MCE_BUTTON_OK);
	        else if (buttons & PSP_CTRL_CIRCLE)
                send_media_center(MCE_BUTTON_OK); // ditto
	        else if (buttons & PSP_CTRL_SQUARE)
                send_media_center(MCE_BUTTON_ENTER);
        }
        else if (buttonsShift & PSP_CTRL_LTRIGGER)
        {
            // L Trigger for modes
	        if (buttons & PSP_CTRL_CROSS)
				send_media_center(MCE_BUTTON_LIVETV);
	        else if (buttons & PSP_CTRL_CIRCLE)
				send_media_center(MCE_BUTTON_RECTV);
	        else if (buttons & PSP_CTRL_SQUARE)
				send_media_center(MCE_BUTTON_GUIDE);
	        else if (buttons & PSP_CTRL_START)
				send_media_center(MCE_BUTTON_DVDMENU);
        }
        else
        {
            // no shift
	        if (buttons & PSP_CTRL_UP)
				send_media_center(MCE_BUTTON_VOL_UP);
	        else if (buttons & PSP_CTRL_DOWN)
				send_media_center(MCE_BUTTON_VOL_DOWN);
	        else if (buttons & PSP_CTRL_LEFT)
				send_media_center(MCE_BUTTON_CH_DOWN);
	        else if (buttons & PSP_CTRL_RIGHT)
				send_media_center(MCE_BUTTON_CH_UP);
	        else if (buttons & PSP_CTRL_START)
				send_media_center(MCE_BUTTON_EHOME);
	        else if (buttons & PSP_CTRL_SELECT)
				send_media_center(MCE_BUTTON_BACK);
        }
    }
    printf("Exiting Media Center Mode\n");
}

//////////////////////////////////////////////////////////////////////
