// 32bit RGB and other features
    // including Portrait modes
    // all line wrapping removed
    // adapted from primitive graphics from Hello World PSP (by nem)
    // butchered by PspPet

#include "std.h"
#include "pg_redux.h"

#include "font_ega.c_" // Classic EGA font - mixed case

#define TRUE_PIXELSIZE    3                //32bit RGB
#define LINESIZE    512 // 512 pixels per line, 480 shown
#define FRAMESIZE    0x88000

//480*272 pixels = 60*38
// 1 pixel => 60x38 or 38x60 characters
// 2 pixel => 30x19 or 19x30 characters
// 4 pixel => 15x9 or 9x15 characters

// draw buffer for video memory (accessed as 32 bit RGB values)
static u32 *pg_vram=(u32*)0x04000000;
static u32 *pg_vramDraw=(u32*)0x44000000; // no cache

// last shown
static u32 *pg_vram2=(u32*)(0x04000000 + FRAMESIZE);
static u32 *pg_vramDraw2=(u32*)(0x44000000 + FRAMESIZE); // no cache

void pgInit32()
{
    // full screen, 32bit RGB, double buffered
    sceDisplaySetMode(0, SCREEN_WIDTH, SCREEN_HEIGHT);
    pgFillvram(0);
    pgScreenFlipV(); // show first
}

void pgWaitVn(u32 count)
{
    while (count--)
        sceDisplayWaitVblankStart();
}

u32* pgGetVramAddr(u32 x, u32 y)
{
    return pg_vramDraw + (y * LINESIZE) + x;
}



// pixel positioning (no wrap)
void pgPrint1AtPixel(u32 xPixel, u32 yPixel, u32 color, const char *str)
{
    while (*str!='\0')
    {
        pgPutChar_L(xPixel, yPixel, color, 0, *str, 1, 0, 1);
        str++;
        xPixel += 8*1;
    }
}
void pgPrint2AtPixel(u32 xPixel, u32 yPixel, u32 color, const char *str)
{
    while (*str!='\0')
    {
        pgPutChar_L(xPixel, yPixel, color, 0, *str, 1, 0, 2);
        str++;
        xPixel += 8*2;
    }
}
void pgPrint4AtPixel(u32 xPixel, u32 yPixel, u32 color, const char *str)
{
    while (*str!='\0')
    {
        pgPutChar_L(xPixel, yPixel, color, 0, *str, 1, 0, 4);
        str++;
        xPixel += 8*4;
    }
}


void pgFillvram(u32 color)
{
    u32* vptr0=(u32*)pgGetVramAddr(0, 0);
    int i;
    for (i=0; i<SCREEN_HEIGHT*LINESIZE; i++) {
        *vptr0++ = color;
    }
}

#define swap_pg_(a, b) { u32* t = a; a = b; b = t; }
void pgScreenFlipV()
{
    sceDisplayWaitVblankStart();
    sceDisplaySetFrameBuf((void*)pg_vram, LINESIZE, TRUE_PIXELSIZE, 1);
    swap_pg_(pg_vram, pg_vram2);
    swap_pg_(pg_vramDraw, pg_vramDraw2);
}

// Landscape - regular orientation
void pgPutChar_L(u32 x, u32 y, u32 color, u32 bgcolor, u8 ch, char drawfg, char drawbg, char mag)
{
    int cy;
    const u8* cfont=font+ch*8;
    u32* vptr0=pgGetVramAddr(x, y);
    for (cy=0; cy<8; cy++) {
        int my;
        for (my=0; my<mag; my++) {
            u32* vptr=vptr0;
            u8 b=0x80;
            int cx;
            for (cx=0; cx<8; cx++) {
                int mx;
                for (mx=0; mx<mag; mx++) {
                    if ((*cfont&b)!=0) {
                        if (drawfg) *vptr=color;
                    } else {
                        if (drawbg) *vptr=bgcolor;
                    }
                    vptr++;
                }
                b=b>>1;
            }
            vptr0 += LINESIZE;
        }
        cfont++;
    }
}

/////////////////////////////////////////////////
// Portrait drawing
    // x and y are swapped

void pgPrint1AtPixel_P(u32 xPixel, u32 yPixel, u32 color, const char *str)
{
    while (*str!='\0')
    {
        pgPutChar_P(xPixel, yPixel, color, 0, *str, 1, 0, 1);
        str++;
        xPixel += 8*1;
    }
}
void pgPrint2AtPixel_P(u32 xPixel, u32 yPixel, u32 color, const char *str)
{
    while (*str!='\0')
    {
        pgPutChar_P(xPixel, yPixel, color, 0, *str, 1, 0, 2);
        str++;
        xPixel += 8*2;
    }
}
void pgPrint4AtPixel_P(u32 xPixel, u32 yPixel, u32 color, const char *str)
{
    while (*str!='\0')
    {
        pgPutChar_P(xPixel, yPixel, color, 0, *str, 1, 0, 4);
        str++;
        xPixel += 8*4;
    }
}

void pgPutChar_P(u32 xPort, u32 yPort, u32 color, u32 bgcolor, u8 ch, char drawfg, char drawbg, char mag)
{
    int cy;
    const u8* cfont=font+ch*8;
    u32* vptr0=pgGetVramAddr(yPort, (SCREEN_HEIGHT-1)-xPort);
        // portrait - point to last physical line
    u8 b=0x80;
    for (cy=0; cy<8; cy++) // cy on screen
    {
        int my;
        for (my=0; my<mag; my++) // my on screen
        {
            u32* vptr=vptr0;
            int cx;
            for (cx=0; cx<8; cx++)
            {
                int bit = (cfont[cx]&b)!=0;

                int mx;
                for (mx=0; mx<mag; mx++)
                {
                    if (bit && drawfg)
                        *vptr=color;
                    else if (!bit && drawbg)
                        *vptr=bgcolor;
                    vptr++;
                }
            }
            vptr0 -= LINESIZE;
        }
        b=b>>1;
    }
}


//////////////////////////////////////////////////////////////////////////
