// primitive graphics adapted to RGB and other special cases

void pgInit32();
void pgScreenFlipV();
void pgWaitVn(u32 count);
void pgFillvram(u32 color);

// pixel locations, no wrap

// landscape printing
void pgPrint1AtPixel(u32 x, u32 y, u32 color, const char *str);
void pgPrint2AtPixel(u32 x, u32 y, u32 color, const char *str);
void pgPrint4AtPixel(u32 x, u32 y, u32 color, const char *str);

// portrait printing
void pgPrint1AtPixel_P(u32 x, u32 y, u32 color, const char *str);
void pgPrint2AtPixel_P(u32 x, u32 y, u32 color, const char *str);
void pgPrint4AtPixel_P(u32 x, u32 y, u32 color, const char *str);

// low level
void pgPutChar_L(u32 x, u32 y, u32 color, u32 bgcolor, unsigned char ch, char drawfg, char drawbg, char mag);
void pgPutChar_P(u32 x, u32 y, u32 color, u32 bgcolor, unsigned char ch, char drawfg, char drawbg, char mag);
u32* pgGetVramAddr(u32 x,u32 y);

#define SCREEN_WIDTH  480
#define SCREEN_HEIGHT 272

#define DRAW_LINESIZE   512

// useful RGB colors (ABGR format)

#define COLOR_WHITE  0xFFFFFFFF
#define COLOR_GREY12 0xFF222222
#define COLOR_GREY25 0xFF444444
#define COLOR_GREY50 0xFF888888
#define COLOR_GREY75 0xFFCCCCCC
#define COLOR_RED    0xFF0000FF
#define COLOR_GREEN  0xFF00FF00
#define COLOR_BLUE   0xFFFF0000

#define RGB(r, g, b)    (0xFF000000 | ((b)<<16) | ((g)<<8) | (r))

