#include <pspkernel.h>
#include <pspdebug.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspsircs.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h> // for sprintf

typedef enum { false, true } bool;

#define printf my_printf
extern int my_printf(const char *format, ...);    // my version

