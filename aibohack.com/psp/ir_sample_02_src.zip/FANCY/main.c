// irfancy - irtest with fancy (data driven) interface
//   Raw IR send routine
//    one mode uses RoboSapien IR encoding
//    another mode uses ICybie IR encoding
//    a third mode uses RC-6 (6A) remote control, common for MediaCenter remotes

#include "std.h"
#include "rawir.h"

#include "pg_redux.h"

// Kernel mode access required for hardware hacks
PSP_MODULE_INFO("Robo IR", 0x1000, 1, 1); // KMEM access for ir hacks
PSP_MAIN_THREAD_ATTR(0); // Kernel thread

static u32 PollButtons(u32* buttonsShiftPtr)
{
    static u32 s_buttonsLastPoll = 0;

    SceCtrlData pad;
    sceCtrlReadBufferPositive(&pad, 1);
    u32 buttonsNew = pad.Buttons & ~s_buttonsLastPoll;
    s_buttonsLastPoll = pad.Buttons;
    if (buttonsShiftPtr != NULL)
        *buttonsShiftPtr = s_buttonsLastPoll & ~buttonsNew;
        // first time shift button is pressed it comes through normally
    return buttonsNew;
}

// modes
static void DoRobosapienMode(bool bReverse);
static void DoICybieMode();
static void DoMediaCenterMode();

int main(void)
{
    pgInit32(); // RGB color version - double buffering

    pgFillvram(0);
    pgPrint1AtPixel(0,10,COLOR_WHITE,"IR MultiTest");
    pgPrint1AtPixel(10,20,COLOR_WHITE,".02 - fancy UI");
    pgPrint1AtPixel(10,30,COLOR_WHITE,"by PspPet");
    pgPrint1AtPixel_P(10,10,COLOR_RED,"IR MultiTest");
    pgPrint1AtPixel_P(0,16,RGB(128,0,0),"(example of portrait text)");
    pgScreenFlipV();
    pgWaitVn(150);

    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_DIGITAL);

    // enable RAW IR trickery
    if (!InitRawIR())
    {
        pgFillvram(0);
        pgPrint1AtPixel(0,10,COLOR_WHITE,"IR MultiTest");
        pgPrint1AtPixel(10,20,COLOR_RED," INIT ERROR !!!!");
        pgScreenFlipV();
        pgWaitVn(150);
        return -1;
    }

    while (1)
    {
        // main mode
        pgFillvram(0);
        pgPrint1AtPixel_P(10,10,COLOR_RED,"IR MultiTest");

        pgPrint1AtPixel(0,3*10,COLOR_WHITE,"IR MultiTest");
        pgPrint1AtPixel(0,4*10,COLOR_GREY50,"Press HOME to exit");
        pgPrint1AtPixel(0,8*10,COLOR_GREY50,"Press TRIANGLE for Media Center");
        pgPrint1AtPixel(0,5*10,COLOR_GREY50,"Press CIRCLE for Robosapien (norm)");
        pgPrint1AtPixel(0,6*10,COLOR_GREY50,"Press SQUARE for Robosapien (reverse)");
        pgPrint1AtPixel(0,7*10,COLOR_GREY50,"Press CROSS for ICybie");

        pgScreenFlipV();
        pgWaitVn(10);

        u32 buttons;
        while ((buttons = PollButtons(NULL)) == 0)
            sceDisplayWaitVblankStart(); // slow things down a little

        if (buttons & PSP_CTRL_HOME)
            break;

        if (buttons & PSP_CTRL_CIRCLE)
            DoRobosapienMode(false);
        else if (buttons & PSP_CTRL_SQUARE)
            DoRobosapienMode(true);
        else if (buttons & PSP_CTRL_CROSS)
            DoICybieMode();
        else if (buttons & PSP_CTRL_TRIANGLE)
            DoMediaCenterMode();
        // when modes exit - redraw the instructions
    }
    pgFillvram(0);
    pgScreenFlipV();
    pgWaitVn(10);

    sceKernelExitGame();
    return 0;
}

//////////////////////////////////////////////////////////////////////
// Format for data driven buttons

typedef struct
{
    u32 buttonMask; // either shift or button press masks
    int ircodeEtc; // device dependent, or < 0 for special
    const char* name;
} TABLE_DRIVEN_IR;

#define PSP_CTRL_BOTHTRIGGERS (PSP_CTRL_LTRIGGER|PSP_CTRL_RTRIGGER)

#define START_TABLE(label) static const TABLE_DRIVEN_IR label[] = {
#define START_BLOCK(shift, name) { shift, -1, name },
#define ENTRY(button, ircode, name) { button, ircode, name },
#define END_BLOCK()
#define END_TABLE() { 0, -2, NULL } };

// be sure the non-shifted default "START_BLOCK(0, ???)" is the last block
    // if nothing found in the previous blocks, these buttons will also work

//////////////////////////////////////////////////////////////////////
// where to draw help text for buttons

typedef struct
{
    u32 button;
    int x, y;       // if x < 0 use portrait
    const char* tag;
    // actual data changes
} BUTTON_PROMPT_INFO;

// Laid out on the screen in a rough approximation of where the buttons are
//  on the outside of the screen
//  left side for DPAD, right side for TRIANGLE/SQUARE/CIRLE/CROSS
//  L/R triggers on the top
//  other buttons labelled on the bottom (with portrait oriented text)
#define X_LEFT_BASE 50
#define Y_LEFT_BASE 80
#define X_RIGHT_BASE 200
#define Y_RIGHT_BASE 140
#define Y_HEIGHT 10
#define Y_EXTRA 4 /* a bit more room for UP and DOWN */

enum PspCtrlButtons_EXTRA_WITHSIDEEFFECTS // use sparingly
{
    PSP_CTRL_VOLUP      = 0x100000,
    PSP_CTRL_VOLDOWN    = 0x200000,
    PSP_CTRL_SCREEN     = 0x400000,
};

static const BUTTON_PROMPT_INFO g_buttonPromptInfo[] =
{
    // top line
    { PSP_CTRL_LTRIGGER, 10, 4, "LTrig=" },
    { PSP_CTRL_RTRIGGER, 300, 4, "RTrig=" },

    // left side
    { PSP_CTRL_UP, X_LEFT_BASE, Y_LEFT_BASE, "U=" },
    { PSP_CTRL_LEFT, X_LEFT_BASE-40, Y_LEFT_BASE+Y_HEIGHT*1+Y_EXTRA, "L=" },
    { PSP_CTRL_RIGHT, X_LEFT_BASE+40, Y_LEFT_BASE+Y_HEIGHT*2+Y_EXTRA, "R=" },
    { PSP_CTRL_DOWN, X_LEFT_BASE, Y_LEFT_BASE+Y_HEIGHT*3+Y_EXTRA*2, "D=" },

    { PSP_CTRL_TRIANGLE, X_RIGHT_BASE, Y_RIGHT_BASE, "Triangle=" },
    { PSP_CTRL_SQUARE, X_RIGHT_BASE-40, Y_RIGHT_BASE+Y_HEIGHT*1+Y_EXTRA, "Square=" },
    { PSP_CTRL_CIRCLE, X_RIGHT_BASE+40, Y_RIGHT_BASE+Y_HEIGHT*2+Y_EXTRA, "Circle=" },
    { PSP_CTRL_CROSS, X_RIGHT_BASE, Y_RIGHT_BASE+Y_HEIGHT*3+Y_EXTRA*2, "Cross=" },

    // bottom row - rotated text (aka "portrait")
    // be careful if you use these
    { PSP_CTRL_HOME, -10, 4, "Home=" },
    { PSP_CTRL_VOLDOWN, -10, 60, "VolDown=" },
    { PSP_CTRL_VOLUP, -10, 120, "VolUp=" },
    { PSP_CTRL_SCREEN, -10, 330, "Screen=" },
    // safer to use
    { PSP_CTRL_NOTE, -10, 365, "Note=" },
    { PSP_CTRL_SELECT, -10, 415, "Select=" },
    { PSP_CTRL_START, -10, 464, "Start=" },

    { 0, 0, 0, NULL } // END
};

static bool DrawButtonPrompt(u32 button, const char* name)
{
    BUTTON_PROMPT_INFO const* pInfo;
    const u32 tagColor = RGB(0, 0, 128);  // not so bright
    const u32 labelColor = COLOR_GREY75;

    for (pInfo = g_buttonPromptInfo; pInfo->tag != NULL; pInfo++)
    {
        if (pInfo->button & button)
        {
            int x = pInfo->x;
            if (pInfo->x >= 0)
            {
                // landscape
                pgPrint1AtPixel(x, pInfo->y, tagColor, pInfo->tag);
                x += 8 * strlen(pInfo->tag);
                pgPrint1AtPixel(x, pInfo->y, labelColor, name);
            }
            else
            {
                // portrait
                x = -x;
                pgPrint1AtPixel_P(x, pInfo->y, tagColor, pInfo->tag);
                x += 8 * strlen(pInfo->tag);
                pgPrint1AtPixel_P(x, pInfo->y, labelColor, name);
            }
            return true;
        }
    }
    return false; // no match
}

//////////////////////////////////////////////////////////////////////
// Common data driven UI

typedef void (*SENDIR_PROC)(int ircode);

static char g_printfBuffer[256];
bool g_printfBufferChanged = false;

static void DoUI(const TABLE_DRIVEN_IR* pUI, SENDIR_PROC sendProc,
        const char* modeName)
{
    g_printfBuffer[0] = '\0'; // purge previous
    u32 buttonsShiftLastUpdate = 0xFFFFFFFF;

    while (1)
    {
        bool bDrawShiftState = false;
        u32 drawnShiftStates = 0; // used if bDrawShiftState
        const char* szSubMode = NULL; // used if bDrawShiftState
            //REVIEW: loop is used for multiple purposes,
            //   perhaps split into two separate loops

        u32 buttonsShift;
        u32 buttons = PollButtons(&buttonsShift);

        if (buttons & PSP_CTRL_HOME)
            break;

        if (buttons == 0)
        {
            // no buttons pressed - update screen if needed
            if (buttonsShift == buttonsShiftLastUpdate &&
                !g_printfBufferChanged)
            {
                sceDisplayWaitVblankStart(); // slow things down a little
                continue;
            }
            bDrawShiftState = true;
            buttonsShiftLastUpdate = buttonsShift;
            g_printfBufferChanged = false;
            pgFillvram(0);
            pgPrint2AtPixel(100, 30, COLOR_WHITE, modeName);
        }

        const TABLE_DRIVEN_IR* pBlock = NULL;
        const TABLE_DRIVEN_IR* p;
        bool bFound = false;

        // walk the array of button state info
        for (p = pUI; p->ircodeEtc != -2; p++)
        {
            if (p->ircodeEtc == -1)
            {
                // new block start
                pBlock = NULL;
                if (p->buttonMask == 0)
                {
                    pBlock = p; // default applies (should be last)
                    if (szSubMode == NULL)
                        szSubMode = pBlock->name;
                }
                else if ((buttonsShift & p->buttonMask) == p->buttonMask)
                {
                    pBlock = p; // it applies
                    szSubMode = pBlock->name;
                }
            }
            else if (pBlock != NULL && !bDrawShiftState && (buttons & p->buttonMask))
            {
                // regular entry with proper shifts, activate the button
                //  (first found)
                printf("\n"); // wipe single line
                (*sendProc)(p->ircodeEtc);
                bFound = true;
                break;
            }
            else if (pBlock != NULL && bDrawShiftState)
            {
                // draw the prompts, only first found per button
                if (!(drawnShiftStates & p->buttonMask))
                {
                    DrawButtonPrompt(p->buttonMask, p->name);
                    drawnShiftStates |= p->buttonMask;
                }
            }
        }

        if (bDrawShiftState)
        {
            if (szSubMode != NULL)
                pgPrint1AtPixel(120, 50, COLOR_WHITE, szSubMode);
            DrawButtonPrompt(PSP_CTRL_HOME, "Exit");
            drawnShiftStates |= PSP_CTRL_HOME;

            // for non-trigger buttons, report shift state modes
            for (p = pUI; p->ircodeEtc != -2; p++)
            {
                if (p->ircodeEtc == -1 && p->buttonMask != 0 &&
                    p->buttonMask != PSP_CTRL_BOTHTRIGGERS &&
                    (buttonsShift & p->buttonMask) == 0 &&
                    ((~drawnShiftStates) & p->buttonMask))
                {
                    char szT[32];
                    sprintf(szT, "*%s", p->name);
                    DrawButtonPrompt(p->buttonMask, szT);
                    drawnShiftStates |= p->buttonMask;
                }
            }

            // one line of 'printf' status info
            pgPrint1AtPixel(130, 60, RGB(0,128,0), g_printfBuffer);

            // wrap up screen update
            pgScreenFlipV();
            pgWaitVn(10);
        }
        sceDisplayWaitVblankStart(); // slow things down a little
    }
}

//////////////////////////////////////////////////////////////////////
// RoboSapien data driven UI

#include "roboir.h"
#define ROBOSAP_FLIP    0x8000 // special case for RoboSapien L<->R

START_TABLE(UI_RoboSapien)
  // table must be organized so most complex shifts are first
  START_BLOCK(PSP_CTRL_BOTHTRIGGERS, "Body Rocking")
    ENTRY(PSP_CTRL_UP, ROBOSAP_LEAN_FORWARD, "Lean Forward")
    ENTRY(PSP_CTRL_DOWN, ROBOSAP_LEAN_FORWARD, "Lean Backward")
    ENTRY(PSP_CTRL_LEFT, ROBOSAP_TILT_BODY_LEFT | ROBOSAP_FLIP, "Lean Left")
    ENTRY(PSP_CTRL_RIGHT, ROBOSAP_TILT_BODY_RIGHT | ROBOSAP_FLIP, "Lean Right")
  END_BLOCK()
  START_BLOCK(PSP_CTRL_LTRIGGER, "Left Arm")
    ENTRY(PSP_CTRL_UP, ROBOSAP_LEFT_ARM_UP | ROBOSAP_FLIP, "L Arm Up")
    ENTRY(PSP_CTRL_DOWN, ROBOSAP_LEFT_ARM_DOWN | ROBOSAP_FLIP, "L Arm Down")
    ENTRY(PSP_CTRL_LEFT, ROBOSAP_LEFT_ARM_OUT | ROBOSAP_FLIP, "L Arm Out")
    ENTRY(PSP_CTRL_RIGHT, ROBOSAP_LEFT_ARM_IN | ROBOSAP_FLIP, "L Arm In")
    ENTRY(PSP_CTRL_TRIANGLE, ROBOSAP_LEFT_HAND_THUMP | ROBOSAP_FLIP, "L Thump")
    ENTRY(PSP_CTRL_SQUARE, ROBOSAP_LEFT_HAND_PICKUP | ROBOSAP_FLIP, "L Pickup")
    ENTRY(PSP_CTRL_CIRCLE, ROBOSAP_LEFT_HAND_THROW | ROBOSAP_FLIP, "L Throw")
    ENTRY(PSP_CTRL_CROSS, ROBOSAP_LEFT_HAND_SWEEP | ROBOSAP_FLIP, "L Sweep")
    ENTRY(PSP_CTRL_NOTE, ROBOSAP_LEFT_HAND_STRIKE_1 | ROBOSAP_FLIP, "L Strike1")
    ENTRY(PSP_CTRL_SELECT, ROBOSAP_LEFT_HAND_STRIKE_2 | ROBOSAP_FLIP, "L Strike2")
    ENTRY(PSP_CTRL_START, ROBOSAP_LEFT_HAND_STRIKE_3 | ROBOSAP_FLIP, "L Strike3")
  END_BLOCK()
  START_BLOCK(PSP_CTRL_RTRIGGER, "Right Arm")
    ENTRY(PSP_CTRL_UP, ROBOSAP_RIGHT_ARM_UP | ROBOSAP_FLIP, "R Arm Up")
    ENTRY(PSP_CTRL_DOWN, ROBOSAP_RIGHT_ARM_DOWN | ROBOSAP_FLIP, "R Arm Down")
    // reverse order of next two
    ENTRY(PSP_CTRL_RIGHT, ROBOSAP_RIGHT_ARM_OUT | ROBOSAP_FLIP, "R Arm Out")
    ENTRY(PSP_CTRL_LEFT, ROBOSAP_RIGHT_ARM_IN | ROBOSAP_FLIP, "R Arm In")
    ENTRY(PSP_CTRL_TRIANGLE, ROBOSAP_RIGHT_HAND_THUMP | ROBOSAP_FLIP, "R Thump")
    ENTRY(PSP_CTRL_SQUARE, ROBOSAP_RIGHT_HAND_PICKUP | ROBOSAP_FLIP, "R Pickup")
    ENTRY(PSP_CTRL_CIRCLE, ROBOSAP_RIGHT_HAND_THROW | ROBOSAP_FLIP, "R Throw")
    ENTRY(PSP_CTRL_CROSS, ROBOSAP_RIGHT_HAND_SWEEP | ROBOSAP_FLIP, "R Sweep")
    ENTRY(PSP_CTRL_NOTE, ROBOSAP_RIGHT_HAND_STRIKE_1 | ROBOSAP_FLIP, "R Strike1")
    ENTRY(PSP_CTRL_SELECT, ROBOSAP_RIGHT_HAND_STRIKE_2 | ROBOSAP_FLIP, "R Strike2")
    ENTRY(PSP_CTRL_START, ROBOSAP_RIGHT_HAND_STRIKE_3 | ROBOSAP_FLIP, "R Strike3")
  END_BLOCK()

  END_BLOCK()
  START_BLOCK(PSP_CTRL_SELECT, "Skits")
    ENTRY(PSP_CTRL_UP, ROBOSAP_BURP, "Burp")
    ENTRY(PSP_CTRL_DOWN, ROBOSAP_HIGH_5, "High 5")
    ENTRY(PSP_CTRL_LEFT, ROBOSAP_BULLDOZER, "Bulldozer")
    ENTRY(PSP_CTRL_RIGHT, ROBOSAP_OOPS, "Fart")
    ENTRY(PSP_CTRL_TRIANGLE, ROBOSAP_WHISTLE, "Whistle")
    ENTRY(PSP_CTRL_CIRCLE, ROBOSAP_TALKBACK, "Talkback")
    ENTRY(PSP_CTRL_SQUARE, ROBOSAP_ROAR, "Roar")
    ENTRY(PSP_CTRL_CROSS, ROBOSAP_WAKEUP, "Wakeup")
  END_BLOCK()
  START_BLOCK(0, "Walking")
    ENTRY(PSP_CTRL_SQUARE, ROBOSAP_STOP, "STOP")
    ENTRY(PSP_CTRL_UP, ROBOSAP_WALK_FORWARD, "Forward")
    ENTRY(PSP_CTRL_DOWN, ROBOSAP_WALK_BACKWARD, "Backward")
    ENTRY(PSP_CTRL_LEFT, ROBOSAP_TURN_LEFT, "Left")
    ENTRY(PSP_CTRL_RIGHT, ROBOSAP_TURN_RIGHT, "Right")
  END_BLOCK()
END_TABLE()

// handle reverse case
void SendRoboSap_normal(int ircode)
{
    send_robosapien(ircode & 0xFF); // no flip
}
void SendRoboSap_reverse(int ircode)
{
    if (ircode & ROBOSAP_FLIP)
        send_robosapien((ircode & 0xFF) ^ 8); // flip
    else
        send_robosapien(ircode & 0xFF); // no flip
}


static void DoRobosapienMode(bool bReverse)
{
    DoUI(UI_RoboSapien,
        bReverse ? SendRoboSap_reverse : SendRoboSap_normal,
        "RoboSapien");
}

//////////////////////////////////////////////////////////////////////
// ICybie data driven UI

START_TABLE(UI_ICybie)

#if 0
  // this needs more testing
  START_BLOCK(PSP_CTRL_RTRIGGER, "Fake Charger")
    ENTRY(PSP_CTRL_START, ICYBIE_START_CHARGER_SEARCH, "StartSearch")
    ENTRY(PSP_CTRL_SELECT, ICYBIE_STOP_CHARGER_SEARCH, "StopSearch")
    ENTRY(PSP_CTRL_UP, ICYBIE_FAKE_CHARGER_CENTER, "Here")
    ENTRY(PSP_CTRL_LEFT, ICYBIE_FAKE_CHARGER_LEFT, "Left")
    ENTRY(PSP_CTRL_RIGHT, ICYBIE_FAKE_CHARGER_RIGHT, "Right")
    ENTRY(PSP_CTRL_DOWN, ICYBIE_FAKE_CHARGER_CENTER, "Here")
  END_BLOCK()

  START_BLOCK(PSP_CTRL_SELECT, "Fake Obstacle")
    ENTRY(PSP_CTRL_UP, ICYBIE_FAKE_TOP_REFLECTION, "Top")
    ENTRY(PSP_CTRL_DOWN, ICYBIE_FAKE_BOTTOM_REFLECTION, "Bottom")
    ENTRY(PSP_CTRL_LEFT, ICYBIE_FAKE_LEFT_REFLECTION, "Left")
    ENTRY(PSP_CTRL_DOWN, ICYBIE_FAKE_RIGHT_REFLECTION, "Right")
  END_BLOCK()
#endif

  START_BLOCK(PSP_CTRL_LTRIGGER, "Remote 7-12")
    ENTRY(PSP_CTRL_UP, ICYBIE_REMOTE7, "#7 - STAY")
    ENTRY(PSP_CTRL_LEFT, ICYBIE_REMOTE8, "#8 - GUARD mode")
    ENTRY(PSP_CTRL_RIGHT, ICYBIE_REMOTE9, "#9 - LISTEN mode")
    ENTRY(PSP_CTRL_DOWN, ICYBIE_REMOTE10, "#10 - ADV. PLAY mode")
    ENTRY(PSP_CTRL_TRIANGLE, ICYBIE_REMOTE11, "#11 - TRAIN VOICE mode")
    ENTRY(PSP_CTRL_SQUARE, ICYBIE_REMOTE12, "#12 - exit mode")
  END_BLOCK()

  START_BLOCK(0, "Remote 1-6")
    ENTRY(PSP_CTRL_UP, ICYBIE_REMOTE1, "#1 - BOW")
    ENTRY(PSP_CTRL_LEFT, ICYBIE_REMOTE2, "#2 - SIT DOWN")
    ENTRY(PSP_CTRL_RIGHT, ICYBIE_REMOTE3, "#3 - HEAD SHAKE")
    ENTRY(PSP_CTRL_DOWN, ICYBIE_REMOTE4, "#4 - TRICK mode")
    ENTRY(PSP_CTRL_TRIANGLE, ICYBIE_REMOTE5, "#5 - PEE")
    ENTRY(PSP_CTRL_SQUARE, ICYBIE_REMOTE6, "#6 - WAG TAIL")
    ENTRY(PSP_CTRL_CIRCLE, ICYBIE_REMOTE_LARGE, "Stop/Enter")
    ENTRY(PSP_CTRL_CROSS, ICYBIE_REMOTE_LARGE, "Stop/Enter")
    ENTRY(PSP_CTRL_START, ICYBIE_REMOTE_SMALL, "power down")
  END_BLOCK()
END_TABLE()

static void DoICybieMode()
{
    DoUI(UI_ICybie, send_icybie, "ICybie");
}

//////////////////////////////////////////////////////////////////////
// Media Center data driven UI

#include "mceir.h"

START_TABLE(UI_MediaCenter)
  START_BLOCK(PSP_CTRL_RTRIGGER, "Menu Navigate")
    ENTRY(PSP_CTRL_UP, MCE_BUTTON_UP, "Menu Up")
    ENTRY(PSP_CTRL_DOWN, MCE_BUTTON_DOWN, "Menu Down")
    ENTRY(PSP_CTRL_LEFT, MCE_BUTTON_LEFT, "Menu Left")
    ENTRY(PSP_CTRL_RIGHT, MCE_BUTTON_RIGHT, "Menu Right")
    ENTRY(PSP_CTRL_TRIANGLE, MCE_BUTTON_BACK, "Back")
    ENTRY(PSP_CTRL_CROSS, MCE_BUTTON_OK, "OK")
    ENTRY(PSP_CTRL_CIRCLE, MCE_BUTTON_OK, "OK")
    ENTRY(PSP_CTRL_SQUARE, MCE_BUTTON_ENTER, "Enter")
  END_BLOCK()

  START_BLOCK(PSP_CTRL_LTRIGGER, "Main Modes")
    ENTRY(PSP_CTRL_CROSS, MCE_BUTTON_LIVETV, "Live TV")
    ENTRY(PSP_CTRL_CIRCLE, MCE_BUTTON_RECTV, "Recorded TV")
    ENTRY(PSP_CTRL_SQUARE, MCE_BUTTON_GUIDE, "Guide")
    ENTRY(PSP_CTRL_START, MCE_BUTTON_GUIDE, "DVD Menu")

  START_BLOCK(0, "TV Watching")
    ENTRY(PSP_CTRL_UP, MCE_BUTTON_VOL_UP, "Vol+")
    ENTRY(PSP_CTRL_DOWN, MCE_BUTTON_VOL_DOWN, "Vol-")
    ENTRY(PSP_CTRL_LEFT, MCE_BUTTON_CH_DOWN, "Channel-")
    ENTRY(PSP_CTRL_RIGHT, MCE_BUTTON_CH_UP, "Channel+")
    ENTRY(PSP_CTRL_START, MCE_BUTTON_EHOME, "MCE Home")
    ENTRY(PSP_CTRL_SELECT, MCE_BUTTON_BACK, "Back")
  END_BLOCK()
END_TABLE()

static void DoMediaCenterMode()
{
    DoUI(UI_MediaCenter, send_media_center, "Media Center");
}

////////////////////////////////////////////////////////////////////
// one line printf - used by ir send procs

#include <stdarg.h>

int my_printf(const char *format, ...)
{
    va_list args;
    va_start(args, format);
    int ret = vsprintf(g_printfBuffer, format, args);
    va_end(args);

    char* pch = strchr(g_printfBuffer, '\n');
    if (pch != NULL)
        *pch = '\0';    // one line only

    g_printfBufferChanged = true;
    return ret;
}

////////////////////////////////////////////////////////////////////
