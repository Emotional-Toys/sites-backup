// media center

void send_media_center(int code8);

//////////////////////////////////////////////////////////////////////
// Media Center codes 
    // only specify last byte of message

#define MCE_BUTTON1 0x01
#define MCE_BUTTON2 0x02
#define MCE_BUTTON3 0x03
#define MCE_BUTTON4 0x04
#define MCE_BUTTON5 0x05
#define MCE_BUTTON6 0x06
#define MCE_BUTTON7 0x07
#define MCE_BUTTON8 0x08
#define MCE_BUTTON9 0x09
  
#define MCE_BUTTON_WHAT 0x00
#define MCE_BUTTON_OK 0x22
#define MCE_BUTTON_LEFT 0x20
#define MCE_BUTTON_RIGHT 0x21
#define MCE_BUTTON_DOWN 0x1F
#define MCE_BUTTON_UP 0x1E
#define MCE_BUTTON_PLAY 0x16
#define MCE_BUTTON_POWER 0x0C
#define MCE_BUTTON_STOP 0x19
#define MCE_BUTTON_REC 0x17
#define MCE_BUTTON_REW 0x15
#define MCE_BUTTON_FWD 0x14
#define MCE_BUTTON_PAUSE 0x18
#define MCE_BUTTON_NEXT 0x1A
#define MCE_BUTTON_PREV 0x1B
#define MCE_BUTTON_EHOME 0x0D
#define MCE_BUTTON_BACK 0x23
#define MCE_BUTTON_GUIDE 0x26
#define MCE_BUTTON_INFO 0x0F
#define MCE_BUTTON_LIVETV 0x25
#define MCE_BUTTON_VIDEO 0x4A
#define MCE_BUTTON_MUSIC 0x47
#define MCE_BUTTON_TV 0x46
#define MCE_BUTTON_PICTURES 0x49
#define MCE_BUTTON_VOL_UP 0x10
#define MCE_BUTTON_VOL_DOWN 0x11
#define MCE_BUTTON_MUTE 0x0E
#define MCE_BUTTON_CH_UP 0x12
#define MCE_BUTTON_CH_DOWN 0x13
#define MCE_BUTTON_ENTER 0x0B
#define MCE_BUTTON_CLEAR 0x0A
#define MCE_BUTTON_DVDMENU 0x24
#define MCE_BUTTON_RECTV 0x48

//////////////////////////////////////////////////////////////////////
