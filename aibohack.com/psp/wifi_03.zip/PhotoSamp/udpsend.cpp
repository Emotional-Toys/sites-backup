// PSP UDP Send
//  primarily for sending image data
// limited to 30KB

#include <stdio.h>
#include <windows.h>    // Sleep
#pragma comment(lib, "wsock32.lib")

#define MAX_DATA_SIZE   30000

// keep UDP file size small to avoid problems

/////////////////////////////////////////////////////////////

WSADATA g_wsaData;

byte g_image[MAX_DATA_SIZE];
int g_cbImage = 0;

/////////////////////////////////////////////////////////////

bool ParseIPAddrString(byte ipAddr[4], const char* szIPAddr)
{
    int b1, b2, b3, b4;
    if (sscanf(szIPAddr, "%d.%d.%d.%d", &b1, &b2, &b3, &b4) != 4)
        return false;
    ipAddr[0] = b1;
    ipAddr[1] = b2;
    ipAddr[2] = b3;
    ipAddr[3] = b4;
    return true;
}

int main(int argc, char* argv[])
{
    if (argc != 4)
    {
	    printf("usage: udpsend psp_ip_address port data_file\n");
        return -1;
    }
    const char* szIPForward = argv[1];
    int port = atoi(argv[2]);
    const char* szDataFile = argv[3];

	byte ipaddrDest[4];
    if (!ParseIPAddrString(ipaddrDest, szIPForward))
    {
        printf("udpsend: Bad IP address\n");
        return -1;
    }


    // load file
    FILE* pf = fopen(szDataFile, "rb");
    if (pf == NULL)
    {
        printf("udpsend: missing data file\n");
        return -1;
    }
    fseek(pf, 0, SEEK_END);
    g_cbImage = ftell(pf);
    fseek(pf, 0, SEEK_SET);
    if (g_cbImage <= 0)
    {
        printf("udpsend: data file too small\n");
        fclose(pf);
        return -1;
    }
    if (g_cbImage > MAX_DATA_SIZE)
    {
        printf("udpsend: data file too big (limited to %d)\n", MAX_DATA_SIZE);
        fclose(pf);
        return -1;
    }
    if (fread(g_image, g_cbImage, 1, pf) != 1)
    {
        printf("udpsend: data read error\n");
        fclose(pf);
        return -1;
    }
    fclose(pf);

// WiFi send

    if (WSAStartup(MAKEWORD(1,1), &g_wsaData) != 0) // windows specific
    {
        printf("udpsend: winsock init error\n");
        return -1;
    }

// general socket stuff
    // send data as on big UDP send to a specific IP address

	SOCKET hSock = socket(AF_INET, SOCK_DGRAM, 0);
    if (hSock == INVALID_SOCKET) 
    {
        printf("udpsend: socket create error\n");
        goto cleanup;
    }

	SOCKADDR_IN sinDest;
	sinDest.sin_family = AF_INET;
	sinDest.sin_port = htons(port);
    sinDest.sin_addr.S_un.S_un_b.s_b1 = ipaddrDest[0];
    sinDest.sin_addr.S_un.S_un_b.s_b2 = ipaddrDest[1];
    sinDest.sin_addr.S_un.S_un_b.s_b3 = ipaddrDest[2];
    sinDest.sin_addr.S_un.S_un_b.s_b4 = ipaddrDest[3];
	
	if (sendto(hSock, (char*)g_image, g_cbImage, 0,
	            (struct sockaddr*)&sinDest, sizeof(sinDest)) != g_cbImage)
    {
        printf("udpsend: sendto error\n");
    }

    // that's all folks...

cleanup:
	WSACleanup(); // windows specific

    return 0;
}


