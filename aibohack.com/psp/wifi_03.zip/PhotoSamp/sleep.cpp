#include <windows.h>

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    if (argc > 1)
	    Sleep(atoi(argv[1]) * 1000);
    return 0;
}
