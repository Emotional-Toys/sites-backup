// CLIE SpyStillCam Watcher

#include "std.h"
#include "util.h"
#include "pg_redux.h"
#include "nlh.h"

#include "spy_protocol.h"

///////////////////////////////////////////////////////////

void TestClieSpyWatcher(const char* szMyIPAddr)
{
    PICKER picker;

    my_initpicker(&picker, "Which CLIE ?");

    if (!my_loadpicks_fromfile(&picker, "ms0:/ipaddr.txt", true))
    {
        // fill in some defaults
        my_addpick(&picker, "10.0.1.100", "", (u32)0x6401000A); 
        my_addpick(&picker, "10.0.1.101", "", (u32)0x6501000A); 
        my_addpick(&picker, "10.0.1.102", "", (u32)0x6601000A); 
    }

    int iAddress = my_picker(&picker);
    if (iAddress == -1)
        return; // abort

    const char* szClieAddr = picker.picks[iAddress].szBig;
    const u8* ip_addr = (u8*)&(picker.picks[iAddress].userData);
            // high byte first

    my_print("CLIE test\n");

    // instructions
    {
        pgFillvram(0);
        pgPrint4( 0,0,COLOR_WHITE, "CLIE Test");
        pgPrint2( 0,2,COLOR_WHITE, "my addr:");
        pgPrint2(12,2,COLOR_WHITE, szMyIPAddr);
        pgPrint2( 0,3,COLOR_WHITE, "CLIE addr:");
        pgPrint2( 12,3,COLOR_WHITE, szClieAddr);
        pgScreenFlipV();
        pgWaitVn(10);
    }

    SOCKET sock = nlhSimpleConnectWithTimeout(SOCK_STREAM /*TCP/IP*/,
        ip_addr, SPY_PORT, 500, nlhDefaultStatusProc, "Connecting...");

    if (sock == INVALID_SOCKET)
    {
        // timeout ?
        pgFillvram(0);
        pgPrint4(0,0,COLOR_WHITE, "Did not find CLIE");
        pgScreenFlipV();
        pgWaitVn(10);
        return;
    }

    pgFillvram(0);
    pgPrint4(0,0,COLOR_WHITE, "Found CLIE");
    pgScreenFlipV();
    pgWaitVn(10);

    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(0); // digital
    u32 buttonsLast = 0;

    while (1) // aibo running loop
    {
        u8 cmd = SPYCMD_GETJPG;
        if (sceNetInetSend(sock, &cmd, 1, 0) != 1)
            break;      // diconnect

        u16 cb16;   // 16 bit size in Intel byte order
        if (nlhRecvBlockTillDone(sock, (u8*)&cb16, 2) != 2)
            break;
        if (cb16 <= 0 || cb16 > MAX_JPEG)
            break;  // something wrong - REVIEW: we should correct/flush/retry

        static u8 buffer[MAX_JPEG];
        if (nlhRecvBlockTillDone(sock, buffer, cb16) != cb16)
            break;

        if (!DecodeJpgAndDisplay(buffer, cb16))
        {
            my_print("DecodeJpgAndDisplay failed for CLIESPY image???\n");
        }

        SceCtrlData pad;
        sceCtrlReadBufferPositive(&pad, 1); 
        u32 buttonsNew = pad.Buttons & ~buttonsLast;
        buttonsLast = pad.Buttons;

        if (buttonsNew & PSP_CTRL_TRIANGLE)
            break;  // stop
    }
        

    sceNetInetClose(sock);
        // REVIEW: shutdown instead ??
    my_print("end of CLIE test\n");
}
