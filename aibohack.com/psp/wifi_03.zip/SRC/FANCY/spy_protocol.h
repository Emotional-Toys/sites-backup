// CLIE SpyStillCam 2.1 protocol
// for more info see:
//   http://www.aibohack.com/clie
// (c) CliePet/PspPet

// SpyStillCam 2.1
#define SPY_PORT 51009
#define SPY_PROTOCOL_VERSION 5

#define SPYCMD_GETVER 0x01
    // return byte version number

// 320x240x16 sent as a JPG
#define SPYCMD_GETJPG 0x10 // return JPG (320x240)
#define MAX_JPEG	30000

// JPEG quality
#define SPYCMD_SETQUAL_10 0x11
#define SPYCMD_SETQUAL_20 0x12
#define SPYCMD_SETQUAL_30 0x13
#define SPYCMD_SETQUAL_40 0x14
#define SPYCMD_SETQUAL_50 0x15
#define SPYCMD_SETQUAL_60 0x16
#define SPYCMD_SETQUAL_70 0x17
#define SPYCMD_SETQUAL_80 0x18
#define SPYCMD_SETQUAL_90 0x19

// camera settings (relatively generic for NX/NZ cameras)
#define SPYCMD_SETWB_0 0x20 // auto (usually)
#define SPYCMD_SETWB_1 0x21
#define SPYCMD_SETWB_2 0x22
#define SPYCMD_SETWB_3 0x23

#define SPYCMD_SETEXP_0 0x28 // -2
#define SPYCMD_SETEXP_1 0x29 // -1
#define SPYCMD_SETEXP_2 0x2A // norm ?
#define SPYCMD_SETEXP_3 0x2B // 1
#define SPYCMD_SETEXP_4 0x2C // 2

#define SPYCMD_SETEFFECT_0 0x30 // off
#define SPYCMD_SETEFFECT_1 0x31
#define SPYCMD_SETEFFECT_2 0x32
#define SPYCMD_SETEFFECT_3 0x33
#define SPYCMD_SETEFFECT_4 0x34

#define SPYCMD_SETZOOM_1 0x40
#define SPYCMD_SETZOOM_2 0x41
#define SPYCMD_SETZOOM_3 0x42

#define SPYCMD_SETCAMLIGHT_0 0x48 // NX80 only
#define SPYCMD_SETCAMLIGHT_1 0x49

/////////////////////////////////////////////////

