// Aibo test image poll

// requires RCodePlus or LifePlus on WiFi connected ERS-210 or ERS-220
// Telemetry interface used, no remote control
//  NOTE: a future separate AiboRemote-like program may be written

#include "std.h"

#include "util.h"
#include "nlh.h"
#include "pg_redux.h"

#include "aibo_telem.h"


///////////////////////////////////////////////////////////
// WiFi polling

// after polling AIBO we get image and color matrix data

static PACKED_YUV10_DATA g_yuv10;  // too big for stack
    // ERS-2x0 packed camera image is 176x144 pixels
           // packed into 10 bits per pixel
    // PSP screen is 480x272

static u8 g_colorImage[CY_COLORIMAGE*CX_COLORIMAGE];


static int PollAiboImage(SOCKET sock)
    // return 1 if ok, 0 if ok but no image ready, -1 on error
{
    u8 cmd = TELEMREQ_GETYUV10;
    u32 cbPacket;
    if (sceNetInetSend(sock, &cmd, 1, 0) != 1)
        return -1; // error
    if (nlhRecvBlockTillDone(sock, (u8*)&cbPacket, 4) != 4)
        return -1; // error
    if (cbPacket == 0)
        return 0;   // no image ready
    if (cbPacket != sizeof(g_yuv10))
        return -1;  // size error -- REVIEW: need non-blocking purge to recover

    if (nlhRecvBlockTillDone(sock, (u8*)&g_yuv10, sizeof(g_yuv10)) != sizeof(g_yuv10))
        return -1;
    if (g_yuv10.sig != SIG_YUV10_DATA)
        return -1;
    return 1;
}

static int PollAiboColor(SOCKET sock)
    // return 1 if ok, 0 if ok but no image ready, -1 on error
{
    u8 cmd = TELEMREQ_GETCOLORIMAGE;
    u32 cbPacket;
    if (sceNetInetSend(sock, &cmd, 1, 0) != 1)
        return -1; // error
    if (nlhRecvBlockTillDone(sock, (u8*)&cbPacket, 4) != 4)
        return -1; // error
    if (cbPacket == 0)
        return 0;   // no image ready
    if (cbPacket != sizeof(g_colorImage))
        return -1;  // size error -- REVIEW: need non-blocking purge to recover

    if (nlhRecvBlockTillDone(sock, (u8*)g_colorImage, sizeof(g_colorImage)) != sizeof(g_colorImage))
        return -1;
    return 1;
}

///////////////////////////////////////////////////////////
// video decoding - custom YUV10 codec (10 bits per pixel)
// a lot of ugly code you can mostly ignore

inline u8 limit(int v)
{
    if (v < 0)
        return 0;
    else if (v > 255)
        return 255;
    else
        return (u8)v;
}

#define EMIT(_b) \
    *pbOut++ = (u8)((_b) << 3); \
    if (bDouble) \
        *pbOut++ = (u8)((_b) << 3);

static void expand5(u8* pbOut, const u8* pbIn, /*bool*/int bDouble)
{
    // expand 5 bits to 8
    // u8* pbOutExpected = pbOut + CX_FULLIMAGE*CY_FULLIMAGE_PACKED;

    int cbIn = PACKED_FIVEBITS;
    if (bDouble)
        cbIn = cbIn / 2;    // half as many input u8s, same output
    while (cbIn > 0)
    {
        u8 b, bIn;
        bIn = *pbIn++;
        b = (u8)((bIn) & 0x1F);
        EMIT(b);
        b = (u8)((bIn >> 5));
        bIn = *pbIn++;
        b = (u8)(((bIn << 3) | b) & 0x1F);
        EMIT(b);
        b = (u8)((bIn >> 2) & 0x1F);
        EMIT(b);
        b = (u8)((bIn >> 7));
        bIn = *pbIn++;
        b = (u8)(((bIn << 1) | b) & 0x1F);
        EMIT(b);
        b = (u8)(bIn >> 4);
        bIn = *pbIn++;
        b = (u8)(((bIn << 4) | b) & 0x1F);
        EMIT(b);
        b = (u8)((bIn >> 1) & 0x1F);
        EMIT(b);
        b = (u8)((bIn >> 6));
        bIn = *pbIn++;
        b = (u8)(((bIn << 2) | b) & 0x1F);
        EMIT(b);
        b = (u8)((bIn >> 3) & 0x1F);
        EMIT(b);
        cbIn -= 5;
    }
}

#define MyMul(factor, intVal) (((int)(factor*64) * (intVal)) / 64)

#define X_START ((SCREEN_WIDTH - CX_FULLIMAGE)/2)
#define Y_START ((SCREEN_HEIGHT - CY_FULLIMAGE)/2)
#define X_START2 ((SCREEN_WIDTH - CX_FULLIMAGE*2)/2)

static void DrawToScreen(const u8* pbY, const u8* pbV, const u8* pbU, int bDoubleImage)
{
    u32* pBase;
    int cyMax;
    int y;
    if (bDoubleImage)
    {
        // can't fit it all in - full screen height
        pBase = pgGetVramAddr(X_START2, 0);
        cyMax = (SCREEN_HEIGHT / 2);
            //  (7 or 8 good lines truncated - all from the bottom)
    }
    else
    {
        // 1:1 size
        pBase = pgGetVramAddr(X_START, Y_START);
        cyMax = CY_FULLIMAGE - 1;
            // drop last line since it includes crap
    }

    for (y = 0; y < cyMax; y++)
    {
        u32* pDraw = pBase + (DRAW_LINESIZE * y) * (bDoubleImage ? 2 : 1);
        u32* pDraw2 = pDraw + DRAW_LINESIZE;
        int x;
        for (x = 0; x < CX_FULLIMAGE; x++)
        {
            int Y = *pbY++;
            int vS = (*pbV++) - 128;
            int uS = (*pbU++) - 128;

            // YUV implementation with fixed point math
            int r = Y + MyMul(1.4075, vS);
            int g = Y - MyMul(0.3455, uS) - MyMul(0.7169, vS);
            int b = Y + MyMul(1.7790, uS);

            u32 color = 0xFF000000 |
                (limit(b) << 16) | (limit(g) << 8) | limit(r);
            *pDraw++ = color;
            if (bDoubleImage)
            {
                *pDraw++ = color;
                *pDraw2++ = color;
                *pDraw2++ = color;
            }
        }
    }
}


static void DrawAiboImage(int bDoubleImage)
{
    // large temporary data
    static u8 rgbY[CX_FULLIMAGE*CY_FULLIMAGE_PACKED];
    static u8 rgbV[CX_FULLIMAGE*CY_FULLIMAGE_PACKED];
    static u8 rgbU[CX_FULLIMAGE*CY_FULLIMAGE_PACKED];

    // yuv decode
    expand5(rgbY, g_yuv10.compressedY, 0);    //  not double
    expand5(rgbU, g_yuv10.compressedU, 1);
    expand5(rgbV, g_yuv10.compressedV, 1);

    DrawToScreen(rgbY, rgbV, rgbU, bDoubleImage);
}

///////////////////////////////////////////////////////////
// Color detection matrix - displayed as lower res color image

#define COLOR_CDT0    RGB(255, 0, 0)        // red
#define COLOR_CDT1    RGB(255, 81, 146) // pink
#define COLOR_CDT4    RGB(135, 114, 255) // blue/FAV
#define COLOR_CDT5    RGB(151, 255, 54) // green/UNFAV
#define COLOR_CDT6    RGB(180, 121, 88) // fleshy

static void DrawColorImage(int xLeft, int yTop, u32 color, u8 mask)
{
    // assumes g_colorImage filled in with data
    u32* pRow = pgGetVramAddr(xLeft, yTop);
    u8* pb = g_colorImage;
    int y;
    for (y = 0; y < CY_COLORIMAGE; y++)
    {
        u32* pDraw = pRow;
        int x;
        for (x = 0; x < CX_COLORIMAGE; x++)
        {
            if ((*pb++) & mask)
                *pDraw++ = color;
            else
                *pDraw++ = 0;   // black
        }
        pRow += DRAW_LINESIZE;
    }
}

///////////////////////////////////////////////////////////


void TestAiboPoll(const char* szMyIPAddr)
{
    my_print("AIBO test\n");

    // hard coded AIBO IP address - must be on same net
    PICKER picker;

    my_initpicker(&picker, "Which AIBO ?");
    if (!my_loadpicks_fromfile(&picker, "ms0:/ipaddr.txt", true))
    {
        // fill in some defaults
        my_addpick(&picker, "10.0.1.100", "default WLANCONF.TXT", (u32)0x6401000A); 
        my_addpick(&picker, "10.0.1.101", "", (u32)0x6501000A); 
        my_addpick(&picker, "10.0.1.102", "", (u32)0x6601000A); 
    }

    int iAddress = my_picker(&picker);
    if (iAddress == -1)
        return; // abort

    const char* szAiboAddr = picker.picks[iAddress].szBig;
    const u8* ip_addr = (u8*)&(picker.picks[iAddress].userData);
            // high byte first

    // instructions
    {
        pgFillvram(0);
        pgPrint4( 0,0,COLOR_WHITE, "AIBO Test");
        pgPrint2( 0,2,COLOR_WHITE, "my addr:");
        pgPrint2(12,2,COLOR_WHITE, szMyIPAddr);
        pgPrint2( 0,3,COLOR_WHITE, "AIBO addr:");
        pgPrint2( 12,3,COLOR_WHITE, szAiboAddr);
        pgScreenFlipV();
        pgWaitVn(10);
    }

    SOCKET sock = nlhSimpleConnectWithTimeout(SOCK_STREAM /*TCP/IP*/,
        ip_addr, TELEMETRY_PORT, 500, nlhDefaultStatusProc, "Connecting...");

    if (sock == INVALID_SOCKET)
    {
        // timeout or other error
        pgFillvram(0);
        pgPrint4(0,0,COLOR_WHITE, "Did not find AIBO");
        pgScreenFlipV();
        pgWaitVn(10);
        return;
    }

    // connected

    pgFillvram(0);
    pgPrint4(0,0,COLOR_WHITE, "Found AIBO");
    pgScreenFlipV();
    pgWaitVn(10);

    u32 buttonsLast = 0;
    int bDoubleImage = 0;
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(0); // digital

//REVIEW: can we change the recv timeout?
    while (1) // aibo running loop
    {
        u32 buttonsNew;
        SceCtrlData pad;

        pgFillvram(COLOR_GREY25);

        int n = PollAiboImage(sock);
        if (n < 0)
            break; // stop on error
        if (n > 0)
            DrawAiboImage(bDoubleImage);

        if (!bDoubleImage)
        {
            if (PollAiboColor(sock) > 0)
            {
                DrawColorImage(0, 0, COLOR_CDT0, 0x01);
                DrawColorImage(0, CY_COLORIMAGE+4, COLOR_CDT1, 0x01);

                DrawColorImage(SCREEN_WIDTH-CX_COLORIMAGE, 0, COLOR_CDT4, 0x10);
                DrawColorImage(SCREEN_WIDTH-CX_COLORIMAGE, CY_COLORIMAGE+4, COLOR_CDT5, 0x20);
                DrawColorImage(SCREEN_WIDTH-CX_COLORIMAGE, 2*(CY_COLORIMAGE+4), COLOR_CDT6, 0x40);
            }
        }
        // done drawing this frame
        pgScreenFlipV();

        sceCtrlReadBufferPositive(&pad, 1); 
        buttonsNew = pad.Buttons & ~buttonsLast;
        buttonsLast = pad.Buttons;

        if (buttonsNew & PSP_CTRL_TRIANGLE)
            break;  // stop
        if (buttonsNew & PSP_CTRL_CIRCLE)
            bDoubleImage = 1;
        if (buttonsNew & PSP_CTRL_SQUARE)
            bDoubleImage = 0;
    }
    sceNetInetClose(sock);
        // REVIEW: shutdown instead ??

    my_print("end of AIBO test\n");
}
