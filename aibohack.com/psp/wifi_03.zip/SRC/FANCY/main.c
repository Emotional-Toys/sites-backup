// WiFi Multi-Test app
// .03 - user mode thread refactoring
// with thanks to 'benji'

// see "WiFi Simple .03" for a simpler example

#include "std.h"

#include "pg_redux.h"
#include "util.h"

#include "nlh.h" // net lib helper

////////////////////////////////////////////////////

//NOTE: kernel mode module flag and kernel mode thread are both required
PSP_MODULE_INFO("WIFI_TEST_APP", 0x1000, 1, 1); /* 0x1000 REQUIRED!!! */
PSP_MAIN_THREAD_ATTR(0); /* 0 REQUIRED!!! */
PSP_MAIN_THREAD_STACK_SIZE_KB(32); /* smaller stack for kernel thread */

static void DoInetNetTest(); // web access
int user_main(SceSize args, void* argp);

int main(void)
{
    // kernel mode thread
    pgInit32(); // RGB color version - double buffering

    {
        pgFillvram(0);
        pgPrint4(0,1,COLOR_WHITE,"WiFi MultiTest");
        pgPrint4(0,3,COLOR_GREY50,"Version .03");
        pgPrint4(0,4,COLOR_GREY50," (by PspPet)");
        pgScreenFlipV();
        pgWaitVn(10);
    }

    my_print_init();
    my_print("WiFi modules loading\n");

    if (nlhLoadDrivers(&module_info) != 0)
    {
        my_print("Net driver load error\n");
        return 0;
    }

    // create user thread, tweek stack size here if necessary
    SceUID thid = sceKernelCreateThread("User Mode Thread", user_main,
            0x11, // default priority
            256 * 1024, // stack size (256KB is regular default)
            PSP_THREAD_ATTR_USER, NULL);

    // start user thread, then wait for it to do everything else
    sceKernelStartThread(thid, 0, NULL);
    sceKernelWaitThreadEnd(thid, NULL);

    sceKernelExitGame();
    return 0;
}

int user_main(SceSize args, void* argp)
{
    // user mode thread does all the real work

    DoInetNetTest();
    return 0;
}

////////////////////////////////////////////////////
// The tests

static void TestMiniTelnetD(const char* szMyIPAddr);
static void TestPhotoFrame(const char* szMyIPAddr);

// see aibo.c
extern void TestAiboPoll(const char* szMyIPAddr);
// see cliespy.c
extern void TestClieSpyWatcher(const char* szMyIPAddr);

////////////////////////////////////////////////////
// the main test routine - pick connection, connect, ask which tests to run

static void DoInetNetTest()
{
    u32 err;
    int state;
    char szMyIPAddr[32];
    int connectionConfig = -1;
    int iTest = 0;

    // nlhInit must be called from user thread for DHCP to work
    err = nlhInit();
    my_printn("nlhInit returns ", err, "\n");

    if (err != 0)
    {
        nlhTerm();
        return;
    }

    // enumerate connections
    {
        PICKER pickConn; // connection picker
        int iNetIndex;
        int iPick;

        my_initpicker(&pickConn, "Pick Connection");
        for (iNetIndex = 1; iNetIndex < 100; iNetIndex++) // skip the 0th connection
        {
            char data[128];
            char name[128];
            char detail[128];
            if (sceUtilityCheckNetParam(iNetIndex) != 0)
                break;  // no more
            // my_printn8("config ", (u8)iNetIndex, "\n");
            sceUtilityGetNetParam(iNetIndex, 0, name);
            // my_print(" NAME='"); my_print(name); my_print("'\n");

            sceUtilityGetNetParam(iNetIndex, 1, data);
            strcpy(detail, "SSID=");
            strcat(detail, data);

            sceUtilityGetNetParam(iNetIndex, 4, data);
            if (data[0])
            {
                // not DHCP
                sceUtilityGetNetParam(iNetIndex, 5, data);
                strcat(detail, " IPADDR=");
                strcat(detail, data);
            }
            else
            {
                strcat(detail, " DHCP");
            }

            my_addpick(&pickConn, name, detail, (u32)iNetIndex);

            if (pickConn.pick_count >= MAX_PICK)
                break;  // no more
        }

        if (pickConn.pick_count == 0)
        {
            pgFillvram(0);
            pgPrint4(0,1,COLOR_WHITE, "no connections");
            pgPrint4(0,3,COLOR_WHITE, "please create");
            pgPrint4(0,4,COLOR_WHITE, "connection with");
            pgPrint4(0,5,COLOR_WHITE, "static IP addr");
            pgScreenFlipV();
            pgWaitVn(200);
            goto close_net;
        }

        iPick = my_picker(&pickConn);
        if (iPick == -1)
            goto close_net; // give up
        connectionConfig = (int)(pickConn.picks[iPick].userData);
    }

    my_printn("using connection ", connectionConfig, "\n");

    // try first connection
    err = sceNetApctlConnect(connectionConfig);
    my_printn("sceNetApctlConnect returns ", err, "\n");
    if (err != 0)
        goto close_net;

    state = 0;
    err = sceNetApctlGetState(&state);
    my_printn("getstate: err=", err, ", ");
    my_printn("state=", state, "\n");
    if (err != 0)
        goto close_connection;

    // 4 connected with IP address
    while (1)
    {
        char szT[32];
        int state;

        err = sceNetApctlGetState(&state);
        if (err != 0)
        {
            my_printn("sceNetApctlGetState returns ", err, "\n");
            goto close_connection;
        }
        pgFillvram(0);
        pgPrint4(0,1,COLOR_WHITE, "Connecting");
        if (state >= 0 && state <= 4)
        {
            // cute little status bar
            memset(szT, '+', 10);
            szT[(state+1)*2] = '\0';
        }
        else
            sprintf(szT, "state=%d", state);
        pgPrint4(0,2,COLOR_WHITE, szT);

        pgScreenFlipV();
        pgWaitVn(50);

        // 0 - idle
        // 1,2 - starting up
        // 3 - waiting for dynamic IP
        // 4 - got IP - usable
        if (state == 4)
            break;  // connected with static IP
    }

    // get IP address
    {
        if (sceNetApctlGetInfo(8, szMyIPAddr) != 0)
            strcpy(szMyIPAddr, "unknown IP address");

        my_print("sceNetApctlGetInfo #8: ipaddr=");
        my_print(szMyIPAddr);
        my_print("\n");
    }

    while (1)
    {
        typedef void (*TEST_PROC)(const char* szIPAddr);
        TEST_PROC testProc;

        PICKER pickTest; // room for title + 5 picks
        my_initpicker(&pickTest, "== Pick Test ==");
        my_addpick(&pickTest, "Mini TelnetD", "mini telnet-like test PC->PSP",
                (u32)TestMiniTelnetD);
        my_addpick(&pickTest, "Photo Frame", "UDP JPG images PC->PSP",
                (u32)TestPhotoFrame);
        my_addpick(&pickTest, "Aibo Poll", "TCP image and remote AIBO->PSP",
                (u32)TestAiboPoll);
        my_addpick(&pickTest, "CLIE SpyWatch", "TCP JPG images CLIE->PSP",
                (u32)TestClieSpyWatcher);
        my_addpick(&pickTest, "Exit", "end tests",
                (u32)NULL);

        pickTest.pick_start = iTest;
        iTest = my_picker(&pickTest);

        if (iTest == -1)
            continue;   // ignore triangle - don't exit unless "Exit" picked

        testProc = (TEST_PROC)(pickTest.picks[iTest].userData);

        if (testProc == NULL)
            break;  // EXIT

        // run the test
        (*testProc)(szMyIPAddr);
    }

close_connection:
    err = sceNetApctlDisconnect();
    my_printn("sceNetApctlDisconnect returns ", err, "\n");

close_net:
    nlhTerm();
}

//////////////////////////////////////////////////////////////////////
// Simple test - TCP/IP server - a fake telnetd

static void TestMiniTelnetD(const char* szMyIPAddr)
{
    u32 err;

    // instructions
    {
        pgFillvram(0);
        pgPrint4(0,1,COLOR_WHITE, "Connected");
        pgPrint4(0,3,COLOR_WHITE, "telnet to");
        pgPrint4(0,4,COLOR_WHITE, szMyIPAddr);
        pgPrint4(0,5,COLOR_WHITE, "port 23");
        pgScreenFlipV();
        pgWaitVn(10);
    }

    // mini telnetd-lite server
    {
        SOCKET sockListen;
        struct sockaddr_in addrListen;
        struct sockaddr_in addrAccept;
        int cbAddrAccept;
        SOCKET sockClient;

        sockListen = sceNetInetSocket(AF_INET, SOCK_STREAM, 0);
        my_printn("socket returned ", sockListen, "\n");
        if (sockListen & 0x80000000)
            goto done;

        addrListen.sin_family = AF_INET;
        addrListen.sin_port = htons(23);
        addrListen.sin_addr[0] = 0;
        addrListen.sin_addr[1] = 0;
        addrListen.sin_addr[2] = 0;
        addrListen.sin_addr[3] = 0;
            // any

        err = sceNetInetBind(sockListen, &addrListen, sizeof(addrListen));
        my_printn("bind returned ", err, "\n");
        my_printn("  errno=", sceNetInetGetErrno(), "\n");
        if (err)
            goto done;

        err = sceNetInetListen(sockListen, 1);
        my_printn("listen returned ", err, "\n");
        my_printn("  errno=", sceNetInetGetErrno(), "\n");
        if (err)
            goto done;

        // blocking accept (wait for one connection)
        cbAddrAccept = sizeof(addrAccept);
        sockClient = sceNetInetAccept(sockListen, &addrAccept, &cbAddrAccept);
        my_printn("accept returned ", err, "\n");
        my_printn("  errno=", sceNetInetGetErrno(), "\n");
        my_printn("  cb=", cbAddrAccept, "\n");
        if (sockClient & 0x80000000)
            goto done;

        err = sceNetInetSend(sockClient, "Hello from PSP\n\r", 14+2, 0);
        err = sceNetInetSend(sockClient, "type all you want\n\r", 17+2, 0);

        // lame processing loop
        {
            // we draw using the medium pg2 font
            // 30 x 19 characters
            const int maxChars = 30*19;
            char telnet_string[maxChars+1];
            memset(telnet_string, ' ', maxChars); // start with blanks
            telnet_string[maxChars] = '\0';

            int insertPoint = 0;

            while (1)
            {
                int cch;
                cch = sceNetInetRecv(sockClient,
                    (u8*)telnet_string+insertPoint,
                    maxChars-insertPoint, 0);
                if (cch <= 0)
                    break; // usually connection dropped
                insertPoint += cch;
                if (insertPoint >= maxChars)
                    insertPoint = 0;    // start over at top of the screen

                pgFillvram(0);
                pgPrint2(0,0,COLOR_WHITE,telnet_string);
                        // this does line wrap for us
                pgScreenFlipV();
            }
        }
        err = sceNetInetClose(sockClient);
            // REVIEW: shutdown() instead ?
        my_printn("closesocket(client) returned ", err, "\n");

done:
        // done for now
        err = sceNetInetClose(sockListen);
        my_printn("closesocket returned ", err, "\n");
    }
}

//////////////////////////////////////////////////////////////////////
// Simple test - UDP/IP server - a photo frame

#define MAX_UDP_SAFE_BUFFER 30000
// UDP data size note:
// UDP can only handle certain sizes
//  30KB is usually good enough for 480x272 JPGs
//  (NOTE: same "MAX_JPEG" size used by ClieSpy protocol)
// the RCVBUF size reports $A280 (41,600 bytes) but over 32KB gave me problems
// if you need a larger size, plan on some experimentation/testing

static void TestPhotoFrame(const char* szMyIPAddr)
{
    u32 err;

    // instructions
    {
        pgFillvram(0);
        pgPrint4(0,1,COLOR_WHITE, "udpsend");
        pgPrint4(1,3,COLOR_WHITE, "jpg to");
        pgPrint4(2,4,COLOR_WHITE, szMyIPAddr);
        pgPrint4(3,5,COLOR_WHITE, "port 100");
        pgScreenFlipV();
        pgWaitVn(10);
    }

    // mini udp listener
    {
        SOCKET sockListen;
        struct sockaddr_in addrListen;

        SceCtrlData pad;
        u32 buttonsLast;
        sceCtrlSetSamplingCycle(0);
        sceCtrlSetSamplingMode(0); // digital
        sceCtrlReadBufferPositive(&pad, 1); 
        buttonsLast = pad.Buttons;

        // open UDP/IP port ("Datagram")
        sockListen = sceNetInetSocket(AF_INET, SOCK_DGRAM, 0);
        my_printn("socket returned ", sockListen, "\n");
        if (sockListen & 0x80000000)
            goto done;

        addrListen.sin_family = AF_INET;
        addrListen.sin_port = htons(100); // port 100 - arbitrary
        addrListen.sin_addr[0] = 0;
        addrListen.sin_addr[1] = 0;
        addrListen.sin_addr[2] = 0;
        addrListen.sin_addr[3] = 0;
            // any connection

        err = sceNetInetBind(sockListen, &addrListen, sizeof(addrListen));
        my_printn("bind returned ", err, "\n");
        my_printn("  errno=", sceNetInetGetErrno(), "\n");
        if (err)
            goto done;

        while (1)
        {
            u32 buttonsNew;
            sceCtrlReadBufferPositive(&pad, 1); 
            buttonsNew = pad.Buttons & ~buttonsLast;
            buttonsLast = pad.Buttons;

            if (buttonsNew & PSP_CTRL_TRIANGLE)
                break;  // stop

            static u8 buffer[MAX_UDP_SAFE_BUFFER];
            struct sockaddr_in addrFrom;
            int cbAddrFrom = sizeof(addrFrom);
            u32 cb;
            cb = sceNetInetRecvfrom(sockListen, buffer, sizeof(buffer), 0,
                            &addrFrom, &cbAddrFrom);
            my_printn("recvfrom returned ", cb, "\n");
            my_printn("  errno=", sceNetInetGetErrno(), "\n");

            if (cb > 0)
            {
                if (!DecodeJpgAndDisplay(buffer, cb))
                {
                    // function displays error message on screen
                    my_print("DecodeJpegAndDisplay for photo frame failed\n");
                }
            }
            else if (cb == -1)
            {
                // something catastrophic - don't try again
                // socket receive is locked up
                //REVIEW: handle this better ??
                break;
            }
        }
done:
        // done for now
        err = sceNetInetClose(sockListen);
        my_printn("closesocket returned ", err, "\n");
    }
}
