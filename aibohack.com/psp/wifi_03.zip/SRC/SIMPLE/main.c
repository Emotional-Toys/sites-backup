// WiFi Simple test app .03

#include "std.h"
#include "nlh.h" // net lib helper

//////////////////////////////////////////////////////////////////////

//NOTE: kernel mode module flag and kernel mode thread are both required
PSP_MODULE_INFO("WIFI_TEST_APP", 0x1000, 1, 1); /* 0x1000 REQUIRED!!! */
PSP_MAIN_THREAD_ATTR(0); /* 0 REQUIRED!!! */
PSP_MAIN_THREAD_STACK_SIZE_KB(32); /* smaller stack for kernel thread */

int user_main(SceSize args, void* argp);

int main(void)
{
    // Kernel mode thread
    pspDebugScreenInit();

    printf("WiFi Simple .03\n");
    printf("  (by PspPet)\n");
    printf("\n");

    if (nlhLoadDrivers(&module_info) != 0)
    {
        printf("Driver load error\n");
        return 0;
    }

    // create user thread, tweek stack size here if necessary
    SceUID thid = sceKernelCreateThread("User Mode Thread", user_main,
            0x11, // default priority
            256 * 1024, // stack size (256KB is regular default)
            PSP_THREAD_ATTR_USER, NULL);

    // start user thread, then wait for it to do everything else
    sceKernelStartThread(thid, 0, NULL);
    sceKernelWaitThreadEnd(thid, NULL);

    sceKernelExitGame();
    return 0;
}

//////////////////////////////////////////////////////////////////////

static void TestMiniTelnetD(const char* szMyIPAddr);

int user_main(SceSize args, void* argp)
{
    // user mode thread does all the real work
    u32 err;
    int connectionConfig = -1;

    // nlhInit must be called from user thread for DHCP to work
    err = nlhInit();
    if (err != 0)
    {
        printf("WiFi Init error\n");
        printf("nlhInit returns $%x\n", err);
        printf("Please check Network Settings\n");
        sceKernelDelayThread(10*1000000); // 10sec to read before exit
        goto close_net;
    }

    // enumerate connections
#define MAX_PICK 10
    struct
    {
        int index;
        char name[64];
    } picks[MAX_PICK];
    int pick_count = 0;

    int iNetIndex;
    for (iNetIndex = 1; iNetIndex < 100; iNetIndex++) // skip the 0th connection
    {
        if (sceUtilityCheckNetParam(iNetIndex) != 0)
            break;  // no more
        sceUtilityGetNetParam(iNetIndex, 0, picks[pick_count].name);
        picks[pick_count].index = iNetIndex;
        pick_count++;
        if (pick_count >= MAX_PICK)
            break;  // no more room
    }

    if (pick_count == 0)
    {
        printf("No connections\n");
        printf("Please try Network Settings\n");
        sceKernelDelayThread(10*1000000); // 10sec to read before exit
        goto close_net;
    }

    printf("Found %d possible connections\n", pick_count);
#ifdef LATER
    if (pick_count > 1)
    {
        // customize user interface to let user pick
    }
#endif

    printf(" using the first one '%s'\n", picks[0].name);
    connectionConfig = picks[0].index;


    // Connect
    printf("using connection #%d\n", connectionConfig);
    err = sceNetApctlConnect(connectionConfig);
    if (err != 0)
    {
        printf("sceNetApctlConnect returns $%x\n", err);
        sceKernelDelayThread(10*1000000); // 10sec to read before exit
        goto close_net;
    }

    // Report status while waiting for connection to access point
    int stateLast = -1;
    printf("Connecting...\n");
    while (1)
    {
        int state;
        err = sceNetApctlGetState(&state);
        if (err != 0)
        {
            printf("sceNetApctlGetState returns $%x\n", err);
            sceKernelDelayThread(10*1000000); // 10sec to read before exit
            goto close_connection;
        }
        if (state > stateLast)
        {
            printf("  connection state %d of 4\n", state);
            stateLast = state;
        }
        if (state == 4)
            break;  // connected with static IP

        // wait a little before polling again
        sceKernelDelayThread(50*1000); // 50ms
    }
    printf("Connected!\n");

    // connected, get my IPADDR and run test
    char szMyIPAddr[32];
    if (sceNetApctlGetInfo(8, szMyIPAddr) != 0)
        strcpy(szMyIPAddr, "unknown IP address");
    printf("my IPADDR = %s\n", szMyIPAddr);

    TestMiniTelnetD(szMyIPAddr);

    // all done

close_connection:
    err = sceNetApctlDisconnect();
    if (err != 0)
        printf("sceNetApctlDisconnect returns $%x\n", err);

close_net:

    nlhTerm();

    printf("Program exiting\n");
    sceKernelDelayThread(4*1000000); // 4sec to read any final status

    return 0;
}

//////////////////////////////////////////////////////////////////////
// Simple test - TCP/IP server - a fake telnetd

static void TestMiniTelnetD(const char* szMyIPAddr)
{
    u32 err;

    // instructions
    pspDebugScreenClear();
    printf("Connected!\n");
    printf("  telnet to %s port 23\n", szMyIPAddr);
    printf("\n");

    // mini telnetd-lite server
    {
        SOCKET sockListen;
        struct sockaddr_in addrListen;
        struct sockaddr_in addrAccept;
        int cbAddrAccept;
        SOCKET sockClient;

        sockListen = sceNetInetSocket(AF_INET, SOCK_STREAM, 0);
        if (sockListen <= 0)
        {
            printf("socket returned $%x\n", sockListen);
            goto done;
        }

        addrListen.sin_family = AF_INET;
        addrListen.sin_port = htons(23);
        addrListen.sin_addr[0] = 0;
        addrListen.sin_addr[1] = 0;
        addrListen.sin_addr[2] = 0;
        addrListen.sin_addr[3] = 0;
            // any

        err = sceNetInetBind(sockListen, &addrListen, sizeof(addrListen));
        if (err != 0)
        {
            printf("bind returned $%x\n", err);
            printf("  errno=$%x\n", sceNetInetGetErrno());
            goto done;
        }

        err = sceNetInetListen(sockListen, 1);
        if (err != 0)
        {
            printf("listen returned $%x\n", err);
            printf("  errno=$%x\n", sceNetInetGetErrno());
            goto done;
        }

        // blocking accept (wait for one connection)
        cbAddrAccept = sizeof(addrAccept);
        sockClient = sceNetInetAccept(sockListen, &addrAccept, &cbAddrAccept);
        if (sockClient <= 0)
        {
            printf("accept returned $%x\n", err);
            printf("  errno=$%x\n", sceNetInetGetErrno());
            goto done;
        }

        sceNetInetSend(sockClient, "Hello from PSP\n\r", 14+2, 0);
        sceNetInetSend(sockClient, "type all you want\n\r", 17+2, 0);
            // send returns number of bytes sent

        // This example uses socket timeouts "RCVTIMEO"
        // See the fancy version of WiFi MultiTest for similar telnet-d
        //  without the timeout

        // warning - not all values will work (please confirm experimentally)
        u32 timeout = 1000000; // in microseconds == 1 sec
        err = sceNetInetSetsockopt(sockClient, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout));
        if (err != 0)
            printf("set SO_RCVTIMEO failed\n");

#if 0
        // check the current setting
        {
        u32 data;
        int len;
        err = sceNetInetGetsockopt(sockClient, SOL_SOCKET, SO_RCVTIMEO,
            (char*)&data, &len);
        if (err == 0 && len == 4)
            printf("Get SO_RCVTIMEO = %d ($%x)\n", data, data);
        }
        // NOTE: returns "100"
#endif

        // lame processing loop
        int idleCount = 0; // number of seconds of idle
        while (1)
        {
            char buffer[128];
            int cch;
            cch = sceNetInetRecv(sockClient, (u8*)buffer, sizeof(buffer)-1, 0);
            if (cch == 0)
                break;      // connection closed

            if (cch < 0)
            {
                int errno = sceNetInetGetErrno();
                if (errno == 11)
                {
                    // recv timeout
                    if (++idleCount >= 15)
                    {
                        // nag
                        sceNetInetSend(sockClient, " [I'm waiting ] ", 16+2, 0);
                        idleCount = 0;
                    }
                    continue; // call recv again
                }
                // other problem
                printf("recv failed errno=$%x\n", sceNetInetGetErrno());
                break;
            }
            buffer[cch] = '\0';
            printf("%s", buffer);
            idleCount = 0;
        }
        printf("\n");

        err = sceNetInetClose(sockClient);
        if (err != 0)
            printf("closesocket(client) returned $%x\n", err);
        printf("Connection closed\n");

done:
        // done for now
        err = sceNetInetClose(sockListen);
        if (err != 0)
            printf("closesocket returned $%x\n", err);
    }
}

//////////////////////////////////////////////////////////////////////
