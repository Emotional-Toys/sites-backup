#include <pspkernel.h>
#include <pspctrl.h>
#include <pspdisplay.h>
#include <pspdebug.h>

#include <pspiofilemgr.h>
#include <pspiofilemgr_fcntl.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define bool int
#define false 0
#define true 1

#define printf pspDebugScreenPrintf
