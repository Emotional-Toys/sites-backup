PSAR Dumper Version 2B (.02B)
    A tool to help legal reverse engineering of the PSP system components.
    Extracts the contents of the update data file, and saves them as
    separate files on memory stick.
    When it can, it will also automatically decrypt the .PRX files
    (like the PSPSDK PRXDecrypter tool)

    Advanced expert tool.

Legal Note:
    The files you download (ie. the updater EBOOT.PBP) and the files
    extracted by this tool (ie. the contents of the OUT and OUTX folders)
    are all Sony copyrighted material !!

    You can use them under certain "fair uses".
    Do not post these files on the Internet.

    Use this tool at your own risk!

    The tool itself contains no Sony copyrighted material.

Instructions:
    You will need a memory stick with around 30MB free
    You will need a homebrew compatible PSP (1.0 or 1.50 firmware)

    Install the right version of the software:
        RUN10 - copy contents to memory stick for 1.0 PSP
        RUN15 - copy contents to memory stick for 1.5 PSP

    Find an EBOOT.PBP for the system update you want to decode.
    They are available on the web.
    This version is recommended for decrypting the 2.0 update.

    NOTE: if you can't find them, you probably shouldn't be using this tool.

    Do not copy the update EBOOT.PBP to the PSP!!!
    Instead extract the components using "unpack-pbp" or other similar tool.
    You want the PSAR file, usually called "UNKNOWN.PSAR" or "DATA.PSAR"

    NOTE: if you have never used 'unpack-pbp' or a similar tool before,
        you probably shouldn't be using this tool.

    Copy the PSAR file you want dumped to \DATA.PSAR on the memory stick

    Run the program on the PSP ("PSAR Dumper")
    When it is finished, pop out the battery (program has dumb exit code)

    Look at the memory stick.
    \OUT\*.* - all the files
    \OUTX\*.* - the decypted ~PSP files (.prx and .txt)

    It will delete the original \DATA.PSAR from the memory stick for you,
        to help free up space
    This version will not save the encrypted PRXs to OUT, but it will
        save the decrypted PRXs to OUTX. This is also to save space so
        you can decrypt the entire 2.0 update on a 32MB stick.

    Special files:
    \OUT\README.TXT - extraction report for files
    \OUTX\README.TXT - extraction report for ~PSP/prx files
    \OUT\data0.bin. \OUT\data1.bin - special blocks at start of PSAR
             (update version info)
    \OUTX\part?_psp_ipl.bin - special case IPL decryption (very low level)

------
Tested and works for the following PSP Firmware updates:
    Old 1.00 "BOGUS" update
    1.50 update
    1.51 update
    1.52 update
    2.00 update
    2.01 update
    2.50 update
    For all these versions, the ~PSP PRX files are decrypted

    2.60 update (no decrypt)
    2.70 update (no decrypt)
    For the latest versions, the PRX files are not decrypted
        (the OUTX folder will be mostly empty)
    If someone wants to reverse engineer the compression on the newer
    IPL files, then we should be able to figure this out

------
