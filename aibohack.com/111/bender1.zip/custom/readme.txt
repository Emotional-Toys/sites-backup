Notes for AIBO custom personality: Bender AIBO

Test Version 1.0

Contents of the "custom" directory are for documentation only
(these files are not needed to run the AIBO personality)

Also included in this directory:
    readme.txt = this file
    comments.ini = state descriptions (for use with QOpenR version .7 and above)
    bender.sbl = Simplified Behavior Language source file
    *.sbh = files included by "bender.sbl"

Credits:
    Behavior and tools - AiboPet (that's me)
    Sound Samples - the Internet
    Voice Talent - John Di Maggio

--------------------------------------
Technical notes:

'Aperios.gz' is a hacked version of the ERA-111 "A" AiboWare.
It has been hacked to increase the WAVE file limit from 2MB to 4MB.
I'm guessing the practical limit is less than 4MB
(where AIBO runs out of RAM on boot-up).

The "bender.sbl" file includes the source for the state machine.

The Stage/Personality of the dog is marked as "Adult #1".
This is meaningless since Bender AIBO does not evolve and has none
of the standard AIBO personality traits.

If you use version 1.8 or later of the AIBO Browser,
the custom state names should be displayed when browsing.
The logic in 'bender.sbl' gets compiled to be behavior file "b_at_a1".

Learning should be possible. If you praise the dog when it does something you like, and scold it if it does something you don't like.

--------------------------------------

Website: http://aibopet.go.to
Suggestions/Comments: aibopet@go.to
