AIBO Scope 1.3
Edge Detection Matrices added


