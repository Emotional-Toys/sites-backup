Notes for AIBO custom personality: Wassup AIBO!

Contents of the "custom" directory are for documentation only
(these files are not needed to run the AIBO personality)

--------------------------------------
Wassup is a custom AIBO personality.

The core software is from an ERA-111 ("A" version).
The concept is based on Hello AIBO!, but implemented on top of ERA-111 software.
The personality is based on Youth#3 (Good Boy).
If you browse the memory stick, it will say the stage is Adult#4, but that is misleading since the behavior files are all custom.

Credits:
    Behavior and tools - AiboPet
    Annoying commercial - Budweiser

--------------------------------------

Website: http://aibopet.go.to/images.htm
Suggestions/Comments: aibopet@go.to
