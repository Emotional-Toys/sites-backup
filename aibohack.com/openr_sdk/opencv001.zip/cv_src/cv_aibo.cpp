// AiboPet's OpenCV extensions

#include "cv_aibo.hpp"
#include <stdio.h>

#include <OPENR/OObserver.h>
#include <OPENR/OFbkImage.h>
#include <OPENR/OPENRAPI.h>

static const CvSize s_size176x143 = { 176, 143 };
CvAiboImage::CvAiboImage(int nPlanes, int depth)
    : CvImage(s_size176x143, depth, nPlanes)
{
    assert(nPlanes == 1 || nPlanes == 3);
    cvCreateData(this);
}

CvAiboImage::~CvAiboImage()
{
    cvReleaseData(this);
}

void CvAiboImage::DumpInfo()
{
    printf("CvAiboImage object address $%lx\n", (long)this);
	printf("\tnSize = %d\n", nSize);
	printf("\tID = %d\n", ID);
	printf("\tnChannels = %d\n", nChannels);
	printf("\talphaChannel = %d\n", alphaChannel);
	printf("\tdepth = %d\n", depth);
	printf("\tdataOrder = %d\n", dataOrder);
	printf("\torigin = %d\n", origin);
	printf("\talign = %d\n", align);
	printf("\twidth = %d\n", width);
	printf("\theight = %d\n", height);
	printf("\timageSize = %d\n", imageSize);
	printf("\twidthStep = %d\n", widthStep);
    printf("\timageData = $%lx\n", (long)imageData);
}

static inline byte limit(int v)
{
    if (v >= 255)
        return 255;
    else if (v <= 0.0)
        return 0;
    else
        return (byte)v;
}

static void YCrCb2RGB(byte y, byte cr, byte cb, byte* rgb)
{
    // offset binary [0, 255] -> signed char [-128, 127]
    sbyte scr = (sbyte)(cr ^ 0x80);
    sbyte scb = (sbyte)(cb ^ 0x80);

    double Y  = (double)y / 255.0;   //  0.0 <= Y  <= 1.0
    double Cr = (double)scr / 128.0; // -1.0 <= Cr <  1.0
    double Cb = (double)scb / 128.0; // -1.0 <= Cb <  1.0

    int R = (int)(255 * (Y + Cb));
    int G = (int)(255 * (Y - 0.51*Cb - 0.19*Cr));
    int B = (int)(255 * (Y + Cr));

    rgb[0] = limit(R);
    rgb[1] = limit(G);
    rgb[2] = limit(B);
}

void CvAiboImage::GetFromFbkImageEvent(const ONotifyEvent& event)
{
    assert(depth == IPL_DEPTH_8U);
    assert(nChannels == 1 || nChannels == 3);

    // Get Hi-Res image
    OFbkImageVectorData* imageVec = (OFbkImageVectorData*)event.Data(0);
    OFbkImageInfo* info = imageVec->GetInfo(ofbkimageLAYER_H);
    byte*          data = imageVec->GetData(ofbkimageLAYER_H);

    OFbkImage yImage(info, data, ofbkimageBAND_Y);

    assert(width == yImage.Width());
    assert(height == yImage.Height()-1); // last line dropped

    if (nChannels == 3)
    {
	    OFbkImage crImage(info, data, ofbkimageBAND_Cr);
	    OFbkImage cbImage(info, data, ofbkimageBAND_Cb);
	    for (int y = 0; y < height; y++)
	    {
			byte* pb = (byte*)imageData + widthStep * y;
	        for (int x = 0; x < width; x++)
	        {
	            //REVIEW: fast enough ?
	            YCrCb2RGB(yImage.Pixel(x, y), crImage.Pixel(x, y),
	                      cbImage.Pixel(x, y), pb);
	            pb += 3;
	        }
	    }
    }
    else
    {
        assert(nChannels == 1);
        // just Y
	    for (int y = 0; y < height; y++)
	    {
			byte* pb = (byte*)imageData + widthStep * y;
	        for (int x = 0; x < width; x++)
                *pb++ = yImage.Pixel(x, y);
        }
    }
}

////////////////////////////////////////////////////////////////


// first part of .BMP file (hard coded size)
static const byte bmpHdr176x143[] =
{
	0x42, 0x4d,
    // 0x36, 0x29, 0x01, 0,
    0x26, 0x27, 0x01, 0,
    0, 0,
	0, 0, 0x36, 0, 0, 0, 0x28, 0,
	0, 0, 176, 0, 0, 0, 143, 0,
	0, 0, 0x01, 0, 0x18, 0, 0, 0,
	0, 0,
    // 0, 0x29, 0x01, 0,
    0xF0, 0x26, 0x01, 0,
    0xc4, 0x0e,
	0, 0,
    0xc4, 0x0e, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0
};


bool CvAiboImage::SaveAsBmp(const char* pathName)
{
    assert(depth == IPL_DEPTH_8U);
    assert(width == 176 && height == 143);  // hard coded above
    assert(nChannels == 1 || nChannels == 3);
    FILE* file = fopen(pathName, "wb");
    if (file == NULL)
		return false;

    int nErr = 0;
    if (fwrite(bmpHdr176x143, sizeof(bmpHdr176x143), 1, file) != 1)
        nErr++;

    for (int y = 0; y < height; y++)
    {
        int y2 = height - 1 - y; // reverse Y
		byte* pb = (byte*)imageData + widthStep * y2;
        if (nChannels == 3)
        {
            // write colors
			if (fwrite(pb, width*nChannels, 1, file) != 1)
	            nErr++;
        }
        else
        {
            assert(nChannels == 1);
            // write same color 3 times per pixel (black and white image)
            for (int x = 0; x < width; x++)
            {
                byte rgb[3];
                rgb[0] = rgb[1] = rgb[2] = *pb++;
				if (fwrite(rgb, 3, 1, file) != 1)
                {
                    printf("Write3 error\n");
		            nErr++;
                }
            }
        }
    }
	fclose(file);
    return nErr == 0;
}

///////////////////////////////////////////////////////////////

