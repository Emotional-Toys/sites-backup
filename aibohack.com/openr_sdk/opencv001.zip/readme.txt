Reorganized

OpenCV source provided by Intel.
    http://www.intel.com/research/mrl/research/opencv

Original port done by Eric Vaughan
    http://droidlogic.com

CvAiboImage and other modifications by AiboPet
    http://aibohack.com

----------------------------------------------------------
Directories/Files:

    cv_inc/*.h* - public headers for CV interface (including cv_aibo.hpp)
    cv_lib/*.a - place for *.a libraries (very big, not in release)
    cv_src/*.* - source to libcb + Aibo extensions

    test1/*.* - simple test program (sort of like ImageObserver)
                Press AIBO's head to capture image
    MS/*.* - memory stick image

    makefile - makes it all
        after building, copy the contents of the MS directory on top of
            an SDK prepared memory stick


----------------------------------------------------------

Classes:
	CvAiboImage (see cv_aibo.hpp)
        - derived from CvImage
        - provides 176x143 24 bit color image capture (see sample code)
        - can save as Bitmap files (color or B&W)

----------------------------------------------------------
