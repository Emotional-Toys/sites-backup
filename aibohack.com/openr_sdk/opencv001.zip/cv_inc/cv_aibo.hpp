// AiboPet's OpenCV extensions

#include "cv.hpp"

// CvAiboImage for 176x143 color image
// the last line is screwed up by tag info

struct ONotifyEvent;

class CvAiboImage : public CvImage
{
public:
    CvAiboImage(int nPlanes, int depth = IPL_DEPTH_8U);
        // constructor allocated image array
        // nPlanes = 3 for color, 1 for B&W (Y only)
    ~CvAiboImage();
        // destructor frees image array

	void DumpInfo();
        // diagnostic dump

	void GetFromFbkImageEvent(const ONotifyEvent& event);
        // use in event notification to get color image

    bool SaveAsBmp(const char* pathName);
        // save as .BMP
};

