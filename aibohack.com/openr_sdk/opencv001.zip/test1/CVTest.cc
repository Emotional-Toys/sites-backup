// CVTest program

#include "CVTest.h"
#include <OPENR/OPENRAPI.h>
#include <OPENR/core_macro.h>
#include <assert.h>

#include "cv_aibo.hpp" // public interface

CVTest::CVTest()
{
    m_headSensorID = oprimitiveID_UNDEF;
	m_fbkID = oprimitiveID_UNDEF;
}

#define FBK_LOCATOR "PRM:/r1/c1/c2/c3/i1-FbkImageSensor:F1"
#define HEAD_SENSOR_LOCATOR "PRM:/r1/c1/c2/c3/f1-Sensor:f1"

OStatus CVTest::DoInit(const OSystemEvent& event)
{
    NEW_ALL_SUBJECT_AND_OBSERVER;
    REGISTER_ALL_ENTRY;
    SET_ALL_READY_AND_NOTIFY_ENTRY;

	OStatus result;
    result = OPENR::OpenPrimitive(HEAD_SENSOR_LOCATOR, &m_headSensorID);
    assert(result == oSUCCESS);
	result = OPENR::OpenPrimitive(FBK_LOCATOR, &m_fbkID);
    assert(result == oSUCCESS);

    return oSUCCESS;
}

OStatus CVTest::DoStart(const OSystemEvent& event)
{
    ENABLE_ALL_SUBJECT;
    ASSERT_READY_TO_ALL_OBSERVER;

    // we don't have camera data yet, do simple primitive drawing tests

    printf("Simple CV tests\n");

    CvAiboImage image(3); // color
	cvSetZero(&image); // clear it

    // image.DumpInfo();

    CvPoint ptCenter = { 176/2, 143/2 };
    // draw a red rectangle
    CvPoint pt1 = { 5, 5 };
    CvPoint pt2 = { 176-5, 143-5 };
    cvRectangle(&image, pt1, pt2, CV_RGB(255,0,0), 1);

    // draw a blue circle
    cvCircle(&image, ptCenter, 50, CV_RGB(0,0,255), 1);

    // draw a smaller green filled circle
    cvCircle(&image, ptCenter, 10, CV_RGB(0,255,0), -1);

    // draw a polygon in top left
    CvPoint points[] =
    {
        { 20, 10 }, { 30, 20 }, { 30, 30 }, { 20, 40 },
        { 10, 30 }, { 10, 20 }
    };
    cvFillConvexPoly(&image, points, sizeof(points)/sizeof(CvPoint),
        CV_RGB(128,128,0));

    // ok, enough silly tests, save the result

    if (image.SaveAsBmp("/MS/simple.bmp"))
	    printf("basic drawing saved\n");
    else
	    printf("ERROR: problem saving simple bitmap\n");

    return oSUCCESS;
}

OStatus CVTest::DoStop(const OSystemEvent& event)
{
    DISABLE_ALL_SUBJECT;
    return oSUCCESS;
}

OStatus CVTest::DoDestroy(const OSystemEvent& event)
{
    DELETE_ALL_SUBJECT_AND_OBSERVER;
    return oSUCCESS;
}


void CVTest::NotifyAiboImage(const ONotifyEvent& event)
{
    // called 25 times per second with a new image

    static int s_captureNumNext = 1;

    bool headNow = false;

    //BLOCK: get current head sensor
    {
        OSensorValue val;
        if (OPENR::GetSensorValue(m_headSensorID, &val) == oSUCCESS)
            headNow = (val.value > 1000); // hit hard
        else
            printf("ERROR: can't get head sensor status\n");
    }

    if (headNow)
    {
        // hard head pressed => capture (hold to capture more)

        printf("capturing number %d\n", s_captureNumNext);

        char fileName[64];

        //BLOCK: color image
        {
		    CvAiboImage imageColor(3);
		    imageColor.GetFromFbkImageEvent(event); // gets RGB image

	        sprintf(fileName, "/MS/%02d_IMAGE.BMP", s_captureNumNext);
		    if (imageColor.SaveAsBmp(fileName))
	            printf("saved original image as %s\n", fileName);
	        else
	            printf("ERROR: SaveAsBmp failed (%s)\n", fileName);
        }

	    CvAiboImage imageY(1);  // 1 channel - intensity only

        //BLOCK: get b&w image
        {
		    imageY.GetFromFbkImageEvent(event); // gets Y only

	        sprintf(fileName, "/MS/%02d_YONLY.BMP", s_captureNumNext);
		    if (imageY.SaveAsBmp(fileName))
	            printf("saved Y image as B&W %s\n", fileName);
	        else
	            printf("ERROR: SaveAsBmp failed (%s)\n", fileName);
        }

        //BLOCK: Canny edge detection
        {
	        CvAiboImage imageCanny(1); // just the edges

	        cvCanny(&imageY, &imageCanny, 4, 8, 3); // REVIEW: parameters?
	        sprintf(fileName, "/MS/%02d_CANNY.BMP", s_captureNumNext);
		    if (imageCanny.SaveAsBmp(fileName))
	            printf("saved Canny edges as B&W %s\n", fileName);
	        else
	            printf("ERROR: SaveAsBmp failed (%s)\n", fileName);
        }

        //BLOCK: Laplacian
        {
	        CvAiboImage imageLaplacian16s(1, IPL_DEPTH_16S); // short values
	        cvLaplace(&imageY, &imageLaplacian16s, 3);

	        CvAiboImage imageOut(1); // B&W image - looks cool
	        cvConvertScale(&imageLaplacian16s, &imageOut);

	        sprintf(fileName, "/MS/%02d_LAPLA.BMP", s_captureNumNext);
		    if (imageOut.SaveAsBmp(fileName))
	            printf("saved laplace convolution as B&W %s\n", fileName);
	        else
	            printf("ERROR: SaveAsBmp failed (%s)\n", fileName);
        }

#ifdef LATER
        // contours, camshift, etc
#endif
        s_captureNumNext++;
    }

    // we can accept more images now
    observer[event.ObsIndex()]->AssertReady(event.SenderID());
}
