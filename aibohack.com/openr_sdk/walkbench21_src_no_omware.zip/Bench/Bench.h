
#include <OPENR/OObject.h>
#include <OPENR/OSubject.h>
#include <OPENR/OObserver.h>
#include "TCPConnection.h"
#include "def.h"

#define SERVER_CONNECTION_MAX  1
#define SERVER_BUFFER_SIZE     1024 /* large enough for reply */
#define RECEIVE_SIZE 1  /* one byte at a time */
#define SERVER_PORT            23   /* standard telnet */

class Bench : public OObject
{
public:
	Bench();
	virtual ~Bench() {}
	
	OSubject* subject[numOfSubject];
	OObserver* observer[numOfObserver]; 
	
	virtual OStatus DoInit(const OSystemEvent& event);
	virtual OStatus DoStart(const OSystemEvent& event);
	virtual OStatus DoStop(const OSystemEvent& event);
	virtual OStatus DoDestroy(const OSystemEvent& event);
	
	//////////////////////////
    // LAN (mini-telnet)
public:
	void ListenCont(void* msg);
	void SendCont(void* msg);
	void ReceiveCont(void* msg);
	void CloseCont(void* msg);
	
private:
	OStatus InitTCPConnection(int index);
    OStatus Listen(int index);
    OStatus Send(int index);
    OStatus Receive(int index);
    OStatus Close(int index);

    antStackRef    ipstackRef;
    TCPConnection  connection[SERVER_CONNECTION_MAX];

	//////////////////////////
    // Sony OMWARE walking
public:
    void Sony_ReadySetMotion(const OReadyEvent &event);
    void Sony_NotifyMotionResult(const ONotifyEvent& event);
private:

	//////////////////////////
    // CMU walking

public:
    void Cmu_ReadySetMotion(const OReadyEvent &event);
    void Cmu_NotifyMotionResult(const ONotifyEvent& event);
private:
};

extern Bench Self;

/////////////////////////////////////////////////////////////
// glue to cmd.cc

#define MAX_REPLY_LEN 1023
void ProcessCommand(char chCmd, char* szReply);

