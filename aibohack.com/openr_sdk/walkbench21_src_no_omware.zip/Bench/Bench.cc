//
// Copyright 2002 Sony Corporation 
//
// Permission to use, copy, modify, and redistribute this software for
// non-commercial use is hereby granted.
//
// This software is provided "as is" without warranty of any kind,
// either expressed or implied, including but not limited to the
// implied warranties of fitness for a particular purpose.
//

#include <string.h>
#include <OPENR/OSyslog.h>
#include <OPENR/OPENRAPI.h>
#include <OPENR/core_macro.h>

#include <ant.h>
#include <EndpointTypes.h>
#include <TCPEndpointMsg.h>
#include "Bench.h"
#include "entry.h"

Bench::Bench()
{
}

OStatus
Bench::DoInit(const OSystemEvent& event)
{
    NEW_ALL_SUBJECT_AND_OBSERVER;
    REGISTER_ALL_ENTRY;
    SET_ALL_READY_AND_NOTIFY_ENTRY;

    return oSUCCESS;
}

OStatus
Bench::DoStart(const OSystemEvent& event)
{
    ENABLE_ALL_SUBJECT;
    ASSERT_READY_TO_ALL_OBSERVER;

#if 0
    // CMU motion engine already stretches
    OPENR::SetMotorPower(opowerON);
    OPENR::SetDefaultJointGain(oprimitiveUNDEF);
    OPENR::EnableJointGain(oprimitiveUNDEF);
#endif

    // LAN setup
    ipstackRef = antStackRef("IPStack");
    for (int index = 0; index < SERVER_CONNECTION_MAX; index++) {
        OStatus result = InitTCPConnection(index);
        if (result != oSUCCESS) return oFAIL;
    }

    Listen(0);

    return oSUCCESS;
}    

OStatus
Bench::DoStop(const OSystemEvent& event)
{
    OPENR::SetMotorPower(opowerOFF);
    DISABLE_ALL_SUBJECT;
    DEASSERT_READY_TO_ALL_OBSERVER;
    return oSUCCESS;
}

OStatus
Bench::DoDestroy(const OSystemEvent& event)
{
    DELETE_ALL_SUBJECT_AND_OBSERVER;
    return oSUCCESS;
}

OStatus
Bench::Listen(int index)
{
    if (connection[index].state != CONNECTION_CLOSED) return oFAIL;

    //
    // Create endpoint
    //
    antEnvCreateEndpointMsg tcpCreateMsg(EndpointType_TCP,
                                         SERVER_BUFFER_SIZE * 2);
    tcpCreateMsg.Call(ipstackRef, sizeof(tcpCreateMsg));
    if (tcpCreateMsg.error != ANT_SUCCESS) {
        OSYSLOG1((osyslogERROR, "%s : %s[%d] antError %d",
                  "Bench::Listen()",
                  "Can't create endpoint",
                  index, tcpCreateMsg.error));
        return oFAIL;
    }
    connection[index].endpoint = tcpCreateMsg.moduleRef;

    //
    // Listen
    //
    TCPEndpointListenMsg listenMsg(connection[index].endpoint,
                                   IP_ADDR_ANY, SERVER_PORT);
    listenMsg.continuation = (void*)index;

    listenMsg.Send(ipstackRef, myOID_,
                   Extra_Entry[entryListenCont], sizeof(listenMsg));
    
    connection[index].state = CONNECTION_LISTENING;

    return oSUCCESS;
}

void
Bench::ListenCont(void* msg)
{
    TCPEndpointListenMsg* listenMsg = (TCPEndpointListenMsg*)msg;
    int index = (int)listenMsg->continuation;

    if (listenMsg->error != TCP_SUCCESS) {
        OSYSLOG1((osyslogERROR, "%s : %s %d",
                  "Bench::ListenCont()",
                  "FAILED. listenMsg->error", listenMsg->error));
        Close(index);
        return;
    }

    connection[index].state = CONNECTION_CONNECTED;
    connection[index].recvSize = RECEIVE_SIZE;
    Receive(index);
}

OStatus
Bench::Send(int index)
{
    if (connection[index].sendSize == 0 ||
        connection[index].state != CONNECTION_CONNECTED) return oFAIL;

    TCPEndpointSendMsg sendMsg(connection[index].endpoint,
                               connection[index].sendData,
                               connection[index].sendSize);
    sendMsg.continuation = (void*)index;

    sendMsg.Send(ipstackRef, myOID_,
                 Extra_Entry[entrySendCont],
                 sizeof(TCPEndpointSendMsg));

    connection[index].state = CONNECTION_SENDING;
    connection[index].sendSize = 0;
    return oSUCCESS;
}

void
Bench::SendCont(void* msg)
{
    TCPEndpointSendMsg* sendMsg = (TCPEndpointSendMsg*)msg;
    int index = (int)(sendMsg->continuation);

    if (sendMsg->error != TCP_SUCCESS) {
        OSYSLOG1((osyslogERROR, "%s : %s %d",
                  "Bench::SendCont()",
                  "FAILED. sendMsg->error", sendMsg->error));
        Close(index);
        return;
    }

    connection[index].state = CONNECTION_CONNECTED;
    connection[index].recvSize = RECEIVE_SIZE;
    Receive(index);
}

OStatus
Bench::Receive(int index)
{
    if (connection[index].state != CONNECTION_CONNECTED &&
        connection[index].state != CONNECTION_SENDING) return oFAIL;

    TCPEndpointReceiveMsg receiveMsg(connection[index].endpoint,
                                     connection[index].recvData,
                                     1, connection[index].recvSize);
    receiveMsg.continuation = (void*)index;

    receiveMsg.Send(ipstackRef, myOID_,
                    Extra_Entry[entryReceiveCont], sizeof(receiveMsg));

    return oSUCCESS;
}

void
Bench::ReceiveCont(void* msg)
{
    TCPEndpointReceiveMsg* receiveMsg = (TCPEndpointReceiveMsg*)msg;
    int index = (int)(receiveMsg->continuation);

    if (receiveMsg->error != TCP_SUCCESS) {
        OSYSLOG1((osyslogERROR, "%s : %s %d",
                  "Bench::ReceiveCont()",
                  "FAILED. receiveMsg->error", receiveMsg->error));
        Close(index);
        return;
    }

    int cb = receiveMsg->sizeMin;   // actual size
    if (cb != 1)
    {
        OSYSLOG1((osyslogERROR, "%s : %s %d",
                  "Bench::ReceiveCont()",
                  "FAILED. bad size", cb));
        Close(index);
        return;
    }

    char chCmd = connection[index].recvData[0];

    static char szReply[MAX_REPLY_LEN+1]; // too big for stack
    szReply[0] = '\0';

    if (chCmd >= ' ' && chCmd < 0x7F)
	    ProcessCommand(chCmd, szReply); // skip control characters

    int cbReply = strlen(szReply) + 1;
// printf("REPLY cb = %d: %s\n", cbReply, szReply);
    memcpy(connection[index].sendData, szReply, cbReply);
    connection[index].sendSize = cbReply;
    Send(index);
}

OStatus
Bench::Close(int index)
{
    if (connection[index].state == CONNECTION_CLOSED ||
        connection[index].state == CONNECTION_CLOSING) return oFAIL;

    TCPEndpointCloseMsg closeMsg(connection[index].endpoint);
    closeMsg.continuation = (void*)index;

    closeMsg.Send(ipstackRef, myOID_,
                  Extra_Entry[entryCloseCont], sizeof(closeMsg));

    connection[index].state = CONNECTION_CLOSING;

    return oSUCCESS;
}

void
Bench::CloseCont(void* msg)
{
    TCPEndpointCloseMsg* closeMsg = (TCPEndpointCloseMsg*)msg;
    int index = (int)(closeMsg->continuation);

    connection[index].state = CONNECTION_CLOSED;
    Listen(index);
}

OStatus
Bench::InitTCPConnection(int index)
{
    connection[index].state = CONNECTION_CLOSED;

    // 
    // Allocate send buffer
    //
    antEnvCreateSharedBufferMsg sendBufferMsg(SERVER_BUFFER_SIZE);

    sendBufferMsg.Call(ipstackRef, sizeof(sendBufferMsg));
    if (sendBufferMsg.error != ANT_SUCCESS) {
        OSYSLOG1((osyslogERROR, "%s : %s[%d] antError %d",
                  "Bench::InitTCPConnection()",
                  "Can't allocate send buffer",
                  index, sendBufferMsg.error));
        return oFAIL;
    }

    connection[index].sendBuffer = sendBufferMsg.buffer;
    connection[index].sendBuffer.Map();
    connection[index].sendData
        = (byte*)(connection[index].sendBuffer.GetAddress());

    //
    // Allocate receive buffer
    //
    antEnvCreateSharedBufferMsg recvBufferMsg(SERVER_BUFFER_SIZE);

    recvBufferMsg.Call(ipstackRef, sizeof(recvBufferMsg));
    if (recvBufferMsg.error != ANT_SUCCESS) {
        OSYSLOG1((osyslogERROR, "%s : %s[%d] antError %d",
                  "Bench::InitTCPConnection()",
                  "Can't allocate receive buffer",
                  index, recvBufferMsg.error));
        return oFAIL;
    }

    connection[index].recvBuffer = recvBufferMsg.buffer;
    connection[index].recvBuffer.Map();
    connection[index].recvData
        = (byte*)(connection[index].recvBuffer.GetAddress());

    return oSUCCESS;
}

////////////////////////////////////////////////////////////////////
// Sony OMWARE glue

// #include <OMWares/MoNetMessageMaker.h>

void Bench::Sony_ReadySetMotion(const OReadyEvent &event)
{
}

void Bench::Sony_NotifyMotionResult(const ONotifyEvent& event)
{
    printf("OMWARE motion finished.\n");
    observer[obsSonyMotionResult]->AssertReady();
}

////////////////////////////////////////////////////////////////////
// CMU Motion glue

void Bench::Cmu_ReadySetMotion(const OReadyEvent &event)
{
}

void Bench::Cmu_NotifyMotionResult(const ONotifyEvent& event)
{
    printf("CMU motion finished.\n");
    observer[obsSonyMotionResult]->AssertReady();
}

////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////
