#include <string.h>
#include <OPENR/OPENRAPI.h>
#include "Bench.h"


#define CRLF "\n\r"

static void ProcessSonyCmd(char chCmd, char* szReply);
static void ProcessCmuCmd(char chCmd, char* szReply);
static void DisableCmu();

static int g_type = 1;  // start in CMU mode
static float g_raising_tilt = -1.5; // approx -90 degrees

void ProcessCommand(char chCmd, char* szReply)
{
    // printf("Bench $%x" CRLF, chCmd);

    // general purpose

    if (chCmd == 'Y')
    {
        g_type = 1;
        strcpy(szReply, "CMU CMPack02 walking (RoboCup winner)" CRLF);
    }
    else if (chCmd == 'y')
    {
        if (g_type == 1)
            DisableCmu();   // CMU MotionObject normally send to servos constantly
        g_type = 0;
		strcpy(szReply, "Sony OMWARE walking (like ERS-111)" CRLF);
    }
    else if (chCmd == '?')
    {
        strcpy(szReply, "WalkBench (V2.01) by AiboPet" CRLF);
        strcat(szReply, " (c) 2002" CRLF);
        strcat(szReply, " Walking code by Sony (OMWARE)" CRLF);
        strcat(szReply, " Walking code by CMPack'02 team (CMU)" CRLF);
        sprintf(szReply+strlen(szReply), "  type = %d" CRLF, g_type);
        strcat(szReply, "" CRLF);
    }
    else if (g_type == 0)
    {
        ProcessSonyCmd(chCmd, szReply);
    }
    else if (g_type == 1)
    {
        ProcessCmuCmd(chCmd, szReply);
    }
    else
    {
        sprintf(szReply, "Error: internal state error!" CRLF);
    }
}

/////////////////////////////////////////////////////////////////////////
// Sony / OMWare

#include <OMWares/MoNetMessageMaker.h>

struct WALK_INFO_OMWARE
{
    const char* name;
    WALK_STYLE ws;
};

static WALK_INFO_OMWARE g_wiOMWARE[10] =
{
 { "DEFAULT_WALKING",   DEFAULT_WALKING },
 { "STABLE_WALKING",    STABLE_WALKING },
 { "SLOW_WALKING",      SLOW_WALKING },
 { "FAST_WALKING",      FAST_WALKING },
 { "OFFLOAD_WALKING",   OFFLOAD_WALKING },
 { "BABY_WALKING",      BABY_WALKING },
 { "LIZARD_WALKING",    LIZARD_WALKING },
 { "CREEP_WALKING",     CREEP_WALKING },
 { "TROT_WALKING",      TROT_WALKING },
 { "ADAPTIVE_WALKING",  ADAPTIVE_WALKING }
};

struct WALK_XY
{
    double sx, sy;
	    // y positive in the right direction
};

static bool FindDirectionCmd(char chCmd, WALK_DIR* pwd, WALK_XY *pxy, char* dir_name)
{
    WALK_DIR wdIgnore;
    WALK_XY xyIgnore;
    if (pwd == NULL)
        pwd = &wdIgnore;
    if (pxy == NULL)
        pxy = &xyIgnore;

    pxy->sx = 0;
    pxy->sy = 0;

    if (chCmd == 'w')
    {
        strcpy(dir_name, "Forward");
        *pwd = WALK_FORWARD;
        pxy->sx = 1;
    }
    else if (chCmd == 'e')
    {
        strcpy(dir_name, "RightFwd");
        *pwd = WALK_RIGHTFORWARD;
        pxy->sx = 1;
        pxy->sy = .5;
    }
    else if (chCmd == 'q')
    {
        strcpy(dir_name, "LeftFwd");
        *pwd = WALK_LEFTFORWARD;
        pxy->sx = 1;
        pxy->sy = -.5;
    }
    else if (chCmd == 'd')
    {
        strcpy(dir_name, "Right");
        *pwd = WALK_RIGHT;
        pxy->sx = 1;
        pxy->sy = 1;
    }
    else if (chCmd == 'a')
    {
        strcpy(dir_name, "Left");
        *pwd = WALK_LEFT;
        pxy->sx = 1;
        pxy->sy = -1;
    }
    else if (chCmd == 'x')
    {
        strcpy(dir_name, "Backward");
        *pwd = WALK_BACKWARD;
        pxy->sx = -1;
    }
    else
    {
        return false; // no match
    }
    return true;    // got it

}

static void ProcessSonyCmd(char chCmd, char* szReply)
{
    static int g_style = 0;

    OSubject *sbj = Self.subject[sbjSonySetMotion];
    if (!sbj->IsReady())
    {
        strcpy(szReply, "Sony (OMWARE) subject not ready - command ignored" CRLF);
        return;
    }

    const int steps = 1000; // a long time

    MoNetMessageMaker mmm;
    bool haveNewMotion = true;

    WALK_DIR wd;
    char dir_name[64];

    if (chCmd == 'S')
    {
        // emergency stop
		mmm.MakeWalkingCommand(mmmmcStopMoveEmergency, mmmscWalkStop);
        strcpy(szReply, "Emergency Stop" CRLF);
    }
#if 0
    else if (chCmd == 'p')
    {
		mmm.MakeWalkingCommand(mmmmcStopMoveNormal, mmmscWalkStop);
        strcpy(szReply, "Stop #2" CRLF);
    }
#endif
    else if (chCmd == 's')
    {
        // normal stop
		mmm.MakeWalkingCommand(mmmmcMoveNow, mmmscWalkStop);
        strcpy(szReply, "Stop" CRLF);
    }
    else if (chCmd == 'D')
    {
        // tight right
		mmm.MakeStepWalkingCommand(mmmmcMoveNow, mmmscWalkTurnRight, steps);
        strcpy(szReply, "Tight Right Turn" CRLF);
    }
    else if (chCmd == 'A')
    {
        // tight left
		mmm.MakeStepWalkingCommand(mmmmcMoveNow, mmmscWalkTurnLeft, steps);
        strcpy(szReply, "Tight Left Turn" CRLF);
    }
#if 0
    else if (chCmd == 'X')
    {
        // skip back
		mmm.MakeStepWalkingCommand(mmmmcMoveNow, mmmscSkipBack, steps);
        strcpy(szReply, "Skip Back" CRLF);
    }
#endif

// jkl = kicking
    else if (chCmd == 'l')
    {
        // kick right
		mmm.MakeWalkingCommand(mmmmcMoveNow, mmmscRightKick);
        strcpy(szReply, "Kick Right" CRLF);
    }
    else if (chCmd == 'k')
    {
        strcpy(szReply, "Sorry - no center kick - try 'l' or 'j'" CRLF);
	    haveNewMotion = false;
    }
    else if (chCmd == 'j')
    {
        // kick left
		mmm.MakeWalkingCommand(mmmmcMoveNow, mmmscLeftKick);
        strcpy(szReply, "Kick Left" CRLF);
    }

// style switch
    else if (chCmd >= '0' && chCmd <= '9')
    {
        g_style = chCmd - '0';
        sprintf(szReply, "Walking style = %d (%s)" CRLF,
            g_style, g_wiOMWARE[g_style].name);
	}
// style specific commands follow
    else if (FindDirectionCmd(chCmd, &wd, NULL, dir_name))
    {
        // walk in one of the directions
		MMM_SubCmd mmmscWalk = (MMM_SubCmd)(mmmscWalkStop +
             g_wiOMWARE[g_style].ws + wd);
		mmm.MakeStepWalkingCommand(mmmmcMoveNow, mmmscWalk, steps);
        sprintf(szReply, "Walk %s %s" CRLF, g_wiOMWARE[g_style].name, dir_name);
    }
    else
    {
        sprintf(szReply, "Error: bad command '%c' (OMWARE)" CRLF, chCmd);
	    haveNewMotion = false;
    }

    if (haveNewMotion)
    {
		sbj->SetData(mmm.ProvideMoNetMessage(), sizeof(OMoNetMessage));
		sbj->NotifyObservers();
    }
}

/////////////////////////////////////////////////////////////////////////
// CMU / MotionObject

#include "../Motion/MotionInterface.h"

using namespace Motion;

void ProcessCmuCmdLong(char* szXYA)
{
    // printf("LCMD: '%s' ", szXYA);

    if (szXYA[0] == ':')
    {
        char szNum[3+1];
        szNum[3] = '\0';
        memcpy(szNum, szXYA+1, 3);
        int x = atoi(szNum);
        memcpy(szNum, szXYA+4, 3);
        int y = atoi(szNum);
        memcpy(szNum, szXYA+7, 3);
        int r = atoi(szNum);


	    OSubject *sbj = Self.subject[sbjCmuSetMotion];
	    if (!sbj->IsReady())
	    {
            // printf("-- NOT READY!\n");
	        return;
	    }
	
        // printf("%d %d %d -> ", x, y, r);

		MotionCommand mc;
		memset(&mc, 0, sizeof(mc));
	    mc.enable = true; // ADDED
	
	    g_raising_tilt += .05;   // raise a bit per tick
	    if (g_raising_tilt > 0)
	        g_raising_tilt = 0;

	    mc.head_cmd = HEAD_ANGLES;
		mc.head_tilt = g_raising_tilt;
	    mc.tail_cmd = TAIL_AIM;

	    mc.motion_cmd = MOTION_WALK_TROT;
        mc.vx = x * MAX_DX / 99;
	    mc.vy = -y * MAX_DY / 99;
	    mc.va = -r * MAX_DA / 99;

        // printf("%g %g %g\n", mc.vx, mc.vy, mc.va);

		sbj->SetData(&mc, sizeof(mc));
		sbj->NotifyObservers();
    }
    else
    {
        // printf("-- ERROR!\n");
    }
}

static void ProcessCmuCmd(char chCmd, char* szReply)
{
    static int g_speed = 50; // percent
    static bool g_strafe = false;

    static int g_ibNext = 0;
    static char g_szLong[32];

    if (g_ibNext > 0)
    {
        g_szLong[g_ibNext++] = chCmd;
        if (g_ibNext == 10)
        {
            g_szLong[g_ibNext] = '\0';
            ProcessCmuCmdLong(g_szLong);
            g_ibNext = 0;
        }
        return;
    }

    if (chCmd == ':')
    {
        // start of long command
        g_szLong[0] = chCmd;
        g_ibNext = 1;
        return;
    }


    OSubject *sbj = Self.subject[sbjCmuSetMotion];
    if (!sbj->IsReady())
    {
        strcpy(szReply, "CMU (Motion) subject not ready - command ignored" CRLF);
        return;
    }

	MotionCommand mc;
	memset(&mc, 0, sizeof(mc));
    mc.enable = true; // ADDED

    g_raising_tilt += .2;   // raise a bit per command, up until level
    if (g_raising_tilt > 0)
        g_raising_tilt = 0;

    mc.head_cmd = HEAD_ANGLES;
    mc.head_tilt = g_raising_tilt;
    mc.head_pan = 0;
    mc.head_roll = 0;

    mc.tail_cmd = TAIL_AIM;
    mc.tail_pan = 0;
    mc.tail_tilt = 0;

    bool haveNewMotion = true; // clear if no motion
    bool immediateStop = false; // set if repeating is not typical (eg: kicks)

    WALK_XY xy;
    char dir_name[64];

    if (chCmd == 's')
    {
	    mc.motion_cmd = MOTION_STAND_NEUTRAL;
        strcpy(szReply, "Stop Neutral" CRLF);
    }
    else if (chCmd == 'S')
    {
	    mc.motion_cmd = MOTION_STAND_CROUCH;
        strcpy(szReply, "Stop Crouch" CRLF);
    }

    else if (chCmd == 'T')
    {
        g_strafe = true;
        strcpy(szReply, "Stafe not turn" CRLF);
	    haveNewMotion = false;
    }
    else if (chCmd == 't')
    {
        g_strafe = false;
        strcpy(szReply, "Turn not strafe" CRLF);
	    haveNewMotion = false;
    }

// safer kicks
    else if (chCmd == 'k')
    {
	    mc.motion_cmd = MOTION_KICK_BUMP;
        strcpy(szReply, "Kick Bump" CRLF);
        immediateStop = true;
    }
    else if (chCmd == 'j')
    {
	    mc.motion_cmd = MOTION_KICK_HEAD_L;
        strcpy(szReply, "Kick Head Left" CRLF);
        immediateStop = true;
    }
    else if (chCmd == 'l')
    {
	    mc.motion_cmd = MOTION_KICK_HEAD_R;
        strcpy(szReply, "Kick Head Right" CRLF);
        immediateStop = true;
    }
    else if (chCmd == 'u')
    {
	    mc.motion_cmd = MOTION_KICK_HEAD_SOFT_L;
        strcpy(szReply, "Kick Head Soft Left" CRLF);
        immediateStop = true;
    }
    else if (chCmd == 'o')
    {
	    mc.motion_cmd = MOTION_KICK_HEAD_SOFT_R;
        strcpy(szReply, "Kick Head Soft Right" CRLF);
        immediateStop = true;
    }

// dangerous kicks
    else if (chCmd == 'K')
    {
	    mc.motion_cmd = MOTION_KICK_FOREWARD; // a little rough
	    mc.led = RED_FACE_LEDS;
        strcpy(szReply, "Kick Forward" CRLF);
        immediateStop = true;
    }
    else if (chCmd == 'J')
    {
	    mc.motion_cmd = MOTION_KICK_DIVE_L;
	    mc.led = RED_FACE_LEDS;
        strcpy(szReply, "Kick Dive Left" CRLF);
        immediateStop = true;
    }
    else if (chCmd == 'L')
    {
	    mc.motion_cmd = MOTION_KICK_DIVE_R;
	    mc.led = RED_FACE_LEDS;
        strcpy(szReply, "Kick Dive Right" CRLF);
        immediateStop = true;
    }
    else if (chCmd == 'I')
    {
	    mc.motion_cmd = MOTION_KICK_DIVE;
	    mc.led = RED_FACE_LEDS;
        strcpy(szReply, "Kick Dive" CRLF);
        immediateStop = true;
    }

    else if (chCmd == 'h')
    {
	    mc.motion_cmd = MOTION_KICK_HOLD;
        strcpy(szReply, "Hold" CRLF);
    }
    else if (chCmd == 'V')
    {
	    mc.motion_cmd = MOTION_DANCE;
	    mc.led = RED_FACE_LEDS;
        strcpy(szReply, "Dance!" CRLF);
        immediateStop = true;
    }

// speed specific
    else if (chCmd >= '0' && chCmd <= '9')
    {
        g_speed = (chCmd - '0') * 10;
        if (g_speed == 0)
            g_speed = 100;
        sprintf(szReply, "New speed=%d%%" CRLF, g_speed);
    }
    else if (FindDirectionCmd(chCmd, NULL, &xy, dir_name))
    {
	    mc.motion_cmd = MOTION_WALK_TROT;
	    mc.led = LED_TAIL_RED;
        mc.vx = xy.sx * MAX_DX * g_speed / 100;
        // strafe - not rotate
        if (g_strafe)
	        mc.vy = -xy.sy * MAX_DY * g_speed / 100;
        else
	        mc.va = -xy.sy * MAX_DA * g_speed / 100;
        sprintf(szReply, "Walk %d%% %s" CRLF, g_speed, dir_name);

	    mc.tail_tilt = 100; // tail up when walking
    }
    else if (chCmd == 'D')
    {
        // tight right
	    mc.motion_cmd = MOTION_WALK_TROT;
        mc.vx = 0;
        if (g_strafe)
	        mc.vy = -1 * MAX_DY * g_speed / 100;
        else
	        mc.va = -1 * MAX_DA * g_speed / 100;
		strcpy(szReply, "Tight Right Turn" CRLF);

	    mc.tail_pan = +100;
    }
    else if (chCmd == 'A')
    {
        // tight left
	    mc.motion_cmd = MOTION_WALK_TROT;
        mc.vx = 0;
        if (g_strafe)
	        mc.vy = +1 * MAX_DY * g_speed / 100;
        else
	        mc.va = +1 * MAX_DA * g_speed / 100;
		strcpy(szReply, "Tight Left Turn" CRLF);

	    mc.tail_pan = -100;
    }

#if 0
    // dribble broken - no walk_d.prm ???
    else if (chCmd == 'W')
    {
	    mc.motion_cmd = MOTION_WALK_DRIBBLE;
	    mc.led = LED_TAIL_BLUE;
        sprintf(szReply, "Dribble %d%% Fwd" CRLF, g_speed);
        mc.vx = MAX_DX * g_speed / 100;
    }
#endif
    else 
    {
		sprintf(szReply, "Error: bad command '%c' (CMU)" CRLF, chCmd);
	    haveNewMotion = false;
    }

    if (haveNewMotion)
    {
		sbj->SetData(&mc, sizeof(mc));
		sbj->NotifyObservers();


#if 0
        // will this work?
        if (immediateStop)
        {
            // do something smarter
            // right now we have ADDED code in MotionObject to prevent repeat
        }
#endif
    }
}

static void DisableCmu()
{
    OSubject *sbj = Self.subject[sbjCmuSetMotion];
    if (!sbj->IsReady())
    {
        return; // hope it works out...
    }

	MotionCommand mc;
	memset(&mc, 0, sizeof(mc));
    mc.enable = false;  // all that matters

	sbj->SetData(&mc, sizeof(mc));
	sbj->NotifyObservers();
}
