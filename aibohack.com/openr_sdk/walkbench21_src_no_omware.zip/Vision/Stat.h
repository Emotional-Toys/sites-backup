/****************************************************************************
 * This program is copyright 2001 (c) 2001                                   
 *   by Scott Lenser, Carnegie Mellon University.  All rights reserved.      
 *---------------------------------------------------------------------------
 * This program is free software; you can redistribute it and/or modify      
 * it under the terms of the GNU General Public License as published by      
 * the Free Software Foundation; either version 2 of the License, or         
 * (at your option) any later version.                                       
 *                                                                           
 * This program is distributed in the hope that it will be useful,           
 * but WITHOUT ANY WARRANTY; without even the implied warranty of            
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             
 * GNU General Public License for more details.                              
 *                                                                           
 * You should have received a copy of the GNU General Public License         
 * along with this program; if not, write to the Free Software               
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA   
 ***************************************************************************/

#ifndef INCLUDED_Stat_h
#define INCLUDED_Stat_h

#include <algo.h>
#include <vector.h>
#include <pair.h>

// look at symetric Kullback-Leibler distance

#define STAT_TEMPL_DECL template<class IntBidirectionalIterator>
#define STAT_TEMPL_DEFN IntBidirectionalIterator

/*------------------------------------------------------------------
CLASS
  StatTest

DESCRIPTION
  A statistical test for determining how different two distributions
are.
------------------------------------------------------------------*/
STAT_TEMPL_DECL
class StatTest {
public:
  StatTest() {}

  virtual ~StatTest() {}

  virtual double operator()(IntBidirectionalIterator x1s, IntBidirectionalIterator x1e,
                            IntBidirectionalIterator x2s, IntBidirectionalIterator x2e) = 0;

  //. ----------------------------------------------------------------
  // Compares the two values (returned from op()) to determine the one
  //   that indicates more similarity.
  // INPUT
  //   val1 - the first  value returned from operator()
  //   val2 - the second value returned from operator()
  // RETURNS
  //   best - +1 if val1 indicates more difference than val2
  //          -1 if val2 indicates more difference than val1
  //          0 otherwise
  // -----------------------------------------------------------------
  virtual int compStat(double val1,double val2) {
    return ((val1 > val2) - (val1 < val2));
  }

  virtual double mostDifferent() {
    return HUGE_VAL;
  }

  virtual double mostSimilar() {
    return 0.0;
  }

  virtual double probDifferent(double statistic) {
    return statistic;
  }

private:
};


/*------------------------------------------------------------------
CLASS
  ProbDistanceTest

DESCRIPTION
  My own test.
------------------------------------------------------------------*/
STAT_TEMPL_DECL
class ProbDistanceTest : public StatTest<STAT_TEMPL_DEFN> {
public:
  ProbDistanceTest() {}

  virtual ~ProbDistanceTest() {}

  virtual double operator()(IntBidirectionalIterator x1s, IntBidirectionalIterator x1e,
                            IntBidirectionalIterator x2s, IntBidirectionalIterator x2e);

  virtual double probDifferent(double statistic);

private:
};


struct PDTCompare : public binary_function<pair<int, double>, pair<int, double>, bool> {
  bool operator()(const pair<int, double> &x, const pair<int, double> &y) {
    return 
      (x.first<y.first) ||
      (x.first==y.first && x.second<y.second);
  }
};

STAT_TEMPL_DECL
double
ProbDistanceTest<STAT_TEMPL_DEFN>::operator()(IntBidirectionalIterator x1s, IntBidirectionalIterator x1e,
                                              IntBidirectionalIterator x2s, IntBidirectionalIterator x2e) {
  static const double epsilon=1e-2;

  vector<pair<int, double> > data;
  int size1,size2;

  data.reserve(x2e-x2s + x1e-x1s);

  IntBidirectionalIterator x1;
  for(x1=x1s; x1!=x1e; x1++)
    data.push_back(std::make_pair(1,*x1));
  size1 = data.size();

  IntBidirectionalIterator x2;
  for(x2=x2s; x2!=x2e; x2++)
    data.push_back(std::make_pair(2,*x2));
  size2 = data.size() - size1;

  sort(data.begin(),data.end(),PDTCompare());

  uint start2;
  for(start2=0; start2<data.size() && data[start2].first==1; start2++)
    ;

  uint cur1;
  double old2d;
  double cur2d;
  double distance;
  double size_ratio;

  cur1=0;
  cur2d=(double)start2;
  old2d=cur2d;
  distance=0.0;
  size_ratio=(double)(data.size()-start2)/start2;
  while(cur1 < start2) {
    double val1,val2;

    val1 = data[cur1].second;
    val2=0.0;
    old2d = cur2d;
    if((uint)(cur2d)+1 <= (old2d+size_ratio)) {
      val2 += data[(uint)(cur2d)].second*((uint)(cur2d)+1 - old2d);
      cur2d = (uint)(cur2d)+1;
    }
    while((uint)(cur2d)+1 <= (old2d+size_ratio)) {
      val2 += data[(uint)(cur2d)].second;
      cur2d = (uint)(cur2d)+1;
    }
    // must add epsilon to ensure that rounding error doesn't make us go past end of array
    if((uint)(cur2d)+epsilon < (old2d+size_ratio)) {
      val2 += data[(uint)(cur2d)].second*(old2d+size_ratio - cur2d);
      cur2d = old2d+size_ratio;
    }
    val2 /= size_ratio; // normalize for ratio of sizes

    distance += fabs(val1 - val2);

    cur1++;
  }
  distance /= (double)(start2); // normalize for data size

  return distance;
}

STAT_TEMPL_DECL
double
ProbDistanceTest<STAT_TEMPL_DEFN>::probDifferent(double statistic) {
  return statistic;
}

#endif
