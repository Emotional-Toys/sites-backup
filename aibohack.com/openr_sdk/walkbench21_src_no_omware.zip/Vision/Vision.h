/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef INCLUDED_Vision_h
#define INCLUDED_Vision_h

#include <math.h>

class PacketStream;
class PacketStreamCollection;

#include "../headers/system_config.h"
#include "../headers/field.h"
#include "../headers/gvector.h"
#include "../headers/Geometry.h"
#include "../headers/markmap.h"
#include "../headers/Util.h"

#include "cmvision.h"
#include "VisionInterface.h"

using namespace VisionInterface;

#include "../Main/globals.h"

extern int DebugClass;
extern char DebugInfo[1024];

#define MAX_TMAPS 16

typedef uchar pixel;
typedef uchar cmap_t;
typedef CMVision::image<uchar> image;
typedef CMVision::color_class_state color_class_state;
typedef CMVision::run<cmap_t> run;
typedef CMVision::region region;

// this include needs to be AFTER the run typedef
#include "SPOutVisionEncoder.h"

const int bits_y = 4;
const int bits_u = 6;
const int bits_v = 6;

#ifdef PLATFORM_LINUX
const int bits_r = 5;
const int bits_g = 6;
const int bits_b = 5;
#endif

#define MAX_COLORS 9
#define NUM_COLORS 9

// FIXME: These should be determined from colors.txt
// DO NOT reorder these as the order is assumed elsewhere in the code!
#define COLOR_BACKGROUND 0
#define COLOR_ORANGE     1
#define COLOR_GREEN      2
#define COLOR_PINK       3
#define COLOR_CYAN       4
#define COLOR_YELLOW     5
#define COLOR_BLUE       6
#define COLOR_RED        7
#define COLOR_WHITE      8

/* focal dist of camera:
   fh = (w/2) / tan(h/2) = (176/2) / (100 / (2*109)) = 88 / (100/109)
      = 95.92
   fv = (h/2) / tan(v/2) = (144/2) / (100 / (2*150)) = 60 / (100/150)
      = 90
 */
static const double FocalDist =(176.0/2)/tan(HorzFOV/2); // 158.76
static const double FocalDistV=(144.0/2)/tan(VertFOV/2); // 161.71
// size of vertical pixel in terms of size of horizontal pixel
static const double YPixelSize=(FocalDist/FocalDistV);

static const double RobotArea = 13711; // mm^2 (empirically guessed, side view)

#define MIN_EXP_REGION_SIZE 16
#define MIN_EXP_RUN_LENGTH   8

// for radial map
struct RadialRun {
  GVector::vector2d<int> startPt;
  GVector::vector2d<int> endPt;
  int color;
  int length;
};

// for features (for pattern analysis challenge)
struct feature_t {
  uchar val;
};

struct CornerLoc {
  vector2d loc;
  GVector::vector2d<int> imgLoc;
  CornerLoc *next;
  double dist;
  double ctrDist; // dist from centroid
  int neighborCnt;
  bool used;
  CornerLoc *neighbors[4]; // base_dir=x: +x,-x,+y,-y
  int idxX,idxY;
  void setDefault() {
    used = false;
    for(int i=0; i<4; i++)
      neighbors[i] = NULL;
  }
  void print(const char *s="") {
    pprintf(TextOutputStream,"%s, this = %p neighbors = [%p %p %p %p]\n",
	    s,
	    (void *)this,
	    (void *)neighbors[0],
	    (void *)neighbors[1],
	    (void *)neighbors[2],
	    (void *)neighbors[3]);
  }
};

typedef MarkMap<CornerLoc> CornerMap;

// FIXME: put reasonable value and change code to protect against problems
#define MAX_RADIAL_RUNS (176+144)

// additional information needed by vision about objects not exported to other objects
struct VisionObjectInfo {
  region *reg,*reg2;
};

class Vision{
public: // read-only outside of class
  ulong frameTimestamp;

  int num_tmaps;
  int cur_tmap;
  cmap_t *cmap; // colorized vision frame
  cmap_t *tmap[MAX_TMAPS]; // threshold map
  run *rmap,*rmap2; // run maps
  region *reg; // regions
  feature_t *corner; // corner map
  CornerMap corner_map;
  CornerMap clean_corner_map;

  double marker_color_offset; // offset in pixels of colored region away from pink region

  RadialRun *radial_runs;

  VisionObjectInfo vobj_info[NUM_OBJECTINFO_OBJECTS];
  RadialObjectMap radial_map;

  color_class_state color[MAX_COLORS];

  int width,height;
  int max_width,max_height;
  int max_runs,max_regions;
  int num_colors,num_runs,num_regions;
  int num_radial_runs;

  double body_angle, body_height;
  double head_angles[3];

  vector3d camera_loc,camera_dir,camera_up,camera_right;
  // direction vectors of ego up/horizon directions in img coordinates
  // img_hor is pointing to the right of up direction
  vector2d img_up,img_hor;

  // distortion calibration stuff
  double sq_distort_coeff,lin_distort_coeff;

public:
  // output stuff
  SPOutVisionEncoder *encoder;
  uchar *encodeBuf;

  PacketStream *visionAvgColorStream;
  PacketStream *visionColorAreaStream;
  PacketStream *visionRadialMapStream;
  PacketStream *visionRawStream;
  PacketStream *visionRLEStream;
  PacketStream *visionObjStream;

  int outCountAvgColor;  // number of frames since avg img color was output
  int outCountColorArea; // number of frames since color area was output
  int outCountRadialMap; // number of frames since radial map was output
  int outCountRaw;       // number of frames since raw image was output
  int outCountRLE;       // number of frames since RLE image was output

  // other stuff
  CMVision::image_yuv<const uchar> img;

public:
  bool thresholdImage(CMVision::image_idx<rgb> &img);
#ifdef PLATFORM_LINUX
  bool thresholdImage(CMVision::image<rgb> &img);
#endif
  bool thresholdImage(CMVision::image_yuv<const uchar> &img);

  template<class image>
  bool runLowLevelVision(image &img);
  bool getBodyParameters();

  bool onImage(int x, int y) {
    return (0<=x && x<width && 0<=y && y<height);
  }
  void clipToImage(int &x, int &y) {
    x = bound(x,0,width -1);
    y = bound(y,0,height-1);
  }
  static bool inBox(int x, int y, int x1, int y1, int x2, int y2) {
    return (x1<=x && x<x2 && y1<=y && y<y2);
  }

  int getColorUnsafe(int x,int y)
    {return(cmap[y*width+x]);}
  int getNearColor(int x,int y)
    {return(cmap[bound(y,0,height-1)*width+bound(x,0,width-1)]);}
  // adds the colors found to the color_cnt histogram
  int addToHistHorizStrip(int y, int x1, int x2, int *color_cnt);
  int addToHistVertStrip (int x, int y1, int y2, int *color_cnt);

  template<class Callback, class CallbackParams>
  bool drawLine(int x1, int y1, int x2, int y2, Callback callback, CallbackParams params);
  // returns true if hitting a boundary (or 0 dx and dy) cause line drawing to terminate
  template<class Callback, class CallbackParams>
  bool drawLine2(int x1, int y1, int dx, int dy, Callback callback, CallbackParams params);

  // find the (x,y) pixel location most in direction dir_x,dir_y of color color_idx
  // starts at (x,y) when performing search
  // finds a local maximum solution
  bool findCorner(int color_idx, int dir_x, int dir_y, int *x, int *y);
  // align v1 and v2 on a vertical plane
  // output plane_dir (the direction of the plane in xy coordinates)
  // v1_dz,v2_dz - the project of v1,v2 onto the plane.
  //   x is the radial (distance) component and y is the elevation component
  // returns the cos of the horizontal angle between v1 and v2
  double alignVertical(vector3d v1, vector3d v2, vector2d &plane_dir, vector2d &v1_dz, vector2d &v2_dz);

  // finds the direction of the ray through this pixel in robot coordinates
  vector3d getPixelDirection(double x, double y);
  // finds the point which through pixel (x,y) which intersects plane Z=z
  // returns true if ray intersects this z plane
  bool intersectPixelZPlane(double x, double y, double z_value, vector3d &loc);
  // convert ego vector to camera coordinates (z=distance, x/y in same direction as image x/y)
  vector3d convertToCamera(vector3d ego);
  // convert camera coordinates (z=distance, x/y in same direction as image x/y) to image coordinates
  vector2d cameraToImg(vector3d camera);
  // calculates the locations top_loc,bot_loc which result in a vertical seperation of seperation when
  // traveling in the directions top_dz,bot_dz.  The first component of top_dz,bot_dz is the distance
  // and the second component is the elevation, these vectors should be normalized before calling this
  // function.
  bool findLocVerticalSeperation(vector2d top_dz,vector2d bot_dz,double seperation,vector2d &top_loc,vector2d &bot_loc);
  // finds the ego angle on ground for a point
  double groundAngle(double x, double y);
  // finds the leftest and rightmost ego angles on ground for a bounding box
  void findSpan(double &left, double &right, double x1, double x2, double y1, double y2);
  // calculates the edge mask for a bounding box
  int calcEdgeMask(double x1, double x2, double y1, double y2);
  int calcEdgeMask(int x1,int x2,int y1,int y2);
  int calcEdgeMask(region *reg)
    {return(calcEdgeMask(reg->x1,reg->x2,reg->y1,reg->y2));}
  int calcEdgeMask(int x,int y,int slop=0);

  void findBall(VObject *ball,VisionObjectInfo *ball_info);
  void findMarkers(VObject *markers,VisionObjectInfo *marker_infos);
  void findGoal(int color_idx,VObject *goal,VObject *goal_edges,VisionObjectInfo *goal_info);
  void findRobots(int color_idx,VObject *robots,VisionObjectInfo *robot_infos,int max_robots);
  void findBarEnd(int color_idx,VObject *bar_end,VisionObjectInfo *bar_end_info);
  void findObjectInFrontOfIR(ObjectInfo *obj_info);
  bool runHighLevelVision(ObjectInfo *obj_info);

  void AddRadialObject(double x, double y, RadialObjectMap *radial_map, int robj_idx, int ang_idx);
  void UpdateRadialAngle(int ang_idx,GVector::vector2d<int> scan_start_img,GVector::vector2d<int> scan_end_img);
  void createRadialMap();

public:
  int setThreshold(int threshold_id);

  const vector3d &get_camera_loc() {return camera_loc;}
  const vector3d &get_camera_dir() {return camera_dir;}
  int getColor(int x,int y)
    {return((x>=0 && y>=0 && x<width && y<height)?
            cmap[y*width+x] : COLOR_BACKGROUND);}
  int getWidth() {return width;}
  int getHeight() {return height;}
  bool initialize(char *config_file,int width_param,int height_param);
  void initializeStreams(PacketStreamCollection *out_psc);
  bool close();

  // calculate the image up/right vectors from the camera pos/dir vectors
  void calcImgVectors();

  void setHeadAngles(const double *angles);
  void setBodyParams(double body_angle_param, double body_height_param) {
    body_angle=body_angle_param;
    body_height=body_height_param;
  }

  RadialObjectMap *getRadialMap() {
    return &radial_map;
  }

  bool processFrame(ObjectInfo *obj_info, const uchar *data_y, const uchar *data_u, const uchar *data_v, int width, int height);
#ifdef PLATFORM_LINUX
  bool processFrame(ObjectInfo *obj_info, CMVision::image_idx<rgb> *img, int width, int height);
  bool processFrame(ObjectInfo *obj_info, CMVision::image<rgb> *img, int width, int height);
#endif
  bool saveThresholdImage(char *filename);

  void updateCorners(CMVision::image_yuv<const uchar> *src_img);
  void updateCorners(CMVision::image<rgb> *src_img);
  template<class Image>
  void findPattern(Image *src_img,bool loose_corner_threshold,vector2d &centroid);
  template<class Image>
  int classifyPattern(Image *src_img,vector2d centroid);
  template<class Image>
  int idPattern(Image *src_img,vector3d &loc,bool loose_corner_threshold);
  int identifyPattern(CMVision::image_yuv<const uchar> *src_img,vector3d &loc,bool loose_corner_threshold);
  int identifyPattern(CMVision::image<rgb> *src_img,vector3d &loc,bool loose_corner_threshold);

  void sendAvgColor ();
  void sendRawImage ();
  void sendRLEImage ();
  void sendColorArea();
  void sendRadialMap();

  bool ballDisabled;
  bool calcTotalArea;
  bool barVisionOn;
};

#endif
