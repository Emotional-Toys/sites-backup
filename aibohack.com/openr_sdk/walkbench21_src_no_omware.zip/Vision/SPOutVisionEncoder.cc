/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#include "../headers/SPOutEncoder.h"
#include "../Vision/Vision.h"
#include "SPOutVisionEncoder.h"

uchar *
SPOutVisionEncoder::encodeAngles(uchar *buf,
                                 double body_angle,double body_height,
                                 double tilt,double pan,double roll) {
  encodeAsFloat(&buf,body_angle );
  encodeAsFloat(&buf,body_height);
  encodeAsFloat(&buf,tilt);
  encodeAsFloat(&buf,pan );
  encodeAsFloat(&buf,roll);

  return buf;
}

int
SPOutVisionEncoder::encodeVisionRaw(uchar *buf,
                                    double body_angle,double body_height,
                                    double tilt,double pan,double roll,
                                    CMVision::image_yuv<const uchar> &img)
{
  const uchar *row_y,*row_u,*row_v;

  uchar *orig_buf;
  orig_buf = buf;

  buf = encodeAngles(buf,body_angle,body_height,tilt,pan,roll);

  int height,width;

  height = img.height;
  width  = img.width;

  for(int y=0; y<height; y++) {
    row_y = img.buf_y + y*img.row_stride;
    row_u = img.buf_u + y*img.row_stride;
    row_v = img.buf_v + y*img.row_stride;
    for(int x=0; x<width; x++) {
      *(buf  )=row_y[x];
      *(buf+1)=row_u[x];
      *(buf+2)=row_v[x];
      buf+=3;
    }
  }

  return buf-orig_buf;
}

uchar *
SPOutVisionEncoder::encodeVisionRun(uchar *buf, run *run) {
  buf[0]=(uchar)run->color;
  buf[1]=(uchar)run->x;
  buf[2]=(uchar)run->width;
  return buf+3;
}

int
SPOutVisionEncoder::encodeVisionRLE(uchar *buf,
                                    double body_angle,double body_height,
                                    double tilt,double pan,double roll,
                                    int num_runs, run *runs)
{
  uchar *orig_buf;
  orig_buf = buf;

  buf = encodeAngles(buf,body_angle,body_height,tilt,pan,roll);

  for(; num_runs>0; num_runs--, runs++) {
    buf=encodeVisionRun(buf,runs);
  }
  return buf-orig_buf;
}

int
SPOutVisionEncoder::encodeVisionObjs(uchar *buf, ObjectInfo *obj_info) {
  static const double min_print=0.1;

  VObject *objs=(VObject *)obj_info;

  uchar *orig_buf;
  orig_buf = buf;

  unsigned short objects_seen=0U;
  int num_seen=0;
  for(int i=0; i<NUM_VISION_OBJECTS; i++) {
    if(objs[i].confidence > min_print) {
      objects_seen |= 1<<i;
      num_seen++;
    }
  }
  addToEncoding(&buf,(uchar *)&objects_seen,sizeof(objects_seen));

  for(int i=0; i<NUM_VISION_OBJECTS; i++) {
    VObject *obj=&objs[i];
    if(objects_seen & (1<<i)) {
      encodeAsFloat(&buf,obj->confidence);
      encodeAsFloat(&buf,obj->loc.x);
      encodeAsFloat(&buf,obj->loc.y);
      encodeAsFloat(&buf,obj->loc.z);
      encodeAsFloat(&buf,obj->left);
      encodeAsFloat(&buf,obj->right);
      encodeAsFloat(&buf,obj->distance);
      encodeAsFloat(&buf,obj->confInFrontOfIR);
      addToEncoding(&buf,(uchar *)&obj->edge,sizeof(obj->edge));
    }
  }

  return buf-orig_buf;
}

int
SPOutVisionEncoder::encodeVisionRadialMap(uchar *buf, RadialObjectMap *vis_map) {
  static const double min_print=0.1;
  static const int ulong_bits = 8*sizeof(ulong);

  uchar *orig_buf;
  orig_buf = buf;

  ulong angles_seen[(NUM_ANGLES+ulong_bits-1)/ulong_bits];
  for(int i=0; i<sizeof(angles_seen)/sizeof(angles_seen[0]); i++)
    angles_seen[i]=0UL;
  for(int ang_idx=0; ang_idx<NUM_ANGLES; ang_idx++) {
    if(vis_map->robjects[ROBJECT_VISIBLE_START][ang_idx].confidence > min_print) {
      angles_seen[ang_idx/ulong_bits] |= 1UL<<(ang_idx%ulong_bits);
    }
  }
  for(int i=0; i<sizeof(angles_seen)/sizeof(angles_seen[0]); i++)
    encodeAs<ulong>(&buf,angles_seen[i]);

  for(int ang_idx=0; ang_idx<NUM_ANGLES; ang_idx++) {
    if(angles_seen[ang_idx/ulong_bits] & (1UL<<(ang_idx%ulong_bits))) {
      ushort objects_seen;

      objects_seen = 0U;
      for(int robj_idx=0; robj_idx<NUM_ROBJECTS; robj_idx++) {
        if(vis_map->robjects[robj_idx][ang_idx].confidence > min_print) {
          objects_seen |= 1U<<robj_idx;
        }
      }

      encodeAs<ushort>(&buf,objects_seen);
      for(int robj_idx=0; robj_idx<NUM_ROBJECTS; robj_idx++) {
        RadialObjectReading *robj;
        robj = &vis_map->robjects[robj_idx][ang_idx];
        if(objects_seen & (1U<<robj_idx)) {
          encodeAs<float>(&buf,robj->confidence);
          encodeAs<float>(&buf,robj->distance);
        }
      }
    }
  }

  return buf-orig_buf;
}
