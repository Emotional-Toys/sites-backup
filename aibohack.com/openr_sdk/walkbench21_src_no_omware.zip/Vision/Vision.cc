/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#include <stdio.h>
#include <iostream.h>
#include <algo.h>

#ifdef PLATFORM_APERIOS
#include <MCOOP.h>
#endif

#include <OPENR/OSyslog.h>

#include "../headers/CircBufPacket.h"
#include "../headers/Config.h"
#include "../headers/Dictionary.h"
#include "../headers/gvector.h"
#include "../headers/Utility.h"
#include "../headers/Util.h"
#include "../Motion/Kinematics.h"
#include "../Motion/MotionInterface.h"
#include "../Main/globals.h"

#include "cmv_region.h"
#include "Vision.h"

// for pattern analysis challenge
#include "Stat.h"
#include "shape_data.h"

#ifdef PLATFORM_LINUX
#include "../../util/shared/image.h"
#include "../../util/shared/win.h"

extern xpixmap win_pix;
xdrawable *DebugDrawable = &win_pix;
static bool DrawUpVector      = false;
static bool DrawRadialLines   = false;
static bool DrawEdgeImg       = false;
static bool DrawBlackImg      = false;
static bool DrawCorners       = true;
static bool DrawSloppyCorners = true;
static bool DrawCentroid      = true;
#endif

double AvgImgColor[3]={-1.0,-1.0,-1.0};

// if this is true the radial map will be filled in properly,
// otherwise it will claim that nothing is visible
static const bool EnableRadialMap = true;

static const int MaxCorners = 100; // maximum number of corners for pattern analysis challenge

int DebugClass = 0;
char DebugInfo[1024];

bool ShouldThresholdImage = true;

bool Vision::initialize(char *vision_cfg_file,int width_param,int height_param)
{
#ifdef PLATFORM_APERIOS
  sError result;
#endif

  memset(DebugInfo,0,sizeof(DebugInfo)/sizeof(DebugInfo[0]));

  char colors_file_buf[256],tmapfile_base_buf[256];
  const char *colors_file,*tmapfile_base;
  { // scope to make dictionary auto clean up
    Dictionary vis_config;
    vis_config.read(vision_cfg_file);

    if(!vis_config.getValueString("colors_file",colors_file))
      colors_file = "/MS/config/colors.txt";
    if(!vis_config.getValueString("thresh_base",tmapfile_base))
      tmapfile_base = "/MS/config/thresh";
    if(!vis_config.getValueInt("num_thresholds",num_tmaps))
      num_tmaps = 1;
    int val=0;
    if(!vis_config.getValueInt("color_area",val) || val!=1)
      calcTotalArea = false;
    else
      calcTotalArea = true;
    if(!vis_config.getValueDouble("marker_color_offset",marker_color_offset))
      marker_color_offset = 0.0;
    barVisionOn = (vis_config.getValueInt("bar_vision",val) && val==1);

    // copy out before memory goes away
    strcpy(colors_file_buf,  colors_file  );
    strcpy(tmapfile_base_buf,tmapfile_base);
    colors_file = colors_file_buf;
    tmapfile_base = tmapfile_base_buf;
  }

  int num_y,num_u,num_v;
  int size;

  width  = width_param;
  height = height_param;
  max_width  = width;
  max_height = height;

  // Load color information
  num_colors = CMVision::LoadColorInformation(color,MAX_COLORS,colors_file);
  if(num_colors <= 0){
    pprintf(TextOutputStream,"  ERROR: Could not load color information.\n");
  }
  else {
    pprintf(TextOutputStream,"  Loaded %d colors.\n",num_colors);
  }

  // Set up threshold
  size = 1 << (bits_y + bits_u + bits_v);
  num_y = 1 << bits_y;
  num_u = 1 << bits_u;
  num_v = 1 << bits_v;

  cur_tmap = 0;
  memset(tmap,0,sizeof(tmap));
  for(int i=0; i<num_tmaps; i++) {
#ifdef PLATFORM_APERIOS
    result = NewRegion(size, reinterpret_cast<void**>(&tmap[i])); 
    if (result != sSUCCESS)
      pprintf(TextOutputStream,"Unable to allocate tmap buffer %d of size %d\n",i,size);
#else
    tmap[i] = new cmap_t[size];
#endif
    memset(tmap[i],0,size*sizeof(cmap_t));
  }

  for(int i=0; i<num_tmaps; i++) {
    char tmapfile[256];
    if(i==0)
      sprintf(tmapfile,"%s.tm",tmapfile_base);
    else
      sprintf(tmapfile,"%s%d.tm",tmapfile_base,i);
    if(!CMVision::LoadThresholdFile(tmap[i],num_y,num_u,num_v,tmapfile)) {
      if(i==0)
	pprintf(TextOutputStream,"  ERROR: Could not load threshold file '%s'.\n",tmapfile);
    }
    int remapped=CMVision::CheckTMapColors(tmap[i],num_y,num_u,num_v,num_colors,0);
    if(remapped>0)
      pprintf(TextOutputStream,"remapped %d colors in threshold file '%s'\n",remapped,tmapfile);
  }

  // Allocate map structures
  max_width  = width;
  max_height = height;
  size = width * height;
  max_runs = size / MIN_EXP_RUN_LENGTH;
  max_regions = size / MIN_EXP_REGION_SIZE;
  size = max_width * max_height;
  NewLarge(&cmap,size+1); // +1 is for extra terminator
  if(!cmap) {
    cout << "Couldn't allocate cmap\n\xFF" << endl;
    *((long *)0xDEADCC44)=1;
  }
  NewLarge(&rmap,max_runs);
  if(!rmap) {
    cout << "Couldn't allocate rmap\n\xFF" << endl;
    *((long *)0xDEAD7744)=1;
  }
  NewLarge(&rmap2,max_runs);
  if(!rmap) {
    cout << "Couldn't allocate rmap2\n\xFF" << endl;
    *((long *)0xDEAD7745)=1;
  }
  NewLarge(&radial_runs,MAX_RADIAL_RUNS);
  if(!radial_runs) {
    cout << "Couldn't allocate radial runs\n" << endl;
    *((long *)0xDEAD7A75)=1;
  }
  NewLarge(&reg,max_regions);
  if(!reg) {
    cout << "Couldn't allocate reg\n" << endl;
    *((long *)0xDEAD7E66)=1;
  }

  body_angle=0.0;
  body_height=100.0;
  head_angles[0]=head_angles[1]=head_angles[2]=0.0;

  // initialize output stuff
  encodeBuf = NULL;
  encoder = NULL;
  // Always init
  //if(config.spoutConfig.dumpVisionRLE!=0) {
  //if(config.spoutConfig.dumpVisionRLE) {
  // body position (5 floats) + image size*3 chars(value, x, length) + stop chars
  // body position (5 floats) + image size*3 chars(y, u, v) + stop chars
#ifdef PLATFORM_APERIOS
  NewRegion(5*4+176*144*3+2,(void **)&encodeBuf);
  if(encodeBuf==NULL)
    pprintf(TextOutputStream,"Null vision rle encode buf\n");
  else
    encoder=new SPOutVisionEncoder;
  //}
#endif

  corner = NewLarge(&corner,176*144);
  corner_map      .init(12,12,0,0,175,143,MaxCorners);
  clean_corner_map.init(12,12,0,0,175,143,MaxCorners);

  visionAvgColorStream  = NULL;
  visionColorAreaStream = NULL;
  visionRadialMapStream = NULL;
  visionRawStream       = NULL;
  visionRLEStream       = NULL;
  visionObjStream       = NULL;

  outCountAvgColor  = 0;
  outCountColorArea = 0;
  outCountRadialMap = 0;
  outCountRaw       = 0;
  outCountRLE       = 0;

  //pprintf(TextOutputStream,"Done initializing vision.\n");

  ballDisabled=false;

  frameTimestamp = 0UL;

  return(true);
}

void Vision::initializeStreams(PacketStreamCollection *out_psc) {
  static const int normal_raw_size=176*144*3+5*4; // 76052
  int raw_id;
  raw_id    =out_psc->allocateStream(normal_raw_size*3,3);
  visionRawStream=out_psc->getStream(raw_id);
  visionRawStream->type = SPOutEncoder::VisionRawLead;
  visionRawStream->binary = true;

  static const int normal_rle_size=5*1024;
  int rle_id;
  rle_id    =out_psc->allocateStream(normal_rle_size*10,10);
  visionRLEStream=out_psc->getStream(rle_id);
  visionRLEStream->type = SPOutEncoder::VisionRLELead;
  visionRLEStream->binary = true;

  int vobj_id;
  vobj_id         = out_psc->allocateStream(sizeof(ObjectInfo)*10,10);
  visionObjStream = out_psc->getStream(vobj_id);
  visionObjStream->type = SPOutEncoder::VisionObjLead;
  visionObjStream->binary = true;

  int vrad_map_id;
  vrad_map_id = out_psc->allocateStream(sizeof(float)*2*NUM_ANGLES*NUM_ROBJECTS*3,10);
  visionRadialMapStream = out_psc->getStream(vrad_map_id);
  visionRadialMapStream->type = SPOutEncoder::VisionRadialMapLead;
  visionRadialMapStream->binary = true;

  int vavg_color_id;
  vavg_color_id   = out_psc->allocateStream(3*10,10);
  visionAvgColorStream = out_psc->getStream(vavg_color_id);
  visionAvgColorStream->type = SPOutEncoder::VisionAvgColorLead;
  visionAvgColorStream->binary = true;

  int vcolor_area_id;
  vcolor_area_id   = out_psc->allocateStream(3*(MAX_COLORS*sizeof(ulong)+1),10);
  visionColorAreaStream = out_psc->getStream(vcolor_area_id);
  visionColorAreaStream->type = SPOutEncoder::VisionColorAreaLead;
  visionColorAreaStream->binary = true;
}

bool Vision::close()
{
  for(int i=0; i<num_tmaps; i++) {
#ifdef PLATFORM_APERIOS
    DeleteRegion(tmap[i]);
#else
    delete[] tmap[i];
#endif
  }
  delete(cmap);
  delete(rmap);
#ifdef PLATFORM_APERIOS
  DeleteRegion(reg);
#else
  delete(reg);
#endif

  memset(tmap,0,sizeof(tmap));
  cmap = NULL;
  rmap = NULL;
  reg  = NULL;

  max_width  = 0;
  max_height = 0;

#ifdef PLATFORM_APERIOS
  DeleteRegion(encodeBuf); // don't care about error
#else
  delete[] encodeBuf;
#endif
  delete encoder;

  DeleteLarge(corner);

  return(true);
}

bool Vision::getBodyParameters() {
  static ulong last_timestamp=1UL;

  static int last_idx=0;

  ulong time=GetTime();

#ifdef PLATFORM_APERIOS
  bool done=false;
  if(LocUpdateQueueBuffer!=NULL) {
    while(!done) {
      ulong buffer_timestamp=LocUpdateQueueBuffer->buffer[last_idx].timestamp;
      if(last_timestamp < buffer_timestamp && buffer_timestamp < time) {
        body_angle =LocUpdateQueueBuffer->buffer[last_idx].body.angle;
        body_height=LocUpdateQueueBuffer->buffer[last_idx].body.height;
        last_timestamp=buffer_timestamp;
        last_idx = (last_idx+1) % Motion::MotionLocalizationUpdateQueueBufferSize;

        //pprintf(TextOutputStream,"got ba %g bh %g time=%lu\n",body_angle,body_height,buffer_timestamp);
      }
      else {
        done=true;

        //pprintf(TextOutputStream,"no buffers\n");
      }
    }
  }
#endif

  //pprintf(TextOutputStream,"body_angle %g body_height %g\n",body_angle,body_height);

  return true;
}

void Vision::setHeadAngles(const double *angles) {
  memcpy(head_angles,angles,sizeof(double)*3);
}

inline double similar(double a,double b) {
  double s = (a - b) / (a + b);
  return(1 - fabs(s));
}

inline double pct_from_mean(double a,double b) {
  double s = (a - b) / (a + b);
  return fabs(s);
}

inline double uniform_with_gaussian_tails(double v, double uni_width, double gauss_stddev) {
  double eff_v;

  eff_v = max(fabs(v)-uni_width,0.0);
  return gaussian_with_min(eff_v/gauss_stddev,1e-3);
}

inline double sqrdist(double x1, double y1, double x2, double y2) {
  double xd,yd;

  xd = x1 - x2;
  yd = y1 - y2;

  return xd*xd + yd*yd;
}

vector3d Vision::getPixelDirection(double x, double y) {
  vector3d img_pixel_dir; // direction vector of pixel in image coordinates

  img_pixel_dir.set((x+.5-width/2.0),(height/2.0-(y+.5))*YPixelSize,FocalDist);

  vector3d robot_pixel_dir; // direction vector of pixel in robot coordinates
  robot_pixel_dir = 
    camera_dir  *img_pixel_dir.z +
    camera_up   *img_pixel_dir.y +
    camera_right*img_pixel_dir.x;

  robot_pixel_dir = robot_pixel_dir.norm();

  return robot_pixel_dir;
}

bool Vision::intersectPixelZPlane(double x, double y, double z_value, vector3d &loc) {
  vector3d pix_dir;
  bool intersects;

  pix_dir = getPixelDirection(x,y);
  intersects=GVector::intersect_ray_plane(camera_loc,pix_dir,
                                          vector3d(0.0,0.0,z_value),vector3d(0.0,0.0,1.0),
                                          loc);
  return intersects;
}

vector3d Vision::convertToCamera(vector3d ego) {
  vector3d cam;

  ego -= camera_loc;
  cam.set(ego.dot(camera_right),-(ego.dot(camera_up)),ego.dot(camera_dir));

  return cam;
}

vector2d Vision::cameraToImg(vector3d camera) {
  vector2d img;

  img.set(camera.x,camera.y / YPixelSize);
  img *= FocalDist / camera.z;
  img += vector2d(width/2.0 - .5,height/2.0 - .5);

  return img;
}

double Vision::alignVertical(vector3d v1, vector3d v2, vector2d &plane_dir, vector2d &v1_dz, vector2d &v2_dz) {
  vector3d avg_dir;
  avg_dir = (v1+v2).norm();
  
  plane_dir = vector2d(avg_dir.x,avg_dir.y).norm();

  double a1,a2;
  a1 = acos(avg_dir.dot(v1)/v1.length());
  a2 = acos(avg_dir.dot(v2)/v2.length());
  
  vector2d in_plane_dir;
  in_plane_dir.set(hypot(avg_dir.x,avg_dir.y),avg_dir.z);
  
  v1_dz = v2_dz = in_plane_dir;
  
  if(v1.z > avg_dir.z) {
    v1_dz = v1_dz.rotate( a1);
  } else {
    v1_dz = v1_dz.rotate(-a1);
  }
  
  if(v2.z > avg_dir.z) {
    v2_dz = v2_dz.rotate( a2);
  } else {
    v2_dz = v2_dz.rotate(-a2);
  }
  
  vector2d v1_xy_dir,v2_xy_dir;
  
  v1_xy_dir.set(v1.x,v1.y);
  v2_xy_dir.set(v2.x,v2.y);

  //plane_dir = v1_xy_dir + v2_xy_dir;
  //plane_dir.normalize();
  //
  //v1_dz.set(hypot(v1_xy_dir.x,v1_xy_dir.y),v1.z);
  //v2_dz.set(hypot(v2_xy_dir.x,v2_xy_dir.y),v2.z);

  return v1_xy_dir.dot(v2_xy_dir);
}

bool Vision::findLocVerticalSeperation(vector2d top_dz, vector2d bot_dz, double seperation, vector2d &top_loc, vector2d &bot_loc) {
  if(bot_dz.x < 1e-3)
    return false;

  if(top_dz == bot_dz)
    return false;

  double top_t,bot_t;

  // this should be safe because it blows up when
  // a) bottom distance component is zero (filtered out above)
  // b) top and bottom vectors are colinear (filtered out above)
  top_t = seperation / (top_dz.y - bot_dz.y * top_dz.x / bot_dz.x);
  bot_t = top_t * top_dz.x / bot_dz.x;

  if(top_t < 0.0)
    return false;

  top_loc = top_dz * top_t;
  bot_loc = bot_dz * bot_t;

  return true;
}

double Vision::groundAngle(double x, double y) {
  vector3d pix_dir;

  pix_dir = getPixelDirection(x,y);
  return atan2a(pix_dir.y,pix_dir.x);
}

void Vision::findSpan(double &left, double &right, double x1, double x2, double y1, double y2) {
  double angle;

  vector3d bbox_corner_dir; // direction vector through bounding box corner
  
  bbox_corner_dir = getPixelDirection(x1,y1);
  angle = atan2a(bbox_corner_dir.y,bbox_corner_dir.x);
  right = left = angle;

  bbox_corner_dir = getPixelDirection(x1,y2);
  angle = atan2a(bbox_corner_dir.y,bbox_corner_dir.x);
  left  = max(left , angle);
  right = min(right, angle);

  bbox_corner_dir = getPixelDirection(x2,y1);
  angle = atan2a(bbox_corner_dir.y,bbox_corner_dir.x);
  left  = max(left , angle);
  right = min(right, angle);

  bbox_corner_dir = getPixelDirection(x2,y2);
  angle = atan2a(bbox_corner_dir.y,bbox_corner_dir.x);
  left  = max(left , angle);
  right = min(right, angle);
}

int Vision::calcEdgeMask(int x1,int x2,int y1,int y2)
{
  static const int boundary_pixel_size=1;

  int edge;

  edge = 0;
  if(x1 <= 0       +boundary_pixel_size) edge |= OFF_EDGE_LEFT  ;
  if(x2 >= width -1-boundary_pixel_size) edge |= OFF_EDGE_RIGHT ;
  if(y1 <= 0       +boundary_pixel_size) edge |= OFF_EDGE_TOP   ;
  if(y2 >= height-1-boundary_pixel_size) edge |= OFF_EDGE_BOTTOM;

  return edge;
}

int Vision::calcEdgeMask(int x,int y,int slop)
{
  int edge;

  edge = 0;
  if(x <= 0       +slop) edge |= OFF_EDGE_LEFT  ;
  if(x >= width -1-slop) edge |= OFF_EDGE_RIGHT ;
  if(y <= 0       +slop) edge |= OFF_EDGE_TOP   ;
  if(y >= height-1-slop) edge |= OFF_EDGE_BOTTOM;

  return edge;
}

int Vision::addToHistHorizStrip(int y, int x1, int x2, int *color_cnt)
{
  int x;

  y  = bound(y ,0,height-1);
  x1 = bound(x1,0,width -1);
  x2 = bound(x2,0,width -1);

  for(x=x1; x<=x2; x++) {
    color_cnt[getColorUnsafe(x,y)]++;
  }

  return x2-x1+1;
}

int Vision::addToHistVertStrip(int x, int y1, int y2, int *color_cnt)
{
  int y;

  x  = bound(x ,0,width -1);
  y1 = bound(y1,0,height-1);
  y2 = bound(y2,0,height-1);

  for(y=y1; y<=y2; y++) {
    color_cnt[getColorUnsafe(x,y)]++;
  }

  return y2-y1+1;
}

void Vision::findBall(VObject *ball,VisionObjectInfo *ball_info) {
  static const bool debug_ball = false;
  static const bool debug_conf = false;

  static int frame_cnt=0;
#ifdef PLATFORM_LINUX
  static const int print_period=1;
#else
  static const int print_period=90;
#endif
  if(debug_ball)
    frame_cnt = (frame_cnt + 1) % print_period;

  bool print_now = (frame_cnt == 0);

  color_class_state *orange;
  int n;
  int w,h;
  double conf;
  double d;
  double green_f;

  orange=&color[COLOR_ORANGE];

  region *or_reg; // orange region

  or_reg=orange->list;

  ball->confidence = 0.0;

  if(ballDisabled) return;

  if(!or_reg) return;

  for(n=0; or_reg && n<10; or_reg = or_reg->next, n++) {
    double conf0,conf_square_bbox,conf_area,conf_green,conf_area_bonus;
    double conf_red_v_area;
    double conf_dist_project_error;
    double conf_mult;
    int edge;

    w = or_reg->x2 - or_reg->x1 + 1;
    h = or_reg->y2 - or_reg->y1 + 1;
    
    edge = calcEdgeMask(or_reg);

    conf0 = (((w >= 3) && (h >= 3) && (or_reg->area >= 7)) ? 1.0 : 0.0);
    conf_square_bbox = 
      edge ?
      gaussian_with_min(pct_from_mean(w,h) / .6, 1e-3) :
      gaussian_with_min(pct_from_mean(w,h) / .2, 1e-3);
    conf_area =
      edge ?
      gaussian_with_min(pct_from_mean(M_PI*w*h/4.0,or_reg->area) / .6, 1e-3) :
      gaussian_with_min(pct_from_mean(M_PI*w*h/4.0,or_reg->area) / .2, 1e-3);
    conf_red_v_area = 1.0;
    conf_green = 1.0;
    conf_area_bonus = ((double)or_reg->area / 1000);

    conf_mult =
      conf0 *
      conf_square_bbox *
      conf_area *
      conf_red_v_area *
      conf_green;

    conf = conf_mult + conf_area_bonus;

    if(conf > 1.0) conf = 1.0;
    
    if(debug_conf && print_now) {
      pprintf(TextOutputStream,"conf0 %g conf_square_bbox %g conf_area %f conf_area_bonus %f (conf=%f)\n",
              conf0,conf_square_bbox,conf_area,conf_area_bonus,conf);
    }
    
    if(conf <= ball->confidence)
      continue;

    vector3d ball_dir; // direction of ball from camera in robot coordinates
    ball_dir = getPixelDirection(or_reg->cen_x,or_reg->cen_y);
    
    if(debug_ball && print_now) {
      pprintf(TextOutputStream,"candidate ball n%d cen (%f,%f) area %d bbox (%d,%d)-(%d,%d) conf %f\n",
              n,or_reg->cen_x,or_reg->cen_y,or_reg->area,
              or_reg->x1,or_reg->y1,or_reg->x2,or_reg->y2,
              conf);
    }
    
    d = sqrt((FocalDist * FocalDistV) * (M_PI * BallRadius * BallRadius) /
             (or_reg->area));
    
    // Reject if ball above level plane
    double ang_from_level;
    ang_from_level = atan2(ball_dir.z,hypot(ball_dir.x,ball_dir.y));
    if(ang_from_level > (5*(M_PI/180)))
      continue;

    vector3d intersect_ball_loc,pixel_size_ball_loc;
    vector2d pixel_size_ball_loc_2d;

    bool intersects=false;
    vector3d intersection_pt(0.0,0.0,0.0);

    double ground_dist,ground_dist_sq;
    double ball_to_cam_height;
    ball_to_cam_height = camera_loc.y - BallRadius;
    ground_dist_sq = d * d  -  ball_to_cam_height * ball_to_cam_height;
    ground_dist = (ground_dist_sq > 0.0 ? sqrt(ground_dist_sq) : 0.0);
    vector2d ball_dir_2d(ball_dir.x,ball_dir.y);
    pixel_size_ball_loc_2d = vector2d(camera_loc.x,camera_loc.y) + ball_dir_2d * ground_dist;
    pixel_size_ball_loc.set(pixel_size_ball_loc_2d.x,pixel_size_ball_loc_2d.y,BallRadius);
    //pixel_size_ball_loc = camera_loc + ball_dir * d;

    intersects=GVector::intersect_ray_plane(camera_loc,ball_dir,
                                            vector3d(0.0,0.0,BallRadius),vector3d(0.0,0.0,1.0),
                                            intersection_pt);
    if(intersects) {
      intersect_ball_loc = intersection_pt;
    }

    double ang_diff=0.0;
    conf_dist_project_error = 0.5;
    if(intersects) {
      double ang_diff_cos=0.0;
      vector3d cam_to_ball;
    
      cam_to_ball = pixel_size_ball_loc-camera_loc;
      ang_diff_cos = cam_to_ball.norm().dot(ball_dir);
      ang_diff = acos(ang_diff_cos);
      if(debug_conf && print_now) {
        pprintf(TextOutputStream,"\nang_diff_cos=%g ang_diff=%g cam_to_ball=(%g,%g,%g) cam_to_ball_norm=(%g,%g,%g) ball_dir=(%g,%g,%g)\n",
                ang_diff_cos,ang_diff,
                cam_to_ball.x,cam_to_ball.y,cam_to_ball.z,
                cam_to_ball.norm().x,cam_to_ball.norm().y,cam_to_ball.norm().z,
                ball_dir.x,ball_dir.y,ball_dir.z);
      }
    } else {
      ang_diff = atan2a(ball_to_cam_height,ground_dist);
    }
      
    conf_dist_project_error = uniform_with_gaussian_tails(ang_diff / (5/TODEG), .5, .75);
    
    conf_mult *= conf_dist_project_error;
    
    conf = conf_mult + conf_area_bonus;
    
    if(conf > 1.0) conf = 1.0;
    
    if(debug_ball && print_now) {
      pprintf(TextOutputStream,"|conf ang_diff %f (conf=%f)",
              conf_dist_project_error,conf);
    }
    
    if(conf <= ball->confidence)
      continue;
    
    int sx[2],sy[2]; // scan bounding coordinates;
    bool edge_x[2],edge_y[2]; // true if scan coordinate went off edge
    static const int scan_distance = 3;
    static int color_cnts[MAX_COLORS];
    int scan_pixels;
    int good_value;
    
    sx[0] = or_reg->x1 - scan_distance;
    edge_x[0] = (sx[0] < 0);
    if(edge_x[0]) sx[0] = 0;
    sx[1] = or_reg->x2 + scan_distance;
    edge_x[1] = (sx[1] > width-1);
    if(edge_x[1]) sx[1] = width-1;
    sy[0] = or_reg->y1 - scan_distance;
    edge_y[0] = (sy[0] < 0);
    if(edge_y[0]) sy[0] = 0;
    sy[1] = or_reg->y2 + scan_distance;
    edge_y[1] = (sy[1] > height-1);
    if(edge_y[1]) sy[1] = height-1;
    
    scan_pixels = 0;
    for(int color_idx=0; color_idx<MAX_COLORS; color_idx++)
      color_cnts[color_idx]=0;
    
    // do horizontal strips
    for(int side=0; side<2; side++) {
      if(!edge_y[side]) {
        scan_pixels+=addToHistHorizStrip(sy[side],sx[0],sx[1],color_cnts);
      }
    }
    
    // do vertical strips
    for(int side=0; side<2; side++) {
      if(!edge_x[side]) {
        scan_pixels+=addToHistVertStrip(sx[side],sy[0],sy[1],color_cnts);
      }
    }

    int non_robot_fringe=0;
    non_robot_fringe += 5*color_cnts[COLOR_GREEN ];
    non_robot_fringe += 3*color_cnts[COLOR_WHITE ];
    non_robot_fringe += 3*color_cnts[COLOR_BLUE  ];
    non_robot_fringe -=   color_cnts[COLOR_RED   ];
    non_robot_fringe -= 2*color_cnts[COLOR_YELLOW];

    conf_red_v_area = 1 + (((double)non_robot_fringe) / or_reg->area);
    conf_red_v_area = bound(conf_red_v_area,0.0,1.0);
      
    good_value = 0;
    good_value += 2*color_cnts[COLOR_GREEN ];
    good_value += 2*color_cnts[COLOR_WHITE ];
    good_value += 3*color_cnts[COLOR_RED   ]/2;
    good_value += 2*color_cnts[COLOR_BLUE  ];
    good_value -=   color_cnts[COLOR_YELLOW]/2;

    green_f = max(good_value+1,1) / (scan_pixels + 1.0);
    green_f = bound(green_f,0.0,1.0);
    conf_green = green_f;
    
    conf_mult *= conf_green;
    conf_mult *= conf_red_v_area;
    
    conf = conf_mult + conf_area_bonus;

    if(conf > 1.0) conf = 1.0;

    if(debug_ball && print_now) {
      pprintf(TextOutputStream,"|conf red_v_area %f green_f %f (conf=%f) good_value %d g %d w %d r %d b %d y %d scan_pixels %d\n",
              conf_red_v_area,green_f,conf,good_value,
              color_cnts[COLOR_GREEN],color_cnts[COLOR_WHITE],color_cnts[COLOR_RED],color_cnts[COLOR_BLUE],color_cnts[COLOR_YELLOW],
              scan_pixels);
    }

    if(conf <= ball->confidence)
      continue;

    // Decided this is in fact a better ball than we had before so calc and save all the stats for it.
    
    ball->edge = calcEdgeMask(or_reg);
        
    vector3d ball_loc,alt_ball_loc;
    if(ball->edge!=0 && intersects) {
      ball_loc     = intersect_ball_loc;
      alt_ball_loc = pixel_size_ball_loc;
    } else {
      alt_ball_loc = intersect_ball_loc;
      ball_loc     = pixel_size_ball_loc;
    } 

    ball->confidence = conf;
        
    ball->loc = ball_loc;
        
    ball->distance = hypot(ball_loc.x,ball_loc.y);
        
    findSpan(ball->left,ball->right,or_reg->x1,or_reg->x2,or_reg->y1,or_reg->y2);

    ball_info->reg = or_reg;

    if(debug_ball && print_now) {
      pprintf(TextOutputStream,"###found ball, conf %g loc (%g,%g,%g) alt (%g,%g,%g) dist %g left %g right %g edge %d\n",
              ball->confidence,
              ball->loc.x,ball->loc.y,ball->loc.z,
              alt_ball_loc.x,alt_ball_loc.y,alt_ball_loc.z,
              ball->distance,ball->left,ball->right,ball->edge);
    }
  }
}

void Vision::findMarkers(VObject *markers,VisionObjectInfo *marker_infos) {
  const bool debug_markers    = false;
  const bool debug_verbose    = false;
  const bool debug_confidence = false;
  static int frame_cnt=0;
#ifdef PLATFORM_APERIOS
  static const int print_period=30;
#else
  static const int print_period=1;
#endif

  if(debug_markers)
    frame_cnt = (frame_cnt + 1) % print_period;

  static const int MaxMarkerRegions=10;

  // color (along with pink) for markers 0-1, 2-3, and 4-5, respectively
  static const int marker_color_array[3] = {COLOR_CYAN, COLOR_GREEN, COLOR_YELLOW};

  //pprintf(TextOutputStream,"Trying to find markers\n");

  for(int marker_idx=0; marker_idx<6; marker_idx++)
    markers[marker_idx].confidence=0.0;

  region *pk_reg; // pink regions
  int pk_num; // number of pink regions processed

  pk_reg = color[COLOR_PINK].list;
  pk_num=0;

  while(pk_reg && pk_num<MaxMarkerRegions) {
    if(debug_markers && debug_verbose &&
       frame_cnt == 0)
      pprintf(TextOutputStream,"pk %d img (%g,%g) area %d\n",pk_num,pk_reg->cen_x,pk_reg->cen_y,pk_reg->area);

    if(pk_reg->area > 8) {
      for(int color_idx=0; color_idx<3; color_idx++) {
        int marker_color;
        
        marker_color = marker_color_array[color_idx];
        
        region *ot_reg; // the other region
        int ot_num;

        ot_reg = color[marker_color].list;
        ot_num = 0;

        while(ot_reg && ot_num<MaxMarkerRegions) {
          double s,conf1,conf2,conf3;
          double conf;
          int marker_idx;

          if(debug_markers && debug_verbose &&
             frame_cnt == 0)
            pprintf(TextOutputStream,"  ot %d img (%g,%g) area %d\n",ot_num,ot_reg->cen_x,ot_reg->cen_y,ot_reg->area);

          vector3d pk_dir,ot_dir;
          vector2d pk_ctr,ot_ctr;
          bool pink_top;
          vector3d top_dir,bot_dir;
          vector2d xy_dir;
          vector2d top_dz_dir,bot_dz_dir; // vector in distance (radial direction) and elevation
          vector2d marker_dz_loc;
          vector2d marker_xy_loc;
          vector3d marker_loc;
          double top_t,bot_t;
          bool bad_marker=false;

          if(ot_reg->area <= 8)
            bad_marker = true;

          // The color classification we use tends to not pick up colors blended with pink but
          // does pick up colors blended with white.  The causes a .5 pixel bias in the centroid
          // of the color region which then makes distance readings be too small.  The
          // marker_color_offset parameter corrects for this bias by moving the centroid of the
          // colored region.  This parameter should be -.5 in order to make the colored region move
          // the .5 pixels towards the pink region.

          pk_ctr.set(pk_reg->cen_x,pk_reg->cen_y);
          pk_dir = getPixelDirection(pk_ctr.x,pk_ctr.y);
          ot_ctr.set(ot_reg->cen_x,ot_reg->cen_y);
          ot_ctr += (ot_ctr-pk_ctr).norm() * marker_color_offset;
          ot_dir = getPixelDirection(ot_ctr.x,ot_ctr.y);

          // protect against numerical instabilities (we'd end up throwing this out anyway)
          if(fabs(atan2(pk_dir.z,hypot(pk_dir.x,pk_dir.y))) > 25*M_PI/180.0)
            bad_marker=true;

          // protect against numerical instabilities (we'd end up throwing this out anyway)
          if(fabs(atan2(ot_dir.z,hypot(ot_dir.x,ot_dir.y))) > 25*M_PI/180.0)
            bad_marker=true;

          if(!bad_marker) {
            if(debug_markers && debug_verbose &&
               frame_cnt == 0) {
              pprintf(TextOutputStream,"   pk_dir (%g,%g,%g) ot_dir (%g,%g,%g)\n",
                      pk_dir.x,pk_dir.y,pk_dir.z,
                      ot_dir.x,ot_dir.y,ot_dir.z);
            }

            pink_top = pk_dir.z > ot_dir.z;
            if(pink_top) {
              top_dir = pk_dir;
              bot_dir = ot_dir;
            }
            else {
              top_dir = ot_dir;
              bot_dir = pk_dir;
            }

            alignVertical(top_dir,bot_dir,xy_dir,top_dz_dir,bot_dz_dir);

            vector2d pk_to_ot_img;
            pk_to_ot_img = vector2d(pk_reg->cen_x,pk_reg->cen_y) - vector2d(ot_reg->cen_x,ot_reg->cen_y);
            pk_to_ot_img.normalize();
            conf1 = fabs(pk_to_ot_img.dot(img_up));
            conf1 = (conf1 - .966) / (1 - .966); // fall to zero in 15 degrees
            conf1 = bound(conf1,0.0,1.0);
            if(debug_markers && debug_verbose &&
               frame_cnt == 0)
              pprintf(TextOutputStream,"    pk_to_ot_img (%g,%g) img_up (%g,%g) dot %g\n",
                      pk_to_ot_img.x,pk_to_ot_img.y,
                      img_up.x,img_up.y,
                      pk_to_ot_img.dot(img_up));
            
            s = sqrdist(pk_reg->cen_x, pk_reg->cen_y, ot_reg->cen_x, ot_reg->cen_y);
            //conf2 = gaussian_with_min(pct_from_mean(pk_reg->area,ot_reg->area) / .2, 1e-3);
            conf2 = gaussian_with_min(pct_from_mean(pk_reg->area,ot_reg->area) / .3, 1e-3);
            //conf3 = gaussian_with_min(pct_from_mean((pk_reg->area+ot_reg->area)/2,s) / .3, 1e-3);
            conf3 = gaussian_with_min(pct_from_mean((pk_reg->area+ot_reg->area)/2,s) / .5, 1e-3);

            conf = conf1 * conf2 * conf3;
            marker_idx = 2*color_idx + pink_top;

            if(debug_markers && debug_confidence &&
               frame_cnt == 0)
              pprintf(TextOutputStream,"    marker %d conf 1:%g 2:%g 3:%g final:%g\n",marker_idx,conf1,conf2,conf3,conf);

            if(conf > markers[marker_idx].confidence) {
              vector2d top_dz_loc,bot_dz_loc;
              top_dz_loc.set(0,0); bot_dz_loc.set(0,0);
              // FIXME: Use return value
              findLocVerticalSeperation(top_dz_dir,bot_dz_dir,MarkerColorSeperation,top_dz_loc,bot_dz_loc);
          
              if(debug_markers && debug_verbose &&
                 frame_cnt == 0) {
                pprintf(TextOutputStream,"top_t %g bot_t %g ",
                        top_t,bot_t);
              }

              marker_dz_loc = (top_dz_loc + bot_dz_loc) / 2.0;
              marker_xy_loc = xy_dir * marker_dz_loc.x;
              marker_loc.set(marker_xy_loc.x,marker_xy_loc.y,marker_dz_loc.y);
              marker_loc += camera_loc;
        
              if(debug_markers && debug_verbose &&
                 frame_cnt == 0) {
                pprintf(TextOutputStream,"mk dz_loc (%g,%g) xy_loc (%g,%g)\n",
                        top_t,bot_t);
              }


              //          d = sqrt(s);
              //
              if(debug_markers && debug_verbose &&
                 frame_cnt == 0)
                pprintf(TextOutputStream,"    pk %d c %d ot %d marker %d conf %g img_d %g ",
                        pk_num,color_idx,ot_num,marker_idx,conf,sqrt(s));

              markers[marker_idx].confidence = conf;

              markers[marker_idx].loc = marker_loc;
              markers[marker_idx].distance = hypot(marker_loc.x,marker_loc.y);

              int x1,x2,y1,y2; // x1=min x, x2=max x, y1=min y, y2=max y

              x1 = min(pk_reg->x1,ot_reg->x1);
              x2 = max(pk_reg->x2,ot_reg->x2);
              y1 = min(pk_reg->y1,ot_reg->y1);
              y2 = max(pk_reg->y2,ot_reg->y2);

              findSpan(markers[marker_idx].left,markers[marker_idx].right,x1,x2,y1,y2);

              markers[marker_idx].edge = calcEdgeMask(x1,x2,y1,y2);

              marker_infos[marker_idx].reg  = pk_reg;
              marker_infos[marker_idx].reg2 = ot_reg;

              if(debug_markers && debug_verbose &&
                 (frame_cnt == 0))
                pprintf(TextOutputStream,"dist %g img (%g,%g) edge %d\n",
                        marker_dz_loc.x,
                        (pk_reg->cen_x+ot_reg->cen_x)/2.0,(pk_reg->cen_y+ot_reg->cen_y)/2.0,
                        markers[marker_idx].edge);
            }
          }

          ot_num++;
          ot_reg = ot_reg->next;
        }
      }
    }

    pk_num++;
    pk_reg = pk_reg->next;
  }

  if(debug_markers && 
     frame_cnt == 0) {
    for(int marker_idx=0; marker_idx<6; marker_idx++) {
      VObject *marker;
      
      marker=&markers[marker_idx];
      if(marker->confidence > 0.02)
        pprintf(TextOutputStream,"marker %d conf %g loc (%g,%g,%g) dist %g left %g right %g edge %d\n",
                marker_idx,marker->confidence,marker->loc.x,marker->loc.y,marker->loc.z,marker->distance,marker->left,marker->right,marker->edge);  
    }
  }
  

  //pprintf(TextOutputStream,"Done finding markers\n");
}

struct ScanGoalHeightCallbackParams {
  Vision *vision;
  int colorToFind;
  int heightSoFar;
  int greenSoFar;
  int otherSoFar;
  bool up,endLocSet;
  GVector::vector2d<int> endLoc;

  void init(Vision *vision_param, int color_idx, bool up_param) {
    vision = vision_param;
    colorToFind = color_idx;
    heightSoFar = 0;
    greenSoFar = 0;
    otherSoFar = 0;
    up = up_param;
    endLoc.set(0,0);
    endLocSet = false;
  }
};

struct ScanGoalHeightCallback {
  bool operator()(int x,int y,ScanGoalHeightCallbackParams *params) {
    int color = params->vision->getNearColor(x,y);

    if(!params->endLocSet) {
      params->endLocSet = true;
      params->endLoc.set(x,y);
    }

    if(color == params->colorToFind) {
      params->heightSoFar++;
      params->endLoc.set(x,y);
    } else if(color == COLOR_GREEN) {
      params->greenSoFar++;
    } else {
      params->otherSoFar++;
    }

    //pprintf(TextOutputStream,"ht:pt=(%3d,%3d) color=%d cnts:c=%2d g=%2d o=%2d\n",x,y,color,
    //        params->heightSoFar,params->greenSoFar,params->otherSoFar);

    //return (params->heightSoFar > 2*(params->greenSoFar + params->otherSoFar));
    if(params->up)
      return
        ((params->heightSoFar*params->heightSoFar > 
          (params->endLoc-GVector::vector2d<int>(x,y)).sqlength()) ||
         (params->heightSoFar < 5));
    else
      return
        (params->greenSoFar < 5);
  }
};

struct ScanGoalWidthCallbackParams {
  Vision *vision;
  int colorToFind;
  int widthSoFar;
  int otherSoFar;
  int x1,x2,y1,y2;
  GVector::vector2d<int> endLoc;

  void init(Vision *vision_param, int color_idx, int x1_in, int y1_in, int x2_in, int y2_in) {
    vision = vision_param;
    colorToFind = color_idx;
    x1 = x1_in;
    y1 = y1_in;
    x2 = x2_in;
    y2 = y2_in;
    widthSoFar = 0;
    otherSoFar = 0;
    endLoc.set(0,0);
  }
};

struct ScanGoalWidthCallback {
  bool operator()(int x,int y,ScanGoalWidthCallbackParams *params) {
    int color = params->vision->getNearColor(x,y);

    if(color == params->colorToFind) {
      params->widthSoFar++;
      params->endLoc.set(x,y);
    } else {
      params->otherSoFar++;
    }

    //pprintf(TextOutputStream,"wd:pt=(%3d,%3d) color=%d cnts:c=%2d o=%2d\n",x,y,color,
    //        params->widthSoFar,params->otherSoFar);

    return Vision::inBox(x,y,params->x1,params->y1,params->x2,params->y2);
  }
};

template<class Callback, class CallbackParams>
bool Vision::drawLine(int x0,int y0,
                      int x1,int y1,
                      Callback callback, CallbackParams params)
{
  int w,h;
  int sx,sy;
  int dx,dy;

  dx = sign(x1 - x0);
  dy = sign(y1 - y0);
  w = abs(x1 - x0);
  h = abs(y1 - y0);
  sx = h;
  sy = w;

  while(true) {
    // draw point
    if(!callback(x0,y0,params))
      return false;

    if(x0==x1 && y0==y1)
      break;

    // find next point
    if(sx < sy){
      sx += h;
      x0 += dx;
    } else {
      sy += w;
      y0 += dy;
    }
  }

  return true;
}

template<class Callback, class CallbackParams>
bool Vision::drawLine2(int x, int y,
                       int vx,int vy,
                       Callback callback, CallbackParams params)
{
  int w,h;
  int sx,sy;
  int dx,dy;

  if(vx==0 && vy==0) return true;

  dx = sign(vx);
  dy = sign(vy);
  w = abs(vx);
  h = abs(vy);
  sx = h;
  sy = w;

  while(x>=0 && x<width && y>=0 && y<height){
    // draw point
    if(!callback(x,y,params))
      return false;

    // find next point
    if(sx < sy){
      sx += h;
      x += dx;
    }else{
      sy += w;
      y += dy;
    }
  }

  return true;
}

struct FindColorCallbackParams {
  Vision *vision;
  int colorIdx;
  int atX,atY;

  void init(Vision *vision_param,int color_idx) {
    vision = vision_param;
    colorIdx = color_idx;
    atX = atY = 0;
  }    
};

struct FindColorCallback {
  bool operator()(int x, int y, FindColorCallbackParams *params) {
    int color_at=0;

    color_at = params->vision->cmap[y*params->vision->width + x];
    if(color_at == params->colorIdx) {
      params->atX = x;
      params->atY = y;
      return false;
    } else {
      return true;
    }

    return true;
  }
};

struct FindLastColorCallbackParams {
  Vision *vision;
  int colorIdx;
  int atX,atY;

  void init(Vision *vision_param,int color_idx) {
    vision = vision_param;
    colorIdx = color_idx;
    atX = atY = 0;
  }    
};

struct FindLastColorCallback {
  bool operator()(int x, int y, FindLastColorCallbackParams *params) {
    int color_at=0;

    color_at = params->vision->cmap[y*params->vision->width + x];
    if(color_at == params->colorIdx) {
      params->atX = x;
      params->atY = y;
      return true;
    } else {
      return false;
    }

    return true;
  }
};

static const GVector::vector2d<int> Dirs[8] = {
  GVector::vector2d<int>( 1, 0),
  GVector::vector2d<int>( 1, 1),
  GVector::vector2d<int>( 0, 1),
  GVector::vector2d<int>(-1, 1),
  GVector::vector2d<int>(-1, 0),
  GVector::vector2d<int>(-1,-1),
  GVector::vector2d<int>( 0,-1),
  GVector::vector2d<int>( 1,-1)
};

bool Vision::findCorner(int color_idx, int dir_x, int dir_y, int *x, int *y) {
  static const bool debug=false;

  GVector::vector2d<int> cur_loc;

  cur_loc.set(*x,*y);

  // first find a pixel that is of color color_idx
  // use drawLine2

  if(debug)
    pprintf(TextOutputStream,"start (%d,%d)\n",cur_loc.x,cur_loc.y);

  if(!onImage(cur_loc.x,cur_loc.y)) {
    if(debug)
      pprintf(TextOutputStream,"cur_loc (%d,%d) not on image\n",cur_loc.x,cur_loc.y);

    vector2d loc_r,dir_r,intersect_pt;

    loc_r.set(cur_loc.x,cur_loc.y);
    dir_r.set(-dir_x,-dir_y);
    dir_r.normalize();
    if(debug)
      pprintf(TextOutputStream,"dir_r (%g,%g)\n",dir_r.x,dir_r.y);
    if(loc_r.x < 0) {
      if(!GVector::intersect_ray_plane(loc_r,dir_r,vector2d(0,0),vector2d(-1,0),intersect_pt)) {
        if(debug)
          pprintf(TextOutputStream,"x<0 intersection failed\n");
        return false;
      }
      loc_r = intersect_pt;
    }
    if(debug)
      pprintf(TextOutputStream,"1 loc_r (%g,%g)\n",loc_r.x,loc_r.y);
    if(loc_r.x > width-1) {
      if(!GVector::intersect_ray_plane(loc_r,dir_r,vector2d(width-1,0),vector2d(1,0),intersect_pt)) {
        if(debug)
          pprintf(TextOutputStream,"x>width-1 intersection failed\n");
        return false;
      }
      loc_r = intersect_pt;
    }
    if(debug)
      pprintf(TextOutputStream,"2 loc_r (%g,%g)\n",loc_r.x,loc_r.y);
    if(loc_r.y < 0) {
      if(!GVector::intersect_ray_plane(loc_r,dir_r,vector2d(0,0),vector2d(0,-1),intersect_pt)) {
        if(debug)
          pprintf(TextOutputStream,"y<0 intersection failed\n");
        return false;
      }
      if(intersect_pt.x < 0 || intersect_pt.x > width-1) {
        if(debug)
          pprintf(TextOutputStream,"y<0 intersection disturbed x\n");
        return false;
      }
      loc_r = intersect_pt;
    }
    if(debug)
      pprintf(TextOutputStream,"3 loc_r (%g,%g)\n",loc_r.x,loc_r.y);
    if(loc_r.y > height-1) {
      if(!GVector::intersect_ray_plane(loc_r,dir_r,vector2d(0,height-1),vector2d(0,1),intersect_pt)) {
        if(debug)
          pprintf(TextOutputStream,"y>hieght intersection failed\n");
        return false;
      }
      if(intersect_pt.x < 0 || intersect_pt.x > width-1) {
        if(debug)
          pprintf(TextOutputStream,"y>hieght intersection disturbed x\n");
        return false;
      }
      loc_r = intersect_pt;
    }
    if(debug)
      pprintf(TextOutputStream,"4 loc_r (%g,%g)\n",loc_r.x,loc_r.y);
    if(loc_r.y < 0 || loc_r.y > height-1)
      return false;
    if(debug)
      pprintf(TextOutputStream,"5 loc_r (%g,%g)\n",loc_r.x,loc_r.y);
    cur_loc.set((int)loc_r.x,(int)loc_r.y);

    if(debug)
      pprintf(TextOutputStream,"cur_loc moved to (%d,%d)\n",cur_loc.x,cur_loc.y);
  }

  if(cmap[cur_loc.y*width + cur_loc.x]==color_idx) {
    FindLastColorCallbackParams flc_params;
    FindLastColorCallback flc;
    flc_params.init(this,color_idx);
    drawLine2(cur_loc.x,cur_loc.y,dir_x,dir_y,flc,&flc_params);
    cur_loc.set(flc_params.atX,flc_params.atY);
  } else {
    FindColorCallbackParams fc_params;
    FindColorCallback find_color;
    fc_params.init(this,color_idx);
    if(drawLine2(cur_loc.x,cur_loc.y,-dir_x,-dir_y,find_color,&fc_params))
      return false;
    cur_loc.set(fc_params.atX,fc_params.atY);
  }

  if(debug)
    pprintf(TextOutputStream,"found (%d,%d)\n",cur_loc.x,cur_loc.y);

  // now greedily try to move to pixels in dir_x,dir_y direction
  int dir_idxs[4];
  int dir16; // direction quantized down to 16 directions

  dir16 = 0;
  if(abs(dir_x) < abs(dir_y)) {
    if(2*abs(dir_x) < abs(dir_y)) {
      dir16 = 3;
    } else {
      dir16 = 2;
    }
  } else {
    if(abs(dir_x) > 2*abs(dir_y)) {
      dir16 = 0;
    } else {
      dir16 = 1;
    }
  }
  if(dir_y < 0)
    dir16 = 15-dir16; // flip vertically
  if(dir_x < 0)
    dir16 = (dir16 & 0x8) + (0x7 - (dir16 & 0x7)); // flip horizontally

  if(dir16 & 1) {
    dir_idxs[0] = (((dir16+ 1)/2) + 8) % 8;
    dir_idxs[2] = (((dir16+ 3)/2) + 8) % 8;
    dir_idxs[1] = (((dir16+15)/2) + 8) % 8;
    dir_idxs[3] = (((dir16+13)/2) + 8) % 8;
  } else {
    dir_idxs[0] = (((dir16+ 0)/2) + 8) % 8;
    dir_idxs[2] = (((dir16+14)/2) + 8) % 8;
    dir_idxs[1] = (((dir16+ 2)/2) + 8) % 8;
    dir_idxs[3] = (((dir16+ 4)/2) + 8) % 8;
  }

  if(debug)
    pprintf(TextOutputStream,"dir (%4d,%4d) dir_idxs=[%d,%d,%d,%d] dirs=[(%2d,%2d) (%2d,%2d) (%2d,%2d) (%2d,%2d)]\n",
            dir_x,dir_y,
            dir_idxs[0],dir_idxs[1],dir_idxs[2],dir_idxs[3],
            Dirs[dir_idxs[0]].x,Dirs[dir_idxs[0]].y,Dirs[dir_idxs[1]].x,Dirs[dir_idxs[1]].y,
            Dirs[dir_idxs[2]].x,Dirs[dir_idxs[2]].y,Dirs[dir_idxs[3]].x,Dirs[dir_idxs[3]].y
            );

  bool done=false;
  while(!done) {
    bool found_move;
    found_move = false;
    for(int dir_to_try=0; !found_move && dir_to_try<4; dir_to_try++) {
      GVector::vector2d<int> new_loc;
      new_loc = cur_loc + Dirs[dir_idxs[dir_to_try]];
      if(onImage(new_loc.x,new_loc.y)) {
        if(cmap[new_loc.y*width + new_loc.x]==color_idx) {
          found_move = true;
          cur_loc = new_loc;
        }
      }
    }
    done = !found_move;
  }

  if(debug)
    pprintf(TextOutputStream,"climb (%d,%d)\n",cur_loc.x,cur_loc.y);

  *x = cur_loc.x;
  *y = cur_loc.y;

  return true;
}

void Vision::findGoal(int color_idx, VObject *goal, VObject *goal_edges,VisionObjectInfo *goal_info) {
  static const bool debug_goals  =false;
  static const bool debug_verbose=false;
  static const bool debug_conf   =false;
  static const bool debug_sort=false;
  static const int debug_sort_color=5;
  static const int goal_outside_offset=4; // offset to get outside of the goal on image

  static int frame_cnt=0;
#ifdef PLATFORM_LINUX
  static const int print_period=1;
#else
  static const int print_period=90;
#endif
  if(debug_goals)
    frame_cnt = (frame_cnt + 1) % print_period;

  bool print_now = debug_goals && (frame_cnt == 0);

  if(debug_sort && color_idx==debug_sort_color) {
    DebugClass = 0;
    DebugInfo[0] = '\0';
  }

  region *goal_reg;

  //pprintf(TextOutputStream,"Trying to find goal of color %d\n",color_idx);

  goal_reg = color[color_idx].list;

  goal->confidence=0.0;
  goal_edges[0].confidence = 0.0;
  goal_edges[1].confidence = 0.0;

  if(!goal_reg) return;

  if(goal_reg->area < 10) return;

  if(print_now)
    pprintf(TextOutputStream,"region color %d ll (%d,%d) ur (%d,%d) cen (%g,%g) area %d\n",
            color_idx,
            goal_reg->x1,goal_reg->y1,goal_reg->x2,goal_reg->y2,
            goal_reg->cen_x,goal_reg->cen_y,goal_reg->area);

  GVector::vector2d<int> left_loc,right_loc,top_loc,bottom_loc;
  int x_size,y_size;
  
  int start_xh,start_yh;
  start_xh = (int)goal_reg->cen_x;
  start_yh = (int)goal_reg->cen_y;

  int dir_x,dir_y;
  dir_x = (int)(img_up.x*1000);
  dir_y = (int)(img_up.y*1000);

  ScanGoalHeightCallback ht_callback;
  ScanGoalHeightCallbackParams ht_params;

  ht_params.init(this,color_idx,false);
  drawLine2(start_xh,start_yh,-dir_x,-dir_y,ht_callback,&ht_params);
  bottom_loc = ht_params.endLoc;

  ht_params.init(this,color_idx,true);
  drawLine2(start_xh,start_yh,dir_x,dir_y,ht_callback,&ht_params);
  top_loc = ht_params.endLoc;

  if(top_loc == bottom_loc) return;

  GVector::vector2d<int> diff_loc;
  diff_loc = top_loc - bottom_loc;
  diff_loc.set(abs(diff_loc.x),abs(diff_loc.y));
  diff_loc += GVector::vector2d<int>(1,1);
  y_size = (int)(sqrt((double)diff_loc.sqlength()));

  if(y_size < 3) return;

  int start_xw,start_yw;
  start_xw = (start_xh + top_loc.x) / 2;
  start_yw = (start_yh + top_loc.y) / 2;
  dir_x = (int)(img_hor.x*1000);
  dir_y = (int)(img_hor.y*1000);

  ScanGoalWidthCallback wd_callback;
  ScanGoalWidthCallbackParams wd_params;

  wd_params.init(this,color_idx,goal_reg->x1,goal_reg->y1,goal_reg->x2,goal_reg->y2);
  drawLine2(start_xw,start_yw,dir_x,dir_y,wd_callback,&wd_params);
  right_loc = wd_params.endLoc;

  wd_params.init(this,color_idx,goal_reg->x1,goal_reg->y1,goal_reg->x2,goal_reg->y2);
  drawLine2(start_xw,start_yw,-dir_x,-dir_y,wd_callback,&wd_params);
  left_loc = wd_params.endLoc;

  if(left_loc == right_loc) return;

  diff_loc = right_loc - left_loc;
  diff_loc.set(abs(diff_loc.x),abs(diff_loc.y));
  diff_loc += GVector::vector2d<int>(1,1);
  x_size = (int)(sqrt((double)diff_loc.sqlength()));

  if(x_size < 3) return;

  // bottom/top left/right corner (w/ respect to world) (relative to centroid)
  GVector::vector2d<int> blc_cen,brc_cen,tlc_cen,trc_cen;
  // bottom/top left/right corner (w/ respect to world) (img coordinates)
  GVector::vector2d<int> blc_img,brc_img,tlc_img,trc_img;
  GVector::vector2d<int> centroid;

  centroid.set(start_xh,start_yh);

  tlc_cen =
    GVector::vector2d<int>(top_loc.x    - start_xh, top_loc.y    - start_yh) +
    GVector::vector2d<int>(left_loc.x   - start_xw, left_loc.y   - start_yw);
  trc_cen =
    GVector::vector2d<int>(top_loc.x    - start_xh, top_loc.y    - start_yh) +
    GVector::vector2d<int>(right_loc.x  - start_xw, right_loc.y  - start_yw);
  blc_cen =
    GVector::vector2d<int>(bottom_loc.x - start_xh, bottom_loc.y - start_yh) +
    GVector::vector2d<int>(left_loc.x   - start_xw, left_loc.y   - start_yw);
  brc_cen =
    GVector::vector2d<int>(bottom_loc.x - start_xh, bottom_loc.y - start_yh) +
    GVector::vector2d<int>(right_loc.x  - start_xw, right_loc.y  - start_yw);

  tlc_img = centroid + tlc_cen;
  trc_img = centroid + trc_cen;
  blc_img = centroid + blc_cen;
  brc_img = centroid + brc_cen;

  if(print_now && debug_verbose) {
    pprintf(TextOutputStream,"befor tl=(%d,%d) tr=(%d,%d) bl=(%d,%d) br=(%d,%d)\n",
            tlc_img.x,tlc_img.y,
            trc_img.x,trc_img.y,
            blc_img.x,blc_img.y,
            brc_img.x,brc_img.y);
  }

  bool found_tlc,found_trc,found_blc,found_brc;

  found_tlc=findCorner(color_idx,(int)(1000*( img_up.x-img_hor.x)),(int)(1000*( img_up.y-img_hor.y)),&tlc_img.x,&tlc_img.y);
  found_trc=findCorner(color_idx,(int)(1000*( img_up.x+img_hor.x)),(int)(1000*( img_up.y+img_hor.y)),&trc_img.x,&trc_img.y);
  found_blc=findCorner(color_idx,(int)(1000*(-img_up.x-img_hor.x)),(int)(1000*(-img_up.y-img_hor.y)),&blc_img.x,&blc_img.y);
  found_brc=findCorner(color_idx,(int)(1000*(-img_up.x+img_hor.x)),(int)(1000*(-img_up.y+img_hor.y)),&brc_img.x,&brc_img.y);

  if(print_now && debug_verbose) {
    pprintf(TextOutputStream,"after tl=(%d,%d) tr=(%d,%d) bl=(%d,%d) br=(%d,%d)\n",
            (found_tlc ? tlc_img.x : -1),(found_tlc ? tlc_img.y : -1),
            (found_trc ? trc_img.x : -1),(found_trc ? trc_img.y : -1),
            (found_blc ? blc_img.x : -1),(found_blc ? blc_img.y : -1),
            (found_brc ? brc_img.x : -1),(found_brc ? brc_img.y : -1));
  }

  bool good_xsize = false;
  if(found_tlc && found_trc) {
    diff_loc = trc_img - tlc_img;
    diff_loc.set(abs(diff_loc.x),abs(diff_loc.y));
    diff_loc += GVector::vector2d<int>(1,1);
    x_size = (int)(sqrt((double)diff_loc.sqlength()));
    good_xsize = (calcEdgeMask(tlc_img.x,tlc_img.y)==0 && calcEdgeMask(trc_img.x,trc_img.y)==0);
  }
  if(found_blc && found_brc && !good_xsize && 
     (calcEdgeMask(blc_img.x,blc_img.y)==0 && calcEdgeMask(brc_img.x,brc_img.y)==0)) {
    diff_loc = trc_img - tlc_img;
    diff_loc.set(abs(diff_loc.x),abs(diff_loc.y));
    diff_loc += GVector::vector2d<int>(1,1);
    x_size = (int)(sqrt((double)diff_loc.sqlength()));
  }

  bool good_ysize = false;
  if(found_tlc && found_blc) {
    diff_loc = tlc_img - blc_img;
    diff_loc.set(abs(diff_loc.x),abs(diff_loc.y));
    diff_loc += GVector::vector2d<int>(1,1);
    y_size = (int)(sqrt((double)diff_loc.sqlength()));
    good_ysize = (calcEdgeMask(tlc_img.x,tlc_img.y)==0 && 
                  (calcEdgeMask(blc_img.x,blc_img.y) & (OFF_EDGE_TOP | OFF_EDGE_BOTTOM))==0);
  }
  if(found_blc && found_brc && !good_ysize) {
    diff_loc = trc_img - brc_img;
    diff_loc.set(abs(diff_loc.x),abs(diff_loc.y));
    diff_loc += GVector::vector2d<int>(1,1);
    y_size = (int)(sqrt((double)diff_loc.sqlength()));
  }

  if(x_size <= 2 || y_size <=2)
    return;

  double g_conf,g_conf0,g_conf1,g_conf2,g_conf3; // goal confidence values
  double ge_conf,ge_conf0,ge_conf1,ge_conf2,ge_conf3; // goal edge confidence values

  // ******** process central part of goal **********
  double ratio_wh; // ratio of width to height
  int area;

  area = goal_reg->area;

  ratio_wh = (double)x_size / y_size;

  bool found_left_edge,found_right_edge;
  found_left_edge = found_right_edge = false;

  // ********** process edges **********
  int sides[2]={LEFT_SIDE, RIGHT_SIDE};
  for(int side_idx=0; side_idx<2; side_idx++) {
    bool found_tc=false,found_bc=false;
    GVector::vector2d<int> tc_img,bc_img;

    switch(sides[side_idx]) {
    case LEFT_SIDE:
      found_tc = found_tlc;
      found_bc = found_blc;
      tc_img = tlc_img;
      bc_img = blc_img;
      break;
    case RIGHT_SIDE:
      found_tc = found_trc;
      found_bc = found_brc;
      tc_img = trc_img;
      bc_img = brc_img;
      break;
    }

    if(found_tc && found_bc && calcEdgeMask(bc_img.x,bc_img.y)==0) {
      VObject *cur_edge;
      cur_edge = &goal_edges[sides[side_idx]];

      found_left_edge = true;
      cur_edge->confidence = 1.0;

      vector3d triang_loc,sep_loc;
      triang_loc.set(0,0,0);
      sep_loc.set(0,0,0);

      vector3d bc_pix_dir;
      bool intersects=false;

      vector2d eff_bc,eff_tc;

      // offset a half pixel to get real corner
      eff_bc.set(bc_img.x,bc_img.y);
      eff_tc.set(tc_img.x,tc_img.y);
      eff_bc += -img_up * .5; 
      eff_tc +=  img_up * .5;
      if(sides[side_idx]==LEFT_SIDE) {
        eff_bc += -img_hor * .5; 
        eff_tc += -img_hor * .5;
      } else {
        eff_bc +=  img_hor * .5; 
        eff_tc +=  img_hor * .5;
      }

      if(print_now && debug_verbose) {
        pprintf(TextOutputStream,"eff bc=(%g,%g) tc=(%g,%g)\n",eff_bc.x,eff_bc.y,eff_tc.x,eff_tc.y);
      }

      bc_pix_dir = getPixelDirection(eff_bc.x,eff_bc.y);

      // FIXME: Change this to a more optimized version
      intersects = GVector::intersect_ray_plane(camera_loc,bc_pix_dir,vector3d(0,0,0),vector3d(0,0,1.0),triang_loc);

      // Calc filters for green below goal, white to left/right of bottom
      vector2d b2t,green_loc_r,white_loc_r;
      b2t = eff_tc - eff_bc;

      green_loc_r = eff_tc - img_up*(b2t.length() + goal_outside_offset);
      white_loc_r = eff_tc - img_up*(b2t.length() * (1.0 - (WallHeight*.67)/GoalHeight));
      white_loc_r += (sides[side_idx]==LEFT_SIDE ? -img_hor : img_hor) * 5;

      GVector::vector2d<int> green_loc,white_loc;
      green_loc.set((int)(green_loc_r.x+.5),(int)(green_loc_r.y+.5));
      white_loc.set((int)(white_loc_r.x+.5),(int)(white_loc_r.y+.5));

      clipToImage(green_loc.x,green_loc.y);
      clipToImage(white_loc.x,white_loc.y);

      int green_rle_idx,white_rle_idx;
      run *green_run,*white_run;
      int green_cnt=0,white_cnt=0;

      green_rle_idx = CMVision::FindStart(rmap,0,num_runs-1,green_loc.x,green_loc.y);
      white_rle_idx = CMVision::FindStart(rmap,0,num_runs-1,white_loc.x,white_loc.y);
      green_run = &rmap[green_rle_idx];
      white_run = &rmap[white_rle_idx];
      if(green_run->x <= green_loc.x && green_run->color == COLOR_GREEN) {
        green_cnt = reg[green_run->parent].area;
      }
      if(white_run->x <= white_loc.x && white_run->color == COLOR_WHITE) {
        white_cnt = reg[white_run->parent].area;
      }

      if(print_now && debug_verbose) {
        pprintf(TextOutputStream,"green loc (%d,%d), white loc (%d,%d)\n",
                green_loc.x,green_loc.y,
                white_loc.x,white_loc.y);
        pprintf(TextOutputStream,"green cnt %d, white cnt %d\n",
                green_cnt,white_cnt);
      }

      ge_conf0 = bound(img_up.dot(b2t.norm()),0.0,1.0);
      ge_conf0 = (ge_conf0 - .966) / (1 - .966); // fall to zero in 15 degrees
      ge_conf0 = bound(ge_conf0,0.0,1.0);
      
      ge_conf1 = 1.0;
      
      //ge_conf2 = uniform_with_gaussian_tails(pct_from_mean(x_size,y_size*2),.2,.2);
      ge_conf2 = (x_size >= 3 && y_size >=3 && .25 <= ratio_wh && ratio_wh <= 8) ? 1.0 : 0.0;

      ge_conf3 = (green_cnt >= 20 && white_cnt >= 15) ? 1.0 : 0.0;

      if(calcEdgeMask(tc_img.x,tc_img.y)==0) {
        // calculate position using both top and bottom pixels
        vector3d top_dir,bot_dir;

        top_dir = getPixelDirection(eff_tc.x,eff_tc.y);
        bot_dir = getPixelDirection(eff_bc.x,eff_bc.y);

        vector2d plane_dir,top_dz_dir,bot_dz_dir;
        alignVertical(top_dir,bot_dir,plane_dir,top_dz_dir,bot_dz_dir);

        vector2d top_dz_loc,bot_dz_loc;
        if(findLocVerticalSeperation(top_dz_dir,bot_dz_dir,GoalHeight,top_dz_loc,bot_dz_loc)) {
          vector2d edge_dz_loc,edge_xy_loc;
          edge_dz_loc = bot_dz_loc;
          edge_xy_loc = plane_dir * edge_dz_loc.x;
          sep_loc.set(edge_xy_loc.x,edge_xy_loc.y,edge_dz_loc.y);
          sep_loc += camera_loc;

          cur_edge->loc = sep_loc;
        }
      } else {
        // no useful top left edge, have to use triangulation
        if(intersects) {
          cur_edge->loc = triang_loc;
        } else {
          ge_conf1 = 0.0;
        }
      }

      ge_conf = ge_conf0 * ge_conf1 * ge_conf2 * ge_conf3;

      cur_edge->confidence = ge_conf;

      if(print_now && debug_conf) {
        pprintf(TextOutputStream,"conf %g (0=%g 1=%g 2=%g 3=%g)\n",ge_conf,ge_conf0,ge_conf1,ge_conf2,ge_conf3);
      }

      if(cur_edge->confidence > 0.0) {
        vector2d ground_loc(cur_edge->loc.x,cur_edge->loc.y);
        cur_edge->left     = ground_loc.angle();
        cur_edge->right    = ground_loc.angle();
        cur_edge->distance = ground_loc.length();
        cur_edge->confInFrontOfIR = 0.0;
        cur_edge->edge = 0;
      }

      if(print_now && debug_verbose)
        pprintf(TextOutputStream,"side %d tri_loc=(%g,%g,%g) sep_loc=(%g,%g,%g)\n",sides[side_idx],
                triang_loc.x,triang_loc.y,triang_loc.z,
                sep_loc.x,sep_loc.y,sep_loc.z);
    }
  }

  vector2d main_goal_green_probe_pt_r;
  GVector::vector2d<int> main_goal_green_probe_pt;
  int main_goal_green_cnt;

  //cout << "bl (" << bottom_loc.x << "," << bottom_loc.y << ") tl (" << top_loc.x << "," << top_loc.y 
  //     << ") goo " << goal_outside_offset << endl;

  main_goal_green_probe_pt_r.set(bottom_loc.x,bottom_loc.y);
  main_goal_green_probe_pt_r += (vector2d(bottom_loc.x - top_loc.x, bottom_loc.y - top_loc.y)).norm() * goal_outside_offset;
  main_goal_green_probe_pt.set((int)(main_goal_green_probe_pt_r.x + .5),(int)(main_goal_green_probe_pt_r.y + .5));
  
  if(print_now && debug_verbose)
    pprintf(TextOutputStream,"main green probe = (%d,%d)\n",
            main_goal_green_probe_pt.x,main_goal_green_probe_pt.y);

  main_goal_green_cnt = 0;
  if(onImage       (main_goal_green_probe_pt.x,main_goal_green_probe_pt.y)) {
    if(getColorUnsafe(main_goal_green_probe_pt.x,main_goal_green_probe_pt.y)==COLOR_GREEN) {
      int green_rle_idx;
      run *green_run;
      
      green_rle_idx = CMVision::FindStart(rmap,0,num_runs-1,main_goal_green_probe_pt.x,main_goal_green_probe_pt.y);
      green_run = &rmap[green_rle_idx];
      if(green_run->x <= main_goal_green_probe_pt.x && green_run->color == COLOR_GREEN) {
        main_goal_green_cnt = reg[green_run->parent].area;
      }
    }
  } else {
    main_goal_green_cnt = width*height;
  }

  g_conf0 = (area > 2000) ? 1.0 : similar(ratio_wh,2.0);
  
  g_conf1 = ((area > 2000) || 
             (.866 <= ratio_wh && ratio_wh <= 3.0  &&  area > 20 )) ? 1.0 : 0.0;
  g_conf2 = (x_size >= 3 && y_size >=3) ? 1.0 : 0.0;

  g_conf3 = (main_goal_green_cnt >= 30) ? 1.0 : 0.0;

  g_conf = g_conf0 * g_conf1 * g_conf2 * g_conf3;
  if(print_now && debug_conf)
    pprintf(TextOutputStream,"area %d x %d y %d gc %d conf %g (0=%g 1=%g 2=%g 3=%g)\n",
            area,x_size,y_size,main_goal_green_cnt,g_conf,g_conf0,g_conf1,g_conf2,g_conf3);

  if(debug_sort) sprintf(DebugInfo,"%d ",main_goal_green_cnt);

  if(g_conf < goal_edges[0].confidence)
    g_conf = goal_edges[0].confidence;
  if(g_conf < goal_edges[1].confidence)
    g_conf = goal_edges[1].confidence;

  if(g_conf > 0.0) {
    double dist;
    
    dist = FocalDistV * GoalHeight / y_size;

    vector3d goal_loc,goal_dir;

    goal_dir = getPixelDirection(goal_reg->cen_x, goal_reg->cen_y);

    //sprintf(DebugInfo,"%g ",atan2a(goal_dir.z,hypot(goal_dir.x,goal_dir.y)));

    if(atan2(goal_dir.z,hypot(goal_dir.x,goal_dir.y)) <= (5*(M_PI/180))) {
      if(onImage(top_loc.x,top_loc.y) && calcEdgeMask(top_loc.x,top_loc.y)==0) {
        goal_loc = camera_loc + goal_dir * dist;
      } else {
        // no useful top edge, fall back on triangulation

        bool intersects = false;
        vector2d eff_bot_loc;
        vector3d triang_loc;
        vector3d bot_pix_dir;

        eff_bot_loc.set((double)bottom_loc.x,(double)bottom_loc.y);
        eff_bot_loc += img_up * -.5;
        bot_pix_dir = getPixelDirection(eff_bot_loc.x,eff_bot_loc.y);

        intersects = GVector::intersect_ray_plane(camera_loc,bot_pix_dir,vector3d(0,0,0),vector3d(0,0,1.0),triang_loc);
        if(intersects) {
          goal_loc = triang_loc;
        } else {
          if(print_now && debug_conf)
            pprintf(TextOutputStream,"squashing goal because no useful distance estimate\n");
          g_conf = 0.0;
        }
      }
      
      if(g_conf > 0.0) {
        goal->confidence = g_conf;
        
        goal->loc = goal_loc;
        goal->distance = hypot(goal_loc.x,goal_loc.y);
        
        findSpan(goal->left,goal->right,goal_reg->x1,goal_reg->x2,goal_reg->y1,goal_reg->y2);
        if(goal_edges[LEFT_SIDE].confidence > 0.0) {
          goal->left = goal_edges[LEFT_SIDE].left;
        } else {
          bool set_one = false;
          if(found_blc) {
            goal->left = groundAngle(blc_img.x,blc_img.y); // FIXME: add half pixel offset
            set_one = true;
          }
          if(found_tlc &&
             (!set_one || calcEdgeMask(tlc_img.x,tlc_img.y)==0))
            goal->left = groundAngle(tlc_img.x,tlc_img.y); // FIXME: add half pixel offset
        }
        if(goal_edges[RIGHT_SIDE].confidence > 0.0) {
          goal->right = goal_edges[RIGHT_SIDE].right;
        } else {
          bool set_one = false;
          if(found_brc) {
            goal->right = groundAngle(brc_img.x,brc_img.y); // FIXME: add half pixel offset
            set_one = true;
          }
          if(found_trc &&
             (!set_one || calcEdgeMask(trc_img.x,trc_img.y)==0))
            goal->right = groundAngle(trc_img.x,trc_img.y); // FIXME: add half pixel offset
        }
        
        goal->edge = calcEdgeMask(goal_reg);
        
        goal_info->reg = goal_reg;
      }
    } else {
      if(debug_conf)
        pprintf(TextOutputStream,"Nej Angel!\n");
    }
  } else {
    if(debug_sort)
      sprintf(DebugInfo,"%g ",-100.0);
  }

  if(print_now) {
    pprintf(TextOutputStream,"goal of color %d conf %g loc (%g,%g,%g) dist %g left %g right %g edge %d\n",
            color_idx,goal->confidence,goal->loc.x,goal->loc.y,goal->loc.z,goal->distance,goal->left,goal->right,goal->edge);
    pprintf(TextOutputStream,"goal left  edge of color %d conf %g loc (%g,%g,%g) dist %g left %g right %g edge %d\n",
            color_idx,goal_edges[LEFT_SIDE].confidence,goal_edges[LEFT_SIDE].loc.x,goal_edges[LEFT_SIDE].loc.y,goal_edges[LEFT_SIDE].loc.z,goal_edges[LEFT_SIDE].distance,goal_edges[LEFT_SIDE].left,goal_edges[LEFT_SIDE].right,goal_edges[LEFT_SIDE].edge);
    pprintf(TextOutputStream,"goal right edge of color %d conf %g loc (%g,%g,%g) dist %g left %g right %g edge %d\n",
            color_idx,goal_edges[RIGHT_SIDE].confidence,goal_edges[RIGHT_SIDE].loc.x,goal_edges[RIGHT_SIDE].loc.y,goal_edges[RIGHT_SIDE].loc.z,goal_edges[RIGHT_SIDE].distance,goal_edges[RIGHT_SIDE].right,goal_edges[RIGHT_SIDE].right,goal_edges[RIGHT_SIDE].edge);
  }

  if(debug_sort && color_idx==debug_sort_color) {
    if(goal        ->confidence > .4 ||
       goal_edges[0].confidence > .4 ||
       goal_edges[1].confidence > .4) {
      DebugClass = 1;
      sprintf(&DebugInfo[strlen(DebugInfo)],"%g %g %g",goal->confidence,goal_edges[0].confidence,goal_edges[1].confidence);
    }
  }
}

void Vision::findRobots(int color_idx,VObject *robots,VisionObjectInfo *robot_infos,int max_robots)
{
  static const bool debug_robots =false;
  static const bool debug_verbose=false;
  static const bool debug_conf   =false;

  region *robot_reg;
  vector3d dir;
  double d;
  int i,n,mn;

  static region *robot_regions[3]; // FIXME: assumes max_robots<3

  // clear out current values
  for(i=0; i<max_robots; i++) robots[i].confidence = 0.0;

  if(debug_robots)
    pprintf(TextOutputStream,"doing robot color %d\n",color_idx);

  // merge regions that can be connected by horizontal lines that don't go through
  //  too large of green regions
  n = 0;
  robot_reg = color[color_idx].list;
  while(robot_reg && n<20){
    region *match_reg,**match_reg_prev_next;

    match_reg_prev_next = &robot_reg->next;
    match_reg = *match_reg_prev_next;
    mn=0;

    while(match_reg && mn<20) {
      bool merged=false;
      int yl,yh; // overlap of regions in y (low,high)
      int overlap_height;
      int total_bad_size,total_empty_size;
      region *left_reg,*right_reg;
      
      total_bad_size=0;
      total_empty_size=0;

      yl = max(robot_reg->y1,match_reg->y1);
      yh = min(robot_reg->y2,match_reg->y2);
      overlap_height = yh - yl + 1;

#ifdef PLATFORM_LINUX
//      if(debug_robots && debug_verbose) {
//        pprintf(TextOutputStream,"considering merge\n");
//        pprintf(TextOutputStream,"r1 :(%8.4f,%8.4f) bbox (%3d,%3d)-(%3d,%3d)\n",
//                robot_reg->cen_x,robot_reg->cen_y,robot_reg->x1,robot_reg->y1,robot_reg->x2,robot_reg->y2);
//        pprintf(TextOutputStream," r2:(%8.4f,%8.4f) bbox (%3d,%3d)-(%3d,%3d)\n",
//                match_reg->cen_x,match_reg->cen_y,match_reg->x1,match_reg->y1,match_reg->x2,match_reg->y2);
//      }
#endif

      if(yh >= yl) {
#ifdef PLATFORM_LINUX
        if(debug_robots && debug_verbose) {
          pprintf(TextOutputStream,"r1 :(%8.4f,%8.4f) area %5d bbox (%3d,%3d)-(%3d,%3d)\n",
                  robot_reg->cen_x,robot_reg->cen_y,robot_reg->area,
                  robot_reg->x1,robot_reg->y1,robot_reg->x2,robot_reg->y2);
          pprintf(TextOutputStream," r2:(%8.4f,%8.4f) area %5d bbox (%3d,%3d)-(%3d,%3d)\n",
                  match_reg->cen_x,match_reg->cen_y,match_reg->area,
                  match_reg->x1,match_reg->y1,match_reg->x2,match_reg->y2);
        }
#endif

        if(robot_reg->cen_x < match_reg->cen_x) {
          left_reg  = robot_reg;
          right_reg = match_reg;
        } else {
          left_reg  = match_reg;
          right_reg = robot_reg;
        }
        
        int y; // y pixel coordinate we are currently processing
        // xl = right most pixel of left  region on current y (default is left  bounding box edge)
        // xr = left  most pixel of right region on current y (default is right bounding box edge)
        int xl,xr; // x (left/right) of area between regions
        int left_run_idx,right_run_idx; // index in left/right region being compared
        int empty_run_idx=0; // index of run in "empty" space between regions
        run *left_run,*right_run,*empty_run; // run in left/right region or "empty" space between
        int max_bad_size; // largest run of bad color between regions
        // total run length of left/right regions on current y value
        // total size of "empty" space between regions
        // not currently used because it can be sensitive to spottled robot (like blue ones)
        //int left_x_size,right_x_size;
        int empty_x_size;

        // skip ahead in left region to the y coordinate we want to process
        y = yl;
        left_run_idx = left_reg->run_start;
        left_run = &rmap[left_run_idx];
        while(left_run_idx != -1 && left_run->y < yl) {
          empty_run_idx = left_run_idx+1;
          left_run_idx = (left_run->next!=0 ? left_run->next : -1);
          left_run = (left_run_idx!=-1 ? &rmap[left_run_idx] : NULL);
        }
        // skip ahead in right region to the y coordinate we want to process
        right_run_idx = right_reg->run_start;
        right_run = &rmap[right_run_idx];
        while(right_run_idx != -1 && right_run->y < yl) {
          right_run_idx = (right_run->next!=0 ? right_run->next : -1);
          right_run = (right_run_idx!=-1 ? &rmap[right_run_idx] : NULL);
        }

        // while we haven't processed all of the horizontal scan lines at different y's
        while(y <= yh) {
          // process left region for this value of y
          //left_x_size = 0;
          xl = left_reg->x2;
          while(left_run_idx != -1 && left_run->y == yl) {
            //left_x_size += left_run->width;
            xl = left_run->x + left_run->width - 1;
            empty_run_idx = left_run_idx+1;
            left_run_idx = (left_run->next!=0 ? left_run->next : -1);
            left_run = (left_run_idx!=-1 ? &rmap[left_run_idx] : NULL);
          }
          empty_run = &rmap[empty_run_idx];
          // process right region for this y value
          //right_x_size = 0;
          xr = right_reg->x1;
          while(right_run_idx != -1 && right_run->y == yl) {
            //right_x_size += right_run->width;
            xr = right_run->x;
            right_run_idx = (right_run->next!=0 ? right_run->next : -1);
            right_run = (right_run_idx!=-1 ? &rmap[right_run_idx] : NULL);
          }

          // find first run in "empty" region between regions
          // this should usually be quick since start from run immediately
          //   following rightmost left region run
          while(empty_run_idx < num_runs &&
                (empty_run->y < y ||
                 empty_run->x + empty_run->width - 1 <= xl)) {
            empty_run_idx++;
            empty_run = &rmap[empty_run_idx];
          }

          empty_x_size = xr-1 - (xl+1) + 1;
          max_bad_size = 0;
          // gather summary statistics for "empty" space between regions for this y
          while(empty_run_idx < num_runs &&
                (empty_run->y == y &&
                 empty_run->x < xr)) {
            int bad_size;
            int region_idx;
            region *region;
            
            bad_size = 0;
            region_idx = empty_run->parent;
            region = &reg[region_idx];
            if(region->color != color_idx) {
              if(debug_robots && debug_verbose)
                pprintf(TextOutputStream,"y=%d, run color=%d x1=%d x2=%d, reg area=%d\n",
                        y,empty_run->color,empty_run->x,empty_run->x+empty_run->width-1,region->area);
              bad_size = region->area;
            }
            
            if(bad_size > max_bad_size)
              max_bad_size = bad_size;
            
            empty_run_idx++;
            empty_run = &rmap[empty_run_idx];
          }

          // FIXME: should probably take a median here instead of a mean
          total_bad_size += max_bad_size;
          if(empty_x_size > 0)
            total_empty_size += empty_x_size;
          y++;
        }

        if(debug_robots && debug_verbose)
          pprintf(TextOutputStream,"yl %3d yh %3d height %3d total_bad_size %5d "
                  "bad_avg %g total_empty_size %d avg_empty %g\n",
                  yl,yh,overlap_height,
                  total_bad_size,(double)total_bad_size / overlap_height,
                  total_empty_size,(double)total_empty_size / overlap_height);

        double avg_bad_size;
        double avg_empty_size;
        double frac_empty_size;
        double avg_width;
        avg_bad_size = ((double)total_bad_size  ) / overlap_height;
        avg_empty_size = ((double)total_empty_size) / overlap_height;
        avg_width = (left_reg ->x2 -  left_reg->x1 + 1 +
                     right_reg->x2 - right_reg->x1 + 1) / 2.0;
        frac_empty_size = avg_empty_size / avg_width;
        if( avg_bad_size < 8.0 &&
            frac_empty_size < 2.0) {
          if(debug_robots && debug_verbose)
            pprintf(TextOutputStream,"merging regions\n");
          CMVision::MergeRegions(robot_reg,match_reg,match_reg_prev_next,rmap);
          merged=true;

          if(debug_robots && debug_verbose) {
            pprintf(TextOutputStream,"res:(%8.4f,%8.4f) area %5d bbox (%3d,%3d)-(%3d,%3d)\n",
                    robot_reg->cen_x,robot_reg->cen_y,robot_reg->area,
                    robot_reg->x1,robot_reg->y1,robot_reg->x2,robot_reg->y2);
          }
        }
      }

      if(!merged) {
        match_reg_prev_next = &( (*match_reg_prev_next)->next );
      }
      match_reg = *match_reg_prev_next;
      mn++;
    }
  
    robot_reg = robot_reg->next;
    n++;
  }

  // pick out best robots
  robot_reg=color[color_idx].list;
  while(robot_reg) {
    dir = getPixelDirection(robot_reg->cen_x, robot_reg->cen_y);

    if(debug_robots && debug_verbose) {
      pprintf(TextOutputStream,"d# (%9.5f,%9.5f) %3d (%3d,%3d)-(%3d,%3d) dir (%g,%g,%g)\n",
              robot_reg->cen_x,robot_reg->cen_y,robot_reg->area,
              robot_reg->x1,robot_reg->y1,robot_reg->x2,robot_reg->y2,
              dir.x,dir.y,dir.z);
      pprintf(TextOutputStream,"z %g d %g a %g\n",dir.z,hypot(dir.x,dir.y),atan2(dir.z,hypot(dir.x,dir.y))*180.0/M_PI);
    }
        
    if(atan2(dir.z,hypot(dir.x,dir.y)) <= 7*M_PI/180.0) {
      if(debug_robots && debug_verbose) {
        pprintf(TextOutputStream,"ok angle\n");
      }

      double conf,conf0,conf1,conf2,conf3;
      int width,height;

      width  = robot_reg->x2 - robot_reg->x1 + 1;
      height = robot_reg->y2 - robot_reg->y1 + 1;

      conf0 = (width>=5) * (height>=4);

      // FIXME: these are lousy and need to be good since we select robots based on them
      // change to be more area based
      conf1 = gaussian_with_min(pct_from_mean(width,height) / 1.0, 1e-3);

      conf2 = 2.0*((double)robot_reg->area) / (width*height);
      conf2 = bound(conf2,0.0,1.0);

      conf3 = robot_reg->area/400.0;

      conf = conf0 * (conf1 * conf2 + conf3);
      conf = bound(conf,0.0,1.0);

      if(conf0 >= 0) {
        if(debug_robots && debug_verbose)
          pprintf(TextOutputStream,"width %d height %d area %d\n",width,height,robot_reg->area);
        
        if(debug_conf)
          pprintf(TextOutputStream,"conf 1:%8.5g 2:%8.5g 3:%8.5g final:%8.5g\n",conf1,conf2,conf3,conf);
      }

      // find first slot with confidence less than this
      int ins_idx;
      for(ins_idx=0; ins_idx<max_robots; ins_idx++) {
        if(robots[ins_idx].confidence < conf)
          break;
      }

      // move old stuff down to make room
      for(int robot_idx=max_robots-1; robot_idx>ins_idx; robot_idx--) {
        robots[robot_idx]       =robots[robot_idx-1];
        robot_regions[robot_idx]=robot_regions[robot_idx-1];
      }

      if(ins_idx < max_robots) {
        robots[ins_idx].confidence = conf;
        findSpan(robots[ins_idx].left,robots[ins_idx].right,
                 robot_reg->x1,robot_reg->x2,
                 robot_reg->y1,robot_reg->y2);
        
        // distance projected onto camera direction
        d = sqrt(RobotArea * FocalDist * FocalDistV / robot_reg->area);
        // distance to object
        d = d / camera_dir.dot(dir);
        
        robots[ins_idx].loc = camera_loc + dir*d;
        robots[ins_idx].distance = d;
        robots[ins_idx].edge = calcEdgeMask(robot_reg);
        
        robot_regions[ins_idx] = robot_reg;
      }
    }

    robot_reg = robot_reg->next;
  }

  for(int robot_idx=0; robot_idx<max_robots; robot_idx++) {
    robot_infos[robot_idx].reg = robot_regions[robot_idx];
  }

  static int frame_cnt=0;
#ifdef PLATFORM_APERIOS
  static const int out_period=30; // period in frames to print at
#else
  static const int out_period=1; // period in frames to print at
#endif
  if(debug_robots && 
     color_idx == COLOR_RED) {
    frame_cnt = (frame_cnt + 1) % out_period;
  }
  if(debug_robots && 
     frame_cnt == 0) {
    pprintf(TextOutputStream,"color %d\n",color_idx);
    robot_reg = color[color_idx].list;
    for(int robot_idx=0; robot_idx<10 && robot_reg; robot_idx++) {
      pprintf(TextOutputStream,"r#%d (%9.5f,%9.5f) %3d (%3d,%3d)-(%3d,%3d)\n",
              robot_idx,robot_reg->cen_x,robot_reg->cen_y,robot_reg->area,
              robot_reg->x1,robot_reg->y1,robot_reg->x2,robot_reg->y2);
      robot_reg = robot_reg->next;
    }

    for(int robot_idx=0; robot_idx<max_robots; robot_idx++) {
      if(robots[robot_idx].confidence > 0.01) {
        robot_reg=robot_regions[robot_idx];
        dir = getPixelDirection(robot_reg->cen_x, robot_reg->cen_y);
        //pprintf(TextOutputStream,"cam dir (%g,%g,%g) up (%g,%g,%g) right (%g,%g,%g) dir (%g,%g,%g)\n",
        //       camera_dir.x,  camera_dir.y,  camera_dir.z,
        //       camera_up.x,   camera_up.y,   camera_up.z,
        //       camera_right.x,camera_right.y,camera_right.z,
        //       dir.x,dir.y,dir.z);
        pprintf(TextOutputStream,"m#%d c (%f,%f) a %d dir (%g,%g,%g) dp %g %g %g bbox (%d,%d)-(%d,%d)\n",
                robot_idx,robot_reg->cen_x,robot_reg->cen_y,robot_reg->area,
                dir.x,dir.y,dir.z,
                sqrt(RobotArea * FocalDist * FocalDistV / robot_reg->area),
                camera_dir.dot(dir),
                sqrt(RobotArea * FocalDist * FocalDistV / robot_reg->area) / camera_dir.dot(dir),
                robot_reg->x1,robot_reg->y1,robot_reg->x2,robot_reg->y2);
        pprintf(TextOutputStream,"conf %f left %f right %f distance %f loc (%f,%f) edge %x\n",
                robots[robot_idx].confidence,
                robots[robot_idx].left, robots[robot_idx].right,
                robots[robot_idx].distance,
                robots[robot_idx].loc.x, robots[robot_idx].loc.y,
                robots[robot_idx].edge);
      }
    }
  }
}

void Vision::findBarEnd(int color_idx,VObject *bar_end,VisionObjectInfo *bar_end_info)
{
  static const bool debug_bar =false;
  static const bool debug_conf=true;
  static const bool debug_verbose=true;

  static int frame_cnt=0;
#ifdef PLATFORM_LINUX
  static const int print_period=1;
#else
  static const int print_period=90;
#endif
  if(debug_bar && color_idx==COLOR_BLUE)
    frame_cnt = (frame_cnt + 1) % print_period;

  bool print_now = debug_bar && (frame_cnt == 0);

  region *bar_reg;

  bar_end->confidence = 0.0;

  for(bar_reg=color[color_idx].list; bar_reg!=NULL; bar_reg=bar_reg->next) {
    vector3d dir;

    dir = getPixelDirection(bar_reg->cen_x,bar_reg->cen_y);

    if(print_now && debug_verbose) {
      pprintf(TextOutputStream,"bar (%9.5f,%9.5f) %3d (%3d,%3d)-(%3d,%3d) dir (%g,%g,%g)\n",
              bar_reg->cen_x,bar_reg->cen_y,bar_reg->area,
              bar_reg->x1,bar_reg->y1,bar_reg->x2,bar_reg->y2,
              dir.x,dir.y,dir.z);
      pprintf(TextOutputStream,"z %g d %g a %g\n",dir.z,hypot(dir.x,dir.y),atan2(dir.z,hypot(dir.x,dir.y))*180.0/M_PI);
    }

    if(atan2a(dir.z,hypot(dir.x,dir.y)) > 0)
      continue;

    int width, height;

    width  = bar_reg->x2 - bar_reg->x1 + 1;
    height = bar_reg->y2 - bar_reg->y1 + 1;
    
    double conf,conf0,conf1;

    conf0 = (width>=5) * (height>=3);
    conf1 = bound(bar_reg->area/400.0,0.0,1.0);

    conf = conf0*conf1;

    if(conf <= bar_end->confidence)
      continue;

    vector3d loc;
    bool intersects;
    // 50.0 seems to work better than 25.0 for no particular reason
    intersects = intersectPixelZPlane(bar_reg->cen_x,bar_reg->cen_y,50.0,loc);
    if(!intersects)
      continue;

    loc.z = 25.0;

    bar_end->confidence = conf;
    bar_end->loc = loc;
    bar_end->distance = hypot(loc.x,loc.y);
    bar_end->edge = calcEdgeMask(bar_reg);

    bar_end_info->reg = bar_reg;
  }

  if(print_now) {
    pprintf(TextOutputStream,"bar end, color %d, conf %g loc (%g,%g,%g) distance %g edge %x\n",
            color_idx,bar_end->confidence,bar_end->loc.x,bar_end->loc.y,bar_end->loc.z,
            bar_end->distance,bar_end->edge);
  }
}

void Vision::findObjectInFrontOfIR(ObjectInfo *obj_info) {
  static const int window_size = 6;

  int window_x1,window_x2;
  int window_y1,window_y2;

  window_x1 =  width/2 - window_size/2;
  window_y1 = height/2 - window_size/2;
  window_x2 =  width/2 + window_size/2 - 1;
  window_y2 = height/2 + window_size/2 - 1;

  int run_idx;
  run *rle;

  run_idx=CMVision::FindStart<run>(rmap,0,num_runs-1,window_x1,window_y1);
  rle = &rmap[run_idx];

  int black_pixels;
  int y;
  int last_object = 0;

  black_pixels = window_size * window_size;
  y = rle->y;
  while(rle->y <= window_y2) {
    while(rle->x + rle->width < window_x1 && rle->y <= y) {
      rle++;
    }

    while(rle->x <= window_x2 && rle->y <= y) {
      region *this_reg;
      VObject *obj_to_use=NULL;

      this_reg = &reg[rle->parent];
      if(this_reg == vobj_info[last_object].reg ||
         (MARKER <= last_object && last_object < MARKER+6 && this_reg == vobj_info[last_object].reg2)) {
        obj_to_use = &((VObject *)obj_info)[last_object];
      } else {
        for(int obj_idx=0; obj_to_use==NULL && obj_idx<NUM_VISION_OBJECTS; obj_idx++) {
          if(this_reg == vobj_info[obj_idx].reg ||
             (MARKER <= obj_idx && obj_idx < MARKER+6 && this_reg == vobj_info[obj_idx].reg2)) {
            obj_to_use = &((VObject *)obj_info)[obj_idx];
            last_object = obj_idx;
          }
        }
      }

      int x1_add,x2_add;
      int add;
      
      x1_add = max(window_x1,(int)rle->x);
      x2_add = min(window_x2,(int)rle->x+rle->width-1);
      
      add = x2_add - x1_add + 1;
      black_pixels -= add;

      if(obj_to_use!=NULL) {
        obj_to_use->confInFrontOfIR += add;
      }

      rle++;
    }

    while(rle->y <= y)
      rle++;

    y = rle->y;
  }

  for(int obj_idx=0; obj_idx<NUM_VISION_OBJECTS; obj_idx++) {
    int denominator;

    denominator = window_size * window_size;
    if(ROBOT <= obj_idx && obj_idx < ROBOT+NUM_ROBOTS_PER_COLOR*2) {
      denominator -= black_pixels;
      denominator = max(denominator, 1);
    }
    ((VObject *)obj_info)[obj_idx].confInFrontOfIR /= (double)denominator;
  }
}

// Scan states
static const int SS_Begin      =  0;
static const int SS_Field      =  1;
static const int SS_Ball       =  2;
static const int SS_Obstacle   =  3;
static const int SS_RedRobot   =  4;
static const int SS_BlueRobot  =  5;
static const int SS_Wall       =  6;
static const int SS_CyanGoal   =  7;
static const int SS_YellowGoal =  8;
static const int SS_End        =  9;
static const int SS_Stripe     = 10;
static const int NumSS         = 11;

static const int ColorToBestState[NUM_COLORS]=
  {
    /* COLOR_BACKGROUND */ SS_Obstacle,
    /* COLOR_ORANGE     */ SS_Ball,
    /* COLOR_GREEEN     */ SS_Field,
    /* COLOR_PINK       */ SS_End,
    /* COLOR_CYAN       */ SS_CyanGoal,
    /* COLOR_YELLOW     */ SS_YellowGoal,
    /* COLOR_BLUE       */ SS_BlueRobot,
    /* COLOR_RED        */ SS_RedRobot,
    /* COLOR_WHITE      */ SS_Stripe
  };

static const bool ColorStateOK[NumSS][NUM_COLORS]=
  {
    // background, orange, greeen, pink, cyan, yellow, blue,  red, white
    {       false,  false,  false,false,false,  false,false,false, false}, // SS_Begin
    {       false,  false,   true,false,false,  false,false,false, false}, // SS_Field     
    {       false,   true,  false, true,false,  false,false,false, false}, // SS_Ball
    {        true,  false,  false,false,false,  false,false,false, false}, // SS_Obstacle  
    {       false,  false,  false,false,false,  false,false, true, false}, // SS_RedRobot  
    {       false,  false,  false,false,false,  false, true,false, false}, // SS_BlueRobot 
    {       false,  false,  false,false,false,  false,false,false,  true}, // SS_Wall      
    {       false,  false,  false,false, true,  false,false,false, false}, // SS_CyanGoal  
    {       false,  false,  false,false,false,   true,false,false, false}, // SS_YellowGoal
    {       false,  false,  false,false,false,  false,false,false, false}, // SS_End       
    {       false,  false,  false,false,false,  false,false,false,  true}  // SS_Stripe
  };

static const bool debug_radial=false;

template<class T>
T CheckBound(T x,T low,T high,const char *var_name) {
  if(x != bound(x,low,high)) {
    pprintf(TextOutputStream,"failed bounds check on %s\n",var_name);
  }
  return bound(x,low,high);
}

void Vision::AddRadialObject(double x, double y, RadialObjectMap *radial_map, int robj_idx, int ang_idx) {
  //robj_idx = CheckBound(robj_idx,0,NUM_ROBJECTS,"robj_idx");
  //ang_idx  = CheckBound(ang_idx, 0,NUM_ANGLES-1,"ang_idx");

  if(radial_map->robjects[robj_idx][ang_idx].confidence==0.0) {
    RadialObjectReading *ror;
    vector3d loc;

    ror = &radial_map->robjects[robj_idx][ang_idx];
    ror->confidence = 1.0;
    if(intersectPixelZPlane(x,y,0.0,loc)) {
      ror->distance = hypot(loc.x,loc.y);
    } else {
      ror->distance = RadialFarDistance;
    }
  }
}

struct RadialRLEParams {
  Vision *vis;
  int runIdx;
  int curColor;
  RadialRun *curRun;

  void init(Vision *_vis) {
    vis = _vis;
    runIdx = -1;
    curColor = -1;
    curRun = NULL;
  }
};

struct RadialRLECallback {
  bool operator()(int cur_x,int cur_y,RadialRLEParams *rsp) {
    int color;

    color = rsp->vis->getColorUnsafe(cur_x,cur_y);
    if(color == rsp->curColor) {
      rsp->curRun->endPt.set(cur_x,cur_y);
      rsp->curRun->length++;
    } else {
      rsp->runIdx++;
      rsp->curColor = color;
      rsp->curRun = &rsp->vis->radial_runs[rsp->runIdx];
      rsp->curRun->startPt.set(cur_x,cur_y);
      rsp->curRun->endPt  .set(cur_x,cur_y);
      rsp->curRun->color = color;
      rsp->curRun->length = 1;
    }

    return true;
  }
};

void Vision::UpdateRadialAngle(int ang_idx,GVector::vector2d<int> scan_start_img,GVector::vector2d<int> scan_end_img) {
  static const bool debug_verbose = true;
  RadialRLEParams rrp;
  rrp.init(this);

  RadialRLECallback callback;
  drawLine(scan_start_img.x,scan_start_img.y,scan_end_img.x,scan_end_img.y,callback,&rrp);
  num_radial_runs = rrp.runIdx+1;
  
  for(int rr_idx=0; rr_idx<num_radial_runs; rr_idx++) {
    RadialRun *rr=&radial_runs[rr_idx];
    if(debug_radial && debug_verbose)
      pprintf(TextOutputStream,"rr_idx %2d color %2d length %2d start (%3d,%3d) end (%3d,%3d)\n",
              rr_idx,rr->color,rr->length,rr->startPt.x,rr->startPt.y,rr->endPt.x,rr->endPt.y);
  }

  int scan_state;
  int next_state;
  GVector::vector2d<int> start_pt[NumSS];
  GVector::vector2d<int> last_good_pt;
  int example_cnt,old_example_cnt;
  bool seen[NumSS];
  bool added_object;

  scan_state = SS_Begin;
  next_state = SS_Begin;
  last_good_pt = scan_start_img;
  example_cnt = 0;
  for(int state_idx=0; state_idx<NumSS; state_idx++) {
    start_pt[state_idx] = scan_start_img;
    seen[state_idx] = false;
  }
  added_object = true;

  for(int cur_rr_idx=0; cur_rr_idx<num_radial_runs; cur_rr_idx++) {
    RadialRun *rr;
    int run_color;

    rr = &radial_runs[cur_rr_idx];
    run_color = rr->color;

    bool got_next_state = false;
    old_example_cnt = example_cnt;
    if(scan_state == ColorToBestState[run_color]) {
      example_cnt += rr->length;
      old_example_cnt = example_cnt;     
      last_good_pt = rr->endPt;
      got_next_state = true;
    }

    if(!got_next_state && ColorStateOK[scan_state][run_color]) {
      got_next_state = true;
      example_cnt -= rr->length;
      if(example_cnt < 0)
        got_next_state = false;
    }

    if(!got_next_state) {
      next_state = ColorToBestState[run_color];
    }

    if(debug_radial && debug_verbose)
      pprintf(TextOutputStream,"state %2d cnt %2d next %2d, run info:run_idx %2d(%2d) color %2d length %2d start (%3d,%3d) end(%3d,%3d)\n",
              scan_state,example_cnt,next_state,
              cur_rr_idx,num_radial_runs,
              rr->color,rr->length,rr->startPt.x,rr->startPt.y,rr->endPt.x,rr->endPt.y);

    if(!added_object && !seen[scan_state] && old_example_cnt >= 5) {
      added_object = true;

      // Add cur object to radial map
      bool add=true;
      int obj_add_idx=0;
      switch(scan_state) {
      case SS_Begin: add=false; break;
      case SS_End:   add=false; break;
      case SS_Ball:       obj_add_idx = ROBJECT_BALL;              break;
      case SS_Field:      obj_add_idx = ROBJECT_FIELD_CLEAR_START; break;
      case SS_YellowGoal: obj_add_idx = ROBJECT_YELLOW_GOAL;       break;
      case SS_CyanGoal:   obj_add_idx = ROBJECT_CYAN_GOAL;         break;
      case SS_Obstacle:
	{
	  obj_add_idx = ROBJECT_ROBOT;

          add=false;
          
          vector3d start_loc(0.0,0.0,0.0),end_loc(0.0,0.0,0.0);
          bool start_intersects,end_intersects;
          static const double min_obstacle_length = 50.0;
          
          int other_cnt=0;
          int background_cnt=example_cnt;
          int last_background =cur_rr_idx;

          int peek_rr_idx=cur_rr_idx;
          bool done=false;
          while(peek_rr_idx<num_radial_runs &&
                !done) {
            RadialRun *peek_rr;
            int color;

            peek_rr = &radial_runs[peek_rr_idx];
            color = peek_rr->color;
            switch(color) {
	    case COLOR_ORANGE:
	      break;
            case COLOR_BACKGROUND:
              background_cnt += peek_rr->length;
	      last_background = peek_rr_idx;
              break;
	    default:
              other_cnt += peek_rr->length;
              if(other_cnt > background_cnt ||
		 peek_rr->length >= 5) {
                other_cnt -= peek_rr->length;
                done=true;
              }
	      break;
            }
	    if(!done)
	      peek_rr_idx++;
          }

          GVector::vector2d<int> background_end;
          background_end = radial_runs[last_background].endPt;

          start_intersects = intersectPixelZPlane(start_pt[scan_state].x,
                                                  start_pt[scan_state].y,
                                                  0.0,start_loc);
          end_intersects   = intersectPixelZPlane(background_end.x,
                                                  background_end.y,
                                                  0.0,end_loc  );
          add = (!start_intersects ||
		 !end_intersects   ||
		 ((end_loc - start_loc).length() >= min_obstacle_length));
	  added_object = add;
          
          if(debug_radial)
            pprintf(TextOutputStream,"obstacle %d si %d ei %d sl (%g,%g) el (%g,%g) dist %g bc %d\n",
                    add?1:0,start_intersects?1:0,end_intersects?1:0,
                    start_loc.x,start_loc.y,end_loc.x,end_loc.y,
                    (end_loc - start_loc).length(),
		    background_cnt);
          
          int robj_idx;
          robj_idx = obj_add_idx;

          if(radial_map.robjects[robj_idx][ang_idx].confidence==0.0 && add) {
            if(debug_radial)
              pprintf(TextOutputStream,"adding object %d at pt (%d,%d)\n",robj_idx,
                      start_pt[scan_state].x,start_pt[scan_state].y);

            RadialObjectReading *ror;
            
            ror = &radial_map.robjects[robj_idx][ang_idx];
            ror->confidence = 1.0;
            if(start_intersects) {
              ror->distance = hypot(start_loc.x,start_loc.y);
            } else {
              ror->distance = RadialFarDistance;
            }

	    seen[SS_Obstacle] = true;
          }

	  add = false;

	  break;
	}
      case SS_BlueRobot:  obj_add_idx = ROBJECT_BLUE_ROBOT;        break;
      case SS_RedRobot:   obj_add_idx = ROBJECT_RED_ROBOT;         break;
      case SS_Wall:
      case SS_Stripe:
        {
          add=false;
          
          vector3d start_loc(0.0,0.0,0.0),end_loc(0.0,0.0,0.0);
          bool start_intersects,end_intersects;
          static const double min_wall_length = 50.0;
          
          int green_cnt=0;
          int white_cnt=example_cnt;
          int background_cnt=0;
          int last_white =cur_rr_idx;
          bool wall;

          int peek_rr_idx=cur_rr_idx;
          bool done=false;
          while(peek_rr_idx<num_radial_runs &&
                !done) {
            RadialRun *peek_rr;
            int color;

            peek_rr = &radial_runs[peek_rr_idx];
            color = peek_rr->color;
            switch(color) {
            case COLOR_WHITE:
              white_cnt += peek_rr->length;
              last_white = peek_rr_idx;
              break;
            case COLOR_BACKGROUND:
              background_cnt += peek_rr->length;
              if(background_cnt > white_cnt) {
                background_cnt -= peek_rr->length;
                done=true;
              }
              break;
            case COLOR_GREEN:
              done=true;
              break;
            }
	    if(!done)
	      peek_rr_idx++;
          }
          while(peek_rr_idx<num_radial_runs && radial_runs[peek_rr_idx].color!=COLOR_GREEN) {
            peek_rr_idx++;
          }
          for(; peek_rr_idx<num_radial_runs; peek_rr_idx++) {
            RadialRun *peek_rr=&radial_runs[peek_rr_idx];
            int peek_color = peek_rr->color;
            if(peek_color == COLOR_GREEN) {
              green_cnt += peek_rr->length;
            }// else if(peek_color == COLOR_WHITE) {
            //  break;
            //}
          }

          GVector::vector2d<int> white_end;
          white_end = radial_runs[last_white].endPt;

          start_intersects = intersectPixelZPlane(start_pt[scan_state].x,
                                                  start_pt[scan_state].y,
                                                  0.0,start_loc);
          end_intersects   = intersectPixelZPlane(white_end.x,
                                                  white_end.y,
                                                  0.0,end_loc  );
          wall = ((!start_intersects ||
                   !end_intersects   ||
                   ((end_loc - start_loc).length() >= min_wall_length)) &&
                  (green_cnt < white_cnt));
          
          if(debug_radial)
            pprintf(TextOutputStream,"wall %d si %d ei %d sl (%g,%g) el (%g,%g) dist %g gc %d wc %d\n",
                    wall?1:0,start_intersects?1:0,end_intersects?1:0,
                    start_loc.x,start_loc.y,end_loc.x,end_loc.y,
                    (end_loc - start_loc).length(),
		    green_cnt,white_cnt);
          
          int robj_idx;
          robj_idx = (wall ? ROBJECT_WALL : ROBJECT_STRIPE);

          if(radial_map.robjects[robj_idx][ang_idx].confidence==0.0 &&
             (wall || radial_map.robjects[ROBJECT_WALL][ang_idx].confidence==0.0)) {
            if(debug_radial)
              pprintf(TextOutputStream,"adding object %d at pt (%d,%d)\n",robj_idx,
                      start_pt[scan_state].x,start_pt[scan_state].y);

            RadialObjectReading *ror;
            
            ror = &radial_map.robjects[robj_idx][ang_idx];
            ror->confidence = 1.0;
            if(start_intersects) {
              ror->distance = hypot(start_loc.x,start_loc.y);
            } else {
              ror->distance = RadialFarDistance;
            }
          }
          break;
        }
      default: add=false; pprintf(TextOutputStream,"Bad last scan state %d\n",scan_state);
      }

      if(add) {
        if(debug_radial)
          pprintf(TextOutputStream,"adding object %d at pt (%d,%d)\n",obj_add_idx,
                  start_pt[scan_state].x,start_pt[scan_state].y);
        AddRadialObject(start_pt[scan_state].x,start_pt[scan_state].y,&radial_map,obj_add_idx,ang_idx);
        seen[scan_state]=true;

	if(scan_state==SS_RedRobot || scan_state==SS_BlueRobot) {
	  if(!seen[SS_Obstacle]) {
	    if(debug_radial)
	      pprintf(TextOutputStream,"adding object %d at pt (%d,%d)\n",ROBJECT_ROBOT,
		      start_pt[scan_state].x,start_pt[scan_state].y);
	    AddRadialObject(start_pt[scan_state].x,start_pt[scan_state].y,&radial_map,ROBJECT_ROBOT,ang_idx);
	    seen[SS_Obstacle] = true;
	  }
	}
      }

      if(scan_state==SS_End) {
        if(debug_radial && debug_verbose)
          pprintf(TextOutputStream,"ending scan since adding End state\n");
        break;
      }
    }

    if(next_state != scan_state) {
      if(added_object && scan_state==SS_Field) {
        if(debug_radial)
          pprintf(TextOutputStream,"adding object %d at pt (%d,%d)\n",ROBJECT_FIELD_CLEAR_END,last_good_pt.x,last_good_pt.y);
        AddRadialObject(last_good_pt.x,last_good_pt.y,&radial_map,ROBJECT_FIELD_CLEAR_END,ang_idx);
      }
      
      bool identified_robot = (scan_state==SS_Obstacle &&
                               (next_state==SS_BlueRobot ||
                                next_state==SS_RedRobot));
      if(!identified_robot)
        start_pt[next_state] = rr->startPt;
      else
        start_pt[next_state] = start_pt[scan_state];

      scan_state = next_state;
      added_object = false;
      example_cnt = rr->length;
      last_good_pt = rr->endPt;
    }
  }

  int obj_add_idx=ROBJECT_ROBOT;
  bool add=true;
  if(!added_object) {
    switch(scan_state) {
    case SS_Begin: add=false; break;
    case SS_End:   add=false; break;
    case SS_Ball:       obj_add_idx = ROBJECT_BALL;              break;
    case SS_Field:      obj_add_idx = ROBJECT_FIELD_CLEAR_START; break;
    case SS_YellowGoal: obj_add_idx = ROBJECT_YELLOW_GOAL;       break;
    case SS_CyanGoal:   obj_add_idx = ROBJECT_CYAN_GOAL;         break;
    case SS_Obstacle:   obj_add_idx = ROBJECT_ROBOT;             break;
    case SS_BlueRobot:  obj_add_idx = ROBJECT_BLUE_ROBOT;        break;
    case SS_RedRobot:   obj_add_idx = ROBJECT_RED_ROBOT;         break;
    case SS_Stripe:
    case SS_Wall:
      {
        vector3d start_loc(0.0,0.0,0.0),end_loc(0.0,0.0,0.0);
        bool start_intersects,end_intersects;
        static const double min_wall_length = 50.0;

        start_intersects = intersectPixelZPlane(start_pt[scan_state].x,
                                                start_pt[scan_state].y,
                                                0.0,start_loc);
        end_intersects   = intersectPixelZPlane(last_good_pt.x,
                                                last_good_pt.y,
                                                0.0,end_loc  );
        
        bool wall;
        wall = (!start_intersects ||
                !end_intersects   ||
                ((end_loc - start_loc).length() >= min_wall_length));

        if(!wall && example_cnt < 5)
          add = false;

        int robj_idx;
        robj_idx = (wall ? ROBJECT_WALL : ROBJECT_STRIPE);

        if(debug_radial)
          pprintf(TextOutputStream,"finish scan: adding object %d at pt (%d,%d)\n",robj_idx,
                  start_pt[scan_state].x,start_pt[scan_state].y);

        if(add && radial_map.robjects[robj_idx][ang_idx].confidence==0.0 &&
           (wall || radial_map.robjects[ROBJECT_WALL][ang_idx].confidence==0.0)) {
          RadialObjectReading *ror;
          
          ror = &radial_map.robjects[robj_idx][ang_idx];
          ror->confidence = 1.0;
          if(start_intersects) {
            ror->distance = hypot(start_loc.x,start_loc.y);
          } else {
            ror->distance = RadialFarDistance;
          }
        }

        add=false;

        break;
      }
    default: add=false; pprintf(TextOutputStream,"Bad last scan state %d\n",scan_state);
    }

    if(example_cnt < 5) {
      switch(scan_state) {
      case SS_Obstacle:  add=false; break;
      case SS_BlueRobot: add=false; break;
      case SS_RedRobot:  add=false; break;
      }
    }
  } else {
    add=false;
  }

  if(add) {
    if(debug_radial)
      pprintf(TextOutputStream,"finish scan: adding object %d at pt (%d,%d)\n",obj_add_idx,
              start_pt[scan_state].x,start_pt[scan_state].y);
    AddRadialObject(start_pt[scan_state].x,start_pt[scan_state].y,&radial_map,obj_add_idx,ang_idx);
  }

  if(added_object && scan_state==SS_Field) {
    if(debug_radial)
      pprintf(TextOutputStream,"finish scan: adding object %d at pt (%d,%d)\n",ROBJECT_FIELD_CLEAR_END,
              last_good_pt.x,last_good_pt.y);
    AddRadialObject(last_good_pt.x,last_good_pt.y,&radial_map,ROBJECT_FIELD_CLEAR_END,ang_idx);
  }
}

void Vision::createRadialMap() {
  static const bool debug_verbose=true;
  static const bool debug_frustum_intersect=false;

  static int frame_cnt=0;
#ifdef PLATFORM_LINUX
  static const int print_period=1;
#else
  static const int print_period=90;
#endif
  if(debug_radial)
    frame_cnt = (frame_cnt + 1) % print_period;

  bool print_now = debug_radial && (frame_cnt == 0);

  // Clear out old map contents.
  for(int obj_idx=0; obj_idx<NUM_ROBJECTS; obj_idx++) {
    for(int angle_idx=0; angle_idx<NUM_ANGLES; angle_idx++) {
      radial_map.robjects[obj_idx][angle_idx].confidence = 0.0;
      radial_map.robjects[obj_idx][angle_idx].distance   = RadialFarDistance;
    }
  }

  if(!EnableRadialMap)
    return;

  double angle_left,angle_right;

  // Figure out which angles might be visible on the ground
  findSpan(angle_left,angle_right,0,width-1,0,height-1);
  if(print_now && debug_verbose) {
    pprintf(TextOutputStream,"angle range [%g,%g]\n",angle_left,angle_right);
  }

  // Process each angle
  double angle_first;
  angle_first = angle_left - fmodt(angle_left,RadialAngleSpacing);
  double angle_cur;
  int angle_cur_idx;
  for(angle_cur=angle_first, angle_cur_idx=RadialObjectMap::angleToIdx(angle_cur);
      angle_cur>angle_right;
      angle_cur-=RadialAngleSpacing, angle_cur_idx--) {
    if(print_now && debug_verbose) {
      pprintf(TextOutputStream,"processing angle %g\n",angle_cur);
    }

    if(angle_cur_idx < 0 || angle_cur_idx >= NUM_ANGLES) {
      pprintf(TextOutputStream,"angle_cur_idx of %d is out of bounds!!!!!!!\n",angle_cur_idx);
      continue;
    }

    // determine start/end location in ego coordinates of scan
    vector3d scan_start,scan_dir;
    scan_start.set(0.0,0.0,0.0);
    scan_dir.set(cos(angle_cur),sin(angle_cur),0.0);

    // convert to camera coordinates
    vector3d scan_start_cam,scan_dir_cam;
    scan_start_cam = convertToCamera(scan_start);
    scan_dir_cam   = convertToCamera(scan_start+scan_dir) - scan_start_cam;
    if(print_now && debug_verbose)
      pprintf(TextOutputStream,"scan start cam (%g,%g,%g), scan dir cam (%g,%g,%g)\n",
              scan_start_cam.x,scan_start_cam.y,scan_start_cam.z,
              scan_dir_cam.x,  scan_dir_cam.y,  scan_dir_cam.z);

    if(scan_start_cam.z < 1e-3) {
      vector3d intersect_pt;
      if(GVector::intersect_ray_plane(scan_start_cam,scan_dir_cam,vector3d(0.0,0.0,1e-3),vector3d(0.0,0.0,1.0),intersect_pt)) {
        scan_start_cam = intersect_pt;
      } else {
        // drop this angle, doesn't intersect viewable section
        if(print_now)
          pprintf(TextOutputStream,"dropping angle %g because it fails to be in front of camera\n",angle_cur);
        continue;
      }
    }

    // This is the distance to project out to find the horizon
    // It must be large enough to represent infinity reasonably on the camera
    //   but small enough to not screw up the intersection with the plane of the camera.
    static const double inf_distance = 1e6; // mm
    vector3d scan_end_cam;
    scan_end_cam = scan_start_cam + scan_dir_cam * inf_distance;

    if(print_now && debug_verbose)
      pprintf(TextOutputStream,"ssc (%g,%g,%g) sec (%g,%g,%g)\n",
              scan_start_cam.x,scan_start_cam.y,scan_start_cam.z,
              scan_end_cam.x,scan_end_cam.y,scan_end_cam.z);

    if(scan_end_cam.z < 1e-3) {
      vector3d intersect_pt;
      if(GVector::intersect_ray_plane(scan_end_cam,-scan_dir_cam,vector3d(0.0,0.0,1e-3),vector3d(0.0,0.0,1.0),intersect_pt)) {
        scan_end_cam = intersect_pt;
      } else {
        // drop this angle, doesn't intersect viewable section
        if(print_now)
          pprintf(TextOutputStream,"dropping angle %g because end fails to be in front of camera\n",angle_cur);
        continue;
      }
    }

    if(print_now && debug_verbose)
      pprintf(TextOutputStream,"ssc (%g,%g,%g) sec (%g,%g,%g)\n",
              scan_start_cam.x,scan_start_cam.y,scan_start_cam.z,
              scan_end_cam.x,scan_end_cam.y,scan_end_cam.z);

    vector2d scan_start_img_r,scan_end_img_r;
    GVector::vector2d<int> scan_start_img,scan_end_img;

    scan_start_img_r = cameraToImg(scan_start_cam);
    scan_end_img_r   = cameraToImg(scan_end_cam  );

    if(print_now && debug_verbose)
      pprintf(TextOutputStream,"ssc (%g,%g,%g) sec (%g,%g,%g), scan_start_img_r (%g,%g) scan_end_img_r (%g,%g)\n",
              scan_start_cam.x,scan_start_cam.y,scan_start_cam.z,
              scan_end_cam.x,scan_end_cam.y,scan_end_cam.z,
              scan_start_img_r.x,scan_start_img_r.y,
              scan_end_img_r  .x,scan_end_img_r  .y);

    if(GVector::clip_ray(scan_start_img_r,scan_end_img_r  ,0,width-1,0,height-1)) {
      if(print_now && debug_frustum_intersect)
        pprintf(TextOutputStream,"after clip scan_start_img_r (%g,%g) scan_end_img_r (%g,%g)\n",
                scan_start_img_r.x,scan_start_img_r.y,
                scan_end_img_r  .x,scan_end_img_r  .y);

      scan_start_img.set((int)(scan_start_img_r.x + .5),(int)(scan_start_img_r.y + .5));
      scan_end_img  .set((int)(scan_end_img_r  .x + .5),(int)(scan_end_img_r  .y + .5));
    } else {
      if(print_now && debug_frustum_intersect)
        pprintf(TextOutputStream,"clipping failed, angle not visible, skipping\n");
      continue;
    }

    scan_start_img = scan_start_img;
    scan_end_img   = scan_end_img;

    if(print_now && debug_verbose) {
      pprintf(TextOutputStream,"scan img start (%d,%d) r=(%g,%g), end (%d,%d) r=(%g,%g)\n",
              scan_start_img.x,scan_start_img.y,
              scan_start_img_r.x,scan_start_img_r.y,
              scan_end_img.x,scan_end_img.y,
              scan_end_img_r.x,scan_end_img_r.y);
    }

    if(!onImage(scan_start_img.x,scan_start_img.y)) {
      if(print_now)
        pprintf(TextOutputStream,"###Scan starts off image at (%d,%d)!\n",
                scan_start_img.x,scan_start_img.y);
      clipToImage(scan_start_img.x,scan_start_img.y);
    }
    if(!onImage(scan_end_img.x,scan_end_img.y)) {
      if(print_now)
        pprintf(TextOutputStream,"###Scan ends off image at (%d,%d)!\n",
                scan_end_img.x,scan_end_img.y);
      clipToImage(scan_end_img.x,scan_end_img.y);
    }
#ifdef PLATFORM_LINUX
    if(DrawRadialLines) {
      DebugDrawable->setColor(255,0,255);
      DebugDrawable->drawLine(scan_start_img.x,scan_start_img.y,
                              scan_end_img.x,  scan_end_img.y);
    }
#endif

    AddRadialObject(scan_start_img.x,scan_start_img.y,&radial_map,ROBJECT_VISIBLE_START,angle_cur_idx);
    AddRadialObject(scan_end_img.x,  scan_end_img.y,  &radial_map,ROBJECT_VISIBLE_END,  angle_cur_idx);

    // Update radial map for this angle
    UpdateRadialAngle(angle_cur_idx,scan_start_img,scan_end_img);
  }

  if(print_now) {
    pprintf(TextOutputStream,"%17s %1d %13s, %1d %13s, %1d %13s, %1d %13s, %1d %13s, %1d %13s, %1d %13s,"
            " %1d %13s, %1d %13s, %1d %13s, %1d %13s, %1d %13s\n","",
            0,"VisStart",1,"VisEnd",2,"ClearStart",3,"ClearEnd",4,"Wall",5,"Robot",
            6,"RedRobot",7,"BlueRobot",8,"Ball",9,"CyanGoal",10,"YellowGoal",11,"Stripe");
    for(int ang_idx=0; ang_idx<NUM_ANGLES; ang_idx++) {
      pprintf(TextOutputStream,"ang %5.2f idx %3d ",RadialObjectMap::idxToAngle(ang_idx),ang_idx);
      for(int obj_type=0; obj_type<NUM_ROBJECTS; obj_type++) {
        double dist = radial_map.robjects[obj_type][ang_idx].distance;
        if(dist < HUGE_VAL && dist > 1e48)
          pprintf(TextOutputStream,"c%4.2f d%8s, ",
                  radial_map.robjects[obj_type][ang_idx].confidence,
                  "BIG");
        else
          pprintf(TextOutputStream,"c%4.2f d%8.f, ",
                  radial_map.robjects[obj_type][ang_idx].confidence,
                  dist);
      }
      pprintf(TextOutputStream,"\n");
    }
  }
}

void Vision::calcImgVectors() {
  vector3d img_ego_pz_3d;
  vector3d pz_3d(0.0,0.0,1.0);

  img_ego_pz_3d.set(pz_3d.dot(camera_right),
                    pz_3d.dot(camera_up   ),
                    pz_3d.dot(camera_dir  ));
    
  img_up.set(img_ego_pz_3d.x,-img_ego_pz_3d.y);
  img_up.normalize();

  img_hor.set(-img_up.y,img_up.x);

#ifdef PLATFORM_LINUX
  {
    if(DrawUpVector) {
      vector2d s_r,e_r;
      GVector::vector2d<int> s,e;
      s_r.set(width/2.0-.5,height/2.0-.5);
      e_r.set(width/2.0-.5,height/2.0-.5);
      e_r +=  img_up*width; 
      s.set((int)(s_r.x+.5),(int)(s_r.y+.5));
      e.set((int)(e_r.x+.5),(int)(e_r.y+.5));
      DebugDrawable->setColor(128,128,255);
      DebugDrawable->drawLine(s.x,s.y,e.x,e.y);
    }
 }
#endif

  //pprintf(TextOutputStream,"cam: dir=(%10g,%10g,%10g) up=(%10g,%10g,%10g) right=(%10g,%10g,%10g)\n",
  //        camera_dir.x,  camera_dir.y,  camera_dir.z,
  //        camera_up.x,   camera_up.y,   camera_up.z,
  //        camera_right.x,camera_right.y,camera_right.z
  //        );
  //
  //pprintf(TextOutputStream,"img: pz=(%10g,%10g,%10g)\n",
  //        img_ego_pz_3d.x, img_ego_pz_3d.y, img_ego_pz_3d.z
  //        );
  //
  //pprintf(TextOutputStream,"img_2d: up=(%10g,%10g) hor=(%10g,%10g)\n",
  //        img_up.x,  img_up.y,
  //        img_hor.x, img_hor.y
  //        );
}

bool Vision::runHighLevelVision(ObjectInfo *obj_info) {
  //pprintf(TextOutputStream,"obj info is %p\n",obj_info);

  GetHeadPosition(camera_loc,camera_dir,camera_up,camera_right,
                  head_angles,body_angle,body_height);
  calcImgVectors();

  for(int obj_idx=0; obj_idx<NUM_OBJECTINFO_OBJECTS; obj_idx++) {
    ((VObject *)obj_info)[obj_idx].confInFrontOfIR = 0.0;
    vobj_info[obj_idx].reg = NULL;
  }

  //pprintf(TextOutputStream,"camera loc (%g,%g,%g) dir (%g,%g,%g) up (%g,%g,%g) right (%g,%g,%g)\n",
  //        camera_loc.x  ,camera_loc.y  ,camera_loc.z  ,
  //        camera_dir.x  ,camera_dir.y  ,camera_dir.z  ,
  //        camera_up.x   ,camera_up.y   ,camera_up.z   ,
  //        camera_right.x,camera_right.y,camera_right.z);
  //
  //pprintf(TextOutputStream,"head tilt %g pan %g roll %g, body angle %g height %g\n",
  //        head_angles[0],head_angles[1],head_angles[2],
  //        body_angle,body_height);

  findBall(&obj_info->ball,&vobj_info[BALL]);

  findMarkers(obj_info->marker,&vobj_info[MARKER]);

  findGoal(COLOR_YELLOW,&obj_info->yellow_goal,&obj_info->yellow_goal_edges[0],&vobj_info[YELLOW_GOAL]);
  findGoal(COLOR_CYAN  ,&obj_info->cyan_goal  ,&obj_info->cyan_goal_edges  [0],&vobj_info[CYAN_GOAL  ]);

  findRobots(COLOR_RED ,obj_info->red_robots ,&vobj_info[RED_ROBOT ],3);
  findRobots(COLOR_BLUE,obj_info->blue_robots,&vobj_info[BLUE_ROBOT],3);

  if(barVisionOn) {
    findBarEnd(COLOR_RED ,&obj_info->red_bar ,&vobj_info[RED_BAR ]);
    findBarEnd(COLOR_BLUE,&obj_info->blue_bar,&vobj_info[BLUE_BAR]);
  }

  findObjectInFrontOfIR(obj_info);

  createRadialMap();

#ifdef PLATFORM_APERIOS
  // output Vision objects if desired
  static int count=0;
  if(config.spoutConfig.dumpVisionObj!=0) {
    count = (count + 1) % config.spoutConfig.dumpVisionObj;
    if(count==0) {
      if(encodeBuf!=NULL && 
         encoder  !=NULL && 
         visionObjStream!=NULL) {
        int out_size=0;
        out_size = encoder->encodeVisionObjs(encodeBuf,obj_info);
        visionObjStream->writeBinary(encodeBuf,out_size);
      }
    }
  }
#endif

  return true;
}

bool Vision::thresholdImage(CMVision::image_idx<rgb> &img) {
  static rgb rgb_colors[MAX_COLORS];
  static bool initted=false;

  if(!initted) {
    for(int color_idx=0; color_idx<MAX_COLORS; color_idx++)
      rgb_colors[color_idx]=color[color_idx].color;
    initted=true;
  }

  CMVision::RgbToIndex(cmap,img.buf,width,height,rgb_colors,MAX_COLORS);

  return true;
}

#ifdef PLATFORM_LINUX
bool Vision::thresholdImage(CMVision::image<rgb> &img) {
  CMVision::ThresholdImageRGB24<cmap_t,CMVision::image<rgb>,bits_y,bits_u,bits_v>(cmap,img,tmap[cur_tmap]);

  return true;
}
#endif

bool Vision::thresholdImage(CMVision::image_yuv<const uchar> &img) {
  CMVision::ThresholdImageYUVPlanar<cmap_t,CMVision::image_yuv<const uchar>,const uchar,bits_y,bits_u,bits_v>(cmap,img,tmap[cur_tmap]);

  return true;
}

//#define CHECK_RUNS

//#define CHECK_REGIONS

template<class image>
bool Vision::runLowLevelVision(image &img)
{
  static int frame_cnt=-1;
  frame_cnt++;

#ifdef ENABLE_JOIN_NEARBY
  int num_runs_old;
#endif
  int max_area;

  width  = img.width;
  height = img.height;
  //cout << "hello" << endl;

  if(ShouldThresholdImage)
    thresholdImage(img);
  //for(int row=0; row<height; row++) {
  //  for(int col=0; col<width; col++) {
  //    uchar c;
  //    c = cmap[row*width + col];
  //    if(c >= 9) {// || (height-row)<4) {
  //      cout << "RLLV p" << (void *)&cmap[row*width+col] << " r" << row << " c" << col << " color" << (int)c << endl;
  //    }
  //  }
  //}
  num_runs = CMVision::EncodeRuns(rmap,cmap,img.width,img.height,max_runs);

  //cout << "NR" << num_runs << endl;

#ifdef ENABLE_JOIN_NEARBY
  num_runs_old = num_runs;
#endif

  //*((ulong *)num_runs) = 1UL;

#if 0
  {
    bool ok=CMVision::CheckRuns("R1",rmap,num_runs,width,height,num_colors);
    if(!ok) {
      pprintf(TextOutputStream,"error in run data, consistency check failed\n");
    }
  }
#endif

  CMVision::ConnectComponents(rmap,num_runs);
  //*((ulong *)num_runs) = 1UL;

#if 0
  {
    bool ok=CMVision::CheckRuns("R2",rmap,num_runs,width,height,num_colors);
    if(!ok) {
      pprintf(TextOutputStream,"error in run data, consistency check failed\n");
    }
  }
#endif

  //cout << "Nr" << num_runs << endl;
  //pprintf(TextOutputStream,"test\n");

  num_regions = CMVision::ExtractRegions(reg,max_regions,rmap,num_runs);
  //*((ulong *)num_runs) = 1UL;

#if 0
  {
    bool ok=CMVision::CheckRuns("R3",rmap,num_runs,width,height,num_colors);
    if(!ok) {
      pprintf(TextOutputStream,"error in run data, consistency check failed\n");
    }
  }
#endif

  //CMVision::CheckRuns("R4",rmap,num_runs,width,height,num_colors);

  //pprintf(TextOutputStream,"runs:%6d (%6d) regions:%6d (%6d)\n",
  //        num_runs,max_runs,
  //        num_regions,max_regions);

  //cout << "rN " << num_runs  << "reg " << num_regions << endl;
  //CMVision::CheckRegionColors(color,num_colors,reg,num_regions);

  max_area = CMVision::SeparateRegions(color,num_colors,reg,num_regions);
  //OSYSPRINT(("hello"));
  //OSYSLOG1((osyslogERROR,"hello"));
  CMVision::SortRegions(color,num_colors,max_area);

  //cout << "Nr" << num_runs << endl;

  CMVision::MergeRegions(color,num_colors,rmap);

  for(int i=0; i<num_colors; i++)
    color[i].total_area = -1;

  if(calcTotalArea)
    CMVision::CalcTotalArea(color,num_colors);

#ifdef CHECK_REGIONS
  {
    bool ok=CMVision::CheckRegions(color,num_colors,rmap);
    if(!ok) {
      pprintf(TextOutputStream,"error, CheckRegions failed\n");
    }
  }
#endif

  // CMVision::CreateRunIndex(yindex,rmap,num_runs);

#ifdef PLATFORM_APERIOS
  // output avg color if desired
  if(config.spoutConfig.dumpVisionAvgColor!=0) {
    outCountAvgColor = (outCountAvgColor + 1) % config.spoutConfig.dumpVisionAvgColor;
    if(outCountAvgColor==0) {
      sendAvgColor();
    }
  }
#endif

#ifdef PLATFORM_APERIOS
  // output color area if desired
  if(config.spoutConfig.dumpVisionColorArea!=0) {
    outCountColorArea = (outCountColorArea + 1) % config.spoutConfig.dumpVisionColorArea;
    if(outCountColorArea==0) {
      sendColorArea();
    }
  }
#endif

#ifdef PLATFORM_APERIOS
  // output color area if desired
  if(config.spoutConfig.dumpVisionRadialMap!=0) {
    outCountRadialMap = (outCountRadialMap + 1) % config.spoutConfig.dumpVisionRadialMap;
    if(outCountRadialMap==0) {
      sendRadialMap();
    }
  }
#endif

#ifdef PLATFORM_APERIOS
  // output raw frames if desired
  if(config.spoutConfig.dumpVisionRaw!=0) {
    outCountRaw = (outCountRaw + 1) % config.spoutConfig.dumpVisionRaw;
    if(outCountRaw==0) {
      sendRawImage();
    }
  }
#endif

#ifdef PLATFORM_APERIOS
  // output RLE if desired
  if(config.spoutConfig.dumpVisionRLE!=0) {
    outCountRLE = (outCountRLE + 1) % config.spoutConfig.dumpVisionRLE;
    if(outCountRLE==0) {
      sendRLEImage();
    }
  }
#endif

  return(true);
}

bool Vision::processFrame(ObjectInfo *obj_info, const uchar *data_y, const uchar *data_u, const uchar *data_v, int width, int height) {
  frameTimestamp = GetTime();

  img.buf_y=data_y;
  img.buf_u=data_u;
  img.buf_v=data_v;

  img.width=width;
  img.height=height;
  img.row_stride=3*width;

  bool ok=true;

  //cout << "Low" << endl;
  if(ok) ok=runLowLevelVision(img);
  //cout << "Params" << endl;
  if(ok) ok=getBodyParameters();
  //cout << "High" << endl;
  if(ok) ok=runHighLevelVision(obj_info);
  //cout << "Done" << endl;

  return ok;
}

#ifdef PLATFORM_LINUX
bool Vision::processFrame(ObjectInfo *obj_info, CMVision::image_idx<rgb> *img, int width, int height) {
  frameTimestamp = GetTime();

  bool ok=true;

  if(ok) ok=runLowLevelVision(*img);
  if(ok) ok=runHighLevelVision(obj_info);

  return ok;
}

bool Vision::processFrame(ObjectInfo *obj_info, CMVision::image<rgb> *img, int width, int height) {
  frameTimestamp = GetTime();

  bool ok=true;

  if(ok) ok=runLowLevelVision(*img);
  if(ok) ok=runHighLevelVision(obj_info);

  return ok;
}
#endif

void Vision::updateCorners(CMVision::image_yuv<const uchar> *src_img) {
  feature_t *corner_row;
  const cmap_t *src_up; // source row above corner row
  const cmap_t *src_dn; // source row below corner row
  int row,col;

  row = 0;
  src_up = src_img->buf_y + 0*src_img->row_stride;
  src_dn = src_img->buf_y + 1*src_img->row_stride;
  corner_row = corner;

  col = 0;
  corner_row[col].val = 128;
  for(col++; col<src_img->width-1; col++)
    corner_row[col].val = 128 + ((int)-src_up[col-1] + src_up[col+1] + src_dn[col-1] - src_dn[col+1]) / 4;
  corner_row[col].val = 128;

  for(row++; row<src_img->height-1; row++) {
    src_up = src_img->buf_y + (row-1)*src_img->row_stride;
    src_dn = src_img->buf_y + (row+1)*src_img->row_stride;
    corner_row = corner+row*src_img->width;
    
    col = 0;
    corner_row[col].val = 128;
    for(col++; col<src_img->width-1; col++)
      corner_row[col].val = 128 + ((int)-src_up[col-1] + src_up[col+1] + src_dn[col-1] - src_dn[col+1]) / 4;
    corner_row[col].val = 128;    
  }

  src_up = src_img->buf_y + (row-1)*src_img->row_stride;
  src_dn = src_img->buf_y + (row  )*src_img->row_stride;
  corner_row = corner+row*src_img->width;
  
  col = 0;
  corner_row[col].val = 128;
  for(col++; col<src_img->width-1; col++)
    corner_row[col].val = 128 + ((int)-src_up[col-1] + src_up[col+1] + src_dn[col-1] - src_dn[col+1]) / 4;
  corner_row[col].val = 128;    
}

void Vision::updateCorners(CMVision::image<rgb> *src_img) {
  feature_t *corner_row;
  const rgb *src_up; // source row above corner row
  const rgb *src_dn; // source row below corner row
  int row,col;

  row = 0;
  src_up = src_img->buf + 0*src_img->row_stride;
  src_dn = src_img->buf + 1*src_img->row_stride;
  corner_row = corner;

  col = 0;
  corner_row[col].val = 128;
  for(col++; col<src_img->width-1; col++)
    corner_row[col].val = 128 + ((int)-src_up[col-1].red + src_up[col+1].red + src_dn[col-1].red - src_dn[col+1].red) / 4;
  corner_row[col].val = 128;

  for(row++; row<src_img->height-1; row++) {
    src_up = src_img->buf + (row-1)*src_img->row_stride;
    src_dn = src_img->buf + (row+1)*src_img->row_stride;
    corner_row = corner + row*src_img->width;
    
    col = 0;
    corner_row[col].val = 128;
    for(col++; col<src_img->width-1; col++) {
      corner_row[col].val = 128 + ((int)-src_up[col-1].red + src_up[col+1].red + src_dn[col-1].red - src_dn[col+1].red) / 4;
    }
    corner_row[col].val = 128;    
  }

  src_up = src_img->buf + (row-1)*src_img->row_stride;
  src_dn = src_img->buf + (row  )*src_img->row_stride;
  corner_row = corner+row*src_img->width;
  
  col = 0;
  corner_row[col].val = 128;
  for(col++; col<src_img->width-1; col++)
    corner_row[col].val = 128 + ((int)-src_up[col-1].red + src_up[col+1].red + src_dn[col-1].red - src_dn[col+1].red) / 4;
  corner_row[col].val = 128;    
}

template<class Image>
void Vision::findPattern(Image *src_img,bool loose_corner_threshold,vector2d &centroid) {
  static const bool dump_marker_map      =false;
  static const bool dump_clean_marker_map=false;
  static const bool debug_search_corners =true;
  static const bool debug_find_centroid  =false;

  static const int dist_thresholds     [2] = {0x24, 0x12};
  static const int low_dist_thresholds [2] = {0x80-dist_thresholds[0],0x80-dist_thresholds[1]};
  static const int high_dist_thresholds[2] = {0x80+dist_thresholds[0],0x80+dist_thresholds[1]};

  int dist_threshold_idx;
  int low_dist_threshold;
  int high_dist_threshold;

  dist_threshold_idx = (loose_corner_threshold ? 1 : 0);
  low_dist_threshold  = low_dist_thresholds [dist_threshold_idx];
  high_dist_threshold = high_dist_thresholds[dist_threshold_idx];

  updateCorners(src_img);

  //return;

  int width,height;
  width  = src_img->width;
  height = src_img->height;

  corner_map.clear();
  for(int row=1; row<height-1; row++) {
    for(int col=1; col<width-1; col++) {
      uchar val;
      int idx=row*width+col;
      bool add=false;

      val = corner[idx].val;
      if(val < 128) {
        add=(val <  low_dist_threshold      &&
             val <= corner[idx-1    ].val   &&
             val <  corner[idx+1    ].val   &&
             val <= corner[idx-width].val   &&
             val <  corner[idx+width].val   &&
             val <= corner[idx-1-width].val &&
             val <= corner[idx+1-width].val &&
             val <  corner[idx-1+width].val &&
             val <  corner[idx+1+width].val);
      } else {
        add=(val >  high_dist_threshold     &&
             val >  corner[idx-1    ].val   &&
             val >= corner[idx+1    ].val   &&
             val >  corner[idx-width].val   &&
             val >= corner[idx+width].val   &&
             val >  corner[idx-1-width].val &&
             val >  corner[idx+1-width].val &&
             val >= corner[idx-1+width].val &&
             val >= corner[idx+1+width].val);
      }

      if(add) {
        CornerLoc cloc;
	cloc.setDefault();
	cloc.neighborCnt = 0;
        cloc.loc.set(col,row);
        cloc.imgLoc.set(col,row);
        corner_map.add(cloc);
      }
    }
  }

  if(dump_marker_map) {
    for(int i=0; i<corner_map.num_markers; i++) {
      pprintf(TextOutputStream,"i %2d (%3d,%3d) val=%2x\n",i,V2COMP(corner_map[i].imgLoc),
              corner[corner_map[i].imgLoc.y*width+corner_map[i].imgLoc.x].val);
    }
    corner_map.dump();
  }

  int max_cnt = -1;
  int max_x=-1,max_y=-1;
  for(int y=0; y<corner_map.height; y++) {
    for(int x=0; x<corner_map.width; x++) {
      int cnt=corner_map.bin_ref(x,y).num;
      bool update = false;
      if(cnt > max_cnt) {
	update = true;
      } else if(cnt == max_cnt) {
	if(y > max_y)
	  update = true;
	else if(y == max_y &&
		abs(corner_map.width/2 - x) < abs(corner_map.width/2 - max_x))
	  update = true;
      }

      if(update) {
        max_cnt = cnt;
        max_x = x;
        max_y = y;
      }
    }
  }

  if(max_cnt<=0) {
    pprintf(TextOutputStream,"failed to find checker pattern\n");
    return;
  }

  if(debug_find_centroid)
    pprintf(TextOutputStream,"max bucket at (%d,%d) cnt %d\n",max_x,max_y,max_cnt);

  int cur_corner_idx;
  CornerLoc *cur_corner;
  CornerLoc *old_corner_store[5];
  CornerLoc *old_corner=old_corner_store[0];
  CornerLoc *other_corner;
  vector2d base_dist;
  vector2d base_dir;
  int num_base,num_base_x,num_base_y;
  double total_dist=0.0;
  double avg_dist=0.0;
  vector2d start_loc;
  int start_cnt;
  int find_cnt;

  cur_corner = corner_map.bin_ref(max_x,max_y).list;
  start_loc.set(0.0,0.0);
  start_cnt = 0;
  while(cur_corner!=NULL) {
    start_loc += cur_corner->loc;
    start_cnt++;
    cur_corner = cur_corner->next;
  }
  start_loc /= start_cnt;

  clean_corner_map.clear();

  if(corner_map.find(old_corner_store,1,start_loc,width+height) < 1) {
    pprintf(TextOutputStream,"no corner now?, couldn't find pattern\n");
    return;
  }
  cur_corner = old_corner_store[0];
  start_loc = cur_corner->loc;

  cur_corner->idxX = 0;
  cur_corner->idxY = 0;
  clean_corner_map.add(*cur_corner);
  cur_corner->used = true;
  cur_corner_idx=0;

  base_dist.set(0.0,0.0);
  base_dir.set(0.0,0.0);
  num_base = num_base_x = num_base_y = 0;
  if((find_cnt=corner_map.find(old_corner_store,5,cur_corner->loc,width+height)) < 2) {
    pprintf(TextOutputStream,"only one corner, couldn't find pattern\n");
    return;
  }
  for(int i=0; i<find_cnt; i++) {
    double dist;
    vector2d diff,based_diff;
    old_corner = old_corner_store[i];
    if(old_corner->imgLoc == cur_corner->imgLoc)
      continue;
    diff = cur_corner->loc - old_corner->loc;
    dist = diff.length();
    based_diff = diff.project(base_dir);
    if(num_base > 0) {
      bool dist_x=true;
      if(fabs(based_diff.y) > fabs(based_diff.x)) {
	diff = diff.perp();
	based_diff = diff.project(base_dir);
	dist_x=false;
      }
      if(based_diff.x < 0) {
	diff = -diff;
	based_diff = diff.project(base_dir);
      }
      base_dir = (base_dir * num_base + diff.norm()) / (num_base + 1);
      base_dir.normalize();

      if(dist_x) {
	base_dist.x = (num_base_x * base_dist.x + dist) / (num_base_x + 1);
	num_base_x++;
      } else {
	base_dist.y = (num_base_y * base_dist.y + dist) / (num_base_y + 1);
	num_base_y++;
      }
    } else {
      base_dist.x = dist;
      base_dir  = diff.norm();
    }
    num_base++;
  }
  if(debug_search_corners) {
    pprintf(TextOutputStream,"base_dist (%g,%g), cur_corner->loc (%g,%g) old_corner->loc (%g,%g)\n",V2COMP(base_dist),
            V2COMP(cur_corner->loc),V2COMP(old_corner->loc));
  }

  //return;

  while(cur_corner_idx < clean_corner_map.num_markers) {
    find_cnt = 0;

    cur_corner = &clean_corner_map[cur_corner_idx];
    find_cnt = corner_map.find(old_corner_store,sizeof(old_corner_store)/sizeof(old_corner_store[0]),
                               cur_corner->loc,max(base_dist.x,base_dist.y)*1.5);
    if(debug_search_corners) {
      pprintf(TextOutputStream,"cur_corner_idx=%d find_cnt=%d base_dist (%g,%g) base_dir (%g,%g)\n",
	      cur_corner_idx,find_cnt,V2COMP(base_dist),V2COMP(base_dir));
      pprintf(TextOutputStream,"searching around corner (%d,%d) nc %d\n",V2COMP(cur_corner->imgLoc),cur_corner->neighborCnt);
    }
    for(int find_idx=0; find_idx<find_cnt; find_idx++) {
      old_corner = old_corner_store[find_idx];
      if(debug_search_corners)
	pprintf(TextOutputStream,"  found corner %d at (%d,%d) nc %d\n",find_idx,V2COMP(old_corner->imgLoc),old_corner->neighborCnt);
      if(old_corner->imgLoc==cur_corner->imgLoc)
        continue; // ignore self
      double dist;
      double dist_from_expected;
      vector2d diff;
      vector2d based_diff;
      vector2d expected_loc;
      double manhantan_dist;
      bool sign_change,man_dist_ok,used,good;
      int used_idx;
      int cur_corner_str,old_corner_str;
      int new_x,new_y;

      diff = old_corner->loc - cur_corner->loc;
      dist = diff.length();
      based_diff = diff.project(base_dir);
      manhantan_dist = fabs(based_diff.x) + fabs(based_diff.y);
      cur_corner_str = corner[cur_corner->imgLoc.y*width + cur_corner->imgLoc.x].val - 128;
      old_corner_str = corner[old_corner->imgLoc.y*width + old_corner->imgLoc.x].val - 128;

      new_x = cur_corner->idxX;
      new_y = cur_corner->idxY;
      if(fabs(based_diff.x) > fabs(based_diff.y)) {
	if(based_diff.x > 0) {
	  used_idx = 0;
	  new_x++;
	} else {
	  used_idx = 1;
	  new_x--;
	}
      } else {
	if(based_diff.y > 0) {
	  used_idx = 2;
	  new_y++;
	} else {
	  used_idx = 3;
	  new_y--;
	}
      }
      if(debug_search_corners) {
	pprintf(TextOutputStream,"    used_idx %d new idx (%d,%d)\n",used_idx,new_x,new_y);
      }

      expected_loc = start_loc + base_dir*(base_dist.x*new_x) + base_dir.perp()*(base_dist.y*new_y);
      // (vector2d(new_x,new_y)*base_dist).project(base_dir);
      dist_from_expected = GVector::distance(old_corner->loc,expected_loc);
      if(debug_search_corners) {
	pprintf(TextOutputStream,"    expected loc (%g,%g) dist %g\n",
		V2COMP(expected_loc),dist_from_expected);
      }

      man_dist_ok = (manhantan_dist <= 1.7 * max(base_dist.x,base_dist.y)) && (dist >= .7 * min(base_dist.x,base_dist.y));
      //man_dist_ok = (manhantan_dist <= 1.7 * max(base_dist.x,base_dist.y)) &&
      //  (dist_from_expected < max(2.9,.9*max(base_dist.x,base_dist.y)));
      sign_change = ((cur_corner_str * old_corner_str) < 0);
      used = (cur_corner->neighbors[used_idx] != NULL);
      good = (man_dist_ok && sign_change);

      if(debug_search_corners) {
	cur_corner->print("    q cur_corner");
	pprintf(TextOutputStream,"    dist %g man dist %g used %d used_idx %d good %d\n",
		GVector::distance(cur_corner->loc,old_corner->loc),manhantan_dist,
		used?1:0,used_idx,good);
      }
      if(!good)
        continue; // ignore ones with too high of manhantan distance
      cur_corner->neighborCnt++;
      if(used)
	continue;
      if(old_corner->used) {
	cur_corner->neighbors[used_idx    ] = old_corner;
	old_corner->neighbors[used_idx ^ 1] = cur_corner;
	if(debug_search_corners) {
	  cur_corner->print("    cur_corner");
	  old_corner->print("    old_corner");
	}
      } else {
        total_dist += dist;
	bool dist_x=true;
        //pprintf(TextOutputStream,"    diff (%g,%g) based_diff (%g,%g)\n",V2COMP(diff),V2COMP(based_diff));
        if(fabs(based_diff.y) > fabs(based_diff.x)) {
          diff = diff.perp();
          based_diff = diff.project(base_dir);
	  dist_x = false;
        }
        //pprintf(TextOutputStream,"    diff (%g,%g) based_diff (%g,%g)\n",V2COMP(diff),V2COMP(based_diff));
        if(based_diff.x < 0) {
          diff = -diff;
          based_diff = diff.project(base_dir);
        }
        //pprintf(TextOutputStream,"    diff (%g,%g) based_diff (%g,%g)\n",V2COMP(diff),V2COMP(based_diff));
        //pprintf(TextOutputStream,"    base_dist %g\n",base_dist);
        //pprintf(TextOutputStream,"    base dir was (%g,%g) cnt %d diff (%g,%g)",
        //        V2COMP(base_dir),num_base,V2COMP(diff));
        base_dir = (base_dir * num_base + diff.norm()) / (num_base + 1);
        base_dir.normalize();
        //pprintf(TextOutputStream,", now (%g,%g)\n",V2COMP(base_dir));
        num_base++;
	if(dist_x) {
	  base_dist.x = (num_base_x * base_dist.x + dist) / (num_base_x + 1);
	  num_base_x++;
	} else {
	  base_dist.y = (num_base_y * base_dist.y + dist) / (num_base_y + 1);
	  num_base_y++;
	}
	old_corner->setDefault();
        other_corner = clean_corner_map.add(*old_corner);
	cur_corner  ->neighbors[used_idx    ] = other_corner;
	other_corner->neighbors[used_idx ^ 1] = cur_corner;
	other_corner->idxX = new_x;
	other_corner->idxY = new_y;
	if(debug_search_corners) {
	  cur_corner->print("    cur_corner");
	  other_corner->print("    other_corner");
	}
        old_corner->used = true;
      }
    }

    cur_corner_idx++;
  }

  //return;

  if(clean_corner_map.num_markers == 0) {
    pprintf(TextOutputStream,"clean corner map empty, couldn't find pattern\n");
    return;
  }
  avg_dist = total_dist / clean_corner_map.num_markers;

  if(dump_clean_marker_map) {
    for(int i=0; i<clean_corner_map.num_markers; i++) {
      pprintf(TextOutputStream,"i %2d (%3d,%3d) val=%2x\n",i,V2COMP(clean_corner_map[i].imgLoc),
              corner[clean_corner_map[i].imgLoc.y*width+clean_corner_map[i].imgLoc.x].val);
    }
    clean_corner_map.dump();
  }

  vector2d sum_loc(0.0,0.0);
  for(int corner_idx=0; corner_idx<clean_corner_map.num_markers; corner_idx++) {
    sum_loc += clean_corner_map[corner_idx].loc;
  }
  centroid = sum_loc / clean_corner_map.num_markers;
  if(debug_find_centroid) {
    pprintf(TextOutputStream,"sum_loc (%g,%g) centroid (%g,%g), num markers %d, avg dist %g\n",
            V2COMP(sum_loc),V2COMP(centroid),clean_corner_map.num_markers,avg_dist);
  }
#ifdef PLATFORM_LINUX
  if(DrawCentroid) {
    int x,y;
    x = (int)(centroid.x+.5);
    y = (int)(centroid.y+.5);
    DebugDrawable->setColor(255,0,255);
    DebugDrawable->drawLine(x,y,x,y);
  }
#endif

#ifdef PLATFORM_LINUX
  static ximage ximg;
  static bool init_done=false;
  if(DrawEdgeImg) {
    if(!init_done) {
      printf("initializing with width %d height %d\n",src_img->width,src_img->height);
      ximg.initialize(src_img->width,src_img->height,24);
      memset(ximg.getData(),0,src_img->width*src_img->height);
      init_done = true;
    }
    for(int row=0; row<src_img->height; row++) {
      for(int col=0; col<src_img->width; col++) {
        printf("%1x",corner[row*src_img->width+col].val/16);
      }
      printf("\n");
    }
    rgb *data=ximg.getData();
    for(int i=0; i<src_img->width*src_img->height; i++) {
      rgb *cur_data=data+i;
      cur_data->red = cur_data->green = cur_data->blue = corner[i].val;
    }
    DebugDrawable->copy(ximg,0,0);
  }
  if(DrawBlackImg) {
    if(!init_done) {
      printf("initializing with width %d height %d\n",src_img->width,src_img->height);
      ximg.initialize(src_img->width,src_img->height,24);
      memset(ximg.getData(),0,src_img->width*src_img->height);
      init_done = true;
    }
    rgb *data=ximg.getData();
    memset(data,0,src_img->width*src_img->height*sizeof(rgb));
    DebugDrawable->copy(ximg,0,0);
  }
  if(DrawSloppyCorners) {
    DebugDrawable->setColor(0x00,0xFF,0x00);
    for(int i=0; i<corner_map.num_markers; i++) {
      int x,y;
      x=corner_map[i].imgLoc.x;
      y=corner_map[i].imgLoc.y;
      DebugDrawable->drawLine(x,y,x,y);
    }    
  }
  if(DrawCorners) {
    DebugDrawable->setColor(0xFF,0xFF,0xFF);
    for(int i=0; i<clean_corner_map.num_markers; i++) {
      int x,y;
      x=clean_corner_map[i].imgLoc.x;
      y=clean_corner_map[i].imgLoc.y;
      DebugDrawable->drawLine(x,y,x,y);
    }    
  }
#endif

  return;
}

template<class Image>
int Vision::classifyPattern(Image *src_img,vector2d centroid) {
  static const bool debug_sort = true;

  static const bool debug_ctr_dist        =false;
  //static const bool debug_max_ctr_dist    =false;
  static const bool debug_outline_ctr_dist   =false;
  static const bool debug_balance            =false;
  static const bool debug_dist_balance       =false;
  static const bool debug_signed_dist_balance=false;
  static const bool debug_angle_cnt          =false;

  static const int NumShapes=5;

  static const int NumFeatures=5;
  static const int FeatureOutlineCtrDist=0;
  static const int FeatureBalance       =1;
  static const int FeatureDistBalance   =2;
  static const int FeatureAngleCnt      =3;
  static const int FeatureSignedDistBalance=4;

  double pattern_dist[NumFeatures][NumShapes];

  ProbDistanceTest<double *> dist_test;

  int num_corners = clean_corner_map.num_markers;

  if(debug_sort) {
    DebugClass = 6;
    DebugInfo[0] = '\0';
  }

  //return -1;

  double avg_dist=0.0;
  for(int i=0; i<num_corners; i++) {
    CornerLoc *cur_corner=&clean_corner_map[i];
    cur_corner->ctrDist = GVector::distance(centroid,cur_corner->loc);
    avg_dist += cur_corner->ctrDist;
  }
  avg_dist /= num_corners;
 
  static double ctr_dist[MaxCorners];

  double moment=0.0;
  for(int i=0; i<num_corners; i++) {
    CornerLoc *cur_corner=&clean_corner_map[i];
    ctr_dist[i] = cur_corner->ctrDist / avg_dist;
    moment += sq(ctr_dist[i]);
  }
  moment /= num_corners;

  sort(&ctr_dist[0],&ctr_dist[0]+num_corners);

  if(debug_ctr_dist) {
    pprintf(TextOutputStream,"moment %g\n",moment);
    for(int i=0; i<num_corners; i++) {
      pprintf(TextOutputStream,"%2d %8.3f\n",i,ctr_dist[i]);
    }
  }

#if 0
  static const int NumAngles=32;
  static double max_ctr_dist[NumAngles];

  for(int ang_idx=0; ang_idx<NumAngles; ang_idx++)
    max_ctr_dist[ang_idx]=-1.0;

  for(int i=0; i<num_corners; i++) {
    double dist,angle;
    int ang_idx;
    CornerLoc *cur_corner=&clean_corner_map[i];

    dist = cur_corner->ctrDist / avg_dist;
    angle = (cur_corner->loc - centroid).angle();
    ang_idx = (int)(angle*NumAngles/(2*M_PI) + NumAngles) % NumAngles;

    if(dist > max_ctr_dist[ang_idx])
      max_ctr_dist[ang_idx] = dist;
  }

  for(int ang_idx=0; ang_idx<NumAngles; ang_idx++) {
    if(max_ctr_dist[ang_idx]!=-1.0)
      continue;

    int prev_ang_idx;
    int next_ang_idx;

    for(prev_ang_idx=(ang_idx+NumAngles-1)%NumAngles; 
        prev_ang_idx!=ang_idx; 
        prev_ang_idx=(prev_ang_idx+NumAngles-1)%NumAngles)
      if(max_ctr_dist[prev_ang_idx]>0.0)
        break;
    for(next_ang_idx=(ang_idx+1)%NumAngles; 
        next_ang_idx!=ang_idx; 
        next_ang_idx=(next_ang_idx+1)%NumAngles)
      if(max_ctr_dist[next_ang_idx]>0.0)
        break;
    if(prev_ang_idx==ang_idx || next_ang_idx==ang_idx) {
      max_ctr_dist[ang_idx] = 0.0;
      continue;
    }

    double prev_angle,next_angle,cur_angle;
    double t;
    vector2d prev_loc,next_loc,cur_dir,cur_loc;

    prev_angle = prev_ang_idx*2*M_PI/NumAngles;
    next_angle = next_ang_idx*2*M_PI/NumAngles;
    cur_angle  = ang_idx     *2*M_PI/NumAngles;

    prev_loc.set(cos(prev_angle),sin(prev_angle));
    prev_loc *= max_ctr_dist[prev_ang_idx];

    next_loc.set(cos(next_angle),sin(next_angle));
    next_loc *= max_ctr_dist[next_ang_idx];

    cur_dir .set(cos(cur_angle ),sin(cur_angle ));
    if(GVector::intersect_ray_plane_t(prev_loc,next_loc-prev_loc,vector2d(0.0,0.0),cur_dir.perp(),cur_loc,t) &&
       t <= 1.0) {
      max_ctr_dist[ang_idx] = -cur_loc.length();
    } else {
      max_ctr_dist[ang_idx] = 0.0;
    }
  }

  double mc_moment=0.0;
  for(int i=0; i<NumAngles; i++) {
    mc_moment += sq(max_ctr_dist[i]);
  }
  mc_moment /= NumAngles;

  //sort(&max_ctr_dist[0],&max_ctr_dist[0]+NumAngles);

  if(debug_max_ctr_dist) {
    pprintf(TextOutputStream,"mc_moment %g\n",mc_moment);
    for(int i=0; i<NumAngles; i++) {
      pprintf(TextOutputStream,"%2d %8.3f\n",i,max_ctr_dist[i]);
    }
  }
#endif

  static double outline_ctr_dist[MaxCorners];
  int outline_cnt=0;

  double out_moment=0.0;
  for(int i=0; i<num_corners; i++) {
    CornerLoc *cur_corner=&clean_corner_map[i];
    //pprintf(TextOutputStream,"i %2d (%3d,%3d) neighbors %d\n",i,V2COMP(cur_corner->imgLoc),cur_corner->neighborCnt);
    if(cur_corner->neighborCnt < 4) {
      outline_ctr_dist[outline_cnt] = cur_corner->ctrDist / avg_dist;
      out_moment += sq(outline_ctr_dist[outline_cnt]);
      outline_cnt++;
    }
  }
  if(outline_cnt < 1)
    return -1;
  out_moment /= outline_cnt;

  sort(&outline_ctr_dist[0],&outline_ctr_dist[0]+outline_cnt);

  if(debug_outline_ctr_dist) {
    pprintf(TextOutputStream,"out moment %g\n",out_moment);
    for(int i=0; i<outline_cnt; i++) {
      pprintf(TextOutputStream,"%2d %8.3f\n",i,outline_ctr_dist[i]);
    }
  }

  for(int i=0; i<NumShapes; i++) {
    pattern_dist[FeatureOutlineCtrDist][i] = 
      dist_test(&outline_ctr_dist[0],&outline_ctr_dist[outline_cnt],
                data_out_ctr_dist[i],data_out_ctr_dist[i]+data_out_ctr_dist_cnt[i]);
  }

  static const int NumAngles=32;
  static const double AngleSeperation=M_PI/NumAngles; // only have to go half way around
  static double balance[NumAngles];
  for(int ang_idx=0; ang_idx<NumAngles; ang_idx++) {
    int left_cnt,right_cnt;
    vector2d plane_norm;

    left_cnt = right_cnt = 0;
    plane_norm.set(cos(ang_idx*AngleSeperation),sin(ang_idx*AngleSeperation));
    plane_norm = plane_norm.perp();
    for(int corner_idx=0; corner_idx<num_corners; corner_idx++) {
      //pprintf(TextOutputStream,"ang_idx %d corner %d (%g,%g) plane_norm (%g,%g) above %d\n",
      //        ang_idx,corner_idx,
      //        V2COMP(clean_corner_map[corner_idx].loc-centroid),V2COMP(plane_norm),
      //        above_pt_plane(clean_corner_map[corner_idx].loc - centroid,vector2d(0.0,0.0),plane_norm));
      if(GVector::above_pt_plane(clean_corner_map[corner_idx].loc - centroid,vector2d(0.0,0.0),plane_norm))
        right_cnt++;
      else
        left_cnt++;
    }

    balance[ang_idx] = (double)(abs(left_cnt - right_cnt)) / (left_cnt + right_cnt);

    //if(debug_balance)
    //  pprintf(TextOutputStream,"i %d left %d right %d balance %g\n",ang_idx,left_cnt,right_cnt,balance[ang_idx]);
  }

  sort(&balance[0],&balance[0]+NumAngles);

  if(debug_balance) {
    for(int i=0; i<NumAngles; i++) {
      pprintf(TextOutputStream,"%2d %8.3f\n",i,balance[i]);
    }
  }  

  for(int i=0; i<NumShapes; i++) {
    pattern_dist[FeatureBalance][i] = 
      dist_test(&balance[0],&balance[NumAngles],
                data_balance[i],data_balance[i]+data_balance_cnt[i]);
  }

  static double dist_balance[NumAngles];
  for(int ang_idx=0; ang_idx<NumAngles; ang_idx++) {
    double dist=0.0;
    vector2d plane_dir;

    plane_dir.set(cos(ang_idx*AngleSeperation),sin(ang_idx*AngleSeperation));
    for(int corner_idx=0; corner_idx<num_corners; corner_idx++) {
      double a;
      a = GVector::distance_to_line(vector2d(0.0,0.0),plane_dir,clean_corner_map[corner_idx].loc - centroid);
      dist += a;
      //pprintf(TextOutputStream,"ang_idx %d corner_idx %d a %g dist %g\n",ang_idx,corner_idx,a,dist);
    }

    dist_balance[ang_idx] = dist / (avg_dist * NumAngles);

    //pprintf(TextOutputStream,"ang_idx %d dist %g\n",ang_idx,dist);
  }

  sort(&dist_balance[0],&dist_balance[0]+NumAngles);

  if(debug_dist_balance) {
    for(int i=0; i<NumAngles; i++) {
      pprintf(TextOutputStream,"%2d %8.3f\n",i,dist_balance[i]);
    }
  }  

  for(int i=0; i<NumShapes; i++) {
    pattern_dist[FeatureDistBalance][i] = 
      dist_test(&dist_balance[0],&dist_balance[NumAngles],
                data_dist_balance[i],data_dist_balance[i]+data_dist_balance_cnt[i]);
  }

  static double signed_dist_balance[NumAngles];
  for(int ang_idx=0; ang_idx<NumAngles; ang_idx++) {
    double dist=0.0;
    vector2d plane_dir;

    plane_dir.set(cos(ang_idx*AngleSeperation),sin(ang_idx*AngleSeperation));
    for(int corner_idx=0; corner_idx<num_corners; corner_idx++) {
      double a;
      a = GVector::signed_distance_to_line(vector2d(0.0,0.0),plane_dir,clean_corner_map[corner_idx].loc - centroid);
      dist += a;
      //pprintf(TextOutputStream,"ang_idx %d corner_idx %d a %g dist %g\n",ang_idx,corner_idx,a,dist);
    }

    signed_dist_balance[ang_idx] = fabs(dist / (avg_dist * NumAngles));

    //pprintf(TextOutputStream,"ang_idx %d dist %g\n",ang_idx,dist);
  }

  sort(&signed_dist_balance[0],&signed_dist_balance[0]+NumAngles);

  if(debug_signed_dist_balance) {
    for(int i=0; i<NumAngles; i++) {
      pprintf(TextOutputStream,"%2d %8.3f\n",i,signed_dist_balance[i]);
    }
  }  

  for(int i=0; i<NumShapes; i++) {
    pattern_dist[FeatureSignedDistBalance][i] = 
      dist_test(&signed_dist_balance[0],&signed_dist_balance[NumAngles],
                data_signed_distance_balance[i],data_signed_distance_balance[i]+data_signed_distance_balance_cnt[i]);
  }

  
  static const int AngleCntNumAngles=16;
  static const double AngleCntAngleSeperation=2*M_PI/AngleCntNumAngles; // only have to go half way around
  static double angle_cnt[AngleCntNumAngles];
  for(int ang_idx=0; ang_idx<AngleCntNumAngles; ang_idx++)
    angle_cnt[ang_idx]=0.0;
  for(int i=0; i<num_corners; i++) {
    CornerLoc *cur_corner;
    double angle;
    int ang_idx;

    cur_corner = &clean_corner_map[i];
    angle = (cur_corner->loc - centroid).angle() + 2*M_PI;
    ang_idx = (int)(angle / AngleCntAngleSeperation) % AngleCntNumAngles;
    ang_idx = (ang_idx + AngleCntNumAngles) % AngleCntNumAngles;

    //pprintf(TextOutputStream,"corner %d at (%g,%g), angle %g, ang_idx %d\n",
    //        i,V2COMP(cur_corner->loc - centroid),angle,ang_idx);

    angle_cnt[(ang_idx+AngleCntNumAngles-1) % AngleCntNumAngles] += .25;
    angle_cnt[ ang_idx                                         ] += .5;
    angle_cnt[(ang_idx+1                  ) % AngleCntNumAngles] += .25;
  }
  for(int ang_idx=0; ang_idx<AngleCntNumAngles; ang_idx++)
    angle_cnt[ang_idx] /= num_corners;

  sort(&angle_cnt[0],&angle_cnt[0]+AngleCntNumAngles);

  if(debug_angle_cnt) {
    for(int i=0; i<AngleCntNumAngles; i++) {
      pprintf(TextOutputStream,"%2d %8.3f\n",i,angle_cnt[i]);
    }
  }  

  for(int i=0; i<NumShapes; i++) {
    pattern_dist[FeatureAngleCnt][i] = 
      dist_test(&angle_cnt[0],&angle_cnt[AngleCntNumAngles],
                data_angle_cnt[i],data_angle_cnt[i]+data_angle_cnt_cnt[i]);
  }

  // print out raw distances
  for(int i=0; i<NumShapes; i++) {
    pprintf(TextOutputStream,"dist from %d is: outline_ctr_dist %8.4g balance %8.4g dist_balance %8.4g "
	    "signed_dist_balance %8.4g angle_cnt %8.4g\n",
            i,
            pattern_dist[FeatureOutlineCtrDist][i],
            pattern_dist[FeatureBalance][i],
            pattern_dist[FeatureDistBalance][i],
            pattern_dist[FeatureSignedDistBalance][i],
            pattern_dist[FeatureAngleCnt][i]
            );
  }

  // normalize distances
  for(int feature_idx=0; feature_idx<NumFeatures; feature_idx++) {
    double sum_dist=0.0;
    double sum_sq_dist=0.0;
    for(int i=0; i<NumShapes; i++) {
      sum_dist    +=    pattern_dist[feature_idx][i];
      sum_sq_dist += sq(pattern_dist[feature_idx][i]);
    }
    double avg_dist = sum_dist / NumShapes;
    double var_dist = sum_sq_dist / NumShapes - sq(avg_dist);
    double dev_dist = sqrt(var_dist);
    pprintf(TextOutputStream,"mean %8.4g var %8.4g dev %8.4g\n",avg_dist,var_dist,dev_dist);
    for(int i=0; i<NumShapes; i++) {
      pattern_dist[feature_idx][i] -= avg_dist;
      pattern_dist[feature_idx][i] /= dev_dist;
    }
  }

  double total_pattern_dists[NumShapes];
  double min_dist=HUGE_VAL;
  int min_idx =-1;
  for(int i=0; i<NumShapes; i++) {
    double dist;
    dist = 0.0;
    for(int feature_idx=0; feature_idx<NumFeatures; feature_idx++)
      dist += pattern_dist[feature_idx][i];
    total_pattern_dists[i] = dist;
    if(dist < min_dist) {
      min_dist = dist;
      min_idx  = i;
    }
    pprintf(TextOutputStream,"norm dist from %d is: outline_ctr_dist %8.4g balance %8.4g dist_balance %8.4g "
	    "signed_dist_balance %8.4g angle_cnt %8.4g total %8.4g\n",
            i,
            pattern_dist[FeatureOutlineCtrDist][i],
            pattern_dist[FeatureBalance][i],
            pattern_dist[FeatureDistBalance][i],
            pattern_dist[FeatureSignedDistBalance][i],
            pattern_dist[FeatureAngleCnt][i],
            dist);
  }
  
  if(debug_sort) {
    DebugClass = (min_idx!=-1 ? min_idx : 5);
    sprintf(DebugInfo,"%g %g %g %g %g",
            total_pattern_dists[0],
            total_pattern_dists[1],
            total_pattern_dists[2],
            total_pattern_dists[3],
            total_pattern_dists[4]);
  }

  return min_idx;
}

template<class Image>
int Vision::idPattern(Image *src_img,vector3d &loc,bool loose_corner_threshold) {
  //static int next_pattern_id=0;

  int pattern_id;

  vector2d centroid;
  findPattern(src_img,loose_corner_threshold,centroid);
  pattern_id = classifyPattern(src_img,centroid);

  loc = camera_loc + getPixelDirection(centroid.x,centroid.y) * 800.0;

  //pattern_id = next_pattern_id;
  //next_pattern_id = (next_pattern_id+1)%5;

  return pattern_id;
}

int Vision::identifyPattern(CMVision::image_yuv<const uchar> *src_img,vector3d &loc,bool loose_corner_threshold) {
  return idPattern(src_img,loc,loose_corner_threshold);
}

int Vision::identifyPattern(CMVision::image<rgb> *src_img,vector3d &loc,bool loose_corner_threshold) {
  return idPattern(src_img,loc,loose_corner_threshold);
}

int WritePPM(char *filename,rgb *img,int width,int height)
{
  FILE *out;
  int wrote;

  out = fopen(filename,"wb");
  if(!out) return(0);

  fprintf(out,"P6\n%d %d\n%d\n",width,height,255);
  wrote = fwrite(img,sizeof(rgb),width*height,out);
  fclose(out);

  return(wrote);
}

int Vision::setThreshold(int threshold_id) {
  if(threshold_id < 0 || threshold_id >= num_tmaps) {
    return -1;
  } else {
    int old_threshold;
    old_threshold = cur_tmap;
    cur_tmap = threshold_id;
    return old_threshold;
  }
}

bool Vision::saveThresholdImage(char *filename)
{
  rgb *buf;
  int wrote;

  buf = new rgb[width * height];
  if(!buf) return(false);

  CMVision::IndexToRgb<cmap_t,color_class_state>(buf,cmap,width,height,color,num_colors);
  wrote = WritePPM(filename,buf,width,height);
  delete(buf);

  return(wrote > 0);
}

void Vision::sendRawImage() {
#ifdef PLATFORM_APERIOS
  if(encodeBuf!=NULL && 
     encoder  !=NULL && 
     visionRawStream!=NULL) {
    int out_size=0;
    out_size=encoder->encodeVisionRaw(encodeBuf,
                                      body_angle,body_height,
                                      head_angles[0],head_angles[1],head_angles[2],
                                      img);
    if(!visionRawStream->writeBinary(encodeBuf,out_size,frameTimestamp))
      pprintf(TextOutputStream,"problem writing raw image\n");
  } else {
    if(encoder==NULL)
      pprintf(TextOutputStream,"NVEnc\n");
    else if(encodeBuf==NULL)
      pprintf(TextOutputStream,"NVEncBuf\n");
    else
      pprintf(TextOutputStream,"NVRawStream\n");
  }
#endif

  outCountRaw = 0;
}

void Vision::sendRLEImage() {
#ifdef PLATFORM_APERIOS
  if(encodeBuf!=NULL && 
     encoder  !=NULL && 
     visionRLEStream!=NULL) {
    int out_size=0;
#ifdef ENABLE_JOIN_NEARBY
    out_size=encoder->encodeVisionRLE(encodeBuf,
                                      body_angle,body_height,
                                      head_angles[0],head_angles[1],head_angles[2],
                                      num_runs-2,rmap+1);
#else
    out_size=encoder->encodeVisionRLE(encodeBuf,
                                      body_angle,body_height,
                                      head_angles[0],head_angles[1],head_angles[2],
                                      num_runs,rmap);
#endif
    visionRLEStream->writeBinary(encodeBuf,out_size,frameTimestamp);
  } else {
    if(encoder==NULL)
      pprintf(TextOutputStream,"NVEnc\n");
    else if(encodeBuf==NULL)
      pprintf(TextOutputStream,"NVEncBuf\n");
    else
      pprintf(TextOutputStream,"NVRLEStream\n");
  }
#endif

  outCountRLE = 0;
}

void Vision::sendAvgColor() {
#ifdef PLATFORM_APERIOS
  if(encodeBuf!=NULL && 
     visionAvgColorStream!=NULL) {
    int out_size=0;
    uchar *buf;
    buf = encodeBuf;
    SPOutEncoder::encodeAs<float>(&buf,(float)AvgImgColor[0]);
    SPOutEncoder::encodeAs<float>(&buf,(float)AvgImgColor[1]);
    SPOutEncoder::encodeAs<float>(&buf,(float)AvgImgColor[2]);
    out_size = buf - encodeBuf;
    visionAvgColorStream->writeBinary(encodeBuf,out_size,frameTimestamp);
  } else {
    if(encodeBuf==NULL)
      pprintf(TextOutputStream,"NVEncBuf\n");
    else
      pprintf(TextOutputStream,"NVAvgColorStream\n");
  }
#endif

  outCountAvgColor = 0;
}

void Vision::sendColorArea() {
#ifdef PLATFORM_APERIOS
  if(encodeBuf!=NULL && 
     visionColorAreaStream!=NULL) {
    int out_size=0;
    uchar *buf;
    buf = encodeBuf;
    SPOutEncoder::encodeAs<uchar>(&buf,(uchar)num_colors);
    for(int color_idx=0; color_idx<num_colors; color_idx++) {
      SPOutEncoder::encodeAs<ulong>(&buf,(ulong)color[color_idx].total_area);
    }
    out_size = buf - encodeBuf;
    visionColorAreaStream->writeBinary(encodeBuf,out_size,frameTimestamp);
  } else {
    if(encodeBuf==NULL)
      pprintf(TextOutputStream,"NVEncBuf\n");
    else
      pprintf(TextOutputStream,"NVColorAreaStream\n");
  }
#endif

  outCountAvgColor = 0;
}

void Vision::sendRadialMap() {
#ifdef PLATFORM_APERIOS
  if(encodeBuf!=NULL && 
     encoder  !=NULL && 
     visionRadialMapStream!=NULL) {
    int out_size=0;
    out_size=encoder->encodeVisionRadialMap(encodeBuf,&radial_map);
    visionRadialMapStream->writeBinary(encodeBuf,out_size,frameTimestamp);
  } else {
    if(encoder==NULL)
      pprintf(TextOutputStream,"NVEnc\n");
    else if(encodeBuf==NULL)
      pprintf(TextOutputStream,"NVEncBuf\n");
    else
      pprintf(TextOutputStream,"NVRadialMapStream\n");
  }
#endif

  outCountRadialMap = 0;
}

namespace VisionInterface {
  void SendRawImage(Vision *vision) {
    vision->sendRawImage();
  }

  void SendRLEImage(Vision *vision) {
    vision->sendRLEImage();
  }

  int SetThreshold(Vision *vision,int threshold_id) {
    return vision->setThreshold(threshold_id);
  }
}
