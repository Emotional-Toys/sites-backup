/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef __VISION_INTERFACE_H__
#define __VISION_INTERFACE_H__

#include <math.h>

#include "../headers/DogTypes.h"
#include "../headers/Geometry.h"
#include "../headers/SystemUtility.h"

class Vision;

namespace VisionInterface {

  static const double HorzFOV = 58.0 * M_PI / 180.0;
  static const double VertFOV = 48.0 * M_PI / 180.0;

  // Bitmasks for which edges of the image an object borders
  const uchar OFF_EDGE_LEFT   = 1;
  const uchar OFF_EDGE_RIGHT  = 2;
  const uchar OFF_EDGE_TOP    = 4;
  const uchar OFF_EDGE_BOTTOM = 8;

  // High level vision ouput structure for detected objects
  struct VObject{
    double confidence; // [0,1] Estimate of certainty
    vector3d loc;      // Relative to front of robot (on ground)
    double left,right; // Angle to left and right of object (egocentric)
    double distance;   // Distance of object (on ground)
    double confInFrontOfIR;  // confidence of the object being in front of the IR sensor
    uchar edge;          // Is object on edge of image (bitmasks above)
  };

  // Colors: (C)yan (G)reen (Y)ellow (P)ink
  // Markers are specified <color>(O)ver<color>
  // evens are +y, odds are -y; overall order is +x,0,-x
  const int MARKER = 0;
  const int MARKER_COP = 0;
  const int MARKER_POC = 1;
  const int MARKER_GOP = 2;
  const int MARKER_POG = 3;
  const int MARKER_YOP = 4;
  const int MARKER_POY = 5;

  const int YELLOW_GOAL = 6;
  const int YELLOW_GOAL_SIDES = 7;
  const int CYAN_GOAL   = 9;
  const int CYAN_GOAL_SIDES = 10;

  const int LEFT_SIDE =0;
  const int RIGHT_SIDE=1;

  const int BALL = 12;

  const int ROBOT      = 13;
  const int BLUE_ROBOT = 13;
  const int RED_ROBOT  = 16;
  const int NUM_ROBOTS_PER_COLOR = 3;

  const int NUM_MARKERS = 6;

  const int BLUE_BAR = 19;
  const int RED_BAR  = 20;

  // number of normal vision objects
  const int NUM_VISION_OBJECTS = NUM_MARKERS + 2*3 + 1 + 2*NUM_ROBOTS_PER_COLOR;
  // number of vision object in object info structure
  const int NUM_OBJECTINFO_OBJECTS = NUM_VISION_OBJECTS + 2;

  // All the objects we might detect
  struct ObjectInfo{
    VObject marker[6]; // Order:  C/P  P/C  G/P  P/G  Y/P  P/Y
    VObject yellow_goal;
    VObject yellow_goal_edges[2];
    VObject cyan_goal;
    VObject cyan_goal_edges[2];
    VObject ball;
    VObject blue_robots[3];
    VObject red_robots[3];
    VObject blue_bar;
    VObject red_bar;
  };

  // RObject = Radial Object
  const int ROBJECT_VISIBLE_START     = 0;
  const int ROBJECT_VISIBLE_END       = 1;
  // must be start of non fake objects
  const int ROBJECT_FIELD_CLEAR_START = 2;
  const int ROBJECT_FIELD_CLEAR_END   = 3;
  const int ROBJECT_WALL              = 4;
  const int ROBJECT_ROBOT             = 5;
  const int ROBJECT_RED_ROBOT         = 6;
  const int ROBJECT_BLUE_ROBOT        = 7;
  const int ROBJECT_BALL              = 8;
  const int ROBJECT_CYAN_GOAL         = 9;
  const int ROBJECT_YELLOW_GOAL       =10;
  const int ROBJECT_STRIPE            =11;
  const int NUM_ROBJECTS              =12;

  static const double RadialAngleSpacing = 5.0 * M_PI / 180.0;
  static const int NUM_ANGLES = 72;
  // next line is preferred but won't compile on Aperios
  //static const int NUM_ANGLES = (int)(2*M_PI/RadialAngleSpacing + .5);

  static const double RadialFarDistance = 100000.0;

  struct RadialObjectReading {
    double confidence;
    double distance;
  };

  struct RadialObjectMap {
    static inline int angleToIdx(double angle) {
      int angle_idx = (int)round(angle/RadialAngleSpacing) + NUM_ANGLES/2;
      return ((angle_idx % NUM_ANGLES) + NUM_ANGLES) % NUM_ANGLES;
    }
    static inline double idxToAngle(int idx) {
      return (idx - NUM_ANGLES/2) * RadialAngleSpacing;
    }
    static inline ulong idxToMask(int idx) {
      return 1UL << idx;
    }
    inline RadialObjectReading *query(int obj_idx, int angle_idx) {
      return &robjects[obj_idx][angle_idx];
    }

    RadialObjectReading robjects[NUM_ROBJECTS][NUM_ANGLES];
    RadialObjectReading *closest(ulong mask, int angle_idx) {
      RadialObjectReading *closest_robj=NULL;
      
      for(int robj_idx=0; robj_idx<NUM_ROBJECTS; robj_idx++) {
        RadialObjectReading *try_robj;
        try_robj = &robjects[robj_idx][angle_idx];
        if((mask & idxToMask(robj_idx))!=0 &&
           try_robj->confidence > 0.5 && 
           (closest_robj==NULL ||
            closest_robj->distance > try_robj->distance)) {
          closest_robj = try_robj;
        }
      }

      return closest_robj;
    }
  };

  // returns the id of the old threshold or -1 on error
  int SetThreshold(Vision *vision,int threshold_id);

  void SendRawImage(Vision *vision); // Forces the output of the current raw image to the log/spout/wl
  void SendRLEImage(Vision *vision); // Forces the output of the current RLE image to the log/spout/wl
} // namespace vision

#endif
// __VISION_INTERFACE_H__

