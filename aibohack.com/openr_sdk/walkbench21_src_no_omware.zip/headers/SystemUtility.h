/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef INCLUDED_SystemUtility_h
#define INCLUDED_SystemUtility_h

#include "system_config.h"

#include <math.h>
#include <string.h>

#include "DogTypes.h"

#ifdef PLATFORM_APERIOS
#include <MCOOP.h>
#endif

#ifdef PLATFORM_APERIOS
inline char *strdup(char *src)
{
  char *dst;
  dst=new char[strlen(src)+1];
  strcpy(dst,src);
  return dst;
}
#endif

#ifdef PLATFORM_APERIOS
inline ulong GetTime() {
  static struct SystemTime time;
  
  GetSystemTime(&time);
  
  ulong seconds =time.seconds;
  ulong useconds=seconds*1000000+time.useconds;

  return useconds;
}
#else
#include <sys/time.h>

inline ulong GetTime() {
  static struct timeval time={0,0};
  static struct timezone tz={0,0};

  gettimeofday(&time,&tz);
  
  ulong seconds =time.tv_sec;
  ulong useconds=seconds*1000000+time.tv_usec;

  return useconds;
}
#endif

#ifdef PLATFORM_APERIOS
template<class T>
T *NewLarge(T **dst,int count) {
  sError result;

  // + 8096 is workaround for NewRegion rounding down amount of memory requested
  result = NewRegion(sizeof(T)*count+8096, reinterpret_cast<void **>(dst));
  if(result != sSUCCESS)
    *dst = NULL;

  return *dst;
}

template<class T>
void DeleteLarge(T *dst) {
  DeleteRegion(dst);
}
#else
template<class T>
T *NewLarge(T **dst,int count) {
  *dst = new T[count];

  return *dst;
}

template<class T>
void DeleteLarge(T *dst) {
  delete[] dst;
}
#endif

inline double round(double x) {
  x += .5;
  return floor(x);
}

#endif
