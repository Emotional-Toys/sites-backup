/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef INCLUDED_FileSystem_h
#define INCLUDED_FileSystem_h

#include <stddef.h>

#include "system_config.h"

#if defined(PLATFORM_APERIOS) && !defined(PLATFORM_APERIOS_SDK)
#include <OFS/OFS.h>
#else
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#endif


#define HFS_FILE_BUF_SIZE 1024

#if defined(PLATFORM_LINUX) || defined(PLATFORM_APERIOS_SDK)
#define BFS_O_CREAT  O_CREAT
#define BFS_O_TRUNC  O_TRUNC
#define BFS_O_RDONLY O_RDONLY
#define BFS_O_WRONLY O_WRONLY
#define BFS_O_RDWR   O_RDWR
#define BFS_O_APPEND O_APPEND

#define BFS_SEEK_SET SEEK_SET
#define BFS_SEEK_CUR SEEK_CUR
#define BFS_SEEK_END SEEK_END

#else

#define BFS_O_CREAT  OFS_O_CREAT
#define BFS_O_TRUNC  OFS_O_TRUNC
#define BFS_O_RDONLY OFS_O_RDONLY
#define BFS_O_WRONLY OFS_O_WRONLY
#define BFS_O_RDWR   OFS_O_RDWR
#define BFS_O_APPEND OFS_O_APPEND

#define BFS_SEEK_SET OFS_SEEK_SET
#define BFS_SEEK_CUR OFS_SEEK_CUR
#define BFS_SEEK_END OFS_SEEK_END

#endif

namespace BFS {
  int open(const char *filename, int mode);
  size_t read(int fd, void *ptr, size_t size);
  size_t write(int fd, void *ptr, size_t size);
  off_t lseek(int fd,off_t offset, int whence);
  int close(int fd);
  const char *LastError();
}

namespace HFS { // high level filesystem calls
  struct FILE {
    int fd;
    int valid_size;
    bool eof;
    char buf[HFS_FILE_BUF_SIZE];
  };

  FILE *fopen(const char *filename, const char *mode);
  char *fgets(char *buf, int buf_size, FILE *file);
  size_t fread(void *ptr, size_t size, size_t num_elem, FILE *file);
  size_t fwrite(const void *ptr, size_t size, size_t num_elem, FILE *file);
  int fclose(FILE *file);
}


#endif
