/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef INCLUDED_Sensors_h
#define INCLUDED_Sensors_h

#include "../headers/system_config.h"

#ifdef PLATFORM_APERIOS
#include <OPENR/ObjcommTypes.h>
#include <OPENR/OFbkImage.h>
#include <OPENR/OPENR.h>
#include <OPENR/OPENRAPI.h>
#include <OPENR/OPENRMessages.h>

// #include <OMWares/OMGsensorData.h>
#endif

#include "../headers/Geometry.h"

const int CPCJointNeckTilt           =  0; // Head
const int CPCJointNeckPan            =  1;
const int CPCJointNeckRoll           =  2;
const int CPCSensorHeadBackPressure  =  3;
const int CPCSensorHeadFrontPressure =  4;
const int CPCSensorPSD               =  5;
const int CPCJointMouth              =  6;
const int CPCSensorChinSwitch        =  7;
const int CPCJointLFJoint            =  8; // Left front
const int CPCJointLFShoulder         =  9;
const int CPCJointLFKnee             = 10;
const int CPCSensorLFPaw             = 11;
const int CPCJointLHJoint            = 12; // Left hind
const int CPCJointLHShoulder         = 13;
const int CPCJointLHKnee             = 14;
const int CPCSensorLHPaw             = 15;
const int CPCJointRFJoint            = 16; // Right front
const int CPCJointRFShoulder         = 17;
const int CPCJointRFKnee             = 18;
const int CPCSensorRFPaw             = 19;
const int CPCJointRHJoint            = 20; // Right hind
const int CPCJointRHShoulder         = 21;
const int CPCJointRHKnee             = 22;
const int CPCSensorRHPaw             = 23;
const int CPCJointTailPan            = 24; // Tail
const int CPCJointTailTilt           = 25;
const int CPCSensorThermoSensor      = 26;
const int CPCSensorBackSwitch        = 27;
const int CPCSensorAccelFB           = 28; // Front-back (front positive)
const int CPCSensorAccelLR           = 29; // Left-right (right positive)
const int CPCSensorAccelUD           = 30; // Up-down (up positive)

// tail constants
const int TailPanReading  = 0;
const int TailTiltReading = 1;

// Which buttons are pressed
const int HeadFrontButtonIdx = 0;
const int HeadBackButtonIdx  = 1;
const int ChinButtonIdx      = 2;
const int BackButtonIdx      = 3;

const int HeadFrontButton = 1<<HeadFrontButtonIdx;
const int HeadBackButton  = 1<<HeadBackButtonIdx;
const int ChinButton      = 1<<ChinButtonIdx;
const int BackButton      = 1<<BackButtonIdx;

// virtual buttons
const int LogButtonIdx            = 4;
const int VisionObjPlusButtonIdx  = 5;
const int VisionObjMinusButtonIdx = 6;
const int ResetModelsButtonIdx    = 7;

const int LogButton            = 1<<LogButtonIdx;
const int VisionObjPlusButton  = 1<<VisionObjPlusButtonIdx;
const int VisionObjMinusButton = 1<<VisionObjMinusButtonIdx;
const int ResetModelsButton    = 1<<ResetModelsButtonIdx;

const double IROORDist = 900.0; // If IR returns this, we're out of range

class SensorData{
public:
  double legAngles[3*4]; // rotator, shoulder, knee for LF,RF,LH,RH (radians)
  double headAngles[3];  // tilt, pan, roll (radians) (must follow leg array!)
  double tailAngles[2];  // tail tilt,pan
  double IRDistance;     // Distance sensor: mm: between 100.0 and 900.0
  bool paw[4];           // Foot switches
  vector3d accel;        // In G's [-2.0,2.0]
  unsigned int button;   // bitwise OR of above button constants
public:
#ifdef PLATFORM_APERIOS
  void read(OSensorFrameVectorData *sensor);
#endif
  // must be called before button translations are allowed to occur
  static void InitializeSensors();
  static void ResetButtonTranslations();
  static void AddButtonTranslation(int old_button_idx, int new_button_idx);
  static int ButtonStringToNumber(const char *button_str);
private:
  static const int NumButtonTranslations=sizeof(int)*8;
  static unsigned int ButtonTranslations[NumButtonTranslations];
};

#endif
