/*
 * RoboCupGameControlData.h
 *
 * Copyright (C) 2002 Sony Corporation
 * All Rights Reserved.
 */

#ifndef _RoboCupGameControlData_h_DEFINED
#define _RoboCupGameControlData_h_DEFINED


#ifdef __cplusplus
extern "C" {
#endif


/* State */

typedef char RState;
const RState ROBOCUP_STATE_INITIAL      = 0x01; /* initial state             */
const RState ROBOCUP_STATE_READY        = 0x02; /* return to position and wait*/
const RState ROBOCUP_STATE_PLAYING      = 0x03; /* playing game              */
const RState ROBOCUP_STATE_PENALIZED    = 0x04; /* stop by penalty           */
const RState ROBOCUP_STATE_FINAL        = 0x05; /* final state               */


/* Kickoff */

typedef char RKickOff;
const RKickOff ROBOCUP_KICKOFF_OWN      = 0x01;
const RKickOff ROBOCUP_KICKOFF_OPPONENT = 0x02;
const RKickOff ROBOCUP_KICKOFF_INVALID  = 0x03;


/* Penalty */

const int NUM_PENALTY = 4;

const int PENALTY_INDEX_ILLEGAL_DEFENDER = 0;
const int PENALTY_INDEX_OBSTRUCTION      = 1;
const int PENALTY_INDEX_KEEPER_CHARGE    = 2;
const int PENALTY_INDEX_BALL_HOLDING     = 3;


/* Data type definition */

typedef struct {
    RState      state;                  /* state of player                  */
    RKickOff    kickoff;                /* kickoff information              */
    short       ownScore;               /* number of score of own team      */
    short       opponentScore;          /* number of score of opponent team */
    char        penalty[NUM_PENALTY];   /* number of each penalty           */
} RoboCupGameControlData;


#ifdef __cplusplus
}
#endif


#endif /* _RoboCupGameControlData_h_DEFINED */
