/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef INCLUDED_Utility_h
#define INCLUDED_Utility_h

#include <math.h>

#include "system_config.h"

#include "DogTypes.h"
#include "Geometry.h"

struct CylindricalCoordD{
  double angle,distance;
};

inline double deg2rad(double deg_angle) {
  return deg_angle*M_PI/180.0;
}

/*
// use norm_angle() in Util.h
inline double normAngle(double angle) {
  angle=fmod(angle,2*M_PI);
  if(angle < 0.0)
    angle+=2*M_PI;
  if(angle >= M_PI)
    angle-=2*M_PI;

  return angle;
}
*/

inline double
Distance(const vector2d &a, const vector2d &b) {
  double dx,dy;

  dx = a.x - b.x;
  dy = a.y - b.y;

  return sqrt(dx*dx + dy*dy);
}

inline vector2d
EgoToAllo(double theta,const vector2d &ego_vec) {
  return ego_vec.rotate(theta);
}

inline vector2d
AlloToWorld(const vector2d &our_loc, const vector2d &allo_vec) {
  return allo_vec+our_loc;
}

inline vector2d
WorldToAllo(const vector2d &our_loc, const vector2d &world_vec) {
  return world_vec-our_loc;
}

inline vector2d
AlloToEgo(double theta,const vector2d &allo_vec) {
  return allo_vec.rotate(-theta);
}

template <class coord>
vector2d ToVector(coord p)
{
  double x,y;

  x = cos(p.angle) * p.distance;
  y = sin(p.angle) * p.distance;

  return(vector2d(x,y));
}

inline
CylindricalCoordD ToCylindrical(vector2d v)
{
  CylindricalCoordD p;

  p.distance = v.length();
  p.angle = atan2(v.y,v.x);

  return(p);
}

inline double
ramp_up(double in, double zero_end, double one_start) {
  double out=0.0;

  if(in > one_start)
    out=1.0;
  else if(in < zero_end)
    out=0.0;
  else
    out=(in-zero_end)/(one_start-zero_end);
  
  return out;
}

inline double
ramp_dn(double in, double one_end, double zero_start) {
  double out=0.0;

  if(in > zero_start)
    return 0.0;
  else if(in < one_end)
    return 1.0;
  else
    out=(zero_start-in)/(zero_start-one_end);

  return out;
}

template <class num>
num square(num n)
{
  return(n * n);
}

#include "SystemUtility.h"

#endif
