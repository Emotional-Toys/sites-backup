/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef SharedWorldModel_h
#define SharedWorldModel_h

#include "system_config.h"

#include "Geometry.h"
#include "gvector.h"
#include "DogTypes.h"
#include "field.h"
#include "../Behaviors/constants.h"
//#include "CircBufPacket.h"
#include "Config.h"
#include "Gaussian2.h"
#include <math.h>
#include "Util.h"

#include "SharedWorldModelEncoder.h"

class PacketStream;
class PacketStreamCollection;

struct SharedModelEntry {

  /* Store the robot location as two gaussians, one for position and one for
     heading */
  Gaussian2 Position;
  Gaussian2 Angle;

  /* Set to true if this player is the goalie. 
     I.e. we shouldn't yield to them unless 
     the ball is in the defense zone, in which
     case attackers can't touch it.
  */
  bool IsGoalie;

  /* Set to true if this player is the goalie and it is
     currently clearing the ball.
  */
  bool GoalieClearing;
  

  /* Have we actually seen the ball this timestep?  
     If not, no one cares about our estimate of the
     ball position. 
  */
  bool SawBall;
  
  /* How confident are we about our position?
     BTW: We define uncertainty
     in terms of the X and Y axis, NOT an
     arbitrary major and minor axis.

     This is not how things were done in the old
     code so we need to be careful to make sure 
     that we do things right.
  */
  
  /* Analogous to the above, but for the ball. */
  Gaussian2 BallPosition;

  /* State info for challenges/etc. */
  int State;

};

/* Note that I provide space for 8 dogs. It is
   possible that we'd want to have all 8 dogs
   collaborating for a non-soccer task. Although
   I get negative points for hardcoding a constant.

   This gets filled in by the main object
   as messages come into MainObject::NetInput. It is
   then passed to BehaviorSystem::run. From there it
   gets incorporated into the feature set where our
   behaviors can get at it.
*/
const ulong shared_info_time_cutoff = 4000000L;
const double posn_uncertainty_cutoff = 500;
const double ball_uncertainty_cutoff = 500;

/* Repulsion from the walls falls off linearly with
   distance. At D=0 it is wall_repulsion. The slope of
   the line as you move away is wall_falloff (which
   means wall_falloff should be negative).
*/
const double wall_repulsion = 1000;
const double wall_falloff = -5.0;

const double ball_equilibrium = 1000;
// ball_slope = ball_repulsion/ball_equilibrium
const double ball_slope = .1;

const double teammate_repulsion = 300;
const double teammate_falloff = -0.5;

/* This bias guides robots in front of the 
   primary attacker to supporting positions in front.
   It guides robots behind the attacker to 
   supporting positions behind it.
*/
// const double x_bias = 100;
// .5 worked well with newest hack
const double x_bias_gain = 1.0;

const double corridor_slope = .1;
const double corridor_equilibrium = 500;

const double block_slope = .1;

const double y_bias_slope = .1;

// Retrieving info
// Features->shared_model->teammate[ers01 - 1].State;
// Features->shared_model->timestamp[ers01 - 1]

struct SharedModel {
  SharedModelEntry teammate[8];
  ulong timestamp[8];
  int activeRobots[4];
  SPOutSharedWorldModelEncoder encoder;
  PacketStream *swmOutStream;

  void init();
  void initializeStreams(PacketStreamCollection *out_psc);
  bool validPlayerPosn(int index, ulong current_time);
  bool validBallPosn(int index, ulong current_time);    
  bool isGoalie(int index);
  bool clearing(int index);
  bool validBallUncertainty(vector2d uncert);
  Gaussian2 getBallLocation(ulong current_time, int robot_id);


  
  int getMaxIndex(ulong current_time, int uniform_color);
  int getMinIndex(ulong current_time, int uniform_color);
  int getOtherSupporterIndex(ulong current_time,
			     int robot_id,
			     int primary_index);

  double getAttackerActivation(vector2d ball_posn,
			       vector2d robot_posn,
			       int uniform_color);
  double getAttackerActivation(int index, int uniform_color);

  vector2d getSupporterVector(vector2d my_loc,
			      vector2d score_goal,
			      vector2d defend_goal,
			      vector2d vision_ball,
			      int my_id, int uniform_color,
			      ulong current_time);
  
  double getSupporterActivation(vector2d point, 
				vector2d score_goal,
				vector2d defend_goal,
				vector2d vision_ball,
				int my_id, int uniform_color,
				ulong current_time);
  void sendOutput();


  private:
  
  double getWallPF(vector2d point, int uniform_color);
  double getBallPF(vector2d point, vector2d ball,
		   bool offensive_supporter);
  double getTeammatePF(vector2d point, vector2d tm);
  double getXBiasPF(vector2d point, vector2d primary,
		    int uniform_color,
		    bool offensive_supporter);
  double getCorridorPF(vector2d point, 
		       vector2d score_goal,
		       vector2d ball,
		       bool offensive_supporter);
  double getBlockOwnGoalPF(vector2d point,
			   vector2d defend_goal,
			   vector2d ball,
			   bool offensive_supporter);
  double getYBiasPF(vector2d point, vector2d ball,
		    bool offensive_supporter);
};

/* This structure is passed back to the main object
   from the behavior system. Since we pass a filled
   buffer back each time, we use the isValid flag to
   indicate whether or not the buffer needs to be
   sent over the network ('cuz we do NOT want to do
   it every single frame).

*/
struct SharedModelUpdate {
  SharedModelEntry data;
  bool isValid;
};

#endif
