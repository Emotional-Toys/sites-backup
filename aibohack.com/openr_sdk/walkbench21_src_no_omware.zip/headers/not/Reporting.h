/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef INCLUDED_Reporting_h
#define INCLUDED_Reporting_h

#include <stdio.h>

#include "DogTypes.h"
#include "CircBufPacket.h"
#include "SystemUtility.h"

class EventRateReporter {
private:
  const char *eventName;
  ulong timeReportRate;
  ulong countReportRate;
  ulong lastReport;
  ulong count;
  PacketStream **buffer;
public:
  EventRateReporter(const char *name,ulong time_report_rate, ulong count_report_rate, PacketStream **buffer_param) :
    eventName(name),
    timeReportRate(time_report_rate),
    countReportRate(count_report_rate),
    lastReport(0UL),
    count(0UL),
    buffer(buffer_param) {
  }

  void addToCount(bool dodump) {
    count++;
    ulong time;

    time=GetTime();

    if(count >= countReportRate || time-lastReport > timeReportRate) {
      if((*buffer)!=NULL) {
	if (dodump) {
	  pprintf((*buffer),"%s:rate %f\n",eventName,
		  (double)count / ((time-lastReport)/1000000.0));
	}
      }
      lastReport=time;
      count=0UL;
    }
  }
};

class EventTimeReporter {
private:
  const char *eventName;
  ulong totalTimeReportRate;
  ulong timeReportRate;
  ulong countReportRate;
  ulong lastReport;
  ulong count;
  ulong totalTime;
  PacketStream **buffer;
public:
  class EventTimer {
  public:
    EventTimeReporter *etr;
    ulong start_time;

    EventTimer(EventTimeReporter *_etr) {
      etr = _etr;
      start_time = GetTime();
    }

    ~EventTimer() {
      ulong end_time = GetTime();
      ulong elapsed_time = end_time - start_time;
      etr->addTimeEvent(elapsed_time);
    }
  };

  EventTimeReporter(const char *name,
                    ulong total_time_report_rate, ulong time_report_rate, ulong count_report_rate,
                    PacketStream **buffer_param) :
    eventName(name),
    totalTimeReportRate(total_time_report_rate),
    timeReportRate(time_report_rate),
    countReportRate(count_report_rate),
    lastReport(0UL),
    count(0UL),
    totalTime(0UL),
    buffer(buffer_param) {
  }

  void addTimeEvent(ulong elapsed_time) {
    count++;
    totalTime += elapsed_time;
    ulong time;

    time=GetTime();

    if(count >= countReportRate        ||
       totalTime > totalTimeReportRate ||
       time-lastReport > timeReportRate) {
      if((*buffer)!=NULL) {
        pprintf((*buffer),"%s:rate %f, time per event %g, total time pct %6.2f\n",eventName,
                (double)count / ((time-lastReport)/1000000.0),
                (double)totalTime / count,
                100.0*(double)totalTime / (time-lastReport));
      }
      lastReport=time;
      count = 0UL;
      totalTime = 0UL;
    }
  }
};

#endif
