/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef __FIELD_H__
#define __FIELD_H__

#include "gvector.h"

/* Lab values */
const double halfLength   =2155.0; // mm
const double halfWidth    =1410.0; // mm
const double penaltyRegionOffset=1750.0; // mm
const double wedgeSize    = 300.0; // mm
const double goalDepth    = 300.0; // mm
const double goalHalfWidth= 300.0; // mm
const double markerOffset = 100.0; // mm
const double markerHeight = 300.0; // mm from ground to center of marker
const double visionDegHalf=  29.0; // degrees
const double wallWidth    = 100.0; // mm

/* Field A */
/*
const double halfLength   =2102.5; // mm
const double halfWidth    =1347.5; // mm
const double penaltyRegionOffset = halfWidth - 350.0;
const double wedgeSize    = 300.0; // mm
const double goalDepth    = 340.0; // mm from back of goal to front of wall.
const double goalHalfWidth= 300.0; // mm
const double markerOffset = 280.0; // mm
const double markerHeight = 300.0; // mm from ground to center of marker
const double visionDegHalf=  29.0; // degrees
const double wallWidth    = 100.0; // mm
*/

/* Small-size filed values */
/*
const double halfLength   = 1400.0; // mm
const double halfWidth    = 1150.0; // mm
const double penaltyRegionOffset = halfWidth - 225.0;
const double wedgeSize    = 50.0; // mm
const double goalDepth    = 340.0; // mm from back of goal to front of wall.
const double goalHalfWidth= 300.0; // mm
const double markerOffset = 100.0; // mm
const double markerHeight = 300.0; // mm from ground to center of marker
const double visionDegHalf=  29.0; // degrees
const double wallWidth    = 50.0; // mm
*/

const double UNISCALE = 8.0;  // UNISCALE*appropriate width = stddev for 'uniform' distribution

const double BallDiameter=84.3; // mm
const double BallRadius  =BallDiameter/2.0; // 42.15 mm
const double MarkerColorSeperation = 100.0; // mm
const double GoalHeight = 300.0; // mm
const double WallHeight = 100.0; // mm

const double robot_fwd_size = 150;  // mm from center to front
const double robot_back_size = 100; // mm from center to back
const double robot_width = 110; // mm from center to side

typedef GVector::vector2d<double> vector2d;

const vector2d MarkerLocations[6]={
  vector2d(   halfLength+markerOffset,   halfWidth+markerOffset),
  vector2d(   halfLength+markerOffset, -(halfWidth+markerOffset)),
  vector2d(                       0.0,   halfWidth+markerOffset),
  vector2d(                       0.0, -(halfWidth+markerOffset)),
  vector2d(-(halfLength+markerOffset),   halfWidth+markerOffset),
  vector2d(-(halfLength+markerOffset), -(halfWidth+markerOffset))
};

#endif
