/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef WaveLAN_h
#define WaveLAN_h

#include "DogTypes.h"
#include "SharedWorldModel.h"

// Maximum message length that we are willing to route from 
// [robot|linux]->robot.  Note, that this does not affect
// robot->linux message size.
static const ulong MaxRouteMessageLength=1024;

struct NetMsgHeader
{
  enum IDList { ERS01 = 1, ERS02, ERS03, ERS04,
		ERS05, ERS06, ERS07, ERS08, Linux, BCast };

  enum SubsystemList { Sub_Main, Sub_WLO, Sub_NumOfSubsystems };

  enum MessageTypes { MsgText = 1, WLOStream, MsgThresholdSelect, MsgWorldInfo, MsgBallCollection, MsgBarChallenge };

  // This is the total length in bytes of the packet
  // that gets transmitted. It's necessary because the
  // compiler wants to add space in structs of the type:
  // struct foo { NetMsgHeader h; OtherStruct data }
  // When we bcast these, there are truncation issues on
  // the linux side.
  ushort totalLength;
  uchar senderID;
  uchar senderSubsystem;
  uchar receiverID;
  uchar receiverSubsystem;
  uchar messageType;
  uchar pad[1];
};

struct WorldModelMsg {
  NetMsgHeader header;
  SharedModelEntry data;

  void buildHeader(uchar sender_id)
  {
    header.totalLength = sizeof(WorldModelMsg);
    header.senderID        = sender_id;
    header.senderSubsystem = NetMsgHeader::Sub_Main;
    header.receiverID        = NetMsgHeader::BCast;
    header.receiverSubsystem = NetMsgHeader::Sub_Main;
    header.messageType = NetMsgHeader::MsgWorldInfo;
  }
};

struct BallCollectionMsg {
  NetMsgHeader header;
  
  /* Insert whatever other data you want. */
  
  void buildHeader(uchar sender_id) {
    header.totalLength = sizeof(BallCollectionMsg);
    header.senderID        = sender_id;
    header.senderSubsystem = NetMsgHeader::Sub_Main;
    header.receiverID        = NetMsgHeader::BCast;
    header.receiverSubsystem = NetMsgHeader::Sub_Main;
    header.messageType = NetMsgHeader::MsgBallCollection;
  }
};

struct BarChallengeMsg {
  NetMsgHeader header;
  
  /* Insert whatever other data you want. */

  void buildHeader(uchar sender_id) {
    header.totalLength = sizeof(BarChallengeMsg);
    header.senderID        = sender_id;
    header.senderSubsystem = NetMsgHeader::Sub_Main;
    header.receiverID        = NetMsgHeader::BCast;
    header.receiverSubsystem = NetMsgHeader::Sub_Main;
    header.messageType = NetMsgHeader::MsgBarChallenge;
  }
};

#endif
