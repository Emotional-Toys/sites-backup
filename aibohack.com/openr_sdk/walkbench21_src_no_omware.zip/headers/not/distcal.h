/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef __DISTCAL_H__
#define __DISTCAL_H__
/* Auto generated calibration header */

const double scaleDistA[6] = {
  1.055920E+00,
  1.075105E+00,
  1.235720E+00,
  1.091824E+00,
  1.131339E+00,
  1.133116E+00
};

const double scaleDistB[6] = {
  4.421364E+01,
  -7.188660E+01,
  -1.352789E+02,
  -4.014572E+01,
  -6.689156E+01,
  -1.687099E+02
};

const double stdevDistA[6] = {
  5.647518E-02,
  2.830865E-02,
  1.319340E-02,
  2.159441E-02,
  3.030007E-02,
  2.448282E-02
};

const double stdevDistB[6] = {
  3.903282E+01,
  6.725802E+01,
  2.671915E+01,
  2.264161E+01,
  6.965837E+01,
  1.270717E+02
};


const double minstdevDist = 10.0;

#endif
