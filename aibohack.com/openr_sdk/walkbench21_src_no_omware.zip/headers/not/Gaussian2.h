/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef GAUSSIAN2_H_
#define GAUSSIAN2_H_

#include <math.h>

#include "DogTypes.h"
#include "Geometry.h"

/*
 * A class for manipulating two-dimensional gaussian distributions.
 * the mean is represented by a vector2d (x,y).
 * the major-axis and minor-axis standard deviations are given,
 * The angle of the major axis with x is also given.
 */

class Gaussian2 {
 public:
  /* Data members */

  // Ummm... These are never initialized or used, so I'm
  // just going to assume they're an error and comment
  // them out. (otherwise people accessing them by accident
  // will crash the puppy due to uninitialized doubles. Not
  // that I'm bitter or anything)
  
  // double x, y;
  vector2d mean;
  double sMaj, sMin, thetaMaj; /* Aligned with major and minor axes */
  double sx, sy, psxsy;  /* Aligned with x,y axis */
  ulong time;

  /* Public member functions */
  Gaussian2();
  Gaussian2(ulong timestamp, vector2d m, double s1, double s2, double c,
	    bool global);
  Gaussian2(const Gaussian2& g);
  void setsxsy(double sigma_x, double sigma_y, double correlation);
  void setsMajsMin(double sigma_maj, double sigma_min, double angle);
  friend Gaussian2 G2Multiply(Gaussian2 g1, Gaussian2 g2);
  double ang_dev();
  double dist_dev();
};
  

#endif
