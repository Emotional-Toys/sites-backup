/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef __MOTION_H__
#define __MOTION_H__

class MotionPlayer;

#include "../headers/Geometry.h"
#include "Kinematics.h"
#include "Spline.h"
#include "Path.h"

#include "MotionInterface.h"

#ifdef REMOVED_SOUND
#include "Sound.h"
#endif

typedef SplinePath<vector3d,double> splinepath;
typedef HermiteSplineSegment<vector3d,double> spline;

template <class data>
void set3(data *arr,data v0,data v1,data v2)
{
  arr[0] = v0;
  arr[1] = v1;
  arr[2] = v2;
}

namespace Motion{

/*
  Joint array:
   0-11 : Legs (LF,RF,LH,RH) (Rotator, Shoulder, Knee)
  12-14 : Head (Tilt,Pan,Roll)
  15-16 : Tail (Diag Bottom Right, Diag Upper Right)
  17    : Mouth
  18-19 : Ears (L,R)
*/

/*
class MotionStream{
  int length;
public:
  virtual bool LoadMotion(char *file);
  virtual bool Interpolate();
  virtual int length();
};
*/

// Whether legs and head are busy (i.e. something else can't use them yet)
// Also indicates whether the motion generator cannot get a new target itself
#define LEGS_BUSY   1
#define HEAD_BUSY   2
#define TARGET_BUSY 4

const int TimeStep = 8; // 8 ms, can use another for slow motion testing

#define ATTR_ANGLES   1
#define ATTR_POSITION 2

struct LegState{
  long attr,reserved;
  point3d pos;
  double angles[3];
};

struct HeadState{
  long attr,reserved;
  vector3d target;
  double angles[3];
};

struct BodyState{
  BodyPosition pos;
  LegState leg[4];
  HeadState head;
};

struct BodyStateMotion{
  BodyState body;
  long time; // ms
  long reserved;
};

class MotPlayer{
  BodyStateMotion *frame;
  int num_frames;
  int current_frame;
  int base_time;
  bool flip;
  double speed;
public:
  MotPlayer() {frame=NULL;}
  ~MotPlayer() {close();}

  bool load(char *filename);
  void close();
  void play(BodyState &body,int time,double nspeed,bool flip_lr);
  int get(BodyState &body,int time);
};

class Stand{
  BodyState start,target;
  int time,length;

  BodyState neutral;
  BodyState crouch;
public:
  Stand();
  void init();
  void setTarget(BodyState &current,BodyState &ntarget,int ntime);
  void setTarget(BodyState &body,int target,int ntime);

  int getAngles(BodyState &current,BodyState &next);
  int areBusy();
  void getMotionUpdate(MotionLocalizationUpdate &update);
};

struct LegParam{
  vector3d neutral;
  vector3d lift_vel,down_vel;
  double lift_time,down_time;
};

struct LegWalkState{
  spline airpath;
  int time_lift;
  bool air;
};

struct WalkParam{
  LegParam leg[4];
  double body_height;
  double body_angle;
  double hop;  // sinusoidal hop amplitude
  double sway; // sinusoidal sway in y direction
  long period;
  long reserved;
  double front_height, back_height;
};

class Trot{
  WalkParam wp,wp_xy,wp_a,wp_d;
  LegWalkState legw[4];
  splinepath body_loc,body_angle;
  BodyPosition wpos;

  vector3d pos_delta;
  double angle_delta;

  int time, type;
  double cur_cycle,cycle_offset;

  vector3d vel_xya;
  vector3d target_vel_xya;
private:
  void evalPosition(BodyPosition &bp,int time);
  vector3d projectPosition(BodyPosition &bp,vector3d pos);
public:
  Trot();
  void init(int walk_type);
  void load();

  void chooseParam(double dx,double dy,double da);
  void setTarget(double dx,double dy,double da,
                 double accel_time,bool nobound);
  vector3d &velocity() {return(vel_xya);}

  int getAngles(BodyState &current,BodyState &next);
  int areBusy();
  void getMotionUpdate(MotionLocalizationUpdate &update);
};

class Getup{
  MotPlayer m_front;
  MotPlayer m_back;
  MotPlayer m_side;

  int type,time,busy;
public:
  Getup();
  void load();
  void init(int getup_type);

  int getAngles(BodyState &current,BodyState &next);
  int areBusy();
  void getMotionUpdate(MotionLocalizationUpdate &update);
};

class Kick{
  MotPlayer m_dive;
  MotPlayer m_bump;
  MotPlayer m_fwd;
  MotPlayer m_head;
  MotPlayer m_heads;
  MotPlayer m_hold;
  MotPlayer m_dance;

  int type,time,busy;
public:
  Kick();
  void load();
  void init(int kick_type);

  int getAngles(BodyState &current,BodyState &next);
  int areBusy();
  void getMotionUpdate(MotionLocalizationUpdate &update);
};

class Motion{
public:
  MotionCommand cmd;
private:
  int state,top_state;
  int time;

  Stand stand;
  Trot trot;
  Getup getup;
  Kick kick;
#ifdef REMOVED_SOUND
  Sound sound;
#endif

  BodyState body;
  unsigned LED_state;

  bool new_cmd;
  // bool enable;
public:
  Motion();
  void init();
  void init(double *angles);
  void setCommand(MotionCommand &ncmd);

  // void toggle();
  // bool isEnabled() {return(enable);}

  void getAngles(double *angles);
  void getMotionUpdate(MotionLocalizationUpdate &update,ulong time);

  unsigned getLEDState()
    {return(LED_state);}
  void setLEDState(unsigned mask,unsigned val)
    {LED_state = (LED_state & ~mask) | (val & mask);}

#ifdef REMOVED_SOUND
  void setSpeakerSamplingRate(int sample_rate)
    {sound.setSpeakerSamplingRate(sample_rate);}
  void getSoundData(char *data,int data_size)
    {sound.getSoundData(data,data_size);}
#endif
};

} // Namespace

#endif
// __MOTION_H__
