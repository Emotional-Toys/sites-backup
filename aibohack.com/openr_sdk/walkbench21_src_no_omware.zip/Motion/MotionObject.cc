/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef OPENR_STUBGEN
#define OPENR_STUBGEN
#endif

#include <iostream.h>
#include <math.h>

#include <OPENR/OPENR.h>
#include <OPENR/OPENRMessages.h>
#include <OPENR/core_macro.h>

#include <OPENR/OUnits.h>

#include "../headers/Sensors.h"
#ifdef REMOVED_PACKET_TRACE
#include "../headers/AperiosMessageStructures.h"
#include "../headers/CircBufPacket.h"
#include "../headers/Config.h"
#include "../headers/DogTypes.h"
#include "../headers/Reporting.h"
#include "../headers/SharedMem.h"
#include "../headers/SPOutEncoder.h"
#include "../headers/Utility.h"
#include "../headers/Util.h"
#include "SPOutMotionEncoder.h"
#else
// HACKS:
#include "../headers/SystemUtility.h"       // for GetTime
#endif

#include "def.h"

#include "MotionInterface.h"
#include "Motion.h"

#include "MotionObject.h"

Motion::MotionLocalizationUpdateQueue *LocUpdateQueueBuffer = NULL;

// static BogusPacketStream *TextOutputStream=(BogusPacketStream *)0;

static const int MotionOutputDataSize = 64*1024; // 64KB
static const int TotalTextOutput = 32*1024; // 32KB
static const int MaxTextMessages = 256; // maximum number of in flight text messages

static const int MotionUpdateSize = 2*2+8*4+1;
static const int MaxMotionUpdateMessages = 20;
static const int TotalMotionUpdate       = MotionUpdateSize * MaxMotionUpdateMessages;

#include "globals.h"

static const bool DriveEars=false; // currently not double buffering correctly

// #define ZERODOG

static const unsigned int MaxLocQueueSize=10U;
static const unsigned int FrameTime=8U; // (ms)

static const unsigned int SpeakerSamplingRate = 8000;

#ifndef ZERODOG
Motion::Motion motion;
#endif
SensorData sensor;

/*
const int LocStoppedReportPeriod = 250; // (ms)
MotionLocalizationUpdate NoMoveDelta = {
  0.0, 0.0, 0.0,
  false, false
};
*/

static const int NumFrames=4;
// ocommandMAX_FRAMES;

MotionObject::MotionObject() :
  triggerVR(false)
{
  NewComData;

#ifdef REMOVED_PACKET_TRACE
  requestedRegion = false;
  needToSendOutBuffer=false;
  needToSendLocBuffer=false;

  motionUpdateStream = NULL;
  encoder = new SPOutMotionEncoder;
#endif

  motion.init();
#ifdef REMOVED_SOUND
  motion.setSpeakerSamplingRate(SpeakerSamplingRate);
#endif

  memset(&sensor,0,sizeof(sensor));
}

OStatus MotionObject::DoInit(const OSystemEvent& info)
{
  // cout << "MotionObject::DoInit() is invoked." << endl;

#ifdef REMOVED
  config.init();
  config.config("/MS/config/config.cfg");
#endif

  SensorData::InitializeSensors();

  SetComData;

  SetupSound();

#ifdef REMOVED_PACKET_TRACE
  // make sure the library doesn't drop data "for" us
  //   on this reliable communication channel
  observer[obsSharedMemRegionInfo]->SetBufCtrlParam(0,1,16);
#endif

  motion.init(NULL);

  return oSUCCESS;
}

OStatus MotionObject::DoStart(const OSystemEvent& info)
{
  int s,j;

  // cout << "MotionObject::DoStart() is invoked." << endl;

#ifdef REMOVED_PACKET_TRACE
  // our setup
  void *base_addr;

  // allocate the localiation update queue memory and allow attachement
  base_addr=NULL;
  motionLocUpdateMemRgn.init(sizeof(Motion::MotionLocalizationUpdateQueue));
  base_addr = motionLocUpdateMemRgn.getData();

  LocUpdateQueueBuffer=(Motion::MotionLocalizationUpdateQueue *)base_addr;
  for(int i=0; i<Motion::MotionLocalizationUpdateQueueBufferSize; i++) {
    LocUpdateQueueBuffer->buffer[i].timestamp=0UL;
  }

  needToSendLocBuffer=true;
  sendLocUpdateQueueBuffer();

  // allocate the memory for spout style output
  base_addr=NULL;
  outMemRgn.init(sizeof(BogusPacketStreamCollection)+MotionOutputDataSize);
  base_addr = outMemRgn.getData();

  BogusPacketStreamCollection *out_psc;
  uchar *start_address;

  out_psc=(BogusPacketStreamCollection *)base_addr;
  start_address = ((uchar *)base_addr) + sizeof(BogusPacketStreamCollection); 
  out_psc->init(start_address, start_address + MotionOutputDataSize);

  int text_output_stream_id;
  text_output_stream_id = out_psc->allocateStream(TotalTextOutput,MaxTextMessages);
  TextOutputStream = out_psc->getStream(text_output_stream_id);
  TextOutputStream->type   = SPOutEncoder::TextLead;
  TextOutputStream->binary = false;

  int motion_update_stream_id;
  motion_update_stream_id = out_psc->allocateStream(TotalMotionUpdate,MaxMotionUpdateMessages);
  motionUpdateStream = out_psc->getStream(motion_update_stream_id);
  motionUpdateStream->type   = SPOutEncoder::MotionUpdateLead;
  motionUpdateStream->binary = true;

  needToSendOutBuffer=true;

  sendOutputBuffer();
#endif

  // Aperios Setup
  current = 0;
  step    = NumFrames;
  SetUpBuffer();

  OPENR::SetMotorPower(opowerON);

  triggerVR = true;

  SetJointGain(0.0);
  OPENR::SetDefaultJointGain(oprimitiveID_UNDEF);
  OPENR::EnableJointGain(oprimitiveID_UNDEF);
  SetJointGain(0.0);
  SendJointData();

  for(int i=0; i<numOfObserver; ++i){
    if(observer[i]->AssertReady() != oSUCCESS){
      cout << "\tMOARF{" << i << "}" << endl; // motion object assert ready failed
    }
  }

#ifdef REMOVED_PACKET_TRACE
  RequestRegions();
#endif

  return(oSUCCESS);
}

OStatus MotionObject::DoStop(const OSystemEvent& info)
{
  // cout << "MotionObject::DoStop() is invoked." << endl;

  triggerVR = false;

  for (int i=0; i<numOfObserver; ++i){
    observer[i]->DeassertReady();
  }

  return(oSUCCESS);
}

OStatus MotionObject::DoDestroy(const OSystemEvent& info)
{
  // cout << "MotionObject::DoDestroy() is invoked." << endl;

  DeleteComData;

  return(oSUCCESS);
}

void MotionObject::SetUpBuffer()
{
  int buf_id,prim_id;
  OCommandInfo *info;
  int i;

  // Initialize a joint pass for data to be sent to OVRComm
  // For the definition of Joint,  refer to MotionObject.h.    
  for(i=0; i<NumOutputs; i++) {
    OPENR::OpenPrimitive((char*)PrimitiveName[i],&primitiveID[i]);
  }

  // Set that each data is used for a Joint control
  for(buf_id=0; buf_id<NumBuffers; buf_id++) {
    OPENR::NewCommandVectorData(NumFastOutputs,&cmdVecFastID[buf_id],&cmdVecFast[buf_id]);
    cmdVecFast[buf_id]->SetNumData(NumFastOutputs);
    cmdVecFastRgn[buf_id]=new RCRegion(cmdVecFast[buf_id]->vectorInfo.memRegionID,
                                       cmdVecFast[buf_id]->vectorInfo.offset,
                                       (void *)cmdVecFast[buf_id],
                                       cmdVecFast[buf_id]->vectorInfo.totalSize);

    OPENR::NewCommandVectorData(NumBinJoints,&cmdVecSlowID[buf_id],&cmdVecSlow[buf_id]);
    cmdVecSlow[buf_id]->SetNumData(NumBinJoints);
    cmdVecSlowRgn[buf_id]=new RCRegion(cmdVecSlow[buf_id]->vectorInfo.memRegionID,
                                       cmdVecSlow[buf_id]->vectorInfo.offset,
                                       (void *)cmdVecSlow[buf_id],
                                       cmdVecSlow[buf_id]->vectorInfo.totalSize);

    /*
    OPENR::NewCommandVectorData(NumOutputs,&cmdVecSlowID[buf_id],&cmdVecSlow[buf_id]);
    cmdVecSlow[buf_id]->SetNumData(NumOutputs);
    cmdVecSlowRgn[buf_id]=new RCRegion(reinterpret_cast<SharedMemoryHeader *>(cmdVecSlow[buf_id]));
    */

    for(prim_id=0; prim_id<NumPIDJoints; prim_id++) {
      info = cmdVecFast[buf_id]->GetInfo(prim_id);
      info->Set(odataJOINT_COMMAND2,primitiveID[prim_id],NumFrames);
      /*
      info = cmdVecSlow[buf_id]->GetInfo(prim_id);
      info->Set(odataJOINT_COMMAND2,primitiveID[prim_id],NumFrames);
      */
    }

    for(prim_id=LEDOffset; prim_id<LEDOffset+NumLEDs; prim_id++) {
      info = cmdVecFast[buf_id]->GetInfo(prim_id);
      info->Set(odataLED_COMMAND2,primitiveID[prim_id],NumFrames);
      /*
      info = cmdVecSlow[buf_id]->GetInfo(prim_id);
      info->Set(odataLED_COMMAND2,primitiveID[prim_id],NumFrames);
      */
      }

    for(prim_id=EarOffset; prim_id<EarOffset+NumBinJoints; prim_id++) {
      info = cmdVecSlow[buf_id]->GetInfo(prim_id);
      info->Set(odataJOINT_COMMAND3,primitiveID[prim_id],NumFrames);
    }
  }
}

void MotionObject::ReadyMoveJoint(const OReadyEvent& event)
{
  static unsigned int cnt=0;
  static unsigned int cnt_trigger=0;

  if(triggerVR==true)
  {
    // send joint gains every half second for the first 5 seconds
    if(cnt<4000 && cnt>=cnt_trigger){
      cnt_trigger += 300;

#ifdef LIMPDOG
    #error - LIMPDOG not supported
#endif

      SetJointGain((double)cnt / 3000.0);
      cnt_trigger += 300;
    }


    SendJointData(); // send joint data

    cnt+=FrameTime*NumFrames;
  }
  // otherwise is stays ready to reactivate
}

void MotionObject::SetJointGain(double v)
{
  int i;

  v = bound(v,0.0,1.0);

  for(i=0; i<NumPIDJoints; i++){
    OPENR::SetJointGain(primitiveID[i],
                        (word)(v*Pid[i][0]),
                        (word)(v*Pid[i][1]),
                        (word)(v*Pid[i][2]),
                        Pid[i][3], Pid[i][4], Pid[i][5]);
  }
}

void MotionObject::SendJointData()
{
  double angles[NumJoints];
  unsigned LED_state;
  double angle;

  static int num_times_not_ready=0;
  static int max_time=0;

  int time,refcount;
  int frame,buf_id;

  // Check if VRComm is ready or not.
  bool isready = subject[sbjMoveJoint]->IsReady();
  if(!isready){
    // cout << "VRComm not ready " << num_times_not_ready << endl;
    num_times_not_ready++;
    return;
  }

  //static unsigned int debug_cnt=0;
  //debug_cnt++;
  //bool debug_prints=true;//((debug_cnt % 13)==0);

  bool fast_used[NumBuffers];
  bool slow_used[NumBuffers];
  int num_used;

  for(buf_id=0; buf_id<NumBuffers; buf_id++) {
    fast_used[buf_id] = (cmdVecFastRgn[buf_id]->NumberOfReference() != 1);
    slow_used[buf_id] = (cmdVecSlowRgn[buf_id]->NumberOfReference() != 1);
  }

  num_used=0;
  for(buf_id=0; buf_id<NumBuffers; buf_id++) {
    num_used += (fast_used[buf_id] ? 1 : 0);
    num_used += (slow_used[buf_id] ? 1 : 0);
  }

  //if(debug_prints) pprintf(TextOutputStream,"nu %d sa %d sb %d fa %d fb %d\n",num_used,slow_used[0],slow_used[1],fast_used[0],fast_used[1]);

  static const int target_used=2;
  static void *output_cmd[NumOutputs];

  // Create data for 16 frames and notify it to OVirtualRobotComm in a double buffer.   
  // Notify Return Status after sending the frame.  
  while(num_used < target_used) {
    static int cnt=0;
    bool slow;
    
    cnt = (cnt + 1) % 32;
    if(DriveEars)
      slow = (cnt==0);
    else
      slow = false;

    RCRegion *cmd_vec_rgn;
    OCommandVectorData *cmd_vec_p;
    MemoryRegionID cmd_vec_id_p;

    if(slow) {
      int buf_to_use=0;
      while(slow_used[buf_to_use] && buf_to_use<NumBuffers)
        buf_to_use++;
      if(buf_to_use==NumBuffers) {
        pprintf(TextOutputStream,"Ran out of slow buffers\n");
        buf_to_use=NumBuffers-1;
      }

      slow_used[buf_to_use]=true;

      cmd_vec_rgn = cmdVecSlowRgn[buf_to_use];
      cmd_vec_p = reinterpret_cast<OCommandVectorData*>(cmd_vec_rgn->Base());
    }
    else {
      int buf_to_use=0;
      while(fast_used[buf_to_use] && buf_to_use<NumBuffers)
        buf_to_use++;
      if(buf_to_use==NumBuffers) {
        pprintf(TextOutputStream,"Ran out of fast buffers\n");
        buf_to_use=NumBuffers-1;
      }

      fast_used[buf_to_use]=true;

      cmd_vec_rgn = cmdVecFastRgn[buf_to_use];
      cmd_vec_p = reinterpret_cast<OCommandVectorData*>(cmd_vec_rgn->Base());
    }

    num_used++;

    //if(debug_prints) pprintf(TextOutputStream,"nu %d sa %d sb %d fa %d fb %d\n",num_used,slow_used[0],slow_used[1],fast_used[0],fast_used[1]);

    // In case the Buffer is available, set the address in commandValue.
    for(int joint_idx=0; joint_idx<NumPIDJoints; joint_idx++) {
      OCommandData *data = cmd_vec_p->GetData(joint_idx);
      output_cmd[joint_idx] = data->value;
      angles[joint_idx] = 0.0;
    }

    for(int joint_idx=LEDOffset; joint_idx<LEDOffset+NumLEDs; joint_idx++) {
      OCommandData *data = cmd_vec_p->GetData(joint_idx);
      output_cmd[joint_idx] = data->value;
    }

    if(slow) {
      for(int joint_idx=EarOffset; joint_idx<EarOffset+NumBinJoints; joint_idx++) {
        OCommandData *data = cmd_vec_p->GetData(joint_idx);
        output_cmd[joint_idx] = data->value;
      }
    }

    for(frame=0; frame<NumFrames; frame++){
      time = (current + frame)*FrameTime;

#ifndef ZERODOG
      motion.getAngles(angles);
#endif

      if(frame==NumFrames-1){
        static int buffer_num=0;
      
        if(LocUpdateQueueBuffer!=NULL){
          motion.getMotionUpdate(LocUpdateQueueBuffer->buffer[buffer_num],GetTime());
      
          static int dump_count=0;
#ifdef REMOVED_PACKET_TRACE
          if(config.spoutConfig.dumpMoveUpdate) {
            if(++dump_count >= config.spoutConfig.dumpMoveUpdate) {
              if(encoder!=NULL && motionUpdateStream!=NULL) {
                static uchar buf[MotionUpdateSize];
                int out_size=0;
                out_size = encoder->encodeMotionLocalizationUpdate
                  (buf,&LocUpdateQueueBuffer->buffer[buffer_num]);
                motionUpdateStream->writeBinary(buf,out_size);
              } else {
                pprintf(TextOutputStream,"MNENUS");
              }
              dump_count=0;
            }
          }
#endif
      
          buffer_num = (buffer_num + 1) % Motion::MotionLocalizationUpdateQueueBufferSize;
        }else{
          pprintf(TextOutputStream,"no fbk queue\n");
        }
      }

      for(int i=0; i<NumPIDJoints; i++){
        ((OJointCommandValue2*)(output_cmd[i]))[frame].value = micro(angles[i]);
      }

      // angle = radians(20 * sin(2*M_PI*time/500));
      // ((OJointCommandValue2*)(output_cmd[15]))[frame].value = micro(angle); // tail wag
      // ((OJointCommandValue2*)(output_cmd[12]))[frame].value = micro(radians(0)); // head flat
      // jointCmd[17][frame].value = micro(-fabs(angle)); // mouth
      // jointCmd[13][frame].value = micro(angle);


      LED_state = motion.getLEDState();

      for(int led_idx=0; led_idx<NumLEDs; led_idx++) {
        ((OLEDCommandValue2*)(output_cmd[LEDOffset + led_idx]))[frame].led =
          ((LED_state >> led_idx) & 1) ? oledON : oledOFF;
        ((OLEDCommandValue2*)(output_cmd[LEDOffset + led_idx]))[frame].period = 1;
      }
    }

    if(slow) {
      ((OJointCommandValue3*)(output_cmd[EarOffset + 0]))[0].value=((time+750)/1500)%2;
      ((OJointCommandValue3*)(output_cmd[EarOffset + 1]))[0].value=( time     /1500)%2;
    }

    current = (current + step);

    // Passing the data over to Handler
    subject[sbjMoveJoint]->SetData(cmd_vec_rgn);
  }

  // Send data to Handler
  subject[sbjMoveJoint]->NotifyObservers();
}

#ifdef REMOVED_PACKET_TRACE
void
MotionObject::ReadyRegisterRegion(const OReadyEvent &event) {
  //if(needToSendLocBuffer) {
  //  sendLocUpdateQueueBufferIfReady(event.SenderID());
  //} else if(needToSendOutBuffer) {
  //  sendOutputBufferIfReady(event.SenderID());
  //}
}

void
MotionObject::sendOutputBuffer() {
  //cout << "SharedMem::SendMemBlockID() invoked: memID " << regionId << "." << endl;
  OSubject* thisSubj = subject[sbjRegisterRegion];

  if(outMemRgn.getData()!=NULL && needToSendOutBuffer) {
    needToSendOutBuffer=false;
    outMemRgn.setId(MemoryId::MotionOutId);
    thisSubj->SetData(outMemRgn.getMsgForm());
    thisSubj->NotifyObservers();
    //cout << "SharedMemID sent" << endl;
  }
}

void MotionObject::sendLocUpdateQueueBuffer() {
  OSubject* thisSubj = subject[sbjRegisterRegion];

  if(motionLocUpdateMemRgn.validData() && needToSendLocBuffer) {
    needToSendLocBuffer=false;
    motionLocUpdateMemRgn.setId(MemoryId::MotionLocUpdateId);
    thisSubj->SetData(motionLocUpdateMemRgn.getMsgForm());
    thisSubj->NotifyObservers();
  }
}

void MotionObject::RequestRegions() {
}

void MotionObject::ReadyRequestRegion(const OReadyEvent &event)
{
}

void MotionObject::ResultMemRegion(const ONotifyEvent &event)
{
//  int event_num_data = event.NumOfData();
//  for(int event_data_id=0; event_data_id<event_num_data; event_data_id++) {
//    SMMSharedMemRegion region;
//    int region_id;
//    
//    region.init((SMMSharedMemRegion::MsgForm)event.RCData(event_data_id));
//    region_id = region.getId();
//    {
//      cout << "got buffer for region id " << region_id << "?" << endl;
//    }
//  }
//    
//  observer[obsSharedMemRegionInfo]->AssertReady();
}
#endif //REMOVED

void MotionObject::ReadyControlBC(const OReadyEvent& event)
{
  if(triggerBC) SendPowerOnParam();
}

void MotionObject::SendPowerOnParam()
{
  OPENR::SetMotorPower(opowerON);
  triggerBC = false;
}

void MotionObject::ReadyMotionComplete(const OReadyEvent &event)
{
}

void MotionObject::GotSensorFrame(const ONotifyEvent &event)
{
  // Receiving Sensor Data from OVRComm 
  OSensorFrameVectorData *sd = reinterpret_cast<OSensorFrameVectorData *>(event.RCData(0)->Base());
  // double angles[NumPIDJoints];
  // static int pressed = 0;

  sensor.read(sd);

  /*
  bool chin_switch,back_switch;
  double head_front_press,head_back_press;
  // Get chin switch
  chin_switch = ((OSwitchValue)sd[0].GetData( 7)->frame[0].value==oswitchON);
  // Get back switch
  back_switch = ((OSwitchValue)sd[0].GetData(27)->frame[0].value==oswitchON);
  // Get head front pressure sensor (usually 0 if not pressed, .6-1.0 when pressed)
  head_front_press = ((double)sd[0].GetData(4)->frame[0].value)/1.0e6;
  // Get head back  pressure sensor (usually 0 if not pressed, .6-1.0 when pressed)
  // pressing bakc button produces 0-0.7 on front button
  head_back_press  = ((double)sd[0].GetData(3)->frame[0].value)/1.0e6;
  */

  unsigned led = 0;
#ifdef FOOTDOG
  if(sensor.paw[0]) led |= Motion::LED_LOWER_LEFT;
  if(sensor.paw[1]) led |= Motion::LED_LOWER_RIGHT;
  if(sensor.paw[2]) led |= Motion::LED_UPPER_LEFT;
  if(sensor.paw[3]) led |= Motion::LED_UPPER_RIGHT;
  motion.setLEDState(Motion::RED_FACE_LEDS,led);
#endif

  led = Motion::LED_TAIL_RED | Motion::LED_TAIL_BLUE;

  // Testing only
  if(sensor.button & HeadFrontButton){
    motion.setLEDState(Motion::LED_TAIL_BLUE,Motion::LED_TAIL_BLUE);
  }
  if(sensor.button & HeadBackButton){
    motion.setLEDState(Motion::LED_TAIL_RED,Motion::LED_TAIL_RED);
  }

  //  if(sensor.button & BackButton){
  //    pressed++;
  //  pprintf(TextOutputStream,"Back Pressed=%d\n",pressed);

  // if(pressed > (motion.isEnabled()? 500/32 : 64/32)){
  //   motion.toggle();
  //   pprintf(TextOutputStream,"Toggle Enable Motion\n");
  //   pressed = -500/32;
  // }

  // motion.setLEDState(led,led);
  //}else{
  // pressed = 0;
    // motion.setLEDState(led,0);
  //}


  observer[obsSensorFrame]->AssertReady();
}

void MotionObject::UpdateControl(const ONotifyEvent &event)
{

#ifdef ZERODOG
    #error!
#endif

  Motion::MotionCommand cmd;
  int time;

  time = (current)*FrameTime;
  memcpy(&cmd,event.Data(0),sizeof(cmd));

#if 1 // ADDED
  if (cmd.enable)
  {
    // enabled
    if (!triggerVR)
    {
        // it was disabled - kick the loop again (even if not ready)
        triggerVR = true;
	    SendJointData(); // send joint data
    }
	motion.setCommand(cmd);
  }
  else
  {
    // disable - ignore rest of command
    triggerVR = false; // will stop next Ready
  }
#else
  motion.setCommand(cmd);
#endif


  observer[obsControl]->AssertReady();
}

void MotionObject::SetupSound()
{
  char *pt;
  int k;

  pprintf(TextOutputStream,"SetupSound");
  OPENR::OpenPrimitive("PRM:/r1/c1/c2/c3/s1-Speaker:S1", &primitiveID[29]);

  if (OPENR::ControlPrimitive(primitiveID[SpeakerOffset], oprmreqSPEAKER_MUTE_OFF, 0, 0, 0, 0) != oSUCCESS) {
    pprintf(TextOutputStream,"MUTE_OFF ERROR");
    //cout << "MUTE_OFF Error" << endl;
  }
 
  OPrimitiveControl_SpeakerVolume volume(ospkvol10dB);
  //OPrimitiveControl_SpeakerVolume volume(ospkvolinfdB);
  if(!OPENR::ControlPrimitive(primitiveID[SpeakerOffset],
                              oprmreqSPEAKER_SET_VOLUME,
                              &volume, sizeof(volume), 0, 0)) {
    pprintf(TextOutputStream,"Set speaker volume failed.\n");
  }

  for(int i = 0; i < 2; i++) {
    OPENR::NewSoundVectorData(1, SoundTableSize, &soundMemID[i], &soundVecData[i]);
    soundVecData[i]->SetNumData(1);
    soundVecRgn[i]=new RCRegion(soundVecData[i]->vectorInfo.memRegionID,
                                soundVecData[i]->vectorInfo.offset,
                                (void*)(soundVecData[i]),
                                soundVecData[i]->vectorInfo.totalSize);
    
    OSoundInfo *info = soundVecData[i]->GetInfo(0);
    info->Set(odataSOUND_VECTOR, primitiveID[SpeakerOffset], SoundTableSize);
    info->format        = osoundformatPCM;
    info->channel       = 1;
    info->samplingRate  = SpeakerSamplingRate;
    info->bitsPerSample = 8;
    info->frameSize     = info->samplingRate / 1000 * 32;
    
    pt = (char*)soundVecData[i]->GetData(0);
    for(k=0; k<SoundTableSize; k++) pt[k] = rand()%256 - 128;
  }
  soundCur = 0;

  //OPENR::ControlPrimitive(primitiveID[29], oprmreqSPEAKER_MUTE_ON, 0, 0, 0, 0);
}

#ifdef REMOVED_SOUND
OStatus MotionObject::ReadySpeaker(const OReadyEvent &info)
{
  char *pt;
  int i;

  for(i=0; i<2; i++){
    if(soundVecRgn[i]->NumberOfReference() == 1) {
      pt = (char*)soundVecData[i]->GetData(0);
      motion.getSoundData(pt,SoundTableSize);

      subject[sbjSpeaker]->SetData(soundVecRgn[i]);
    }
  }

  subject[sbjSpeaker]->NotifyObservers();

  return oSUCCESS;
}
#endif
