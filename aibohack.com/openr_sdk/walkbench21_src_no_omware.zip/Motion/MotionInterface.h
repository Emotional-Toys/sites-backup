/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef __MOTION_INTERFACE_H__
#define __MOTION_INTERFACE_H__

#include "../headers/DogTypes.h"
#include "../headers/Geometry.h"

//==== Input into motion system ======================================//

namespace Motion{

// Top Level States (state_type in MotionL-nUpdate)
const int STATE_WAITING  = 0;
const int STATE_STANDING = 1;
const int STATE_WALKING  = 2;
const int STATE_KICKING  = 3;
const int STATE_GETUP    = 4;

// Sub-states for each top level state (state in MotionL-nUpdate)

// Standing States
const int MOTION_STAND_NEUTRAL =  100;
const int MOTION_STAND_CROUCH  =  101;

// Walking States
const int MOTION_WALK_TROT     =  200;
const int MOTION_WALK_DRIBBLE  =  201;

// Kicking States
const int MOTION_KICK_DIVE        =  300;
const int MOTION_KICK_BUMP        =  301;
const int MOTION_KICK_FOREWARD    =  302;
const int MOTION_KICK_HEAD_L      =  303;
const int MOTION_KICK_HEAD_R      =  304;
const int MOTION_KICK_HEAD_SOFT_L =  305;
const int MOTION_KICK_HEAD_SOFT_R =  306;
const int MOTION_KICK_DIVE_L      =  307;
const int MOTION_KICK_DIVE_R      =  308;
const int MOTION_KICK_HOLD        =  309;
const int MOTION_DANCE            =  310;

// Fallen States
const int MOTION_GETUP_NEUTRAL =  400;
const int MOTION_GETUP_BACK    =  401;
const int MOTION_GETUP_FRONT   =  402;
const int MOTION_GETUP_LEFT    =  403;
const int MOTION_GETUP_RIGHT   =  404;

#define MOTION_STATE(s) ((s)/100)

// Head States
const int HEAD_LOOKAT          =  0;
const int HEAD_ANGLES          =  1; // Don't use this unless you have to!
const int HEAD_SCAN_BALL       =  2;
const int HEAD_SCAN_BALL_TURN  =  3;
const int HEAD_SCAN_DRIBBLE    =  4;
const int HEAD_SCAN_MARKERS    =  5;
const int NUM_HEAD_CMDS        =  6;

// Tail States
const int TAIL_AIM          =  0;
const int TAIL_FOLLOW       =  1;
const int NUM_TAIL_CMDS     =  2;

// Sound States
const int SOUND_NONE = 0;
const int SOUND_NOTE = 1;
const int SOUND_FILE = 2;

// Sound Files
const int SOUND_FILE_TEST      = 0;
const int SOUND_FILE_SQUARE    = 1;
const int SOUND_FILE_RECTANGLE = 2;
const int SOUND_FILE_T         = 3;
const int SOUND_FILE_L         = 4;
const int SOUND_FILE_TRIANGLE  = 5;
const int SOUND_FILE_TADA      = 6;
const int NUM_SOUND_FILES      = 7;

// LED constants
const int LED_LOWER_LEFT   = 1<<0;
const int LED_LOWER_RIGHT  = 1<<1;
const int LED_MIDDLE_LEFT  = 1<<2;
const int LED_MIDDLE_RIGHT = 1<<3;
const int LED_UPPER_LEFT   = 1<<4;
const int LED_UPPER_RIGHT  = 1<<5;
const int LED_TOP          = 1<<6; // New motion command packet recieved
const int LED_TAIL_RED     = 1<<7;
const int LED_TAIL_BLUE    = 1<<8;
const int LED_ALL          = (1<<9) - 1;
const int NUM_LEDS         = 9;

const int RED_FACE_LEDS = LED_LOWER_LEFT | LED_LOWER_RIGHT |
                          LED_UPPER_LEFT | LED_UPPER_RIGHT;

// walk constants
// maximum speeds (same units as the motion commands)
// const double MAX_DX   = 130; // mm/sec
// const double MAX_DY   =  80; // mm/sec
// const double MAX_DA   = 1.2; // rad/sec

const double MAX_DX   = 240; // 240 mm/sec
const double MAX_DY   = 210; // 160 mm/sec
const double MAX_DA   = 2.2; // 2.0 rad/sec

/*
const double MAX_DX   = 225; // mm/sec
const double MAX_DY   = 170; // mm/sec
const double MAX_DA   = 2.1; // rad/sec
*/

// time (seconds) for a 90 degree windmill turn
const double PI_2_TURN_TIME = 1;

class MotionCommand{
public:
  short enable;     // ADDED!
  short motion_cmd;       // target locomotion state
  short head_cmd;         // head command type
  short tail_cmd;         // tail command type
  short nobound;          // do not automatically bound motion
                          // (0=bounded, 1=unbounded)

  double vx,vy,va;      // desired position and angular velocity
                        // specified in mm/sec and rad/sec

  vector3d head_lookat;  // where look at for head (relative to front of body)
  double head_tilt_offset;  // tilt offset from head target
  double head_tilt; // only necessary if head_cmd==HEAD_ANGLES (should be rare)
  double head_pan;  // only necessary if head_cmd==HEAD_ANGLES (should be rare)
  double head_roll; // only necessary if head_cmd==HEAD_ANGLES (should be rare)

  short tail_pan;       // where to point tail in panning [-100,100]
  short tail_tilt;      // where to point tail in panning [-100,100]
  short mouth;          // mouth open fraction [0,100]
  unsigned short led;   // LED on state

  unsigned short sound_cmd;
  unsigned short sound_frequency;
  unsigned long  sound_duration;
  unsigned short sound_file;

/*
public:
  bool operator==(MotionCommand &mot) const
    {return(target_state == mot.target_state &&
            pos          == mot.pos &&
            heading      == mot.heading &&
            lookat       == mot.lookat &&
            led          == mot.led);}
*/
};

struct BodyAttitude{
  double height; // height of body at center
  double angle;  // angle of body (y axis)
  vector2d neck_offset;
};

struct MotionLocalizationUpdate{
  ulong timestamp;        // timestamp in microseconds
  short state_type,state; // Which motion 

  vector2d pos_delta;     // current position relative to (0,0) from previous
  vector2d heading_delta; // current heading relative to (1,0) from previous

  BodyAttitude body;      // current position of the body
  bool stable;            // whether or not current attitude is reliable
};

const int MotionLocalizationUpdateQueueBufferSize = 8;

// Motion Posiiton Feedback Queue
// gives MainObj access to the position of the body and camera relative to ground
struct MotionLocalizationUpdateQueue {
  MotionLocalizationUpdate buffer[MotionLocalizationUpdateQueueBufferSize];
};

} // namespace MotionInterface

#endif
// __MOTION_INTERFACE_H__
