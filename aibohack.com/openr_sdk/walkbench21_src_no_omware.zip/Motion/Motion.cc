/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#include "../headers/system_config.h"

#include <stdlib.h>
#include <stdio.h>
//#include <strings.h>
#include <iostream.h>

#include "../headers/DogTypes.h"
// #include "../headers/CircBufPacket.h"
#include "../headers/Geometry.h"
#include "../headers/FileSystem.h"
#include "../headers/Sensors.h"

#include "../Vision/VisionInterface.h"

#if 1 // ADDED
// HACKS:
#include "globals.h"
#endif

#include "Kinematics.h"
#include "Spline.h"
// #include "Path.h"
#include "MotionFile.h"

#include "Motion.h"


#ifndef PLATFORM_LINUX
extern SensorData sensor;
#endif

static const bool PrintChecksums=false;

// #define BOUND_MOTION


namespace Motion{

void Complete(BodyState &body)
/*
  You fill in either angles or a target (kinematic) position for the
  joints, and this function does the rest so that it can be sent to
  the robot's joint controller.
*/
{
  int attr,i;

  // legs
  for(i=0; i<4; i++){
    attr = body.leg[i].attr;
    if(!(attr & ATTR_ANGLES) && (attr & ATTR_POSITION)){
      GetLegAngles(body.leg[i].angles,body.leg[i].pos,body.pos,i);
      body.leg[i].attr |= ATTR_ANGLES;

      /*
      printf("%d (%8.2f %8.2f %8.2f)\n",i,
             body.leg[i].pos.x,
             body.leg[i].pos.y,
             body.leg[i].pos.z);
      */
    }
  }

  // head
  attr = body.head.attr;
  if(!(attr & ATTR_ANGLES) && (attr & ATTR_POSITION)){
    GetHeadAngles(body.head.angles,body.head.target,
                  body.pos.angle.y,body.pos.loc.z);
    body.head.attr |= ATTR_ANGLES;
  }
}

void Flip(BodyState &body)
/*
  This mirrors a body position right to left, which is useful for
  motion scripts that aren't symmetric since you don't have to make a
  left and right version of each one.
*/
{
  int i;

  // Flip legs
  swap(body.leg[0],body.leg[1]);
  swap(body.leg[2],body.leg[3]);
  for(i=0; i<4; i++){
    body.leg[i].pos.y = -body.leg[i].pos.y;
  }

  // Flip head
  body.head.target.y = -body.head.target.y;
  body.head.angles[1] = -body.head.angles[1]; // flip pan
  body.head.angles[2] = -body.head.angles[2]; // flip roll
}

void Interpolate(BodyState &body,BodyState &start,BodyState &target,double t)
/*
  This is the core of what the motion files use; it lets you
  interpolate with t=0..1 between two other positions.  If can be used
  for time interplolation (between keyframes like the motion files),
  or could be used to do weighted averages of multiple actions that
  requested a particular body state.
*/
{
  int attr,i,j;

  if(t <= 0.0){
    body = start;
    return;
  }

  if(t >= 1.0){
    body = target;
    return;
  }

  body.pos.loc   = start.pos.loc  *(1-t) + target.pos.loc  *t;
  body.pos.angle = start.pos.angle*(1-t) + target.pos.angle*t;

  // printf(".\n");

  // legs
  for(i=0; i<4; i++){
    attr = start.leg[i].attr & target.leg[i].attr;

    if(attr){
      if(attr & ATTR_POSITION){
        body.leg[i].pos = start.leg[i].pos*(1-t) + target.leg[i].pos*t;
        GetLegAngles(body.leg[i].angles,body.leg[i].pos,body.pos,i);
        attr |= ATTR_ANGLES;
      }else{
        for(j=0; j<3; j++){
          body.leg[i].angles[j] = start.leg[i].angles[j]*(1-t) +
                                  target.leg[i].angles[j]*t;
        }
      }

      body.leg[i].attr = attr;
    }else{
      pprintf(TextOutputStream,"Can't interpolate attr (%ld->%ld)\n",
              start.leg[i].attr,target.leg[i].attr);
    }
  }

  // head
  attr = start.head.attr & target.head.attr;
  // printf("interp attr=%d %ld %ld\n",attr,start.head.attr,target.head.attr);

  if(attr){
    if(attr & ATTR_POSITION){
      body.head.target = start.head.target*(1-t) + target.head.target*t;
      GetHeadAngles(body.head.angles,body.head.target,
                    body.pos.angle.y,body.pos.loc.z);
      attr |= ATTR_ANGLES;
    }else{
      for(j=0; j<3; j++){
        body.head.angles[j] = start.head.angles[j]*(1-t) +
                              target.head.angles[j]*t;
      }
    }

    body.head.attr = attr;
  } else {
    body.head.attr = 0;
  }
}

#ifndef PLATFORM_APERIOS
template <class data>
void DeleteRegion(data *arr)
{
  delete[] arr;
}

#define sSUCCESS 1
#define sERROR   0
typedef int sError;

sError NewRegion(int size,void **ptr)
{
  void *mem = new char[size];
  if(mem){
    *ptr = mem;
    return(sSUCCESS);
  }else{
    return(sERROR);
  }
}
#endif

unsigned long checksum(char *data,int num)
{
  unsigned long c;
  int i;

  c = 0;
  for(i=0; i<num; i++){
    c = c ^ (data[i]*13 + 37);
    c = (c << 13) | (c >> 19);
  }

  return(c);
}

template <class data>
int read_file(data *arr,int num,char *filename)
{
  char name[256];
  int fd;
  // HFS::FILE *in;
  int n;

  if(linux){
    sprintf(name,"%s",filename);
  }else{
    sprintf(name,"/MS/motion/%s",filename);
  }

  fd = BFS::open(name,BFS_O_RDONLY);
  if(fd < 0) return(0);
  n = BFS::read(fd,arr,sizeof(data)*num);
  // pprintf(TextOutputStream,"read_file: %d of %d\n",n,sizeof(data)*num);
  n /= sizeof(data);
  BFS::close(fd);

  return(n);
}

//====================================================================//
//  Motion Player Class
//====================================================================//

bool MotPlayer::load(char *filename)
{
  char name[256];
  HFS::FILE *in;
  int i,num;

  if(linux){
    sprintf(name,"%s",filename);
  }else{
    sprintf(name,"/MS/motion/%s",filename);
  }

  in = HFS::fopen(name,"rb");
  if(!in) return(false);

  num = 0;
  HFS::fread(&num,sizeof(int),1,in);
  if(num<=0 || num>=64) return(false);

  if(false){
    if(frame) delete(frame);
    frame = new BodyStateMotion[num];
  }else{
    if(frame) DeleteRegion(frame);
    frame = NULL;
    NewRegion(sizeof(BodyStateMotion)*num,reinterpret_cast<void**>(&frame));
  }
  if(!frame) return(false);

  HFS::fread(frame,sizeof(BodyStateMotion),num,in);
  HFS::fclose(in);

  num_frames = num;
  current_frame = 0;
  base_time = 0;

  for(i=0; i<num; i++){
    Complete(frame[i].body);
  }

  speed = 0;
  flip = false;

  if(PrintChecksums) {
    pprintf(TextOutputStream,"Loaded Motion '%s'\t frames=%d checksum=0x%X\n",
	    filename,num_frames,
	    checksum((char*)frame,sizeof(BodyStateMotion)*num));
  }

  return(true);
}

void MotPlayer::close()
{
  if(frame) DeleteRegion(frame);

  frame = NULL;
  num_frames = 0;
  current_frame = 0;
  base_time = 0;
}

void MotPlayer::play(BodyState &body,int time,double nspeed,bool flip_lr)
{
  current_frame = 0;
  base_time = time;
  speed = nspeed;
  flip = flip_lr;
  if(frame){
    frame[0].body = body;
    Complete(frame[0].body);
    if(flip) Flip(frame[0].body);
  }
}

int MotPlayer::get(BodyState &body,int time)
{
  int dt,len;
  int busy;

  if(time<base_time || !frame) return(0);

  dt  = time - base_time;
  len = frame[current_frame].time;

  while(current_frame<num_frames-1 && dt>len){
    current_frame++;
    base_time += len;
    dt = time - base_time;
    len = frame[current_frame].time;
  }

  if(current_frame < num_frames-1){
    Interpolate(body,
                frame[current_frame].body,
                frame[current_frame + 1].body,
                ((double)dt) / len);
    // printf("frame=%d t=%f\n",current_frame,((double)dt) / len);
    if(flip) Flip(body);
    busy = LEGS_BUSY;
    if(body.head.attr) busy |= HEAD_BUSY;
    return(busy);
  }else{
    body = frame[num_frames - 1].body;
    if(flip) Flip(body);
    return(0);
  }
}


//====================================================================//
//  Stand Class
//====================================================================//

Stand::Stand()
{
  time = 0;
  length = TimeStep;
}

void Stand::init()
{
  BodyState b;
  int i;

  time = length = 0;

  // Neutral
  for(i=0; i<4; i++) b.leg[i].attr = ATTR_POSITION;
  b.head.attr = 0;

  b.leg[0].pos.set(120, 85,0);
  b.leg[1].pos.set(120,-85,0);
  b.leg[2].pos.set(-90, 77,0);
  b.leg[3].pos.set(-90,-77,0);

  set3(b.head.angles,0.0,0.0,0.0);
  b.pos.loc.set(0,0,105.0);
  b.pos.angle.set(0,RAD(12.0),0);

  neutral = b;

  // Crouch
  for(i=0; i<4; i++) b.leg[i].attr = ATTR_POSITION;
  b.head.attr = 0;

  b.leg[0].pos.set(105, 130,0);
  b.leg[1].pos.set(105,-130,0);
  b.leg[2].pos.set(-70,  75,0);
  b.leg[3].pos.set(-70, -75,0);

#if 0
  // original
  set3(b.head.angles,0.0,0.0,0.0);
#else
  // raise head at start
  set3(b.head.angles,90.0,0.0,0.0);
#endif
  b.pos.loc.set(0,0,100.0);
  b.pos.angle.set(0,RAD(17.5),0);

  crouch = b;
}

void Stand::setTarget(BodyState &body,BodyState &ntarget,int ntime)
{
  start  = body;
  target = ntarget;
  time   = 0;
  length = max(ntime,TimeStep);

  Complete(start);
  Complete(target);
}

void Stand::setTarget(BodyState &body,int target,int ntime)
{
  BodyState b;

  switch(target){
    case MOTION_STAND_NEUTRAL:
      b = neutral;
      setTarget(body,b,ntime);
      break;
    case MOTION_STAND_CROUCH:
      b = crouch;
      setTarget(body,b,ntime);
      break;
    default:
      b = neutral;
      setTarget(body,b,ntime);
  }
}

int Stand::getAngles(BodyState &current,BodyState &next)
{
  double t;
  int busy;

  if(time < length){
    // Calculate current position
    t = min((double)time / length,1.0);
    Interpolate(next,start,target,t);

    busy = LEGS_BUSY;
    if(next.head.attr) busy |= HEAD_BUSY;
  }else{
    next = target;
    busy = 0;
  }

  // move time ahead
  time += TimeStep;

  return(busy);
}

void Stand::getMotionUpdate(MotionLocalizationUpdate &update)
{
}

int Stand::areBusy()
{
  int busy = 0;

  if(time < length){
    busy |= LEGS_BUSY;
    if(start.head.attr & target.head.attr) busy |= HEAD_BUSY;
  }

  return(busy);
}

//====================================================================//
//  Trotting Class
//====================================================================//

const vector3d zero(0,0,0);
const vector3d one(1,0,0);


Trot::Trot()
{
  memset(this,0,sizeof(this));

  body_loc.init(zero,zero);
  body_angle.init(zero,zero);

  cur_cycle = cycle_offset = 0.0;
}

void Trot::load()
{
  int n;

  mzero(wp_xy);
  n = read_file(&wp_xy,1,"walk_xy.prm");
  if(PrintChecksums) {
    pprintf(TextOutputStream,"Loaded XY Trot Paramaters n=%d checksum=0x%X\n",n,
	    checksum((char*)&wp_xy,sizeof(wp_xy)));
  }

  mzero(wp_a);
  n = read_file(&wp_a,1,"walk_a.prm");
  if(PrintChecksums) {
    pprintf(TextOutputStream,"Loaded A Trot Paramaters n=%d checksum=0x%X\n",n,
	    checksum((char*)&wp_a,sizeof(wp_a)));
  }
  
  mzero(wp_d);
  n = read_file(&wp_d,1,"walk_d.prm");
  if(PrintChecksums) {
    pprintf(TextOutputStream,"Loaded D Trot Paramaters n=%d checksum=0x%X\n",n,
	    checksum((char*)&wp_d,sizeof(wp_d)));
  }
  
  wp = wp_xy;
}

void Trot::evalPosition(BodyPosition &bp,int time)
{
  double t;

  t = time / 1000.0;

  bp.loc = body_loc.eval(t);
  bp.angle = body_angle.eval(t);

  bp.angle.y = wp.body_angle;

#ifdef PLATFORM_LINUX
  /*
  printf("Body: l:(%f,%f,%f) a:(%f,%f,%f) t=%d\n",
         bp.loc.x,bp.loc.y,bp.loc.z,
         bp.angle.x,bp.angle.y,bp.angle.z,
         time);
  */
#endif
}

vector3d Trot::projectPosition(BodyPosition &bp,vector3d pos)
{
  vector3d p;
  p = pos.rotate_z(bp.angle.z).rotate_y(bp.angle.y) + bp.loc;
  return(p);
}


void Trot::init(int walk_type)
{
  vector3d body,angle;
  int i;

  type = walk_type;

  time = 0;
  chooseParam(0.0, 0.0, 0.0);

  body.set(0,0,wp.body_height);
  angle.set(0,wp.body_angle,0);

  body_loc.init(body,zero);
  body_angle.init(angle,zero);

  wpos.loc = body;
  wpos.angle = angle;

  for(i=0; i<4; i++){
    legw[i].air = false;
  }

  target_vel_xya.set(0,0,0);
  vel_xya.set(0,0,0);

  pos_delta.set(0,0,0);
  angle_delta = 0.0;

  cur_cycle = cycle_offset = 0.0;
  // printf("Init\n");
}


void Trot::chooseParam(double dx,double dy,double da)
{

  // pprintf(TextOutputStream,"Chooseparam(%f,%f,%f)\n\n",dx, dy, da );

  double new_cycle;
  int sgn;
  if(da >= 0.0)
    sgn = 1;
  else
    sgn = -1;
  
  if(type == MOTION_WALK_DRIBBLE){
    wp = wp_d;
  }
  else if(fabs(da) > 1.0 && fabs(dx) < 50 && fabs(dy) < 50)
    wp = wp_a;
  else
    wp = wp_xy;
  
/****************************/



  // choose a cycle offset so that the walk is continuous
  new_cycle = frac((double)time / max(wp.period,(long)1));
  cycle_offset = frac(cur_cycle - new_cycle + 1);

/*
#ifdef PLATFORM_LINUX
  printf("DING(%d,%d)(%f,%f,%f)\n",
         time,wp.period,
         cur_cycle,new_cycle,cycle_offset);
#endif
*/

}

void Trot::setTarget(double dx,double dy,double da,
                     double accel_time,bool nobound)
{
  double fa,f,l;
  vector2d v;

  if(!nobound){
    da = bound(da, -MAX_DA, MAX_DA);
    fa = 1.0 - fabs(da / MAX_DA);
    v.set(dx / MAX_DX,dy / MAX_DY);

    l = v.length();
    f = (l < fa)? 1.0 : fa / (l + 1E-10);

    // printf("f=%f l=%f fa=%f v(%f,%f)\n",f,l,fa,v.x,v.y);

    dx = MAX_DX * f * v.x;
    dy = MAX_DY * f * v.y;
  }

  target_vel_xya.set(dx,dy,da);
  // printf("xya(%f,%f,%f)\n",dx,dy,da);
}

int Trot::getAngles(BodyState &current,BodyState &next)
{
  int i;
  bool air;
  double cycle;
  BodyPosition nwpos,delta;
  vector3d target,vfp;
  LegWalkState *l;
  double t,air_f,b,vfa;
  double height,hop,sway;
  double accel_mult;
  
  /*
  evalPosition(nwpos,time + TimeStep);
  delta.loc   = nwpos.loc   - wpos.loc;
  delta.angle = nwpos.angle - wpos.angle;
  */

  vector3d max_accel_xya(MAX_DX,MAX_DY,MAX_DA); // * 2

  t = TimeStep / 1000.0;
  // cycle = (double)(time % wp.period) / wp.period;
  cycle = frac(cycle_offset + (double)time / wp.period);
  cur_cycle = cycle;
  // printf("%f\n",cycle);
  
  
  if( fabs(target_vel_xya.x - vel_xya.x) > 150 ){
    accel_mult = .8;
  }else{
    accel_mult = (cos(cycle*4*M_PI)+1);
  }
  max_accel_xya *= accel_mult;
  
  //pprintf(TextOutputStream,"vel_xya (%f,%f,%f)\n",V3COMP(vel_xya));
  //pprintf(TextOutputStream,"target_vel_xya (%f,%f,%f)\n\n",V3COMP(target_vel_xya));
  //pprintf(TextOutputStream,"accel (%f,%f,%f)\n",V3COMP(max_accel_xya));
  
  vel_xya.x = bound(target_vel_xya.x,
                    vel_xya.x-max_accel_xya.x*t,
                    vel_xya.x+max_accel_xya.x*t);
  vel_xya.y = bound(target_vel_xya.y,
                    vel_xya.y-max_accel_xya.y*t,
                    vel_xya.y+max_accel_xya.y*t);
  vel_xya.z = bound(target_vel_xya.z,
                    vel_xya.z-max_accel_xya.z*t,
                    vel_xya.z+max_accel_xya.z*t);

  delta.loc.set(vel_xya.x*t,vel_xya.y*t,0);
  delta.angle.set(0,0,vel_xya.z*t);

  target_vel_xya.rotate_z(-delta.angle.z);


#ifdef PLATFORM_LINUX
  /*
  printf("v=(%f,%f,%f)  dloc = (%f,%f,%f) (%f,%f,%f)-(%f,%f,%f)\n",
         V3COMP(vel_xya),
         V3COMP(delta.loc),
         V3COMP(nwpos.loc),
         V3COMP(wpos.loc));
  */

  /*
  printf("dangle = (%f,%f,%f)\n",
         delta.angle.x,
         delta.angle.y,
         delta.angle.z);
  */
#endif

  // incorporate movement delta
  angle_delta += delta.angle.z;
  pos_delta += delta.loc.rotate_z(angle_delta);


  // if a new cycle is beginning, can choose new walk parameters
  if(((time) % wp.period) <
     ((time + wp.period - TimeStep) % wp.period)){

    chooseParam(delta.loc.x*1000.0/TimeStep,
                delta.loc.y*1000.0/TimeStep,
                delta.angle.z*1000.0/TimeStep);
  }

  for(i=0; i<4; i++){
    l = &legw[i];
    air = (cycle >= wp.leg[i].lift_time) && (cycle < wp.leg[i].down_time);
    air_f = wp.leg[i].down_time - wp.leg[i].lift_time;

    if(air != legw[i].air){
      if(air){
        t = wp.period/1000.0 * 0.75;
        vfp.x = bound(target_vel_xya.x,
                      vel_xya.x-max_accel_xya.x*t,
                      vel_xya.x+max_accel_xya.x*t);
        vfp.y = bound(target_vel_xya.y,
                      vel_xya.y-max_accel_xya.y*t,
                      vel_xya.y+max_accel_xya.y*t);
        vfp.z = 0.0;
        vfa   = bound(target_vel_xya.z,
                      vel_xya.z-max_accel_xya.z*t,
                      vel_xya.z+max_accel_xya.z*t);
        b = (wp.period/1000.0) * (1.0 - air_f) / 2.0;
        target = wp.leg[i].neutral + vfp*b;
        target = target.rotate_z(vfa*b);

        /*
        printf("targetf=(%f,%f,%f) vfp(%f,%f,%f) vfa=%f t=%f b=%f\n",
               V3COMP(target),V3COMP(vfp),vfa,t,b);
        */

        /*
        t = ((wp.period/2)/TimeStep * (1.0-air_f));
        target = wp.leg[i].neutral + delta.loc*t;
        target = target.rotate_z(delta.angle.z*t);
        printf("targetd=(%f,%f,%f)\n",V3COMP(target));
        */

        l->airpath.create(current.leg[i].pos,target,
                          wp.leg[i].lift_vel,wp.leg[i].down_vel);
        // l->pos = target = wp.leg[i].neutral + wp.leg[i].lift_vel;

#ifdef PLATFORM_LINUX
        /*
        printf("Lift: (%g,%g,%g)->(%g,%g,%g)\n",
               l->pos.x,l->pos.y,l->pos.z,
               target.x,target.y,target.z);
        */
#endif
      }else{
        current.leg[i].pos.z = 0.0;
      }
      l->air = air;
    }

    if(air){
      t = (cycle - wp.leg[i].lift_time) / air_f;
      next.leg[i].pos = l->airpath.eval(t);
      //limit how high the legs are allowed to lift up
      if(i <= 1 )
	next.leg[i].pos.z = min(next.leg[i].pos.z, wp.front_height); 
      else
	next.leg[i].pos.z = min(next.leg[i].pos.z, wp.back_height);
	
    }else{
      next.leg[i].pos = (current.leg[i].pos - delta.loc).rotate_z(-delta.angle.z);
    }
    next.leg[i].attr = ATTR_POSITION;
  }

  sway   = wp.sway*cos(2*M_PI*cycle);
  hop    = wp.hop*sin(4*M_PI*cycle);
  height = wp.body_height;
  next.pos.loc.set(0,-sway,height+hop);
  // next.pos.angle.set(0,wp.body_angle-RAD(6)*fabs(vel_xya.y/MAX_DY),0);
  next.pos.angle.set(0,wp.body_angle,0);
  Complete(next);

  /*
#ifdef PLATFORM_LINUX
  for(i=0; i<4; i++){
    printf("  Leg %d: a(%d) p:(%f,%f,%f) angles=(%f,%f,%f)\n",
           i,leg[i].air,pos[i].x,pos[i].y,pos[i].z,
           angles[3*i+0],angles[3*i+1],angles[3*i+2]);
  }
#endif
  */

  time += TimeStep;
  wpos = nwpos;

  return(LEGS_BUSY);
}

void Trot::getMotionUpdate(MotionLocalizationUpdate &update)
{
  vector2d x;

  x.set(1,0);
  update.pos_delta.set(pos_delta.x,pos_delta.y);
  update.heading_delta = x.rotate(angle_delta);

  pos_delta.set(0,0,0);
  angle_delta = 0;
}

int Trot::areBusy()
{
  return(LEGS_BUSY);
}

//====================================================================//
//  Getup Class
//====================================================================//

Getup::Getup()
{
  type = time = busy = 0;
}

void Getup::load()
{
  m_front.load("gu_front.mot");
  m_back .load("gu_back.mot" );
  m_side .load("gu_side.mot" );
}

void Getup::init(int getup_type)
{
  type = getup_type;
  time = 0;
  busy = LEGS_BUSY|HEAD_BUSY;
}

int Getup::getAngles(BodyState &current,BodyState &next)
{
  if(time == 0){
    switch(type){
      case MOTION_GETUP_FRONT: m_front.play(current,time,1,false); break;
      case MOTION_GETUP_BACK:  m_back.play(current,time,1,false);  break;
      case MOTION_GETUP_LEFT:  m_side.play(current,time,1,false);  break;
      case MOTION_GETUP_RIGHT: m_side.play(current,time,1,true);   break;
    }
    time += TimeStep;
  }

  switch(type){
    case MOTION_GETUP_FRONT: busy = m_front.get(next,time); break;
    case MOTION_GETUP_BACK:  busy = m_back.get(next,time);  break;
    case MOTION_GETUP_LEFT:  busy = m_side.get(next,time);  break;
    case MOTION_GETUP_RIGHT: busy = m_side.get(next,time); break;
  }

  time += TimeStep;
  return(busy);
}

int Getup::areBusy()
{
  return(busy);
}

void Getup::getMotionUpdate(MotionLocalizationUpdate &update)
{
  update.stable = false;
}

//====================================================================//
//  Kick Class
//====================================================================//

Kick::Kick()
{
  type = time = busy = 0;
}

void Kick::load()
{
  m_dive .load("k_dive.mot" );
  m_bump .load("k_bump.mot" );
  m_fwd  .load("k_fwd.mot"  );
  m_head .load("k_head.mot" );
  m_heads.load("k_heads.mot");
  m_hold .load("k_hold.mot" );
  m_dance.load("dance.mot");
}

void Kick::init(int kick_type)
{
  // printf("KICK %d!\n",kick_type);
  type = kick_type;
  time = 0;
  busy = LEGS_BUSY|HEAD_BUSY|TARGET_BUSY;
}

int Kick::getAngles(BodyState &current,BodyState &next)
{
  if(time == 0){
    switch(type){
      case MOTION_KICK_DIVE:         m_dive.play(current,time,1,false);  break;
      case MOTION_KICK_HOLD:         m_hold.play(current,time,1,false);  break;
      case MOTION_KICK_DIVE_L:       m_dive.play(current,time,1,false);  break;
      case MOTION_KICK_DIVE_R:       m_dive.play(current,time,1,true);   break;
      case MOTION_KICK_BUMP:         m_bump.play(current,time,1,false);  break;
      case MOTION_KICK_FOREWARD:     m_fwd.play(current,time,1,false);   break;
      case MOTION_KICK_HEAD_L:       m_head.play(current,time,1,false);  break;
      case MOTION_KICK_HEAD_R:       m_head.play(current,time,1, true);  break;
      case MOTION_KICK_HEAD_SOFT_L:  m_heads.play(current,time,1,false); break;
      case MOTION_KICK_HEAD_SOFT_R:  m_heads.play(current,time,1, true); break;
      case MOTION_DANCE:             m_dance.play(current,time,1, false);break;
    }
    time += TimeStep;
  }

  switch(type){
    case MOTION_KICK_DIVE:         busy = m_dive.get(next,time);  break;
    case MOTION_KICK_HOLD:         busy = m_hold.get(next,time);  break;
    case MOTION_KICK_DIVE_L:       busy = m_dive.get(next,time);  break;
    case MOTION_KICK_DIVE_R:       busy = m_dive.get(next,time);  break;
    case MOTION_KICK_BUMP:         busy = m_bump.get(next,time);  break;
    case MOTION_KICK_FOREWARD:     busy = m_fwd.get(next,time);   break;
    case MOTION_KICK_HEAD_L:       busy = m_head.get(next,time);  break;
    case MOTION_KICK_HEAD_R:       busy = m_head.get(next,time);  break;
    case MOTION_KICK_HEAD_SOFT_L:  busy = m_heads.get(next,time); break;
    case MOTION_KICK_HEAD_SOFT_R:  busy = m_heads.get(next,time); break;
    case MOTION_DANCE:             busy = m_dance.get(next,time); break;
  }
  if(busy) busy |= TARGET_BUSY;

  time += TimeStep;
  return(busy);
}

int Kick::areBusy()
{
  return(busy);
}

void Kick::getMotionUpdate(MotionLocalizationUpdate &update)
{
  update.stable = false;
}

//====================================================================//
//  Motion Class
//====================================================================//

Motion::Motion()
{
  // start with a clean slate
  mzero(*this);

  state = MOTION_STAND_NEUTRAL;

  stand.init();
  trot.init(cmd.motion_cmd);
#ifdef REMOVED
  sound.init();
#endif

  // Set up initial command
  // memset(&cmd,0,sizeof(cmd));
  // memset(&body,0,sizeof(body));
  LED_state = LED_ALL;

  // Initial body orienation (lying down)
  body.pos.loc.set(0,0,60.0);
  body.pos.angle.set(0,0,0);

  time = 0;
  new_cmd = false;
  
  // enable = false;
}

void Motion::init()
{
  int i;

  for(i=0; i<4; i++) body.leg[i].attr = ATTR_ANGLES;
  body.head.attr = ATTR_ANGLES;

  set3(body.leg[0].angles, 1.2, 0.0, 0.5);
  set3(body.leg[1].angles, 1.2, 0.0, 0.5);
  set3(body.leg[2].angles,-0.5, 0.0, 2.6);
  set3(body.leg[3].angles,-0.5, 0.0, 2.6);
  set3(body.head.angles,   0.0, 0.0, 0.0);

  body.pos.loc.set(0,0,60.0);
  body.pos.angle.set(0,0,0);

  cmd.motion_cmd = MOTION_STAND_NEUTRAL;
  state = MOTION_STAND_NEUTRAL;
  top_state = MOTION_STATE(state);
}

void Motion::init(double *angles)
{
  int i;

  // Load params
  trot.load();
  getup.load();
  kick.load();
#ifdef REMOVED
  sound.load();
#endif

  if(angles){
    for(i=0; i<4; i++){
      body.leg[i].attr = ATTR_ANGLES;
      mcopy(body.leg[i].angles,&angles[3*i],3);
    }

    body.head.attr = ATTR_ANGLES;
    mcopy(body.head.angles,&angles[12],3);
  }

  stand.setTarget(body,MOTION_STAND_NEUTRAL,4000);
}

//void Motion::toggle()
  //{
  // enable = !enable;
//}

void Motion::setCommand(MotionCommand &ncmd)
{
#ifdef REMOVED
  sound.setCommand(ncmd);
#endif

  cmd = ncmd;
  LED_state = cmd.led;

  //if(!enable && MOTION_STATE(cmd.motion_cmd)!=STATE_GETUP){
  //  cmd.motion_cmd = MOTION_STAND_NEUTRAL;
  //}

  new_cmd = true;
}

void Motion::getAngles(double *angles)
{
  BodyState next;
  double a,da;
  int busy;
  int i;
  int cmd_top_state;

  next = body;
  busy = 0;

  top_state = MOTION_STATE(state);
  // printf("state=%d:%d  ",state,top_state);
  switch(top_state){
    case STATE_STANDING:
      busy = stand.getAngles(body,next);
      break;

    case STATE_WALKING:
      busy = trot.getAngles(body,next);
      busy = 0;
      break;

    case STATE_KICKING:
      busy = kick.getAngles(body,next);
      if(!busy){
        state = MOTION_STAND_NEUTRAL;
        stand.setTarget(body,state,200);
        busy = stand.getAngles(body,next);
      }
      break;

    case STATE_GETUP:
      busy = getup.getAngles(body,next);
      if(!busy){
        state = MOTION_STAND_NEUTRAL;
        stand.setTarget(body,state,500);
        busy = stand.getAngles(body,next);
      }
      break;
  }

  cmd_top_state = MOTION_STATE(cmd.motion_cmd);
  // printf("cmd=%d ctstate=%d\n",cmd.motion_cmd,cmd_top_state);
  switch(cmd_top_state){
    case STATE_STANDING:
      if(cmd.motion_cmd!=state &&
         (!busy || (top_state==STATE_WALKING || top_state==STATE_STANDING))){
        stand.setTarget(body,cmd.motion_cmd,300);
        state = cmd.motion_cmd;
      }
      break;

    case STATE_WALKING:
      if(!busy && cmd.motion_cmd!=state){
	// trot.init();
	trot.init(cmd.motion_cmd);
        state = cmd.motion_cmd;
        new_cmd = true;
      }
      if(new_cmd && state==cmd.motion_cmd){
        // printf("SetTarget(%f,%f,%f)\n",cmd.vx,cmd.vy,cmd.va);
        trot.setTarget(cmd.vx,cmd.vy,cmd.va,1.5,cmd.nobound);
        new_cmd = false;
      }
      break;

    case STATE_KICKING:
      if(!busy || top_state==STATE_WALKING){
        kick.init(cmd.motion_cmd);
        state = cmd.motion_cmd;

#if 1
        cmd.motion_cmd = MOTION_STAND_NEUTRAL; // ADDED!
            // prevents repeating the same motion
            // REVIEW: no motion complete logic
#endif
      }
      break;

    case STATE_GETUP:
      if(cmd.motion_cmd!=state &&
         !(busy && (top_state==STATE_GETUP ||
                    top_state==STATE_STANDING ||
                    top_state==STATE_KICKING))){
        getup.init(cmd.motion_cmd);
        state = cmd.motion_cmd;
      }
      break;
  }
  top_state = MOTION_STATE(state);

  // pprintf(TextOutputStream,"state=%d busy=%d cmd=%d hcmd=%d\n",
  //         state,busy,cmd.motion_cmd,cmd.head_cmd);

  // Set head
  if(!(busy & HEAD_BUSY)){
    switch(cmd.head_cmd){
      case HEAD_LOOKAT:
        next.head.attr = ATTR_POSITION;
        next.head.target = cmd.head_lookat;
        break;
      case HEAD_ANGLES:
        next.head.attr = ATTR_ANGLES;
        set3(next.head.angles,
             bound(cmd.head_tilt,head_tilt_min,head_tilt_max),
             bound(cmd.head_pan ,head_pan_min ,head_pan_max ),
             bound(cmd.head_roll,head_roll_min,head_roll_max));
        break;
      case HEAD_SCAN_BALL:
      case HEAD_SCAN_BALL_TURN:
        da = (top_state == STATE_WALKING)? trot.velocity().z : 0.0;

        if(fabs(da) < 0.5){
          next.head.attr = ATTR_ANGLES;
          a = (time / 2000.0) * 2*M_PI;
          set3(next.head.angles,
               body.pos.angle.y - RAD(20) +
               min(cos(a)*VisionInterface::VertFOV,0.0),
               1.4*sin(a),0.0);
        }else{
          next.head.attr = ATTR_ANGLES;
          set3(next.head.angles,
               RAD(-90)+body.pos.angle.y,
               RAD( 70)*sign(da),
               0.0);
        }
        break;
      case HEAD_SCAN_DRIBBLE:
        next.head.attr = ATTR_ANGLES;
        a = (time / 1000.0) * 2*M_PI;
        set3(next.head.angles,body.pos.angle.y-0.40,1.0*sin(a),0.0);
        break;
      case HEAD_SCAN_MARKERS:
        next.head.attr = ATTR_ANGLES;
        a = (time / 2500.0) * 2*M_PI;
        set3(next.head.angles,body.pos.angle.y,1.4*sin(a),0.0);
        break;
    }
  }

  // update body state and bound tilt speed
  Complete(next);

  // add in head tilt offset
  // body.head.angles[0] += cmd.head_tilt_offset;

  // bound tilt speed
  a = bound(next.head.angles[0],
            body.head.angles[0]-0.05,
            body.head.angles[0]+0.05);
  body = next;
  body.head.angles[0] = a;

  // extract angles
  for(i=0; i<4; i++){
    mcopy(&angles[3*i],body.leg[i].angles,3);
  }
  mcopy(&angles[12],body.head.angles,3);

  // Set tail
  switch(cmd.tail_cmd) {
    case TAIL_AIM:
      angles[15] = bound(RAD((cmd.tail_pan *22)/100),tail_min,tail_max);
      angles[16] = bound(RAD((cmd.tail_tilt*22)/100),tail_min,tail_max);
      break;
    case TAIL_FOLLOW:
#ifdef PLATFORM_APERIOS
      angles[15] = bound(sensor.tailAngles[0],tail_min,tail_max);
      angles[16] = bound(sensor.tailAngles[1],tail_min,tail_max);
#endif
      break;
  }

  // Set mouth
  angles[17] = RAD(bound((-cmd.mouth*50)/100,-50,0));

  // blink top LED to indicate when new commands have been recieved
  if(new_cmd){
    LED_state |= LED_TOP; // on
    new_cmd = false;
  }else{
    LED_state &= ~LED_TOP; // off
  }

  time += TimeStep;
}

void Motion::getMotionUpdate(MotionLocalizationUpdate &update,ulong time)
{
  update.timestamp  = time;
  // update.state_type = (enable)? top_state : STATE_WAITING;
  update.state_type = top_state;
  update.state      = state;

  update.pos_delta.set(0,0);
  update.heading_delta.set(0,0);
  update.body.height = body.pos.loc.z;
  update.body.angle  = body.pos.angle.y;
  update.body.neck_offset.set(::body_to_neck.x*cos(body.pos.angle.y),0);
  update.stable      = true;

  switch(top_state){
    case STATE_GETUP:
      getup.getMotionUpdate(update);
      break;

    case STATE_STANDING:
      stand.getMotionUpdate(update);
      break;

    case STATE_WALKING:
      trot.getMotionUpdate(update);
      break;

    case STATE_KICKING:
      kick.getMotionUpdate(update);
      break;
  }

  // body = update.body;
}

} // Namespace
