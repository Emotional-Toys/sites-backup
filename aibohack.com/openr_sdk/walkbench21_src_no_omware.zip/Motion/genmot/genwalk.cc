/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#include "genmot.h"


void make_walk_param()
{
  Motion::WalkParam wp;
  FILE *out;

  // Development trot (mda=1.3)
  wp.leg[0].neutral.set( 120, 80,0);
  wp.leg[1].neutral.set( 120,-80,0);
  wp.leg[2].neutral.set( -90, 70,0);
  wp.leg[3].neutral.set( -90,-70,0);
  wp.period = 670;

  wp.leg[0].lift_vel.set(0,0, 100);
  wp.leg[1].lift_vel.set(0,0, 100);
  wp.leg[2].lift_vel.set(0,0, 200);
  wp.leg[3].lift_vel.set(0,0, 200);

  wp.leg[0].down_vel.set(0,0,-100);
  wp.leg[1].down_vel.set(0,0,-100);
  wp.leg[2].down_vel.set(0,0,-100);
  wp.leg[3].down_vel.set(0,0,-100);

  wp.leg[0].lift_time=0.0000; wp.leg[0].down_time=0.5000;
  wp.leg[1].lift_time=0.5000; wp.leg[1].down_time=1.0000;
  wp.leg[2].lift_time=0.5000; wp.leg[2].down_time=1.0000;
  wp.leg[3].lift_time=0.0000; wp.leg[3].down_time=0.5000;

  wp.body_angle  = RAD(12.0);
  wp.body_height = 105;
  wp.hop  = 0;
  wp.sway = 0;

  out = fopen("walk_xy.prm","wb");
  if(out){
    fwrite(&wp,sizeof(wp),1,out);
    fclose(out);
  }


  wp.leg[0].neutral.set( 120, 85,0);
  wp.leg[1].neutral.set( 120,-85,0);
  wp.leg[2].neutral.set( -85, 77,0);
  wp.leg[3].neutral.set( -85,-77,0);
  wp.period = 550;

  wp.leg[0].lift_vel.set(0,0, 100);
  wp.leg[1].lift_vel.set(0,0, 100);
  wp.leg[2].lift_vel.set(0,0, 200);
  wp.leg[3].lift_vel.set(0,0, 200);

  wp.leg[0].down_vel.set(0,0,-80);
  wp.leg[1].down_vel.set(0,0,-80);
  wp.leg[2].down_vel.set(0,0,-80);
  wp.leg[3].down_vel.set(0,0,-80);

  wp.leg[0].lift_time=0.0000; wp.leg[0].down_time=0.5000;
  wp.leg[1].lift_time=0.5000; wp.leg[1].down_time=1.0000;
  wp.leg[2].lift_time=0.5000; wp.leg[2].down_time=1.0000;
  wp.leg[3].lift_time=0.0000; wp.leg[3].down_time=0.5000;

  wp.body_angle  = RAD(12.0);
  wp.body_height = 105;
  wp.hop  = 0;
  wp.sway = 0;

  out = fopen("walk_a.prm","wb");
  if(out){
    fwrite(&wp,sizeof(wp),1,out);
    fclose(out);
  }

  /*
  wp.leg[0].neutral.set( 115, 75,0);
  wp.leg[1].neutral.set( 115,-75,0);
  wp.leg[2].neutral.set( -75, 65,0);
  wp.leg[3].neutral.set( -75,-65,0);
  wp.period = 600;

  wp.leg[0].lift_vel.set(0,0, 100);
  wp.leg[1].lift_vel.set(0,0, 100);
  wp.leg[2].lift_vel.set(0,0, 100);
  wp.leg[3].lift_vel.set(0,0, 100);

  wp.leg[0].down_vel.set(0,0, -80);
  wp.leg[1].down_vel.set(0,0, -80);
  wp.leg[2].down_vel.set(0,0, -80);
  wp.leg[3].down_vel.set(0,0, -80);

  wp.leg[0].lift_time=0.0000; wp.leg[0].down_time=0.5000;
  wp.leg[1].lift_time=0.5000; wp.leg[1].down_time=1.0000;
  wp.leg[2].lift_time=0.5000; wp.leg[2].down_time=1.0000;
  wp.leg[3].lift_time=0.0000; wp.leg[3].down_time=0.5000;

  wp.body_angle  = RAD(12.0);
  wp.body_height = 110;
  wp.hop  = 0;
  wp.sway = 0;
  */

  /*
  // Development trot
  wp.leg[0].neutral.set( 123, 85,0);
  wp.leg[1].neutral.set( 123,-85,0);
  wp.leg[2].neutral.set( -80, 75,0);
  wp.leg[3].neutral.set( -80,-75,0);
  wp.period = 600;

  wp.leg[0].lift_vel.set(0,0, 100);
  wp.leg[1].lift_vel.set(0,0, 100);
  wp.leg[2].lift_vel.set(0,0, 200);
  wp.leg[3].lift_vel.set(0,0, 200);

  wp.leg[0].down_vel.set(0,0, -80);
  wp.leg[1].down_vel.set(0,0, -80);
  wp.leg[2].down_vel.set(0,0,-100);
  wp.leg[3].down_vel.set(0,0,-100);

  wp.leg[0].lift_time=0.0000; wp.leg[0].down_time=0.5000;
  wp.leg[1].lift_time=0.5000; wp.leg[1].down_time=1.0000;
  wp.leg[2].lift_time=0.5000; wp.leg[2].down_time=1.0000;
  wp.leg[3].lift_time=0.0000; wp.leg[3].down_time=0.5000;

  wp.body_angle  = RAD(12.0);
  wp.body_height = 105;
  wp.hop  = 0;
  wp.sway = 0;
  */

  /*
  // Trot used in 2001 competition
  wp.leg[0].neutral.set( 123, 85,0);
  wp.leg[1].neutral.set( 123,-85,0);
  wp.leg[2].neutral.set( -80, 75,0);
  wp.leg[3].neutral.set( -80,-75,0);
  wp.period = 500;

  wp.leg[0].lift_vel.set(0,0, 100);
  wp.leg[1].lift_vel.set(0,0, 100);
  wp.leg[2].lift_vel.set(0,0, 200);
  wp.leg[3].lift_vel.set(0,0, 200);

  wp.leg[0].down_vel.set(0,0, -80);
  wp.leg[1].down_vel.set(0,0, -80);
  wp.leg[2].down_vel.set(0,0,-100);
  wp.leg[3].down_vel.set(0,0,-100);

  wp.leg[0].lift_time=0.0000; wp.leg[0].down_time=0.5000;
  wp.leg[1].lift_time=0.5000; wp.leg[1].down_time=1.0000;
  wp.leg[2].lift_time=0.5000; wp.leg[2].down_time=1.0000;
  wp.leg[3].lift_time=0.0000; wp.leg[3].down_time=0.5000;

  wp.body_angle  = RAD(16.0);
  wp.body_height = 104;
  wp.hop  = 0;
  wp.sway = 0;
  */

  /*
  // Development trot
  wp.leg[0].neutral.set( 116, 70,0);
  wp.leg[1].neutral.set( 116,-70,0);
  wp.leg[2].neutral.set( -90, 70,0);
  wp.leg[3].neutral.set( -90,-70,0);
  wp.period = 500;

  wp.leg[0].lift_vel.set(0,0, 150);
  wp.leg[1].lift_vel.set(0,0, 150);
  wp.leg[2].lift_vel.set(0,0, 200);
  wp.leg[3].lift_vel.set(0,0, 200);

  wp.leg[0].down_vel.set(0,0, -80);
  wp.leg[1].down_vel.set(0,0, -80);
  wp.leg[2].down_vel.set(0,0,-100);
  wp.leg[3].down_vel.set(0,0,-100);

  wp.leg[0].lift_time=0.0000; wp.leg[0].down_time=0.5000;
  wp.leg[1].lift_time=0.5000; wp.leg[1].down_time=1.0000;
  wp.leg[2].lift_time=0.5000; wp.leg[2].down_time=1.0000;
  wp.leg[3].lift_time=0.0000; wp.leg[3].down_time=0.5000;

  wp.body_angle  = RAD(14.0);
  wp.body_height = 100;
  wp.hop  = 10;
  wp.sway = 0;
  */

  /*
  // Current best trot
  wp.leg[0].neutral.set( 123, 85,0);
  wp.leg[1].neutral.set( 123,-85,0);
  wp.leg[2].neutral.set( -80, 75,0);
  wp.leg[3].neutral.set( -80,-75,0);
  wp.period = 600;

  wp.leg[0].lift_vel.set(0,0, 100);
  wp.leg[1].lift_vel.set(0,0, 100);
  wp.leg[2].lift_vel.set(0,0, 200);
  wp.leg[3].lift_vel.set(0,0, 200);

  wp.leg[0].down_vel.set(0,0,-100);
  wp.leg[1].down_vel.set(0,0,-100);
  wp.leg[2].down_vel.set(0,0,-100);
  wp.leg[3].down_vel.set(0,0,-100);

  wp.leg[0].lift_time=0.0000; wp.leg[0].down_time=0.5000;
  wp.leg[1].lift_time=0.5000; wp.leg[1].down_time=1.0000;
  wp.leg[2].lift_time=0.5000; wp.leg[2].down_time=1.0000;
  wp.leg[3].lift_time=0.0000; wp.leg[3].down_time=0.5000;

  wp.body_angle  = RAD(16.0);
  wp.body_height = 104;
  wp.hop  = 0;
  wp.sway = 0;
  */

  /*
  // Good trot
  wp.leg[0].neutral.set( 125, 85,0);
  wp.leg[1].neutral.set( 125,-85,0);
  wp.leg[2].neutral.set( -80, 75,0);
  wp.leg[3].neutral.set( -80,-75,0);
  wp.period = 600;

  wp.leg[0].lift_vel.set(0,0, 100);
  wp.leg[1].lift_vel.set(0,0, 100);
  wp.leg[2].lift_vel.set(0,0, 150);
  wp.leg[3].lift_vel.set(0,0, 150);

  wp.leg[0].down_vel.set(0,0,-100);
  wp.leg[1].down_vel.set(0,0,-100);
  wp.leg[2].down_vel.set(0,0,-100);
  wp.leg[3].down_vel.set(0,0,-100);

  wp.leg[0].lift_time=0.0000; wp.leg[0].down_time=0.5000;
  wp.leg[1].lift_time=0.5000; wp.leg[1].down_time=1.0000;
  wp.leg[2].lift_time=0.5000; wp.leg[2].down_time=0.8333;
  wp.leg[3].lift_time=0.0000; wp.leg[3].down_time=0.3333;

  wp.body_angle  = RAD(17.5);
  wp.body_height = 102;
  wp.hop  = 4;
  wp.sway = 0;
  */

  // front_x, front_y, rear_x, rear_y
  // period, lift_vel, down_vel
  // front_air, rear_air, rear_ofs

  /*
  double w;
  w = 75;
  wp.leg[0].neutral.set( 105, w,0);
  wp.leg[1].neutral.set( 105,-w,0);
  wp.leg[2].neutral.set( -70, w,0);
  wp.leg[3].neutral.set( -70,-w,0);
  wp.period = 700;

  wp.leg[0].lift_vel.set(0,0, 100);
  wp.leg[1].lift_vel.set(0,0, 100);
  wp.leg[2].lift_vel.set(0,0, 100);
  wp.leg[3].lift_vel.set(0,0, 100);

  wp.leg[0].down_vel.set(0,0,-100);
  wp.leg[1].down_vel.set(0,0,-100);
  wp.leg[2].down_vel.set(0,0,-100);
  wp.leg[3].down_vel.set(0,0,-100);

  wp.leg[0].lift_time=0.000; wp.leg[0].down_time=0.3333;
  wp.leg[1].lift_time=0.500; wp.leg[1].down_time=0.8333;
  wp.leg[2].lift_time=0.500; wp.leg[2].down_time=0.8333;
  wp.leg[3].lift_time=0.000; wp.leg[3].down_time=0.3333;

  wp.body_angle  = RAD(10.0);
  wp.body_height = 115;
  wp.hop  = 6;
  wp.sway = 0;
  */
}

void test_walks()
{
  Motion::Motion m;
  Motion::MotionCommand cmd;
  double angles[NumPIDJoints];
  double da;
  int dx,dy;
  int i,e;

  mset(angles,0.0,NumPIDJoints);
  mzero(cmd);

  m.init();
  m.init(angles);
  m.toggle();

  for(da=0.0; da<1.9; da+=1.9/10){
    printf("Table: da=%f\n",da);
    for(dx=-230; dx<=230; dx+=20){
      printf("  ");
      for(dy=-230; dy<=230; dy+=10){
        cmd.motion_cmd = Motion::MOTION_WALK_TROT;
        cmd.vx = dx;
        cmd.vy = dy;
        cmd.va = da;
        m.setCommand(cmd);

        for(i=0; i<600/8*4; i++) m.getAngles(angles);
        KinClearErrors();
        for(i=0; i<600/8*4; i++) m.getAngles(angles);
        e = KinGetTotalErrors();
        printf("%c",e?'.':'#'); fflush(stdout);
      }
      printf("\n");
    }
  }
}
