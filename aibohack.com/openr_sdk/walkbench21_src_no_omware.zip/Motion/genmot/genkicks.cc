/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#include "genmot.h"


void make_kicks()
{
  Motion::BodyStateMotion m[16];
  Motion::BodyState b;
  FILE *out;
  int n;
  double f,s,o;
  int t;

  t = 1;

  //==== Grab Kick ====//
  mzero(b);

  n = 0;
  m[n].body = b;
  m[n].time = 500;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.0, 0.0, 0.0);
  LegAng(b,0, 1.2,-0.2, 0.5);
  LegAng(b,1, 1.2,-0.2, 0.5);
  LegAng(b,2, 1.2, 1.0, 0.5);
  LegAng(b,3, 1.2, 1.0, 0.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.5, 1.5, 0.0);
  // LegAng(b,0, 1.8,-0.2,-0.5);
  // LegAng(b,1, 1.8,-0.2,-0.5);
  LegAng(b,2,-2.5, 1.0, 2.5);
  LegAng(b,3,-2.5, 1.0, 2.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  BodyPos(b,104,RAD(16));
  // LegAng(b,0, 1.8,-0.2,-0.5);
  // LegAng(b,1, 1.8,-0.2,-0.5);
  LegAng(b,2,-1.0, 0.5, 0.0);
  LegAng(b,3,-1.0, 0.5, 0.0);
  m[n].body = b;
  m[n].time = 100;
  n++;

  m[n].body = b;
  m[n].time = 400;
  n++;

  BodyPos(b,104,RAD(16));
  LegAng(b,0, 1.2, 0.1, 0.5);
  LegAng(b,1, 1.2, 0.1, 0.5);
  // LegAng(b,2, 1.2, 0.0, 0.5);
  // LegAng(b,3, 1.2, 0.0, 0.5);
  m[n].body = b;
  m[n].time = 200;
  n++;

  BodyPos(b,104,RAD(16));
  LegAng(b,0, 1.9, 0.1,-0.5);
  LegAng(b,1, 1.9, 0.1,-0.5);
  // LegAng(b,2, 1.2, 0.0, 0.5);
  // LegAng(b,3, 1.2, 0.0, 0.5);
  m[n].body = b;
  m[n].time = 100;
  n++;

  BodyPos(b,104,RAD(16));
  LegAng(b,0, 1.9,-0.2,-0.5);
  LegAng(b,1, 1.9,-0.2,-0.5);
  LegAng(b,2,-1.0, 0.5, 0.0);
  LegAng(b,3,-1.0, 0.5, 0.0);
  m[n].body = b;
  m[n].time = 800;  // 2.2
  n++;

  BodyPos(b,104,RAD(16));
  LegAng(b,0,-0.5,-0.1, 0.0);
  LegAng(b,1,-0.5,-0.1, 0.0);
  LegAng(b,2,-0.2, 0.5, 0.0);
  LegAng(b,3,-0.2, 0.5, 0.0);
  m[n].body = b;
  m[n].time = 400;
  n++;

  BodyPos(b,104,RAD(16));
  LegAng(b,0,-0.5,-0.1, 0.0);
  LegAng(b,1,-0.5,-0.1, 0.0);
  LegAng(b,2,-0.2, 0.5, 0.0);
  LegAng(b,3,-0.2, 0.5, 0.0);
  m[n].body = b;
  m[n].time = 100;
  n++;

  BodyPos(b,104,RAD(16));
  LegAng(b,0, 1.5, 1.0, 1.5);
  LegAng(b,1, 1.5, 1.0, 1.5);
  LegAng(b,2,-2.0, 0.5, 0.0);
  LegAng(b,3,-2.0, 0.5, 0.0);
  m[n].body = b;
  m[n].time = 500;
  n++;

  BodyPos(b,104,RAD(16));
  LegAng(b,0, 1.0, 0.0, 0.5);
  LegAng(b,1, 1.0, 0.0, 0.5);
  LegAng(b,2,-2.0, 0.0, 2.5);
  LegAng(b,3,-2.0, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  BodyPos(b,104,RAD(16));
  LegAng(b,0, 1.0, 0.0, 0.5);
  LegAng(b,1, 1.0, 0.0, 0.5);
  LegAng(b,2,-1.0, 0.0, 2.5);
  LegAng(b,3,-1.0, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 1000;
  n++;

  m[n].body = b;
  m[n].time = 0;
  n++;

  out = fopen("k_grab.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);

  //==== Dive Kick ====//
  mzero(b);

  n = 0;
  m[n].body = b;
  m[n].time = 500;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.5, 1.5, 0.0);
  LegAng(b,0, 0.2, 0.2, 0.0);
  LegAng(b,1, 0.2, 0.2, 0.0);
  LegAng(b,2,-0.2, 0.5, 0.2);
  LegAng(b,3,-0.2, 0.5, 0.2);
  m[n].body = b;
  m[n].time = 100;
  n++;

  m[n].body = b;
  m[n].time = 100;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.5, 1.5, 0.0);
  LegAng(b,0, 0.0, 0.2, 0.0);
  LegAng(b,1, 0.0, 0.2, 0.0);
  LegAng(b,2, 0.0, 0.5, 1.5);
  LegAng(b,3, 0.0, 0.5, 1.5);
  m[n].body = b;
  m[n].time = 100;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.5, 1.5, 0.0);
  LegAng(b,0,-1.2, 0.5, 0.0);
  LegAng(b,1,-1.2, 0.5, 0.0);
  LegAng(b,2, 1.2, 0.5, 1.5);
  LegAng(b,3, 1.2, 0.5, 1.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  m[n].body = b;
  m[n].time = 500;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.5, 1.5, 0.0);
  LegAng(b,0, 0.0, 1.5, 0.0);
  LegAng(b,1, 0.0, 1.5, 0.0);
  LegAng(b,2, 0.0, 1.5, 1.5);
  LegAng(b,3, 0.0, 1.5, 1.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.5, 1.5, 0.0);
  LegAng(b,0, 0.0, 1.5, 1.5);
  LegAng(b,1, 0.0, 1.5, 1.5);
  LegAng(b,2, 0.0, 1.5, 1.5);
  LegAng(b,3, 0.0, 1.5, 1.5);
  m[n].body = b;
  m[n].time = 200;
  n++;

  m[n].body = b;
  m[n].time = 500;
  n++;

  out = fopen("k_dive.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);

  //==== Foreward Kick ====//
  mzero(b);

  n = 0;
  m[n].body = b;
  m[n].time = 500;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b,-0.0, 0.0, 0.0);
  LegAng(b,0, 1.3,-0.2,0.5);
  LegAng(b,1, 1.3,-0.2,0.5);
  LegAng(b,2, 1.3, 1.0,0.5);
  LegAng(b,3, 1.3, 1.0,0.5);
  m[n].body = b;
  m[n].time = 100;
  n++;

  BodyPos(b,104,RAD(16));
  LegAng(b,0, 1.3, 0.2,0.5);
  LegAng(b,1, 1.3, 0.2,0.5);
  LegAng(b,2, 1.3, 0.5,0.5);
  LegAng(b,3, 1.3, 0.5,0.5);
  m[n].body = b;
  m[n].time = 200;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.0, 0.0, 0.0);
  LegAng(b,0, 2.2, 0.2,1.6);
  LegAng(b,1, 2.2, 0.2,1.6);
  LegAng(b,2, 1.3, 0.5,0.5);
  LegAng(b,3, 1.3, 0.5,0.5);
  m[n].body = b;
  m[n].time = 100;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.0, 0.0, 0.0);
  LegAng(b,0, 2.2,-0.2,1.6);
  LegAng(b,1, 2.2,-0.2,1.6);
  LegAng(b,2, 1.3, 0.5,0.5);
  LegAng(b,3, 1.3, 0.5,0.5);
  m[n].body = b;
  m[n].time = 100;
  n++;

  BodyPos(b,104,RAD(16));
  LegAng(b,0, 1.0,-0.2,1.3);
  LegAng(b,1, 1.0,-0.2,1.3);
  LegAng(b,2, 1.3, 0.5,0.5);
  LegAng(b,3, 1.3, 0.5,0.5);
  m[n].body = b;
  m[n].time = 200;
  n++;

  m[n].body = b;
  m[n].time = 0;
  n++;

  out = fopen("k_fwd.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);


  //==== Blocking Kick ====//
  mzero(b);

  n = 0;
  m[n].body = b;
  m[n].time = 100;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.0, 0.0, 0.0);
  LegPos(b,0, 123, 85,0);
  LegPos(b,1, 123,-85,0);
  LegPos(b,2, -80, 75,0);
  LegPos(b,3, -80,-75,0);
  m[n].body = b;
  m[n].time = 500;
  n++;

  BodyPos(b,104,RAD(16));
  HeadAng(b, 0.0, 0.0, 0.0);
  LegAng(b,0, 0.5, 1.0, 0.5);
  LegAng(b,1, 0.5, 1.0, 0.5);
  LegAng(b,2,-2.0, 0.0, 2.5);
  LegAng(b,3,-2.0, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  HeadAng(b,-0.5, 0.0, 0.0);
  LegAng(b,0, 1.0,-0.2, 0.5);
  LegAng(b,1, 1.0,-0.2, 0.5);
  LegAng(b,2, 1.0, 0.0, 2.5);
  LegAng(b,3, 1.0, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 600;
  n++;

  m[n].body = b;
  m[n].time = 100;
  n++;

  LegAng(b,0, 1.0, 0.1, 0.5);
  LegAng(b,1, 1.0, 0.1, 0.5);
  m[n].body = b;
  m[n].time = 200;
  n++;

  LegAng(b,0, 2.0, 0.1, 1.6);
  LegAng(b,1, 2.0, 0.1, 1.6);
  m[n].body = b;
  m[n].time = 300;
  n++;

  HeadAng(b,-0.0, 0.0, 0.0);
  LegAng(b,0, 2.0,-0.2, 1.6);
  LegAng(b,1, 2.0,-0.2, 1.6);
  m[n].body = b;
  m[n].time = 100;
  n++;

  LegAng(b,0, 2.0,-0.2, 1.6);
  LegAng(b,1, 2.0,-0.2, 1.6);
  m[n].body = b;
  m[n].time = 100;
  n++;

  LegAng(b,0, 1.0,-0.2, 1.0);
  LegAng(b,1, 1.0,-0.2, 1.0);
  LegAng(b,2, 0.0, 0.0, 1.5);
  LegAng(b,3, 0.0, 0.0, 1.5);
  m[n].body = b;
  m[n].time = 400;
  n++;

  LegAng(b,0, 1.0,-0.2, 1.5);
  LegAng(b,1, 1.0,-0.2, 1.5);
  LegAng(b,2,-1.0, 0.0, 1.5);
  LegAng(b,3,-1.0, 0.0, 1.5);
  m[n].body = b;
  m[n].time = 400;
  n++;

  /*
  out = fopen("k_grab.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);
  */

  //==== Bump Kick ====//
  mzero(b);

  t = 1;

  n = 0;
  m[n].body = b;
  m[n].time = 200*t;
  n++;

  f = 10;
  BodyPos(b,90,RAD(16));
  HeadAng(b,0.0, 0.0, 0.0);
  LegPos(b,0, 123+f, 60,0);
  LegPos(b,1, 123+f,-60,0);
  LegPos(b,2, -80+f, 75,0);
  LegPos(b,3, -80+f,-75,0);
  m[n].body = b;
  m[n].time = 200*t;
  n++;

  BodyPos(b,90,RAD(16));
  HeadAng(b,0.0, 0.0, 0.0);
  LegPos(b,0, 153+f, 60,0);
  LegPos(b,1, 153+f,-60,0);
  LegPos(b,2, -80+f, 75,0);
  LegPos(b,3, -80+f,-75,0);
  m[n].body = b;
  m[n].time = 100*t;
  n++;

  f = 70;
  BodyPos(b,90,RAD(0));
  HeadAng(b,0.0, 0.0, 0.0);
  LegPos(b,0, 153-f, 60,0);
  LegPos(b,1, 153-f,-60,0);
  LegPos(b,2, -80-f, 75,0);
  LegPos(b,3, -80-f,-75,0);
  m[n].body = b;
  m[n].time = 200*t;
  n++;

  m[n].body = b;
  m[n].time = 400;
  n++;

  out = fopen("k_bump.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);


  //==== Punch Kick ====//
  mzero(b);
  BodyPos(b,104,RAD(16));

  n = 0;
  m[n].body = b;
  m[n].time = 500;
  n++;

  f =  0;
  s = 25;

  LegPos(b,0, 124+f, 85+s,0);
  LegPos(b,1, 124+f,-85+s,0);
  LegPos(b,2, -80+f, 75+s,0);
  LegPos(b,3, -80+f,-75+s,0);
  m[n].body = b;
  m[n].time = 500;
  n++;

  LegAng(b,0, 0.0, 0.0, 2.5);
  LegPos(b,1, 124+f,-85+s,0);
  LegPos(b,2, -80-f, 75+s,0);
  LegPos(b,3, -80-f,-75+s,0);
  m[n].body = b;
  m[n].time = 500;
  n++;

  LegAng(b,0, 2.0, 0.0, 1.0);
  LegPos(b,1, 124+f,-85+s,0);
  LegPos(b,2, -80-f, 75+s,0);
  LegPos(b,3, -80-f,-75+s,0);
  m[n].body = b;
  m[n].time = 500;
  n++;

  LegAng(b,0, 2.0, 0.0, 1.0);
  LegPos(b,1, 124+f,-85+s,0);
  LegPos(b,2, -80-f, 75+s,0);
  LegPos(b,3, -80-f,-75+s,0);
  m[n].body = b;
  m[n].time = 100;
  n++;

  LegAng(b,0, 1.0, 0.0, 1.0);
  LegPos(b,1, 124+f,-85+s,0);
  LegPos(b,2, -80-f, 75+s,0);
  LegPos(b,3, -80-f,-75+s,0);
  m[n].body = b;
  m[n].time = 500;
  n++;

  LegPos(b,0, 124, 85,0);
  LegPos(b,1, 124,-85,0);
  LegPos(b,2, -80, 75,0);
  LegPos(b,3, -80,-75,0);
  m[n].body = b;
  m[n].time = 500;
  n++;

  out = fopen("k_punch.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);


  //==== Side Head Kick ====//

  mzero(b);

  n = 0;
  m[n].body = b;
  m[n].time = 300;
  n++;

  f = -38;
  s =  32;
  o =  15;

  HeadAng(b, 0.0, 0.0, 0.0);
  BodyPos(b,104,RAD(16));
  LegPos(b,0, 123-o, 85,0);
  LegPos(b,1, 123+o,-85,0);
  LegPos(b,2, -80  , 75,0);
  LegPos(b,3, -80  ,-75,0);
  m[n].body = b;
  m[n].time = 300;
  n++;

  HeadAng(b,-1.2,-1.5, 0.0);
  BodyPos(b,95,RAD(16));
  LegPos(b,0, 123-o+f, 85+s,0);
  LegPos(b,1, 123+o+f,-85+s,0);
  LegPos(b,2, -80  +f, 75+s,0);
  LegPos(b,3, -80  +f,-75+s,0);
  m[n].body = b;
  m[n].time = 200;
  n++;

  HeadAng(b,-1.2, 1.5, 0.0);
  BodyPos(b,95,RAD(16));
  LegPos(b,0, 123-o+f, 85-s,0);
  LegPos(b,1, 123+o+f,-85-s,0);
  LegPos(b,2, -80  +f, 75-s,0);
  LegPos(b,3, -80  +f,-75-s,0);
  m[n].body = b;
  m[n].time = 200;
  n++;

  out = fopen("k_head.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);

  //==== Soft Side Head Kick ====//

  mzero(b);

  n = 0;
  m[n].body = b;
  m[n].time = 300;
  n++;

  f = -38;
  s =  32;
  o =  15;

  HeadAng(b, 0.0, 0.0, 0.0);
  BodyPos(b,104,RAD(16));
  LegPos(b,0, 123-o, 85,0);
  LegPos(b,1, 123+o,-85,0);
  LegPos(b,2, -80  , 75,0);
  LegPos(b,3, -80  ,-75,0);
  m[n].body = b;
  m[n].time = 300;
  n++;

  HeadAng(b,-1.2,-1.5, 0.0);
  BodyPos(b,95,RAD(16));
  LegPos(b,0, 123-o+f, 85+s,0);
  LegPos(b,1, 123+o+f,-85+s,0);
  LegPos(b,2, -80  +f, 75+s,0);
  LegPos(b,3, -80  +f,-75+s,0);
  m[n].body = b;
  m[n].time = 400;
  n++;

  HeadAng(b,-1.2, 1.5, 0.0);
  BodyPos(b,95,RAD(16));
  LegPos(b,0, 123-o+f, 85-s,0);
  LegPos(b,1, 123+o+f,-85-s,0);
  LegPos(b,2, -80  +f, 75-s,0);
  LegPos(b,3, -80  +f,-75-s,0);
  m[n].body = b;
  m[n].time = 200;
  n++;

  out = fopen("k_heads.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);


  //==== Diagonal Head Kick ====//
  mzero(b);

  n = 0;
  m[n].body = b;
  m[n].time = 300;
  n++;

  f = -38;
  s =  32;
  o =  15;

  HeadAng(b, 0.0, 0.0, 0.0);
  BodyPos(b,104,RAD(16));
  LegPos(b,0, 123-o, 85,0);
  LegPos(b,1, 123+o,-85,0);
  LegPos(b,2, -80  , 75,0);
  LegPos(b,3, -80  ,-75,0);
  m[n].body = b;
  m[n].time = 300;
  n++;

  HeadAng(b,-1.2,-1.5, 0.0);
  BodyPos(b,95,RAD(16));
  LegPos(b,0, 123-o+f, 85+s,0);
  LegPos(b,1, 123+o+f,-85+s,0);
  LegPos(b,2, -80  +f, 75+s,0);
  LegPos(b,3, -80  +f,-75+s,0);
  m[n].body = b;
  m[n].time = 200;
  n++;

  HeadAng(b,-1.2, 1.5, 0.0);
  BodyPos(b,95,RAD(16));
  LegAng(b,0, 0.0, 0.5, 0.0);
  LegPos(b,1, 123+o+f,-85-s,0);
  LegPos(b,2, -80  +f, 75-s,0);
  LegPos(b,3, -80  +f,-75-s,0);
  m[n].body = b;
  m[n].time = 200;
  n++;

  out = fopen("k_diag.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);
}
