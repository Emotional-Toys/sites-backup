/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#include "genmot.h"


void make_getups()
{
  Motion::BodyStateMotion m[16];
  Motion::BodyState b;
  FILE *out;
  int i,n;

  // Note: get up front not currently used
  //==== Get up off of front ====//
  mzero(b);
  b.head.attr = ATTR_ANGLES;
  set3(b.head.angles,0.0,0.0,0.0);

  for(i=0; i<4; i++) b.leg[i].attr = ATTR_ANGLES;
  n = 0;

  m[n].body = b;
  m[n].time = 500;
  n++;

  set3(b.leg[0].angles, 0.0, 0.0, 0.0);
  set3(b.leg[1].angles, 0.0, 0.0, 0.0);
  set3(b.leg[2].angles, 0.0, 0.0, 0.0);
  set3(b.leg[3].angles, 0.0, 0.0, 0.0);
  m[n].body = b;
  m[n].time = 500;
  n++;

  set3(b.leg[0].angles, 0.0, 1.6, 0.0);
  set3(b.leg[1].angles, 0.0, 1.6, 0.0);
  set3(b.leg[2].angles, 1.0, 0.0, 2.5);
  set3(b.leg[3].angles, 1.0, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  set3(b.leg[0].angles, 1.8, 1.6, 0.0);
  set3(b.leg[1].angles, 1.8, 1.6, 0.0);
  set3(b.leg[2].angles,-1.8, 0.0, 2.5);
  set3(b.leg[3].angles,-1.8, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  set3(b.leg[0].angles, 1.8, 0.0, 2.5);
  set3(b.leg[1].angles, 1.8, 0.0, 2.5);
  set3(b.leg[2].angles,-1.8, 0.0, 2.5);
  set3(b.leg[3].angles,-1.8, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  set3(b.leg[0].angles, 1.0, 0.0, 0.5);
  set3(b.leg[1].angles, 1.0, 0.0, 0.5);
  set3(b.leg[2].angles,-1.2, 0.0, 2.5);
  set3(b.leg[3].angles,-1.2, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  out = fopen("gu_front.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);


  //==== Get up off of back ====//
  mzero(b);
  b.head.attr = ATTR_ANGLES;
  set3(b.head.angles,RAD(-90),0.0,0.0);

  for(i=0; i<4; i++) b.leg[i].attr = ATTR_ANGLES;
  n = 0;

  m[n].body = b;
  m[n].time = 500;
  n++;

  set3(b.leg[0].angles, 0.0, 0.0, 0.0);
  set3(b.leg[1].angles, 0.0, 0.0, 0.0);
  set3(b.leg[2].angles, 0.0, 0.0, 0.0);
  set3(b.leg[3].angles, 0.0, 0.0, 0.0);
  m[n].body = b;
  m[n].time = 500;
  n++;

  set3(b.leg[0].angles, 0.0, 0.0, 0.0);
  set3(b.leg[1].angles, 0.0, 0.0, 0.0);
  set3(b.leg[2].angles,-1.8, 0.0, 2.5);
  set3(b.leg[3].angles,-1.8, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  set3(b.leg[0].angles, 1.0, 0.0, 0.5);
  set3(b.leg[1].angles, 1.0, 0.0, 0.5);
  set3(b.leg[2].angles,-1.2, 0.0, 2.5);
  set3(b.leg[3].angles,-1.2, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  out = fopen("gu_back.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);

  //==== Get up off of side ====//
  mzero(b);
  b.head.attr = ATTR_ANGLES;
  set3(b.head.angles,0.0,0.0,0.0);

  for(i=0; i<4; i++) b.leg[i].attr = ATTR_ANGLES;
  n = 0;

  m[n].body = b;
  m[n].time = 500;
  n++;

  set3(b.leg[0].angles, 0.0, 0.0, 0.0);
  set3(b.leg[1].angles, 0.0, 0.0, 0.0);
  set3(b.leg[2].angles, 0.0, 0.0, 0.0);
  set3(b.leg[3].angles, 0.0, 0.0, 0.0);
  m[n].body = b;
  m[n].time = 500;
  n++;

  set3(b.leg[0].angles, 2.0, 0.0, 2.5);
  set3(b.leg[1].angles, 2.0, 0.0, 2.5);
  set3(b.leg[2].angles, 2.0, 0.0, 2.5);
  set3(b.leg[3].angles, 2.0, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 300;
  n++;

  set3(b.leg[0].angles, 2.0, 1.6, 2.5);
  set3(b.leg[1].angles, 2.0, 1.6, 2.5);
  set3(b.leg[2].angles, 2.0, 1.6, 2.5);
  set3(b.leg[3].angles, 2.0, 1.6, 2.5);
  m[n].body = b;
  m[n].time = 700;
  n++;

  set3(b.leg[0].angles, 1.0, 0.0, 0.5);
  set3(b.leg[1].angles, 1.0, 0.0, 0.5);
  set3(b.leg[2].angles,-1.2, 0.0, 2.5);
  set3(b.leg[3].angles,-1.2, 0.0, 2.5);
  m[n].body = b;
  m[n].time = 500;
  n++;

  out = fopen("gu_side.mot","wb");
  fwrite(&n,sizeof(n),1,out);
  fwrite(m,sizeof(Motion::BodyStateMotion),n,out);
  fclose(out);
}
