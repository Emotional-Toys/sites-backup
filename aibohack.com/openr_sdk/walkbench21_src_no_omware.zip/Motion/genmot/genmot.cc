/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#include "genmot.h"


// Helper functions
void BodyPos(Motion::BodyState &b,double height,double angle)
{
  b.pos.loc.set(0,0,height);
  b.pos.angle.set(0,angle,0);
}

void LegPos(Motion::BodyState &b,int leg,double x,double y,double z)
{
  b.leg[leg].attr = ATTR_POSITION;
  b.leg[leg].pos.set(x,y,z);
}

void LegAng(Motion::BodyState &b,int leg,double r,double s,double k)
{
  b.leg[leg].attr = ATTR_ANGLES;
  set3(b.leg[leg].angles,r,s,k);
}

void HeadPos(Motion::BodyState &b,double x,double y,double z)
{
  b.head.attr = ATTR_POSITION;
  b.head.target.set(x,y,z);
}

void HeadAng(Motion::BodyState &b,double t,double p,double r)
{
  b.head.attr = ATTR_ANGLES;
  set3(b.head.angles,t,p,r);
}


// Globals
Motion::Motion m;
Motion::MotionCommand cmd;
double angles[NumPIDJoints];


void make_motions()
{
  make_walk_param();
  make_kicks();
  make_getups();
}

void test_head()
{
  vector3d target,tdir;
  vector3d location,dir,up,right;
  double body_height = 115;
  double body_angle  = RAD(0.0);

  target.set(200,0,0);

  GetHeadAngles(angles,target,body_angle,body_height);
  GetHeadPosition(location,dir,up,right,
                  angles,body_angle,body_height);

  tdir = (target - location).norm();

  printf("td=(%g,%g,%g) d=(%g,%g,%g) a=(%g,%g,%g)\n",
         V3COMP(tdir),V3COMP(dir),
         angles[0],angles[1],angles[2]);
}

int main()
{
  int *err;
  int i;
  int s;

  make_walk_param();
  make_getups();
  make_kicks();
  // test_walks();
  // exit(0);

  mset(angles,0.0,NumPIDJoints);
  mzero(cmd);
  m.init();
  m.init(angles);
  m.toggle();

  if(false){
    cmd.motion_cmd = Motion::MOTION_KICK_BUMP;
    cmd.head_cmd   = Motion::HEAD_SCAN_BALL;
  }else{
    cmd.nobound = true;
    cmd.motion_cmd = Motion::MOTION_WALK_TROT;
    cmd.head_cmd = Motion::HEAD_SCAN_BALL;
    cmd.va = Motion::MAX_DA; // 2.3 // 2.0 // 1.60
    cmd.vx =            0.0; // ?   // 225 // 270.00/(1.3*cmd.va+1);
    cmd.vy =            0.0; // ?   // 175 // 140.00/(1.3*cmd.va+1);
  }

  // 1.5, 105 ( 70)
  // 1.4, 120 ( 86)
  // 1.3, 130 (100)
  // 1.2, 144 (120)

  s = 0;
  m.setCommand(cmd);

  KinClearErrors();
  for(i=0; i<4000*8; i++){
    m.getAngles(angles);

    if(true){
      for(int j=0; j<4; j++){
        printf("l(%6.3f %6.3f %6.3f)  ",angles[j*3+0],angles[j*3+1],angles[j*3+2]);
      }
      // printf("h(%6.3f %6.3f %6.3f)",angles[12],angles[13],angles[14]);
      printf("\n");
    }
  }
  err = KinGetErrors();
  printf("Errors=[%d %d %d %d]\n",
         err[0],err[1],err[2],err[3]);

#if 0
  for(s=0; s<10000/32; s++){
    /*
    if(rand()%4){
      printf("WALK!\n");
      cmd.motion_cmd = Motion::MOTION_WALK_TROT;
      cmd.va = (drand48()*2-1)*1.50;
      cmd.vx = (drand48()*2-1)*190.0/(1.3*cmd.va+1);
      cmd.vy = (drand48()*2-1)*130.0/(1.3*cmd.va+1);
    }else{
      // printf("STAND!\n");
      // cmd.motion_cmd = Motion::MOTION_STAND_NEUTRAL;
      printf("GET UP!\n");
      cmd.motion_cmd = Motion::MOTION_GETUP_BACK;
      cmd.va = 0;
      cmd.vx = 0;
      cmd.vy = 0;
    }
    m.setCommand(cmd);
    */

    for(i=0; i<64/8; i++){
      m.getAngles(angles);

      for(int j=0; j<4; j++){
        printf("l(%6.3f %6.3f %6.3f)  ",angles[j*3+0],angles[j*3+1],angles[j*3+2]);
      }
      // printf("h(%6.3f %6.3f %6.3f)",angles[12],angles[13],angles[14]);
      printf("\n");
    }

#endif

  return(0);
}
