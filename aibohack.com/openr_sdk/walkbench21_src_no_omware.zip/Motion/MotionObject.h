/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#ifndef INCLUDED_MotionObject_h
#define INCLUDED_MotionObject_h

#include <map.h>
#include <list.h>

#include <OPENR/OPENR.h>
#include <OPENR/OPENRAPI.h>
#include <OPENR/OObject.h>
#include <OPENR/OSubject.h>
#include <OPENR/OObserverVector.h>

class PacketStream;
class SPOutMotionEncoder;

#include "def.h"
//#define LIMPDOG

#include "../headers/AperiosSharedMem.h"
// #include "Motion.h"

// Robot Information
const unsigned NumPIDJoints = 18;
const unsigned NumBinJoints =  2;
const unsigned NumLEDs      =  9;
const unsigned NumEars      =  2;
const unsigned NumSpeakers  =  1;

const unsigned NumFastOutputs = NumPIDJoints + NumLEDs;
const unsigned NumJoints      = NumPIDJoints + NumBinJoints;
const unsigned NumOutputs     = NumPIDJoints + NumBinJoints + NumLEDs + NumSpeakers;

const unsigned LEDOffset = NumPIDJoints;
const unsigned EarOffset = NumPIDJoints + NumLEDs;
const unsigned SpeakerOffset = NumPIDJoints + NumLEDs + NumEars;

const char* const PrimitiveName [NumOutputs] = {
  "PRM:/r2/c1-Joint2:j1",       // the left front leg   the joint 
  "PRM:/r2/c1/c2-Joint2:j2",    // the left front leg   the shoulder 
  "PRM:/r2/c1/c2/c3-Joint2:j3", // the left front leg   the knee 
  "PRM:/r4/c1-Joint2:j1",       // the right front leg   the joint 
  "PRM:/r4/c1/c2-Joint2:j2",    // the right front leg    the shoulder 
  "PRM:/r4/c1/c2/c3-Joint2:j3", // the right front leg   the knee 

  "PRM:/r3/c1-Joint2:j1",       // the left hind leg   the joint 
  "PRM:/r3/c1/c2-Joint2:j2",    // the left hind leg   the shoulder 
  "PRM:/r3/c1/c2/c3-Joint2:j3", // the left hind leg   the knee
  "PRM:/r5/c1-Joint2:j1",       // the right hind leg   the joint 
  "PRM:/r5/c1/c2-Joint2:j2",    // the right hind leg   the shoulder 
  "PRM:/r5/c1/c2/c3-Joint2:j3", // the right hind leg   the knee 

  "PRM:/r1/c1-Joint2:j1",       // the neck  tilt (12)
  "PRM:/r1/c1/c2-Joint2:j2",    // the neck   pan 
  "PRM:/r1/c1/c2/c3-Joint2:j3", // the neck   roll 

  "PRM:/r6/c1-Joint2:j1",       // the tail pan (15)
  "PRM:/r6/c2-Joint2:j2",       // the tail chilt

  "PRM:/r1/c1/c2/c3/c4-Joint2:j4", // the mouth (17)

  "PRM:/r1/c1/c2/c3/l1-LED2:l1", // lower  left  LED (18)
  "PRM:/r1/c1/c2/c3/l4-LED2:l4", // lower  right LED
  "PRM:/r1/c1/c2/c3/l2-LED2:l2", // middle left  LED
  "PRM:/r1/c1/c2/c3/l5-LED2:l5", // middle right LED
  "PRM:/r1/c1/c2/c3/l3-LED2:l3", // upper  left  LED
  "PRM:/r1/c1/c2/c3/l6-LED2:l6", // upper  right LED
  "PRM:/r1/c1/c2/c3/l7-LED2:l7", // top          LED

  "PRM:/r6/l2-LED2:l2", // tail red  LED
  "PRM:/r6/l1-LED2:l1", // tail blue LED

  "PRM:/r1/c1/c2/c3/e1-Joint3:j5", // left ear (27)
  "PRM:/r1/c1/c2/c3/e2-Joint3:j6", // right ear
  "PRM:/r1/c1/c2/c3/s1-Speaker:S1" // speaker
};

/*
> Pid: pgain, igain, dgain, pshift, ishift, dshift
> 
> PGAIN: Proportional gain (16bit depth)
> IGAIN: Integral gain (16bit depth)
> DGAIN: Differential gain (16bit depth)
>  
> PSHIFT: Proportional gain shift amount  (4bit)
> ISHIFT: Proportional gain shift amount  (4bit)
> DSHIFT: Proportional gain shift amount  (4bit)
>  
> Operation :
>  
> P, I, D, value, respectively
> Multiple the gain G to the error between the desired value Vd and current
> value Vc,
>      F = (Vd - Vc ) * G
> and shift (0x10 - SHIFT) bit right side.
>      F >> SHIFT
> Namely, SHIFT=0x0E  (0x10 - 0x0E) = 2 bit shift
> Assume Vd = 50, Vc= 20, Gain = 0x16=22, SHIFT=0xE,
> The operation will be
>      (50 - 20) * 22 = 660 =1010010100
>      1010010100 >> 2 = 10100101 =  165
*/

const word Pid[NumPIDJoints][6] =
{
  // Legs
  { 0x16, 0x04, 0x08, 0x0E, 0x02, 0x0F },
  { 0x14, 0x04, 0x06, 0x0E, 0x02, 0x0F },
  { 0x23, 0x04, 0x05, 0x0E, 0x02, 0x0F },

  { 0x16, 0x04, 0x08, 0x0E, 0x02, 0x0F },
  { 0x14, 0x04, 0x06, 0x0E, 0x02, 0x0F },
  { 0x23, 0x04, 0x05, 0x0E, 0x02, 0x0F },

  { 0x16, 0x04, 0x08, 0x0E, 0x02, 0x0F },
  { 0x14, 0x04, 0x06, 0x0E, 0x02, 0x0F },
  { 0x23, 0x04, 0x05, 0x0E, 0x02, 0x0F },

  { 0x16, 0x04, 0x08, 0x0E, 0x02, 0x0F },
  { 0x14, 0x04, 0x06, 0x0E, 0x02, 0x0F },
  { 0x23, 0x04, 0x05, 0x0E, 0x02, 0x0F },

  // Head
  { 0x0A, 0x08, 0x0C, 0x0E, 0x02, 0x0F },
  { 0x0D, 0x08, 0x0B, 0x0E, 0x02, 0x0F },
  { 0x0C, 0x08, 0x0C, 0x0E, 0x02, 0x0F },

  // Tail
  { 0x0A, 0x00, 0x18, 0x0E, 0x02, 0x0F },
  { 0x07, 0x00, 0x11, 0x0E, 0x02, 0x0F },

  // Mouth
  { 0x0E, 0x08, 0x10, 0x0E, 0x02, 0x0F },

  //  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
  //  { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
};

class MotionObject : public OObject {
public:
  OSubject        *subject[numOfSubject];
  OObserverVector *observer[numOfObserver];

  // Must Be Public
  MotionObject();
  ~MotionObject() {}

  // OPEN-R Method 
  virtual OStatus DoInit   ( const OSystemEvent& );
  virtual OStatus DoStart  ( const OSystemEvent& );
  virtual OStatus DoStop   ( const OSystemEvent& );
  virtual OStatus DoDestroy( const OSystemEvent& );

  // Inter Object Communication Method 
  void ReadyMoveJoint     (const OReadyEvent &event);
  void ReadyControlBC     (const OReadyEvent &event);
  void ReadyMotionComplete(const OReadyEvent &event);

#ifdef REMOVED_PACKET_TRACE
  void ReadyRequestRegion (const OReadyEvent &event);
  void ReadyRegisterRegion(const OReadyEvent &event);
  void ResultMemRegion    (const ONotifyEvent &event);
#endif
#ifdef REMOVED_SOUND
  OStatus ReadySpeaker    (const OReadyEvent &event);
#endif
  void UpdateControl      (const ONotifyEvent &event);
  void GotSensorFrame     (const ONotifyEvent &event);

#ifdef REMOVED_SOUND
  void ControlSpeaker     (const ONotifyEvent &info);

  void sendLocUpdateQueueBuffer();
  void sendOutputBuffer();

  void RequestRegions();
#endif

private:
  bool triggerVR, triggerBC;
  int  current; // what 8ms we are on
  int  last_update; // last 8ms frame localization motion report
  int  step;

  // int walksteps; // how many 8ms frames per full cycle
  // Motion motion;

  // Aperios Output buffers
  static const int NumBuffers = 2;
  OPrimitiveID          primitiveID[NumOutputs];
  RCRegion             *cmdVecFastRgn[NumBuffers];
  RCRegion             *cmdVecSlowRgn[NumBuffers];
  MemoryRegionID        cmdVecFastID[NumBuffers];
  MemoryRegionID        cmdVecSlowID[NumBuffers];
  OCommandVectorData   *cmdVecFast[NumBuffers];
  OCommandVectorData   *cmdVecSlow[NumBuffers];
  RCRegion             *soundVecRgn[NumBuffers];
  OSoundVectorData     *soundVecData[NumBuffers];
  MemoryRegionID       soundMemID[NumBuffers];
  //OLEDCommandValue2    *led_cmd[NumLEDs];

  // Sound Stuff
  static const int SoundTableSize = 512;
  int soundCur;

  void SetUpBuffer();
  void SetJointGain(double v);
  void SetJointGain() {SetJointGain(1.0);}
  void SendJointData();
  void SendPowerOnParam();
  void SetupSound();

#ifdef REMOVED_PACKET_TRACE

  // output data
  bool requestedRegion;
  SMMSharedMemRegion outputMemRgn;
  SMMSharedMemRegion motionLocUpdateMemRgn;

  // we create
  bool needToSendOutBuffer;
  bool needToSendLocBuffer;

  SMMSharedMemRegion outMemRgn;

  PacketStream *motionUpdateStream;
  SPOutMotionEncoder *encoder;
#endif
};

#endif // INCLUDED_MotionObject_h
