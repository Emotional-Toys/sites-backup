/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#include <OPENR/ObjcommTypes.h>
#include <OPENR/OFbkImage.h>
#include <OPENR/OPENR.h>
#include <OPENR/OPENRAPI.h>
#include <OPENR/OPENRMessages.h>
#ifdef REMOVED
#include <OMWares/OMGsensorData.h>
#endif

#include "../headers/CircBufPacket.h"
#include "../headers/Dictionary.h"
#include "../headers/Geometry.h"
#include "../headers/Sensors.h"

#define GETD(cpc) (((double)sensor[0].GetData(cpc)->frame[0].value) / 1.0E6)
#define GETB(cpc) ((bool)sensor[0].GetData(cpc)->frame[0].value)

unsigned int SensorData::ButtonTranslations[SensorData::NumButtonTranslations];

void SensorData::read(OSensorFrameVectorData *sensor)
{
  const double g = 9.80665;
  double head_f,head_b;
  bool chin,back;

  legAngles[0*3 + 0] = GETD(CPCJointLFJoint);
  legAngles[0*3 + 1] = GETD(CPCJointLFShoulder);
  legAngles[0*3 + 2] = GETD(CPCJointLFKnee);

  legAngles[1*3 + 0] = GETD(CPCJointRFJoint);
  legAngles[1*3 + 1] = GETD(CPCJointRFShoulder);
  legAngles[1*3 + 2] = GETD(CPCJointRFKnee);

  legAngles[2*3 + 0] = GETD(CPCJointLHJoint);
  legAngles[2*3 + 1] = GETD(CPCJointLHShoulder);
  legAngles[2*3 + 2] = GETD(CPCJointLHKnee);

  legAngles[3*3 + 0] = GETD(CPCJointRHJoint);
  legAngles[3*3 + 1] = GETD(CPCJointRHShoulder);
  legAngles[3*3 + 2] = GETD(CPCJointRHKnee);

  // Get head tilt,pan,roll joint anglea
  headAngles[0] = GETD(CPCJointNeckTilt);
  headAngles[1] = GETD(CPCJointNeckPan);
  headAngles[2] = GETD(CPCJointNeckRoll);

  // Get tail angles
  tailAngles[0] = GETD(CPCJointTailPan );
  tailAngles[1] = GETD(CPCJointTailTilt);

  // Get IR distance sensor
  IRDistance =
    ((double)sensor[0].GetData(CPCSensorPSD)->frame[0].value) / 1000.0;

  // Get foot switches
  paw[0] = GETB(CPCSensorLFPaw);
  paw[1] = GETB(CPCSensorRFPaw);
  paw[2] = GETB(CPCSensorLHPaw);
  paw[3] = GETB(CPCSensorRHPaw);

  // Get acceleration sensors
  accel.x = 
    ((double)sensor[0].GetData(CPCSensorAccelFB)->frame[0].value) / g;
  accel.y = 
    ((double)sensor[0].GetData(CPCSensorAccelLR)->frame[0].value) / g;
  accel.z = 
    ((double)sensor[0].GetData(CPCSensorAccelUD)->frame[0].value) / g;

  // Get switches
  chin = ((OSwitchValue)sensor[0].GetData(CPCSensorChinSwitch)->frame[0].value == oswitchON);
  back = ((OSwitchValue)sensor[0].GetData(CPCSensorBackSwitch)->frame[0].value == oswitchON);
  head_f = ((double)sensor[0].GetData(CPCSensorHeadFrontPressure)->frame[0].value)/1.0e6;
  head_b = ((double)sensor[0].GetData(CPCSensorHeadBackPressure)->frame[0].value)/1.0e6;

  button = 0;
  if(chin)          button |= ButtonTranslations[ChinButtonIdx     ];
  if(back)          button |= ButtonTranslations[BackButtonIdx     ];
  if(head_f > 0.50) button |= ButtonTranslations[HeadFrontButtonIdx];
  if(head_b > 0.75) button |= ButtonTranslations[HeadBackButtonIdx ];
}

int
SensorData::ButtonStringToNumber(const char *button_str) {
  if(strcmp(button_str,"HeadFrontButton")==0)
    return HeadFrontButtonIdx;
  else if(strcmp(button_str,"HeadBackButton")==0)
    return HeadBackButtonIdx;
  else if(strcmp(button_str,"ChinButton")==0)
    return ChinButtonIdx;
  else if(strcmp(button_str,"BackButton")==0)
    return BackButtonIdx;
  else
    return -1;
}

void
SensorData::InitializeSensors() {
  ResetButtonTranslations();

  Dictionary button_dict;
  button_dict.read("/MS/config/button.cfg");

  const char *physical_button_str="";
  int physical_button_num;
  if(button_dict.getValueString("LogButton",physical_button_str) &&
     (physical_button_num=ButtonStringToNumber(physical_button_str))!=-1) {
    AddButtonTranslation(physical_button_num,LogButtonIdx);
  }
  if(button_dict.getValueString("VisionObjPlusButton",physical_button_str) &&
     (physical_button_num=ButtonStringToNumber(physical_button_str))!=-1) {
    AddButtonTranslation(physical_button_num,VisionObjPlusButtonIdx);
  }
  if(button_dict.getValueString("VisionObjMinusButton",physical_button_str) &&
     (physical_button_num=ButtonStringToNumber(physical_button_str))!=-1) {
    AddButtonTranslation(physical_button_num,VisionObjMinusButtonIdx);
  }
  if(button_dict.getValueString("ResetModelsButton",physical_button_str) &&
     (physical_button_num=ButtonStringToNumber(physical_button_str))!=-1) {
    AddButtonTranslation(physical_button_num,ResetModelsButtonIdx);
  }
}

void
SensorData::ResetButtonTranslations() {
  for(int but_idx=0; but_idx<NumButtonTranslations; but_idx++) {
    ButtonTranslations[but_idx] = 1UL << but_idx;
  }
}

void
SensorData::AddButtonTranslation(int old_button_idx, int new_button_idx) {
  ButtonTranslations[old_button_idx] = 1UL << new_button_idx;
}
