/* LICENSE:
  =========================================================================
    CMPack'02 Source Code Release for OPEN-R SDK v1.0
    Copyright (C) 2002 Multirobot Lab [Project Head: Manuela Veloso]
    School of Computer Science, Carnegie Mellon University
  -------------------------------------------------------------------------
    This software is distributed under the GNU General Public License,
    version 2.  If you do not have a copy of this licence, visit
    www.gnu.org, or write: Free Software Foundation, 59 Temple Place,
    Suite 330 Boston, MA 02111-1307 USA.  This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY,
    including MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  -------------------------------------------------------------------------
    Additionally licensed to Sony Corporation under the following terms:

    This software is provided by the copyright holders AS IS and any
    express or implied warranties, including, but not limited to, the
    implied warranties of merchantability and fitness for a particular
    purpose are disclaimed.  In no event shall authors be liable for
    any direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even if
    advised of the possibility of such damage.
  ========================================================================= */

#include <Types.h>

#include "../headers/Config.h"
#include "../headers/Dictionary.h"

Config config;

void
Config::init() {
  spoutConfig.dumpVisionColorArea=0;
  spoutConfig.dumpVisionAvgColor =0;
  spoutConfig.dumpVisionRaw      =0;
  spoutConfig.dumpVisionRLE      =0;
  spoutConfig.dumpVisionObj      =0;
  spoutConfig.dumpVisionRadialMap=0;
  spoutConfig.dumpModelRadialMap =0;
  spoutConfig.dumpModelObj       =0;
  spoutConfig.dumpBehAct         =0;
  spoutConfig.dumpLocalization   =0;
  spoutConfig.dumpGSensor        =0;
  spoutConfig.dumpSharedModelObj =0;
  spoutConfig.dumpRate           =true;
}

void
Config::config(const char *filename) {
  Dictionary cfg_dict;
  cfg_dict.read(filename);

  const char *spout_cfg_file="";
  if(cfg_dict.getValueString("spout_cfg",spout_cfg_file))
    configSPOut(spout_cfg_file);
}

void
Config::configSPOut(const char *filename) {
  Dictionary spout_dict;
  spout_dict.read(filename);

  int enable=0;
  if(spout_dict.getValueInt("dump_vision_avg_color",enable))
    spoutConfig.dumpVisionAvgColor = enable;
  if(spout_dict.getValueInt("dump_vision_color_area",enable))
    spoutConfig.dumpVisionColorArea = enable;
  if(spout_dict.getValueInt("dump_vision_raw",enable))
    spoutConfig.dumpVisionRaw = enable;
  if(spout_dict.getValueInt("dump_vision_rle",enable))
    spoutConfig.dumpVisionRLE = enable;
  if(spout_dict.getValueInt("dump_vision_obj",enable))
    spoutConfig.dumpVisionObj = enable;
  if(spout_dict.getValueInt("dump_vision_radial_map",enable))
    spoutConfig.dumpVisionRadialMap = enable;
  if(spout_dict.getValueInt("dump_model_radial_map",enable))
    spoutConfig.dumpModelRadialMap = enable;
  if(spout_dict.getValueInt("dump_model_obj",enable))
    spoutConfig.dumpModelObj = enable;
  if(spout_dict.getValueInt("dump_beh_act",enable))
    spoutConfig.dumpBehAct = enable;
  if(spout_dict.getValueInt("dump_localization",enable))
    spoutConfig.dumpLocalization = enable;
  if(spout_dict.getValueInt("dump_move_update",enable))
    spoutConfig.dumpMoveUpdate = enable;
  if(spout_dict.getValueInt("dump_rate",enable))
    spoutConfig.dumpRate = (enable != 0);
  if(spout_dict.getValueInt("dump_g_sensor",enable))
    spoutConfig.dumpGSensor = enable;
  if(spout_dict.getValueInt("dump_shared_model_obj",enable))
    spoutConfig.dumpSharedModelObj = enable;
}
