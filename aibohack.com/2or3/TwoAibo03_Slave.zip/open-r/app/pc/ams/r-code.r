// AIBO and Costello (for the 2x0 and 31x)
// SLAVE version

// Requires RCodePlus 250 for AP_AiboSound
//  and old style TDASDATA.BIN (just like Disco AIBO 4)

 // startup
 IF AP_Version < 250 THEN
    HALT
 ENDIF

 PLAY ACTION SIT // initial position
 WAIT

 PLAY ACTION+ BOOT2
 WAIT


:RestartMain
  PLAY ACTION SIT // initial position, just in case
  WAIT

  SET Head_ON 0
  SET Back_ON 0
  SET Tail_U_ON 0
  SET AP_AiboSound 0

:Main
  // Master only initiates conversations

  LOCAL bump 0

  // use back switch (or joystick tail up) to switch to next part
  IF Back_ON > 0 THEN
    // advance to next part
    LET bump 1
    SET Back_ON 0
  ENDIF

  // for ERS-31x
  IF Tail_U_ON != 0 THEN
    LET bump 1
    SET Tail_U_ON 0
  ENDIF

  IF bump != 0 THEN
    ADD part 1
    IF part > 1 THEN
       LET part 0
    ENDIF
    CALL ShowEyesForPart
  ENDIF

  IF AP_AiboSound == 2 THEN // first part of whose on first
    PLAY ACTION+ SLAVE2
    WAIT
    GO RestartMain
  ENDIF

  IF AP_AiboSound == 3 THEN
    PLAY ACTION+ SLAVE3
    WAIT
    GO RestartMain
  ENDIF

  IF AP_AiboSound == 4 THEN // first part of argument
    PLAY ACTION+ SLAVE4
    WAIT
    GO RestartMain
  ENDIF

  IF AP_AiboSound == 5 THEN
    PLAY ACTION+ SLAVE5
    WAIT
    GO RestartMain
  ENDIF

  IF AP_AiboSound == 6 THEN // ni
    IF part == 1 THEN
        WAIT 3000
    ENDIF
    PLAY ACTION+ SLAVE6
    WAIT
    GO RestartMain
  ENDIF

  IF AP_AiboSound == 7 THEN // row row row
    WAIT 2000
    IF part == 1 THEN
        WAIT 4000
    ENDIF
    PLAY ACTION+ SLAVE7
    WAIT
    WAIT 500
    PLAY ACTION+ SLAVE7 // again
    WAIT
    GO RestartMain
  ENDIF

 WAIT 2 // not too long
 GO Main

EXIT

///////////////////////////////////////////////

:ShowEyesForPart
    IF part == 0 THEN
		PLAY ACTION+ G0_EYE2
	    WAIT
    ENDIF
    IF part == 1 THEN
		PLAY ACTION+ G0_EYE3
	    WAIT
    ENDIF
RET

///////////////////////////////////////////////

