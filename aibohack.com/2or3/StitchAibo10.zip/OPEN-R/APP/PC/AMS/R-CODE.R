/////////////////////////////////////////////////////////////
// Stitch RCode Program - by Genie

// Based on RCode 2.51.04+ for Stitch Release

// YART compatible
    // that's what the //{ //} things are for

// "Mini-Obey Cat"
// Mini Obey Cat provide a very basic personality
//  You can customize this using any text editor
//  Please read the comments in this file to figure out what is happening

// NOTES:
// - provides simple functionality using built-in motions and sounds
// - a LAN connection is helpful for debugging
// - works on 2x0 and 31x model AIBOs

/////////////////////////////////////////////////////////////
// Startup

GO Main

/////////////////////////////////////////////////////////////

:Main
    GLOBAL doPrint 0

    VLOAD doPrint       // you can force on for 31x connected to a terminal
    IF AiboId != 0 THEN
        // LAN is connected, print status
        SET doPrint 1
    ENDIF


    GLOBAL debug 0
    VLOAD debug
    IF debug != 0 THEN
        PRINT "DEBUG MODE!"
        SET doPrint 1
    ENDIF

    IF doPrint != 0 THEN
        PRINT "RCode Plus Basic YART Program 2.52 [.??]"
        PRINT "Program will PRINT status information"
    ENDIF

    PRINT "-"

    // initialize the RCODE Runtime 'RCR'
    PUSH doPrint
    CALL RCR_Init:1

    GLOBAL AP_Vocab
    VLOAD AP_Vocab
    GLOBAL AP_VLang
    VLOAD AP_VLang

    IF doPrint != 0 THEN
        PRINT "  AiboType = %d" AiboType
        PRINT "  AP_Version = %d" AP_Version
        PRINT "  AP_Vocab = %d" AP_Vocab
            // program works properly only if AP_Vocab == 0 or 2
        PRINT "  AP_VLang = %d" AP_VLang
            // 3 is English, 2 is Japanese
    ENDIF

    IF AP_Version >= 252 THEN
        AP_DEVCTL 6 1 // enable HFD
        IF doPrint != 0 THEN
            PRINT "HFD module enabled"
        ENDIF
    ENDIF

    //{ "Main/Startup(once)"
        PLAY ACTION LIE // lie down at start
        WAIT
        SET NoFallDown 1 // disable get-up detection
    //}

    // clear globals and sensors

    CLR SENSORS
    LOCAL lastPink 0
    LOCAL lastFav 0
    LOCAL lastUnfav 0
    LOCAL lastHead 0
    LOCAL idleCount 0

    IF debug != 0 THEN
        CALL DoDebugMode
    ENDIF

    // Main Loop
    WHILE 1 = 1

        // Voice and sound
        // do not change the code here
        //  instead edit "????_Handler"

        IF AP_Voice_Cmd > 0 THEN
            PUSH AP_Voice_Cmd
            PUSH AP_Voice_Level
            PUSH AP_Voice_Pitch
            PUSH AP_Voice_Horz
            CALL Voice_Handler:4
            SET AP_Voice_Cmd 0
            LET idleCount 0 
        ENDIF

        IF AP_Loud > 0 THEN
            PUSH AP_Loud_Level
            PUSH AP_Loud_Pitch
            PUSH AP_Loud_Horz
            CALL Loud_Handler:3
            SET AP_Loud 0
            LET idleCount 0 
        ENDIF

        IF AP_Tone > 0 THEN
            PUSH AP_Tone
            CALL AiboTone_Handler:1
            SET AP_Tone 0
            LET idleCount 0 
        ENDIF

        IF AP_AiboSound > 0 THEN
            PUSH AP_AiboSound
            CALL AiboSound_Handler:1
            SET AP_AiboSound 0
            LET idleCount 0 
        ENDIF

        IF AP_Noise > 0 THEN
            CALL Noise_Handler
            SET AP_Noise 0
            LET idleCount 0 
        ENDIF

        IF AP_Rhythm > 0 THEN
            CALL Rhythm_Handler
            SET AP_Rhythm 0
            LET idleCount 0 
        ENDIF

        IF Pink_Ball <> 0 THEN
            IF lastPink == 0 THEN
                PUSH Pink_Ball_H
                PUSH Pink_Ball_V
                PUSH Pink_Ball_D
                CALL PinkBall_Found_Handler:3
                SET lastPink 1
            ENDIF
            PUSH Pink_Ball_H
            PUSH Pink_Ball_V
            PUSH Pink_Ball_D
            CALL PinkBall_Any_Handler:3
            LET idleCount 0 
        ELSE
            IF lastPink != 0 THEN
                CALL PinkBall_Lost_Handler
                SET lastPink 0
                LET idleCount 0 
            ENDIF
        ENDIF

        // other colors
        LOCAL cdtFav // blue level
        LOCAL cdtUnfav // green/yellow
        AP_COLORLVL 4 cdtFav
        AP_COLORLVL 5 cdtUnfav

        IF cdtFav > 20 THEN
            IF lastFav == 0 THEN
                CALL Fav_Found_Handler
                SET lastFav 1
                LET idleCount 0 
            ENDIF
        ELSE
            IF lastFav != 0 THEN
                CALL Fav_Lost_Handler
                SET lastFav 0
                LET idleCount 0 
            ENDIF
        ENDIF

        IF cdtUnfav > 20 THEN
            IF lastUnfav == 0 THEN
                CALL Unfav_Found_Handler
                SET lastUnfav 1
                LET idleCount 0 
            ENDIF
        ELSE
            IF lastUnfav != 0 THEN
                CALL Unfav_Lost_Handler
                SET lastUnfav 0
                LET idleCount 0 
            ENDIF
        ENDIF

        ////////////////////////////////
        // normal sensors

        IF Head_Hit <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Head_Hit"
            ENDIF
            //{ "Sensor All/Head Hit"
                PLAY ACTION+ voice4 // voice4
                WAIT
            //}
            SET Head_Hit 0
            LET idleCount 0 
        ENDIF

        IF Head_Pat <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Head_Pat"
            ENDIF
            //{ "Sensor All/Head Pat"
                PLAY ACTION+ voice3 // voice3
                WAIT
            //}
            SET Head_Pat 0
            LET idleCount 0 
        ENDIF

        IF Head_LONG <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Head_LONG"
            ENDIF
            //{ "Sensor All/Head press long time"
                PLAY ACTION LIE
                WAIT
                PLAY ACTION+ scratch // scratch
                WAIT
            //}
            SET Head_LONG 0
            LET idleCount 0 
        ENDIF

        IF Head_ON <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Head_ON"
            ENDIF
            //{ "Sensor All/Head pressed"
                PLAY ACTION+ mele // mele
                WAIT
            //}
            SET Head_ON 0
            LET idleCount 0 
        ENDIF

        IF Head_OFF <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Head_OFF = %d (ms)" Head_OFF
            ENDIF
            //{ "Sensor All/Head released"
            //}
            SET Head_OFF 0
            LET idleCount 0 
        ENDIF

        IF Back_ON <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Back_ON"
            ENDIF
            //{ "Sensor 2x0/Back pressed"
                PLAY ACTION+ burning // burning
                WAIT
            //}
            SET Back_ON 0
            LET idleCount 0 
        ENDIF

        IF Back_LONG <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Back_LONG"
            ENDIF
            //{ "Sensor 2x0/Back pressed for a long time"
                PLAY ACTION+ voice2 // voice2
                WAIT
            //}
            SET Back_LONG 0
            LET idleCount 0 
        ENDIF

        IF Jaw_ON <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Jaw_ON"
            ENDIF
            //{ "Sensor 2x0/Jaw pressed"
                PLAY ACTION+ voice3 // voice3
                WAIT
            //}
            SET Jaw_ON 0
            LET idleCount 0 
        ENDIF

        IF Jaw_LONG <> 0 THEN
            IF doPrint <> 0 THEN
                PRINT "Sensor: Jaw_LONG"
            ENDIF
            //{ "Sensor 2x0/Jaw pressed for a long time"
                PLAY ACTION+ voice1 // voice1
                WAIT
            //}
            SET Jaw_LONG 0
            LET idleCount 0 
        ENDIF

        // 220 specific sensors
        IF RTail_ON <> 0 THEN
            //{ "Sensor 220/Right Tail button pressed"
                SET Spot 0
            //}
            SET RTail_ON 0
            LET idleCount 0 
        ENDIF

        IF CTail_ON <> 0 THEN
            //{ "Sensor 220/Center Tail button pressed"
                SET Spot 1
            //}
            SET CTail_ON 0
            LET idleCount 0 
        ENDIF

        IF LTail_ON <> 0 THEN
            //{ "Sensor 220/Left Tail button pressed"
                SET Spot 0
            //}
            SET LTail_ON 0
            LET idleCount 0 
        ENDIF

        // 310 specific sensors
        IF Tail_U_ON <> 0 THEN
            //{ "Sensor 31x/Tail pushed up"
                SET Horn_G 1
                SET Horn_O 1
                SET Horn_B 1
            //}
            SET Tail_U_ON 0
            LET idleCount 0 
        ENDIF

        IF Tail_D_ON <> 0 THEN
            //{ "Sensor 31x/Tail pushed down"
                SET Horn_G 0
                SET Horn_O 0
                SET Horn_B 0
            //}
            SET Tail_D_ON 0
            LET idleCount 0 
        ENDIF

        IF Tail_R_ON <> 0 THEN
            //{ "Sensor 31x/Tail pushed right"
            //}
            SET Tail_R_ON 0
            LET idleCount 0 
        ENDIF

        IF Tail_L_ON <> 0 THEN
            //{ "Sensor 31x/Tail pushed left"
            //}
            SET Tail_L_ON 0
            LET idleCount 0 
        ENDIF

        IF Tail_UR_ON <> 0 THEN
            //{ "Sensor 31x/Tail pushed up and right"
            //}
            SET Tail_UR_ON 0
            LET idleCount 0 
        ENDIF

        IF Tail_DR_ON <> 0 THEN
            //{ "Sensor 31x/Tail pushed down and right"
            //}
            SET Tail_DR_ON 0
            LET idleCount 0 
        ENDIF

        IF Tail_UL_ON <> 0 THEN
            //{ "Sensor 31x/Tail pushed up and left"
            //}
            SET Tail_UL_ON 0
            LET idleCount 0 
        ENDIF

        IF Tail_DL_ON <> 0 THEN
            //{ "Sensor 31x/Tail pushed down and left"
            //}
            SET Tail_DL_ON 0
            LET idleCount 0 
        ENDIF

        IF Tail_RollR <> 0 THEN
            //{ "Sensor 31x/Tail rolled right"
            //}
            SET Tail_RollR 0
            LET idleCount 0 
        ENDIF

        IF Tail_RollL <> 0 THEN
            //{ "Sensor 31x/Tail rolled left"
            //}
            SET Tail_RollL 0
            LET idleCount 0 
        ENDIF

        IF Tail_Roll3 <> 0 THEN
            //{ "Sensor 31x/Tail rolled three times"
            //}
            SET Tail_Roll3 0
            LET idleCount 0 
        ENDIF

        IF AP_FaceDetect <> 0 THEN
            // REVIEW: make YART-able later (including Lost)
            PRINT "FACE %d %d" AP_FaceDetect AP_FaceDetect_Horz
            SET AP_FaceDetect 0
            LET idleCount 0 
        ENDIF

        ADD idleCount 1
        IF idleCount > 100 THEN
            LOCAL randVal
            RND randVal 1 5
            IF randVal == 1 THEN
                //{ "Main/Idle for 10sec:Random#1"
                    PLAY ACTION STAND
                    WAIT
                    PLAY ACTION+ voice1 // voice1
                    WAIT
                    PLAY ACTION WALK 0 100
                    WAIT
                    PLAY ACTION+ voice3 // voice3
                    WAIT
                //}
            ENDIF
            IF randVal == 2 THEN
                //{ "Main/Idle for 10sec:Random#2"
                    PLAY ACTION+ voice3 // voice3
                    WAIT
                    PLAY ACTION STAND
                    WAIT
                    PLAY ACTION WALK 0 100
                    WAIT
                    PLAY ACTION+ voice4 // voice4
                    WAIT
                //}
            ENDIF
            IF randVal == 3 THEN
                //{ "Main/Idle for 10sec:Random#3"
                    PLAY ACTION+ voice4 // voice4
                    WAIT
                    PLAY ACTION+ scratch // scratch
                    WAIT
                    PLAY ACTION STAND
                    WAIT
                    PLAY ACTION TURN -90 // Turn Right
                    WAIT
                    PLAY ACTION SIT
                    WAIT
                    PLAY ACTION+ voice2 // voice2
                    WAIT
                //}
            ENDIF
            IF randVal == 4 THEN
                //{ "Main/Idle for 10sec:Random#4"
                    PLAY ACTION+ puppy // puppy
                    WAIT
                    PLAY ACTION+ voice4 // voice4
                    WAIT
                    PLAY ACTION STAND
                    WAIT
                    PLAY ACTION TURN 180 // Turn Around
                    WAIT
                    PLAY ACTION SIT
                    WAIT
                    PLAY ACTION+ voice4 // voice4
                    WAIT
                //}
            ENDIF
            IF randVal == 5 THEN
                //{ "Main/Idle for 10sec:Random#5"
                    PLAY ACTION+ voice1 // voice1
                    WAIT
                    SET Eye_L1 1
                    SET Eye_R1 1
                    SET Eye_L2 1
                    SET Eye_R2 1
                    SET Eye_L3 1
                    SET Eye_R3 1
                    SET Eye_L1 0
                    SET Eye_R1 0
                    SET Eye_L2 0
                    SET Eye_R2 0
                    SET Eye_L3 0
                    SET Eye_R3 0
                    PLAY ACTION+ voice4 // voice4
                    WAIT
                    PLAY ACTION+ voice3 // voice3
                    WAIT
                    PLAY ACTION STAND
                    WAIT
                    PLAY ACTION WALK 0 100
                    WAIT
                    PLAY ACTION SIT
                    WAIT
                    PLAY ACTION+ voice3 // voice3
                    WAIT
                //}
            ENDIF
            LET idleCount 0
        ENDIF

        WAIT 100
    WEND // end of main loop

EXIT

/////////////////////////////////////////////////////////////
// _Handler routines - YART compatible

:Voice_Handler
  ARG id
  ARG level
  ARG pitch
  ARG horz

  IF doPrint <> 0 THEN
    PRINT "Voice_Handler: %d, level=%d, pitch=%d, horz=%d" id level pitch horz
  ENDIF

  IF id == 1 THEN
    //{ "AIBO voice command/'AIBO' or <dog's name>"
        PLAY ACTION+ voice1 // voice1
        WAIT
        PLAY ACTION+ voice4 // voice4
        WAIT
        PLAY ACTION WALK 0 100
        WAIT
    //}
  ENDIF
  IF id == 0x100 THEN
    //{ "AIBO voice command/<owner's name>"
    //}
  ENDIF
  IF id == 2 THEN
    //{ "AIBO voice command/'What's your name?'"
        PLAY ACTION+ voice2 // voice2
        WAIT
        PLAY ACTION+ voice3 // voice3
        WAIT
        PLAY ACTION STAND
        WAIT
        PLAY ACTION TURN 90 // Turn Left
        WAIT
    //}
  ENDIF
  IF id == 3 THEN
    //{ "AIBO voice command/'Say hello'"
        PLAY ACTION+ voice3 // voice3
        WAIT
        PLAY ACTION+ scratch // scratch
        WAIT
        PLAY ACTION STAND
        WAIT
        PLAY ACTION WALK 0 500
        WAIT
        PLAY ACTION TURN 180 // Turn Around
        WAIT
    //}
  ENDIF
  IF id == 4 THEN
    //{ "AIBO voice command/'Shake paw'"
        PLAY ACTION+ voice3 // voice3
        WAIT
        PLAY ACTION+ puppy // puppy
        WAIT
        PLAY ACTION STAND
        WAIT
        PLAY ACTION TURN 90 // Turn Left
        WAIT
        PLAY ACTION WALK 0 500
        WAIT
    //}
  ENDIF
  IF id == 5 THEN
    //{ "AIBO voice command/'Morning'"
        PLAY ACTION+ voice4 // voice4
        WAIT
        PLAY ACTION+ voice1 // voice1
        WAIT
        PLAY ACTION STAND
        WAIT
    //}
  ENDIF
  IF id == 6 THEN
    //{ "AIBO voice command/'Hello'"
        PLAY ACTION+ scratch // scratch
        WAIT
        PLAY ACTION+ voice4 // voice4
        WAIT
        PLAY ACTION+ voice3 // voice3
        WAIT
        SET Eye_L1 1
        SET Eye_R1 1
        SET Eye_L2 1
        SET Eye_R2 1
        SET Eye_L3 1
        SET Eye_R3 1
        SET Eye_L1 0
        SET Eye_R1 0
        SET Eye_L2 0
        SET Eye_R2 0
        SET Eye_L3 0
        SET Eye_R3 0
    //}
  ENDIF
  IF id == 7 THEN
    //{ "AIBO voice command/'Good night'"
        PLAY ACTION+ voice2 // voice2
        WAIT
        SET Eye_L1 1
        SET Eye_R1 1
        SET Eye_L2 1
        SET Eye_R2 1
        SET Eye_L3 1
        SET Eye_R3 1
        SET Eye_L1 0
        SET Eye_R1 0
        SET Eye_L2 0
        SET Eye_R2 0
        SET Eye_L3 0
        SET Eye_R3 0
    //}
  ENDIF
  IF id == 8 THEN
    //{ "AIBO voice command/'See you'"
        PLAY ACTION+ voice4 // voice4
        WAIT
        PLAY ACTION+ voice1 // voice1
        WAIT
    //}
  ENDIF
  IF id == 9 THEN
    //{ "AIBO voice command/'How are you?'"
        PLAY ACTION+ voice1 // voice1
        WAIT
        PLAY ACTION+ voice3 // voice3
        WAIT
    //}
  ENDIF
  IF id == 10 THEN
    //{ "AIBO voice command/'Hey AIBO'"
        PLAY ACTION+ voice2 // voice2
        WAIT
    //}
  ENDIF
  IF id == 11 THEN
    //{ "AIBO voice command/'Thanks'"
        PLAY ACTION+ voice2 // voice2
        WAIT
        PLAY ACTION+ puppy // puppy
        WAIT
        PLAY ACTION CHGPOS_WALK0_STD // {0b:08:00}
        WAIT
    //}
  ENDIF
  IF id == 12 THEN
    //{ "AIBO voice command/'Sorry'"
        PLAY ACTION+ voice4 // voice4
        WAIT
        PLAY ACTION+ voice3 // voice3
        WAIT
        PLAY ACTION STAND
        WAIT
    //}
  ENDIF
  IF id == 13 THEN
    //{ "AIBO voice command/'Cheer up'"
        PLAY ACTION+ voice1 // voice1
        WAIT
        PLAY ACTION STAND
        WAIT
        PLAY ACTION TURN 180 // Turn Around
        WAIT
    //}
  ENDIF
  IF id == 14 THEN
    //{ "AIBO voice command/'Banzai'"
        PLAY ACTION+ voice3 // voice3
        WAIT
    //}
  ENDIF
  IF id == 15 THEN
    //{ "AIBO voice command/'That's right'"
        PLAY ACTION+ voice4 // voice4
        WAIT
    //}
  ENDIF
  IF id == 16 THEN
    //{ "AIBO voice command/'That's wrong'"
        PLAY ACTION+ voice1 // voice1
        WAIT
        PLAY ACTION+ scratch // scratch
        WAIT
    //}
  ENDIF
  IF id == 17 THEN
    //{ "AIBO voice command/'Good AIBO'"
        PLAY ACTION+ voice4 // voice4
        WAIT
        PLAY ACTION+ voice1 // voice1
        WAIT
    //}
  ENDIF
  IF id == 18 THEN
    //{ "AIBO voice command/'Don't do that'"
        PLAY ACTION+ voice3 // voice3
        WAIT
        PLAY ACTION+ puppy // puppy
        WAIT
        PLAY ACTION+ scratch // scratch
        WAIT
    //}
  ENDIF
  IF id == 19 THEN
    //{ "AIBO voice command/'Let's play!'"
        PLAY ACTION+ voice4 // voice4
        WAIT
        PLAY ACTION+ voice3 // voice3
        WAIT
        PLAY ACTION STAND
        WAIT
    //}
  ENDIF
  IF id == 20 THEN
    //{ "AIBO voice command/'Sing a song'"
        PLAY ACTION+ roller // roller
        WAIT
    //}
  ENDIF
  IF id == 21 THEN
    //{ "AIBO voice command/'Dance'"
        PLAY ACTION+ roller // roller
        WAIT
    //}
  ENDIF
  IF id == 22 THEN
    //{ "AIBO voice command/'Show time'"
        PLAY ACTION+ stuck // stuck
        WAIT
    //}
  ENDIF
  IF id == 23 THEN
    //{ "AIBO voice command/'Pose for me'"
        PLAY ACTION+ voice1 // voice1
        WAIT
        SET Eye_L1 1
        SET Eye_R1 1
        SET Eye_L2 1
        SET Eye_R2 1
        SET Eye_L3 1
        SET Eye_R3 1
        SET Eye_L1 0
        SET Eye_R1 0
        SET Eye_L2 0
        SET Eye_R2 0
        SET Eye_L3 0
        SET Eye_R3 0
    //}
  ENDIF
  IF id == 24 THEN
    //{ "AIBO voice command/'Clown around'"
        PLAY ACTION STAND
        WAIT
        PLAY ACTION TURN 180 // Turn Around
        WAIT
    //}
  ENDIF
  IF id == 25 THEN
    //{ "AIBO voice command/'Show off'"
        PLAY ACTION+ stuck // stuck
        WAIT
    //}
  ENDIF
  IF id == 26 THEN
    //{ "AIBO voice command/'Say message'"
        PLAY ACTION+ scratch // scratch
        WAIT
        PLAY ACTION+ voice4 // voice4
        WAIT
    //}
  ENDIF
  IF id == 27 THEN
    //{ "AIBO voice command/'Let's be secret'"
        PLAY ACTION+ voice2 // voice2
        WAIT
        PLAY ACTION+ voice3 // voice3
        WAIT
    //}
  ENDIF
  IF id == 28 THEN
    //{ "AIBO voice command/'Open sesame'"
        PLAY ACTION+ voice2 // voice2
        WAIT
        PLAY ACTION+ voice4 // voice4
        WAIT
    //}
  ENDIF
  IF id == 29 THEN
    //{ "AIBO voice command/'Happy day'"
        PLAY ACTION+ mele // mele
        WAIT
    //}
  ENDIF
  IF id == 30 THEN
    //{ "AIBO voice command/'Stand up'"
        PLAY ACTION STAND
        WAIT
        PLAY ACTION+ voice1 // voice1
        WAIT
    //}
  ENDIF
  IF id == 31 THEN
    //{ "AIBO voice command/'Lie down'"
        PLAY ACTION LIE
        WAIT
        PLAY ACTION+ voice1 // voice1
        WAIT
    //}
  ENDIF
  IF id == 32 THEN
    //{ "AIBO voice command/'Sit down'"
        PLAY ACTION SIT
        WAIT
        PLAY ACTION+ voice2 // voice2
        WAIT
    //}
  ENDIF
  IF id == 33 THEN
    //{ "AIBO voice command/'Turn right'"
        PLAY ACTION TURN -90
        WAIT
        PLAY ACTION+ voice3 // voice3
        WAIT
    //}
  ENDIF
  IF id == 34 THEN
    //{ "AIBO voice command/'Turn left'"
        PLAY ACTION TURN 90
        WAIT
        PLAY ACTION+ voice3 // voice3
        WAIT
    //}
  ENDIF
  IF id == 35 THEN
    //{ "AIBO voice command/'Go forward'"
        PLAY ACTION WALK 0 500
        WAIT
        PLAY ACTION+ voice4 // voice4
        WAIT
    //}
  ENDIF
  IF id == 36 THEN
    //{ "AIBO voice command/'Go backward'"
        PLAY ACTION TURN 180
        WAIT
        PLAY ACTION+ voice3 // voice3
        WAIT
    //}
  ENDIF
  IF id == 37 THEN
    //{ "AIBO voice command/'Go ahead'"
        PLAY ACTION WALK 0 100
        WAIT
        PLAY ACTION+ voice1 // voice1
        WAIT
    //}
  ENDIF
  IF id == 38 THEN
    //{ "AIBO voice command/'Stop'"
        PLAY ACTION+ puppy // puppy
        WAIT
    //}
  ENDIF
  IF id == 39 THEN
    //{ "AIBO voice command/'Faster'"
        PLAY ACTION+ voice1 // voice1
        WAIT
    //}
  ENDIF
  IF id == 40 THEN
    //{ "AIBO voice command/'Slow down'"
    //}
  ENDIF
  IF id == 41 THEN
    //{ "AIBO voice command/'Pink ball'"
    //}
  ENDIF
  IF id == 42 THEN
    //{ "AIBO voice command/'Right leg kick'"
        PLAY ACTION KICK -30 1000
        WAIT
        PLAY ACTION+ voice1 // voice1
        WAIT
    //}
  ENDIF
  IF id == 43 THEN
    //{ "AIBO voice command/'Right leg touch'"
        PLAY ACTION+ voice2 // voice2
        WAIT
    //}
  ENDIF
  IF id == 44 THEN
    //{ "AIBO voice command/'Left leg kick'"
        PLAY ACTION KICK 30 1000
        WAIT
        PLAY ACTION+ voice4 // voice4
        WAIT
    //}
  ENDIF
  IF id == 45 THEN
    //{ "AIBO voice command/'Left leg touch'"
        PLAY ACTION+ voice1 // voice1
        WAIT
    //}
  ENDIF
  IF id == 46 THEN
    //{ "AIBO voice command/'Ready set go'"
        PLAY ACTION+ voice4 // voice4
        WAIT
    //}
  ENDIF
  IF id == 47 THEN
    //{ "AIBO voice command/'You won'"
        PLAY ACTION+ voice3 // voice3
        WAIT
    //}
  ENDIF
  IF id == 48 THEN
    //{ "AIBO voice command/'You lost'"
        PLAY ACTION EMOTION_SAD4_SIT // {20:01:04}
        WAIT
        PLAY ACTION+ voice3 // voice3
        WAIT
    //}
  ENDIF
  IF id == 49 THEN
    //{ "AIBO voice command/'Action one'"
    //}
  ENDIF
  IF id == 50 THEN
    //{ "AIBO voice command/'Action two'"
    //}
  ENDIF
  IF id == 51 THEN
    //{ "AIBO voice command/'Action three'"
    //}
  ENDIF
  IF id == 52 THEN
    //{ "AIBO voice command/'Action four'"
    //}
  ENDIF
  IF id == 53 THEN
    //{ "AIBO voice command/'Action five'"
    //}
  ENDIF
  IF id == 54 THEN
    //{ "AIBO voice command/'I'm here'"
        PLAY ACTION+ puppy // puppy
        WAIT
    //}
  ENDIF
  IF id == 55 THEN
    //{ "AIBO voice command/'Take a picture'"
    //}
  ENDIF
  IF id == 56 THEN
    //{ "AIBO voice command/'Karate chop'"
        PLAY ACTION+ scratch // scratch
        WAIT
    //}
  ENDIF
  IF id == 57 THEN
    //{ "AIBO voice command/'Walk around'"
        PLAY ACTION STAND
        WAIT
        PLAY ACTION WALK 0 100
        WAIT
    //}
  ENDIF
  IF id == 58 THEN
    //{ "AIBO voice command/'Are you tired?'"
        PLAY ACTION+ voice4 // voice4
        WAIT
    //}
  ENDIF
  IF id == 59 THEN
    //{ "AIBO voice command/'Are you hungry?'"
        PLAY ACTION+ voice3 // voice3
        WAIT
    //}
  ENDIF
  IF id == 60 THEN
    //{ "AIBO voice command/'Name registration'"
        CALL RCR_RecordDogsName
    //}
  ENDIF
  IF id == 61 THEN
    //{ "AIBO voice command/'Good boy'"
    //}
  ENDIF
  IF id == 62 THEN
    //{ "AIBO voice command/'Good girl'"
    //}
  ENDIF
  IF id == 63 THEN
    //{ "AIBO voice command/'Bad boy'"
    //}
  ENDIF
  IF id == 64 THEN
    //{ "AIBO voice command/'Bad girl'"
    //}
  ENDIF
  IF id == 65 THEN
    //{ "AIBO voice command/'Let's talk'"
    //}
  ENDIF
  IF id == 66 THEN
    //{ "AIBO voice command/'Be quiet'"
        PLAY ACTION+ scratch // scratch
        WAIT
    //}
  ENDIF
  IF id == 67 THEN
    //{ "AIBO voice command/'What's you owner's name'"
        CALL RCR_SayOwnersName
    //}
  ENDIF
  IF id == 68 THEN
    //{ "AIBO voice command/'Owner registration'"
        CALL RCR_RecordOwnersName
    //}
  ENDIF
  IF id == 69 THEN
    //{ "AIBO voice command/'Function check'"
    //}
  ENDIF

RETURN

///////////////////////

:Loud_Handler
  ARG level
  ARG pitch
  ARG horz

  IF doPrint <> 0 THEN
    PRINT "Loud_Handler: level=%d, pitch=%d, horz=%d" level pitch horz
  ENDIF

  //{ "AIBO hears/loud sound"
      PLAY ACTION+ voice4 // voice4
      WAIT
  //}
RETURN

///////////////////////

:AiboTone_Handler
  ARG id

  IF doPrint <> 0 THEN
    PRINT "AiboTone_Handler: %d" id
  ENDIF

RETURN

///////////////////////

:AiboSound_Handler
  ARG id

  IF doPrint <> 0 THEN
    PRINT "AiboSound_Handler: %d" id
  ENDIF

  //{ "AIBO hears/another AIBO"
      PLAY ACTION+ voice2 // voice2
      WAIT
  //}
RETURN

///////////////////////

:Noise_Handler

  IF doPrint <> 0 THEN
    PRINT "Noise_Handler"
  ENDIF

  //{ "AIBO hears/noise"
      PLAY ACTION+ voice4 // voice4
      WAIT
  //}

RETURN

///////////////////////

:Rhythm_Handler
  IF doPrint <> 0 THEN
    PRINT "Rhythm_Handler"
  ENDIF

  //{ "AIBO hears/music with rhythm"
      PLAY ACTION+ voice2 // voice2
      WAIT
  //}
RETURN

///////////////////////
// Pink Ball

:PinkBall_Found_Handler
  ARG hangle
  ARG vangle
  ARG dist

  IF doPrint <> 0 THEN
    PRINT "PinkBall_Found_Handler (%d %d) %d" hangle vangle dist
  ENDIF

  //{ "AIBO sees/Pink Ball (seen)"
      PLAY ACTION STAND
      WAIT
      PLAY ACTION WALK 0 100
      WAIT
  //}
RETURN

:PinkBall_Lost_Handler
  IF doPrint <> 0 THEN
    PRINT "PinkBall_Lost_Handler (%d %d) %d" hangle vangle dist
  ENDIF
  //{ "AIBO sees/Pink Ball (lost)"
      PLAY ACTION SIT
      WAIT
  //}

RETURN

:PinkBall_Any_Handler // called quite often when tracking
  ARG hangle
  ARG vangle
  ARG dist

  //{ "AIBO sees/Pink Ball (tracking)"
      PLAY ACTION FOLLOW_HEAD4_SLP // {0a:00:04}
      WAIT
  //}

RETURN

///////////////////////

:Fav_Found_Handler
  IF doPrint <> 0 THEN
    PRINT "Fav_Found_Handler"
  ENDIF

  //{ "AIBO sees/Fav Color (seen)"
  //}

RETURN

:Fav_Lost_Handler
  IF doPrint <> 0 THEN
    PRINT "Fav_Lost_Handler"
  ENDIF

  //{ "AIBO sees/Fav Color (lost)"
  //}

RETURN

///////////////////////

:Unfav_Found_Handler
  IF doPrint <> 0 THEN
    PRINT "Unfav_Found_Handler"
  ENDIF

  //{ "AIBO sees/Unfav Color (seen)"
  //}

RETURN

:Unfav_Lost_Handler
  IF doPrint <> 0 THEN
    PRINT "Unfav_Lost_Handler"
  ENDIF

  //{ "AIBO sees/Unfav Color (lost)"
  //}

RETURN


/////////////////////////////////////////////////////////////
:DoDebugMode

    WHILE 1 = 1
        IF AP_FaceDetect > 0 THEN
            PRINT "FACE lvl=%d H=%d V=%d D=%d" AP_FaceDetect AP_FaceDetect_Horz AP_FaceDetect_Vert AP_FaceDetect_Dist
            SET AP_FaceDetect 0
        ENDIF
        IF AP_FaceDetect < 0 THEN
            PRINT "FACE LOST"
            // -level, last H, last V, dist=0
            SET AP_FaceDetect 0
        ENDIF

        WAIT 100

    WEND // end of main loop
RETURN

/////////////////////////////////////////////////////////////
// Include 'RCR' RCode Runtime

#AP_INCLUDE /MS/OPEN-R/APP/PC/AMS/rcrlib.r

/////////////////////////////////////////////////////////////
