Browser23 Browser:

NOTE: works with ERS-210, ERS-220 and ERS-31x AiboWare.

Unzip the program (ABrowser23.exe) and the support DLL (virtaibo2.dll) to the same directory. Run it and let it find the memory stick.

Documentation:
    http://aibohack.com/2or3/browser.htm

----------------------------------------------
History:

Version 3.8
    - Support for Recogition and Human Face database

Version 3.6.02
    - Learning counts for new ERS-31x "B" software

Version 3.6.01
    - Learning counts for AiboPal SE
    - support for new ERS-31x "B" software
    - CDDB dumping and other advanced features

Version 3.4.02
    - fix for name reporting, including AiboLife2 "motion training" names
    - displays all TR.CT color data (even if it isn't used)

Version 3.4
    - reports Life2 style Owner and Registered names
    - minor fixes for advanced browsing
    - new sticks: 310AW09, JU0001/0004 (detection only)

Version 3.3
    - fix for regression - reporting wrong results for AiboLife 1

Version 3.2
    - various reporting fixes

Version 3.1:
    - detects all known memory sticks
    - learning for all AiboLife sticks (210AW01, 220AW01, 310AW01), and 210AW02
    - new 'pvc' AiboWare version technology
    - uses official documented stage names (for 31x, 2x0)
    - even 210 names updated

Version 3.0
    - first release of "ABrowser23"
    - support 210, 31x

....(longer history deleted)

