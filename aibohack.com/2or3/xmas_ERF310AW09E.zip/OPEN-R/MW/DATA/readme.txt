Aibo Pal SE - "XMAS patch"

Includes the 3 encrypted .ODA files as well as ERS-310.MWC and MWCDB.OIF
files from ERF-310AW09J (Japanese "Energetic AIBO")

These files are freely downloadable from the Internet.

They can be safely copyied to an ERF-310AW09E (English "Aibo PAL SE") stick,
since the behavior files are the same.

They only work on a properly keyed ERF-310AW09 stick, so copy protection is maintained.

All applicable copyrights still apply. Read the end-user license agreement
that came with the Aibo Pal SE memory stick.
