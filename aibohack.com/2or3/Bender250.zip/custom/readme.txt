Notes for RCODE custom personality: Bender AIBO

Version 2.0 "A" (for the ERS-210 and ERS-31x)

Contents of the "custom" directory are for documentation only
(these files are not needed to run the AIBO personality)

Also included in this directory:
    readme.txt = this file
    comments.ini = file used by ERS-210 Browser and AiboTool
    Bender20A.be = Master Studio source file for behavior logic
        (email me if you want the much larger .ALB media files)

Credits:
    Behavior - AiboPet
    Sound Samples - the Internet
    Voice Talent - John Di Maggio

--------------------------------------
Master Studio notes:
    * for simple actions, different numbers mean different versions
        For example: "HIT1" and "HIT2" are two ways to react to being hit.
    * for SKIT???? actions, different numbers are parts of the skit.
        For example: SKITDREAM1, SKITDREAM2, SKITDREAM3 and SKITDREAM4
            must be played back in that order
    * Most of the actions and skits are simple, requiring no preparation
        other than having the dog standing up.
    * Some of the skits require sitting or laying down, and additional time
        delays. See the logic in the .be file.
    * Groups are used in the .be file to make it modular.

--------------------------------------
Technical notes:
    For distribution several other additions were made:
    * compressed the .ODA files
    * boot song (Futurama theme)
    * contents of the \CUSTOM directory

--------------------------------------

Website: http://aibopet.com (or) http://aibohack.com
Suggestions/Comments: aibopet@aibohack.com
