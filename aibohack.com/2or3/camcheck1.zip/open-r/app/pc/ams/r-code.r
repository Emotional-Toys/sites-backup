  PRINT "RCode Camera Check and classifier"

  IF AP_Version < 251 THEN
    HALT
  ENDIF

  PLAY ACTION LIE
  WAIT

  GLOBAL cdt 1
  GLOBAL bitmap 2
  AP_DIM cdt 3168 // 88*72 bytes / 2
  AP_DIM bitmap 9531 // 54 byte BMP header + 88*72*3 / 2
  CALL InitBitmapHeader

  PRINT "default settings (999)
  CALL TakePicture

  AP_SAVEIMAGE 999
  CALL ConvertCdt2Bitmap
  AP_SAVEARRAY bitmap "/MS/PHOTOS/SNAP0999.BMP"

  GLOBAL whiteBest -1
  GLOBAL gainBest -1
  GLOBAL shutterBest -1
  GLOBAL countBest -1

  FOR white 1 3
    AP_DEVCTL 1 white
    WAIT 5000 // adjust

    FOR gain 1 3
      AP_DEVCTL 2 gain

      FOR shutter 1 3

        AP_DEVCTL 3 shutter
        WAIT 2000 // let camera adjust to settings

        PRINT "CAPTURE %d %d %d" white gain shutter
        CALL TakePicture

        LET picnum white
        MUL picnum 10
        ADD picnum gain
        MUL picnum 10
        ADD picnum shutter
        // SNAP0wgs.JPG, SNAP0wgs.BMP
        AP_SAVEIMAGE picnum
        CALL ConvertCdt2Bitmap
        AP_SAVEARRAY bitmap "/MS/PHOTOS/SNAP%04d.BMP" picnum

        // figure out the count of matching pixels
        // limit each color range's contribution
        //   so saturated photo won't be picked
        AP_COLORFND cdt 3 x y count1
        IF count1 > 300 THEN
           LET count1 300
        ENDIF
        AP_COLORFND cdt 0x10 x y count2
        IF count2 > 300 THEN
           LET count2 300
        ENDIF
        IF count3 > 300 THEN
           LET count3 300
        ENDIF
        LET count count1
        ADD count count2
        ADD count count3

        IF count > countBest THEN
            PRINT "New BEST %d %d %d - count = %d" white gain shutter count
            LET whiteBest white
            LET gainBest gain
            LET shutterBest shutter
            LET countBest count
        ENDIF

      NEXT
    NEXT
  NEXT

  // re-snap the best one (0000) + text comments
  PRINT "CAPTURE BEST %d %d %d" whiteBest gainBest shutterBest
  AP_DEVCTL 1 whiteBest
  AP_DEVCTL 2 gainBest
  AP_DEVCTL 3 shutterBest
  WAIT 5000

  CALL TakePicture


  AP_SAVEIMAGE 0
  CALL ConvertCdt2Bitmap
  AP_SAVEARRAY bitmap "/MS/PHOTOS/SNAP0000.BMP"

  // text file for the best match
  SET result 3
  AP_DIM result 2 // 3 characters + !
  LET ch1 48
  ADD ch1 whiteBest
  LET ch2 48
  ADD ch2 gainBest
  LET ch3 48
  ADD ch3 shutterBest
  AP_SETB result 0 ch1 ch2 ch3 0x21
  AP_SAVEARRAY result "/MS/PHOTOS/BEST.TXT"

  PRINT "DONE!"

  WAIT 2000

HALT


:InitBitmapHeader
    AP_SETW bitmap  0 0x4d42 0x4a76 0 0
    AP_SETW bitmap  4 0 0x36 0 0x28
    AP_SETW bitmap  8 0 88 0 72
    AP_SETW bitmap 12 0 1 0x18 0
    AP_SETW bitmap 16 0 0x4a40 // rest remain zero
        // bitmap data (BGR) starts at byte offset $36 = 54 (54/2 = 27)
RETURN

// bitmap creation code - using RCODE logic (believe it or not!)
//  cdt = global ARRAY of color input
//  bitmap = global ARRAY to store bitmap
:ConvertCdt2Bitmap
    LOCAL y
    LOCAL x

    LOCAL red1
    LOCAL green1
    LOCAL blue1
    LOCAL red2
    LOCAL green2
    LOCAL blue2

    LOCAL index 9399 // last row
    LOCAL iCdt 0

    FOR y 0 71
      FOR x 0 43
        AP_GETB cdt iCdt blue1 blue2
        ADD iCdt 1
        LET red1 blue1
        LET green1 blue1
        LET red2 blue2
        LET green2 blue2
        AND red1 0x3
        AND blue1 0x10
        AND green1 0x20
        MUL red1 85
        MUL blue1 15
        MUL green1 7
        AND red2 0x3
        AND blue2 0x10
        AND green2 0x20
        MUL red2 85
        MUL blue2 15
        MUL green2 7

        AP_SETB bitmap index blue1 green1 red1 blue2
        ADD index 2
        AP_SETB bitmap index green2 red2
        ADD index 1
      NEXT //x
      SUB index 264 // two rows back
    NEXT //y
RETURN

:TakePicture
  AP_SNAPSHOT
  DO
    WAIT 50
  LOOP WHILE AP_Snap_Ready == 0
  // ignore that one
  AP_SNAPSHOT
  DO
    WAIT 50
  LOOP WHILE AP_Snap_Ready == 0
  AP_GETCOLORARRAY cdt
  PLAY ACTION PHOTOSNAP // camera shutter sound
  WAIT
RETURN
