AEditor23 - Version 4.7

ERS-2x0, ERS-31x, ERS-7 compatible editor

Unzip the program (AEditor23.exe) and the support DLL (virtaibo2.dll) to the same directory.

Documentation:
    http://www.aibohack.com/2or3/editor.htm

----------------------------------------------
History:

Version 4.7.1
- support for ERS-7 servos, editing and playback
- ERS-7 specific LED files not supported (use Skitter)
- ERS-7 specific neck fudged a little
- (use Skitter for more detailed ERS-7 editing)

Version 4.0.1
- lots of little bug fixes for better 310/220 editing
- cleanup of MTN format reading/writing
- new several advanced tweek commands

Version 3.4
- support for 220 motion
- support for limited part edited (head and legs)

Version 3.3
- support for 220 LEDs (limited)
- fix for audio playback bug (especially under WinXP)

Version 3.1 (.01)
- support for 31X and 220 motion formats (fewer servos)
- minimal LED support (waiting for 220 release)

Version 2.1 (.02)
- minor fixes
- add a few more dance steps

Version 2.1 (.01)
- Master Studio friendly
- lots of 210 specific dance steps
- minor UI cleanup
- maintains and can edit PosNames (eg: "a_sit#sit_stand_foo")
- reduce will do more reduction
- allows larger motion files

Version 2.0
- proper joint order and names
- other misc fixes
- non-DEBUG build

----------------------------------------------
