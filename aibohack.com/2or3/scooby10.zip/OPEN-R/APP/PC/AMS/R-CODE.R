:1000	// Main:START
GO:1002
:1002	// Main:STAND
PLAY:ACTION:STAND
WAIT
SET:Head_ON:0
GO:1004
:1003	// Main:Huh
PLAY:ACTION+:huh
WAIT
GO:1002
:1004	// Main:VOICE_RECOG
CALL:1014
CASE:1:GO:1003
CASE:2:GO:1005
CASE:3:GO:1006
CASE:4:GO:1007
CASE:5:GO:1008
CASE:6:GO:1009
CASE:7:GO:1010
CASE:8:GO:1011
CASE:9:GO:1012
CASE:10:GO:1013
EXIT
:1005	// Main:GREETING
PLAY:ACTION+:Hello
WAIT
GO:1002
:1006	// Main:WhatName
PLAY:ACTION+:cheer
WAIT
GO:1002
:1007	// Main:showtime
PLAY:ACTION+:intro1
WAIT
GO:1002
:1008	// Main:Dance
PLAY:ACTION+:scoobdance
WAIT
GO:1002
:1009	// Main:Let_PLay
PLAY:ACTION+:groovy1
WAIT
GO:1002
:1010	// Main:DontDo
PLAY:ACTION+:whimp
WAIT
GO:1002
:1011	// Main:Happy
PLAY:ACTION+:win
WAIT
GO:1002
:1012	// Main:ShowOff
PLAY:ACTION+:greeting
WAIT
GO:1002
:1013	// Main:Morning
PLAY:ACTION+:sniff
WAIT
GO:1002
EXIT
:1014	// Check_sensor:ENTRY
GO:1018
:1015	// Check_sensor:AIBO
RET:1
:1016	// Check_sensor:VOICE_ID?
WAIT:1
IF_1ST:AU_Voice:=:1:1020
GO:1017
:1017	// Check_sensor:WAIT_1SEC
WAIT:1000
GO:1016
:1018	// Check_sensor:INIT
SET:AU_Voice:0
GO:1016
:1019	// Check_sensor:Hello
RET:2
:1020	// Check_sensor:AIBO?
WAIT:1
IF_1ST:AU_Voice_ID:=:1:1015
GO:1021
:1021	// Check_sensor:Hello?
WAIT:1
IF_1ST:AU_Voice_ID:=:6:1019
GO:1024
:1022	// Check_sensor:UN_RECOGNIZE
PLAY:ACTION:WALK:0:100
WAIT
GO:1018
:1023	// Check_sensor:Name
RET:3
:1024	// Check_sensor:WhatName
WAIT:1
IF_1ST:AU_Voice_ID:=:2:1023
GO:1026
:1025	// Check_sensor:Show
RET:4
:1026	// Check_sensor:Show_Time
WAIT:1
IF_1ST:AU_Voice_ID:=:22:1025
GO:1028
:1027	// Check_sensor:Dance
RET:5
:1028	// Check_sensor:ScoobDance
WAIT:1
IF_1ST:AU_Voice_ID:=:21:1027
GO:1030
:1029	// Check_sensor:Play
RET:6
:1030	// Check_sensor:LetsPlay
WAIT:1
IF_1ST:AU_Voice_ID:=:19:1029
GO:1032
:1031	// Check_sensor:dont
RET:7
:1032	// Check_sensor:Dont_do
WAIT:1
IF_1ST:AU_Voice_ID:=:18:1031
GO:1034
:1033	// Check_sensor:HappyDay
RET:8
:1034	// Check_sensor:Happy_Day
WAIT:1
IF_1ST:AU_Voice_ID:=:29:1033
GO:1036
:1035	// Check_sensor:Show_off
RET:9
:1036	// Check_sensor:Showoff
WAIT:1
IF_1ST:AU_Voice_ID:=:25:1035
GO:1038
:1037	// Check_sensor:Mornin
RET:10
:1038	// Check_sensor:Morn
WAIT:1
IF_1ST:AU_Voice_ID:=:5:1037
GO:1022
EXIT
