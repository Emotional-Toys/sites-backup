// AIBO and Costello (for the 2x0 and 31x)
// MASTER version
// Requires RCodePlus 250 for AP_AiboSound
//  and old style TDASDATA.BIN (just like Disco AIBO 4)

 // startup
 IF AP_Version < 250 THEN
    HALT
 ENDIF


 PLAY ACTION SIT // initial position
 WAIT

 PLAY ACTION+ BOOT2
 WAIT

 GLOBAL skit 0
    // 0 = who's on first (MASTER 2, SLAVE 2; MASTER 3; SLAVE 3)
    // 1 = argument (MASTER 4, SLAVE 4; MASTER 5, SLAVE 5)
    // 2 = knights who say "ni" (MASTER 6, SLAVE 6)
    // 3 = row row row (MASTER 7, SLAVE 7; MASTER 8)

:ClearInputs
  PLAY ACTION SIT // initial position, just in case
  WAIT

  SET Head_ON 0
  SET Back_ON 0
  SET Tail_U_ON 0

:Main
  // Master only initiates conversations

  LOCAL bump 0

  // use back switch (or joystick tail up) to switch to next skit
  IF Back_ON > 0 THEN
    // advance to next skit
    LET bump 1
    SET Back_ON 0
  ENDIF

  // for ERS-31x
  IF Tail_U_ON != 0 THEN
    LET bump 1
    SET Tail_U_ON 0
  ENDIF

  IF bump != 0 THEN
    ADD skit 1
    IF skit > 3 THEN
       LET skit 0
    ENDIF
    CALL PreviewSkit
  ENDIF

  IF Head_ON > 0 THEN
    CALL PerformSkit
    WAIT 1000 // wait a second
    GO ClearInputs
  ENDIF

 WAIT 100
 GO Main

EXIT

///////////////////////////////////////////////

:PreviewSkit
    IF skit == 0 THEN
        PLAY ACTION+ G0_EYE0
        PLAY ACTION+ PREVIEW0
        WAIT
    ENDIF
    IF skit == 1 THEN
		PLAY ACTION+ G0_EYE1
        PLAY ACTION+ PREVIEW1
	    WAIT
    ENDIF
    IF skit == 2 THEN
		PLAY ACTION+ G0_EYE5
        PLAY ACTION+ PREVIEW2
	    WAIT
    ENDIF
    IF skit == 3 THEN
		PLAY ACTION+ G0_EYE4
        PLAY ACTION+ PREVIEW3
	    WAIT
    ENDIF
RET

///////////////////////////////////////////////

:PerformSkit

    IF skit == 0 THEN
        // who's on first
        PLAY ACTION+ TONE2
        WAIT
        PLAY ACTION+ MASTER2
        WAIT

        // part 2
        WAIT 2000
        PLAY ACTION+ TONE3
        WAIT
        PLAY ACTION+ MASTER3
        WAIT
    ENDIF

    IF skit == 1 THEN
        // argument
        PLAY ACTION+ TONE4
        WAIT
        PLAY ACTION+ MASTER4
        WAIT

        WAIT 2000
        PLAY ACTION+ TONE5
        WAIT
        PLAY ACTION+ MASTER5
        WAIT
    ENDIF

    IF skit == 2 THEN
        // "ni"
        PLAY ACTION+ TONE6
        WAIT
        PLAY ACTION+ MASTER6
        WAIT
    ENDIF

    IF skit == 3 THEN
        // row row row - solo first
        PLAY ACTION+ MASTER7
        WAIT
        PLAY ACTION+ TONE7
        WAIT
        PLAY ACTION+ MASTER7
        WAIT
        PLAY ACTION+ MASTER7
        WAIT
        PLAY ACTION+ MASTER8
        WAIT
    ENDIF

    // TONE8 and TONE9 not used

RET

///////////////////////////////////////////////

