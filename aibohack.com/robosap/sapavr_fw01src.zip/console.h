
void HandleRxChar(char ch);
void PulsePins_TimerRoutine();
