SapAvr is a AVR90S2313 program that adds additional features
to the existing RoboSapien brain.

The AVR chip intercepts the sensor inputs (2 hands, 2 feet) and IR signal.
It sends control to the original RoboSapien CPU which performs the
actual movements, skits and sounds.

E2PROM:
The chip has 128B E2PROM
We use it for storing enhanced programs
The first 32 bytes are fixed values (see 'e2.h')
The remaining 96 bytes are byte codes for handlers
The data E2PROM has a lifetime of 100,000 erase/write cycles

RAM:
The chip has 128B of RAM. We use very little of this directly.
The C++ compiler allocates this space, and whatever left over is the stack.

PROGRAM FLASH:
The SapAVR program is stored in Flash ROM. Unfortunately there is only 2KB
of space for program. The compiler generates relatively fat code, so
it is easy to fill this up.
See customization #defines in 'sap1.h' for features you can disable
to make everything fit in under 2KB.

PORTS:
See 'ports.txt' and the website for wiring instructions.

From the old board: (signals chopped)
    IR input
	Left hand sensor
	Right hand sensor
	Left foot sensor (both toe and heel)
	Right foot sensor (both toe and heel)

To the old board: (other end of chopped signals)
	IR return (encoded signals trigger standard robosapien skits)
	Left trigger return
	Right trigger return

To external devices:
    Hardware UART (UART1) - reserved for special uses like CMU Cam
    Software UART (UART2) - software 1200 baud for debug console

    3 unused i/o pins (more if you don't need the UARTs)

Sonic sensor is not currently touched

===================
CONSOLE: (debug terminal, debug console, serial to PC)

1200 baud, 8 bit, no handshake


By sending commands to the debug terminal you can control the RoboSapien
This can be used for debugging, or for RF remote control

See webpage for details.

===================
MODES and Enhanced Remote control

See webpage for details.

===================
BUILDING:
    Requires the WinAVR toolset, or at least the avr-gcc compiler and other
        command line tools.

    To build:
    ---------
    make clean
    make


    The resulting file is 'sapavr.hex' which can be programmed to the chip.

===================
