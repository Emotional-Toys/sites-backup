// camera glue for CMU Cam
// connected to UART1

#include "sap1.h"

// dump camera data
//  dump entire buffer and clear it - assumes no input during dump
#if CAMERA_SUPPORT

static void PrintCharOrHex(byte b)
{
    if (b == 0xD)
    {
        PrintEOL();
    }
    else if (b >= 0x20 && b < 0x7F)
    {
        PrintChar(b);
    }
    else
    {
        PrintChar('[');
        PrintHex(b);
        PrintChar(']');
    }
}

void ReportCameraReply()
{
    if (!(flagsreg_2 & FLAGS2_uart1_eol))
        return; // no EOL yet
    PrintChar('+');
    for (byte i = 0; i < gUart1_rxcount; i++)
        PrintCharOrHex(gUart1_buffer[i]);
    gUart1_rxcount = 0;
    flagsreg_2 &= ~FLAGS2_uart1_eol;
}
#endif

