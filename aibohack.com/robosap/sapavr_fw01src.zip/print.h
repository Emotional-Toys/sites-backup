

void PrintStringP(const prog_char* string);
void PrintEOL();

#define PrintChar PrintChar_UART2

#define PrintString(sz) \
    { \
	    static char __tmp[] PROGMEM = sz; \
        PrintStringP(__tmp); \
    }

// misc hex dump
void PrintHex(byte val);
void PrintHex4(byte nib);
void PrintHexSpace(byte val);

byte CvtCharToNibble(byte ch);
