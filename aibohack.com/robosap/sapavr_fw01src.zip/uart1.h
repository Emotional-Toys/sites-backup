void SendChar_UART1(byte chOut);

#define UART1RX_SIZE 32
extern byte gUart1_rxcount;
extern byte gUart1_buffer[UART1RX_SIZE];
