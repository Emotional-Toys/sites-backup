///////////////////////////////////////////////

#include "sap1.h"
#include <avr/pgmspace.h>   // for constant strings

///////////////////////////////////////////////

void PrintEOL()
{
    PrintChar(13);
    PrintChar(10);
}

void PrintHex4(byte nib)
{
    nib = (nib & 15) + '0';
    if (nib > '9')
        nib += 7;
    PrintChar(nib);
}

void PrintHex(byte arg0)
{
    PrintHex4(arg0 >> 4);
    PrintHex4(arg0);
}
void PrintHexSpace(byte arg0)
{
    PrintHex(arg0);
    PrintChar(' ');
}

void PrintStringP(const prog_char* string)
{
    while (1)
    {
        char ch = __LPM(string); // data in program/code space
        if (ch == 0)
            return;
        PrintChar(ch);
        string++;
    }
}

///////////////////////////////////////////////
// simple input

byte CvtCharToNibble(byte ch)
{
    if (ch >= '0' && ch <= '9')
        return ch - '0';
    else if (ch >= 'A' && ch <= 'F')
        return ch - 'A' + 10;
    else if (ch >= 'a' && ch <= 'f')
        return ch - 'a' + 10;
    else
        return 255;
}


///////////////////////////////////////////////

