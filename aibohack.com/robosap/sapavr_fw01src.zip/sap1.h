/////////////////////////////////////////////////
// sap1.h - include pretty much everything

/////////////////////////////////////////////////
// customizable

#define FULL_CMDS 1
    // disable all commands if we run out of space

// turn off to make program smaller
#define CAMERA_SUPPORT 0
#define UART1_SUPPORT 0

/////////////////////////////////////////////////


#if !defined(__AVR_AT90S2313__)
#error !Bad device
#endif

#include <inttypes.h>
#define byte uint8_t

#include <avr/io.h>
#include <avr/pgmspace.h> // for read-only strings

#ifndef __USING_MINT8
//#error "please use -mint8 for smaller code"
#endif

/////////////////////////////////////////////////
// Register conventions:
// fixed: r0 - temp, r1 = 0
// not saved: r18-r27, r30,r31
        // (C routines may use, assembler routines don't need to save)
        // special: r24 or (r25:r24) = first arg and return arg
// saved: r2-r17, r28,r29
        // (assembler routines must save)
        // special: r29:r28(Y) is frame pointer

/////////////////////////////////////////////////
// overall globals

register byte flagsreg_1 asm("r2");
#define FLAGS1_echomode _BV(0)
#define FLAGS1_behaviormode _BV(1)

register byte flagsreg_2 asm("r16");
#define FLAGS2_irin_lastbit _BV(0)
#define FLAGS2_special_shift _BV(1)
#define FLAGS2_uart1_eol _BV(2)

extern byte volatile gTicker;

/////////////////////////////////////////////////
// assembler usage (in interrupts)

// REVIEW: clean this up, use "Z" globals for some things
register byte assy1 asm("r3");
register byte assy2 asm("r4");
register byte assy3 asm("r5");
register byte assy4 asm("r6");
register byte assy5 asm("r7");
register byte assy6 asm("r8");
register byte assy7 asm("r17");

/////////////////////////////////////////////////
// other subsystems

#include "ports.h"
#include "e2.h"

#include "util.h"
#include "uart1.h"
#include "uart2.h"
#include "print.h"

#include "ir.h"
#include "ir_codes.h"
#include "execute.h"

#include "console.h"
#include "camera.h"

/////////////////////////////////////////////////
// for interrupts, use "SIGNAL" macro (only saves SREG, R0 and R1, no sei)

#include <avr/interrupt.h>
#include <avr/signal.h>

/////////////////////////////////////////////////
