
// routines in assembler
extern "C"
{
void PrintChar_UART2(byte chOut);
byte GetChar_UART2();

void Uart2In_TimerRoutine(); // 9600 Hz
void Uart2Out_TimerRoutine(); // 9600 Hz
}
