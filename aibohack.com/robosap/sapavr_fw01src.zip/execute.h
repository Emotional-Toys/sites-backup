void ExecuteOps(byte index);
void ExecuteOps_Indirect(byte index);

