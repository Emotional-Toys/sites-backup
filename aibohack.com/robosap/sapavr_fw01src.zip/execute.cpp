#include "sap1.h"

#define TRACE_EXECUTE 1

void ExecuteOps(byte index)
{
    while (1)
    {
	    if (index < E2_dynamic_base || index >= E2_dynamic_end)
	    {
#if TRACE_EXECUTE
	        PrintString("ExOps err\n\r");
#endif
	        return;
	    }
        byte opc = Read_E2PROM(index++);
#if TRACE_EXECUTE
		PrintHex(opc);
#endif
        if (opc == 0xFF)
        {
#if TRACE_EXECUTE
			PrintEOL();
#endif
            return; // done
        }
        if (opc >= 0x80)
            SendIROut(opc);
        else
            Wait100ms(opc);
    }
}

void ExecuteOps_Indirect(byte indexIndirect)
{
#if TRACE_EXECUTE
    PrintChar('v');
    PrintHex(indexIndirect);
#endif
    ExecuteOps(Read_E2PROM(indexIndirect));
}


/////////////////////////////////////////////////////////////////
