void ReportCameraReply();
