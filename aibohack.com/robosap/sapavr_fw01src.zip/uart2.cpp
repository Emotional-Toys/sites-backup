// Software UART (Uart2)

#include "sap1.h"

//REVIEW: use assembler version (smaller)

struct UART2_GLOBALS
{
    // sending
	byte txcount1; // tick count
	byte txstate;
	byte txdatatmp;

    // receiving
	byte rxstate;     // 0=> wait for start bit, 1 = in middle of start bit
	byte rxcount1;
	byte rxcount_lo;
	byte rxdatatmp;

	byte rxdata;      // final data (clear when processed)

    // REVIEW - use buffer like UART1

};

//REVIEW: how to get this to use 16bit load/store efficiently?
#if 0
UART2_GLOBALS* GetPtr() {
    static UART2_GLOBALS g;
	return &g;
}
#else
static UART2_GLOBALS gUART2_GLOBALS;
#define GetPtr() &gUART2_GLOBALS
#endif

#define PREP_UART2_GLOBALS(gP) register UART2_GLOBALS volatile* gP = GetPtr()

///////////////////////////////////////////////////////////////////
// software UART
// 1200 baud data rate
// interrupt handler called at 8X that rate (9600 Hz)

// REVIEW - hard coded "8" everywhere, make more adaptable

void PrintChar_UART2(byte chOut)
{
    PREP_UART2_GLOBALS(gP);
    while (gP->txstate != 0)
        ;
    gP->txdatatmp = chOut;
    gP->txcount1 = 1; // startup case
    gP->txstate = 12;
}

void Uart2Out_TimerRoutine()
{
    PREP_UART2_GLOBALS(gP);

    if (gP->txstate == 0)
    {
        // UART2 not active (keep pin high)
        SET_B(PORTB_TXD_UART2);
        return;
    }

    if (--gP->txcount1 != 0)
        return; // no state change
    
	// txcount1 down to zero, change state
    gP->txcount1 = 8; // 8X clock rate

    byte newState = --gP->txstate;
    if (newState == 11)
    {
        // start bit
        CLR_B(PORTB_TXD_UART2);
        return;
    }

    if (newState <= 2)
    {
        // stop bit[s] or finally done
        SET_B(PORTB_TXD_UART2);
        return;
    }
    // send a data bit
    byte data = gP->txdatatmp;
    if (data & 1)
        SET_B(PORTB_TXD_UART2);
    else
        CLR_B(PORTB_TXD_UART2);
    gP->txdatatmp = (data >> 1);
}

/////////////////////////////////////////////////


byte GetChar_UART2()
{
    PREP_UART2_GLOBALS(gP);
    register byte val = gP->rxdata;
    if (val != 0)
        gP->rxdata = 0;
    return val;
}

void Uart2In_TimerRoutine() // 9600 Hz = 8X
{
    PREP_UART2_GLOBALS(gP);
    byte state = gP->rxstate;
    if (state == 0)
    {
        // wait for start bit
        if (PIN_B(PORTB_RXD_UART2))
            return; // pin high, no start bit
	    gP->rxstate = 1;    // start state machine
	    gP->rxcount1 = 7;
	    gP->rxcount_lo = 1;
        return;
    }

    // procesing
	if (!PIN_B(PORTB_RXD_UART2))
	    gP->rxcount_lo++; // count low bits

    if (--gP->rxcount1 != 0)
        return; // more bits to do
    byte locount = gP->rxcount_lo;

    // advance state machine, prep for next time
    state++;
    gP->rxstate = state;
    gP->rxcount1 = 8; // reload for next time
    gP->rxcount_lo = 0; // for next time
    
    if (state == 2)
    {
        // validate start bit
        if (locount < 5)
		    gP->rxstate = 0;    // start over
        return;
    }

    // another data bit (lsb sent first)
    byte data = gP->rxdatatmp;
    data = (data >> 1);
    if (locount < 4)
        data |= 0x80;
    gP->rxdatatmp = data;

    if (state != 1+8+1)
        return; // more to go

    // all 8 data bits - don't bother with stop bits
//REVIEW: change to buffer
    gP->rxdata = gP->rxdatatmp;
    gP->rxstate = 0;    // start over
}


//////////////////////////////////////

