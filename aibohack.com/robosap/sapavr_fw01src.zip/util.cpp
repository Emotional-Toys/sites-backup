#include "sap1.h"

byte Read_E2PROM(byte index)
{
    EEAR = index;
    EECR |= _BV(EERE);
        // don't bother to poll
    asm("NOP"); // not needed?
    return EEDR;
}

void Write_E2PROM(byte index, byte val)
{
    EEAR = index;
    EEDR = val;
    cli();
        EECR |= _BV(EEMWE);
        EECR |= _BV(EEWE); // start write process
    sei();

    while (EECR & _BV(EEWE))
        ;
}

void Wait100ms(byte count)
{
    do
    {
        byte rep = 4;
        do 
        {
            gTicker = 240;
			while (gTicker != 0)
		        ;
        }
        while (--rep);
	}
    while (--count);
}

