extern byte gLastIR;

// routines in assembler
extern "C"
{
void SendIROut(byte ircode);

void PollIRIn_TimerRoutine();
void PulseIROut_TimerRoutine();

}

