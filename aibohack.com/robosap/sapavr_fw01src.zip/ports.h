// AVR Port pins for SapAvr modification

#if !defined(__AVR_AT90S2313__)
#error !Bad device
#endif

// port index bits, use _BV() macro for byte values

#define PORTB_L1IN 0 // feet
#define PORTB_R1IN 1
#define PORTB_L2IN 2 // hands
#define PORTB_R2IN 3
        // all 4 open collector, with pullups turned on
        // low => switch closed
// #define PORTB_LED_DETECT 4
#define PORTB_RXD_UART2 5 // software UART
#define PORTB_TXD_UART2 6
//#define PORTB_RESERVED 7


#define PORTD_RXD_UART1 0 // hardware UART
#define PORTD_TXD_UART1 1
#define PORTD_IRIN 2 // low when signal detected
// #define PORTD_RESERVED 3
#define PORTD_LOUT 4 // high for on
#define PORTD_ROUT 5 // high for on
#define PORTD_IROUT 6 // normally high
// there is no PORTD pin 7

///////////////////////////////

#define SET_BIT(port, bit) port |= _BV(bit)
#define CLR_BIT(port, bit) port &= ~_BV(bit)
#define CHECK_BIT(port, bit) (port & _BV(bit))

#define SET_B(bit) SET_BIT(PORTB, bit)
#define CLR_B(bit) CLR_BIT(PORTB, bit)
#define PIN_B(bit) CHECK_BIT(PINB, bit)
#define SET_D(bit) SET_BIT(PORTD, bit)
#define CLR_D(bit) CLR_BIT(PORTD, bit)
#define PIN_D(bit) CHECK_BIT(PIND, bit)

///////////////////////////////
