// debug console command handler
///////////////////////////////////////////////

#include "sap1.h"


struct CONSOLE_GLOBALS
{
    byte E2PROM_address;
	byte cmd_in_progress;
        // 0 at start of command
        // command character if waiting for 1 or 2 byte arg
	byte cmd_in_status;
        // 0 if waiting for first of 2 hex character byte arg
        // != 0 if second/last hex character (+1)
	byte pulse_count_L;
        // for 1/9600 pulse
	byte pulse_count_R;
        // for 1/9600 pulse
};

static CONSOLE_GLOBALS gCONSOLE_GLOBALS;
#define PREP_CONSOLE_GLOBALS(gP) register CONSOLE_GLOBALS* gP = &gCONSOLE_GLOBALS

///////////////////////////////////////////////


static void HandleCmd(byte cmd);
static void HandleCmd2(byte cmd, byte data);

void HandleRxChar(char chIn)
{
    PREP_CONSOLE_GLOBALS(gP);

    byte cmd = gP->cmd_in_progress;
    if (cmd != 0)
    {
#if CAMERA_SUPPORT
	    if (cmd == 'C')
        {
            SendChar_UART1(chIn);
            // echo to CMU Cam
            if (chIn == '\r')
                gP->cmd_in_progress = 0;    // exit echo mode
            return;
        }
#endif
        // otherwise hex input cases
        byte nib = CvtCharToNibble(chIn);
        if (nib == 255)
        {
            PrintString("ERR\r\n");
			gP->cmd_in_progress = 0;    // abend
            return;
        }
        if (gP->cmd_in_status == 0)
        {
            // first of 2 bytes
            gP->cmd_in_status = (nib << 4) | 1; // non-zero
            return;
        }
        byte data = (gP->cmd_in_status ^ 1) | nib;
        gP->cmd_in_progress = 0;
        HandleCmd2(cmd, data);
    }
    else
    {
        gP->cmd_in_status = 0;
        if (chIn == 'O' ||
#if FULL_CMDS
            chIn == 'R' || chIn == 'L' ||
#endif
            chIn == 'A' || chIn == 'W' ||
            chIn == '=' ||
#if CAMERA_SUPPORT
            chIn == 'C' ||
#endif
            chIn == 'T')
        {
            // cmd with byte arg (C special case)
		    gP->cmd_in_progress = chIn;
            gP->cmd_in_status = 0;
        }
        else if (chIn == 'E' || chIn == 'V' || chIn == '*')
        {
            // cmd with nib arg
		    gP->cmd_in_progress = chIn;
            gP->cmd_in_status = 1;
        }
        else
        {
	        HandleCmd(chIn);
        }
    }
}

static void FullDump();

static void HandleCmd(byte cmd)
{
    PREP_CONSOLE_GLOBALS(gP);

    if (cmd == '?')
    {
        FullDump();
    }
    else if (cmd == '\r')
    {
        PrintEOL();
    }
#if FULL_CMDS
    else if (cmd == 'P')
    {
        PrintString("POLL: ");
        PrintHexSpace(PINB);
        PrintHexSpace(PORTB);
        PrintHexSpace(PIND);
        PrintHex(PORTD);
        PrintEOL();
    }
#endif
    else if (cmd == 'I')
    {
        PrintString("IR: ");
        byte ir = gLastIR;
        gLastIR = 0;
        PrintHex(ir);
        PrintEOL();
    }
    else if (cmd == 'D')
    {
        PrintHex(gP->E2PROM_address);
        PrintChar(':');
        PrintHex(Read_E2PROM(gP->E2PROM_address));
        PrintEOL();
		gP->E2PROM_address++;
    }
#if FULL_CMDS && 0
    else if (cmd == 'U')
    {
        // repeat U until interrupted
        while (GetChar_UART2() == 0)
            PrintChar_UART2('U');
    }
#endif
    else if (cmd == 't')
    {
        // put immediate test command here
    }
    else
    {
        PrintString("Bad cmd: ");
        PrintHex(cmd);
        PrintEOL();
    }
}


static void HandleCmd2(byte cmd, byte data)
{
// only for special arg commands!!!

    PREP_CONSOLE_GLOBALS(gP);
    if (cmd == 'O')
    {
	    SendIROut(data);
    }
#if FULL_CMDS
    else if (cmd == 'R')
    {
        gP->pulse_count_R = data;
    }
    else if (cmd == 'L')
    {
        gP->pulse_count_L = data;
    }
#endif
    else if (cmd == 'E')
    {
        // sets all flag bits - only valid for E0, E1, E2
	    flagsreg_1 = data; // not stored in EPROM
    }
    else if (cmd == 'A')
    {
        gP->E2PROM_address = data;
    }
    else if (cmd == 'W')
    {
		Write_E2PROM(gP->E2PROM_address, data);
		gP->E2PROM_address++;
    }
    else if (cmd == 'V')
    {
		Write_E2PROM(data, gP->E2PROM_address);
    }
    else if (cmd == '=')
    {
        ExecuteOps(data);
    }
    else if (cmd == '*')
    {
        ExecuteOps_Indirect(data);
    }
    else if (cmd == 'T')
    {
        // put 1 byte test command here
    }
    else
    {
        // internal error - ignore
    }
}

static void FullDump()
{
    PrintString("  flags : ");
    PrintHexSpace(Read_E2PROM(E2_flags1));
    PrintHexSpace(flagsreg_1);
    PrintHex(flagsreg_2);
    PrintEOL();

    for (byte vBase = E2_proc_startup; vBase <= E2_proc_cam6; vBase++)
    {
		byte index = Read_E2PROM(vBase);
        if (index == 0xFF)
            continue;   // skip
        PrintString(" V[");
        PrintHex4(vBase);
        PrintString("] =");
        PrintHex(index);
        PrintString(" => ");
        while (1)
        {
            byte op = Read_E2PROM(index++);
            if (op == 0xFF)
                break;
            PrintHexSpace(op);
        }
        PrintEOL();
    }
    PrintEOL();
}


///////////////////////////////////////////////

#if FULL_CMDS
// R and L only work properly if echo is off
void PulsePins_TimerRoutine()
{
    PREP_CONSOLE_GLOBALS(gP);
    if (gP->pulse_count_L != 0)
    {
        SET_D(PORTD_LOUT);
        if (--gP->pulse_count_L == 0)
	        CLR_D(PORTD_LOUT);
    }
    if (gP->pulse_count_R != 0)
    {
        SET_D(PORTD_ROUT);
        if (--gP->pulse_count_R == 0)
	        CLR_D(PORTD_ROUT);
    }
}
#endif

///////////////////////////////////////////////
