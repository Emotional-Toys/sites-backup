
byte Read_E2PROM(byte index);
void Write_E2PROM(byte index, byte val);
void Wait100ms(byte count);

