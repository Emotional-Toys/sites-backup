// main entry procs
#define E2_proc_startup 0x00
#define E2_proc_main1 0x01
#define E2_proc_main2 0x02
#define E2_proc_main3 0x03
#define E2_proc_main4 0x04
#define E2_proc_main5 0x05

#define E2_proc_leftarm 0x06
#define E2_proc_leftfoot 0x07
#define E2_proc_rightarm 0x08
#define E2_proc_rightfoot 0x09
// no sonic (yet?)

// Camera (color detect, motion detect)
#define E2_proc_cam1 0x0A
#define E2_proc_cam2 0x0B
#define E2_proc_cam3 0x0C
#define E2_proc_cam4 0x0D
#define E2_proc_cam5 0x0E
#define E2_proc_cam6 0x0F

#define E2_flags1  0x10
    // echo mode etc

#define E2_last_record_index 0x11
    // for IR remote programming

// 15 other bytes reserved

///////////////////////////////////////////////////

#define E2_dynamic_base 0x20
    // $20 -> $7F (96 bytes) for handler op strings

#define E2_dynamic_end 0x7F
    // end of E2PROM

///////////////////////////////////////////////////
