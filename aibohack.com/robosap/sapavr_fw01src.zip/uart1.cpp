// UART1 - hardware UART

#include "sap1.h"

#if UART1_SUPPORT // entire file

byte gUart1_rxcount;
byte gUart1_buffer[UART1RX_SIZE];


void SendChar_UART1(byte chOut)
{
    while (!CHECK_BIT(USR, UDRE))
        ; // transmit buffer not yet ready/empty
    UDR = chOut;
}

// Uart Receive
SIGNAL(SIG_UART_RECV)
{
    //NOTE: saves a ton of registers...

    byte chIn = UDR;
    byte count = gUart1_rxcount;
    if (count >= UART1RX_SIZE)
    {
	    flagsreg_2 |= FLAGS2_uart1_eol; // mark as full
        return; // no room
    }

    if (flagsreg_2 & FLAGS2_uart1_eol)
        return; // EOL hit - don't fill more

    gUart1_buffer[count] = chIn;
    gUart1_rxcount = count+1;
    if (chIn == 0xD)
	    flagsreg_2 |= FLAGS2_uart1_eol; // stop filling
}

/////////////////////////////////////////////////////////////////

#endif // UART1_SUPPORT entire file

