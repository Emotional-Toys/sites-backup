// SapAvr - in C


///////////////////////////////////////////////

#include "sap1.h"

#define VERSION_STRING "C.03"

///////////////////////////////////////////////
// forward
void BehaviorMode1();
void SimpleEchoMode();

// other globals (were in RAM)

#if 0 // now register
byte flagsreg_1;
byte flagsreg_2;
#endif

byte volatile gTicker;

///////////////////////////////////////////////

static void ioinit()
{
    // Timer 0 - 4MHz / 8 / 52 = 9615Hz
    TCNT0 = 256-52;
    TCCR0 = 2; // CK/8
    TIMSK = _BV(TOIE0); // timer0 enable

    // Port B and D - various inputs/outputs (see ports.txt)
    DDRB = _BV(PORTB_TXD_UART2); // mostly inputs
    PORTB = _BV(PORTB_TXD_UART2) |
	    _BV(PORTB_R2IN) | _BV(PORTB_L2IN) |
	    _BV(PORTB_R1IN) | _BV(PORTB_L1IN);
    DDRD = _BV(PORTD_IROUT) |
        _BV(PORTD_ROUT) | _BV(PORTD_LOUT) |
        _BV(PORTD_TXD_UART1);
    PORTD = _BV(PORTD_IROUT) | _BV(PORTD_TXD_UART1);

#if UART1_SUPPORT
    // Harware UART (Uart1) - 2400 baud for CMU Cam2 (jumpers required)
    UBRR = 103;
    UCR = _BV(RXCIE) | _BV(RXEN) | _BV(TXEN);
    USR &= ~_BV(RXC);   // purge any receive
#endif
    sei();

    flagsreg_1 = Read_E2PROM(E2_flags1);
    if (flagsreg_1 == 0xFF)
        flagsreg_1 = FLAGS1_echomode;   // start in echo mode
}

extern "C" void __init()
{
    // light-weight prologue
    asm("eor __zero_reg__,__zero_reg__");
    asm("out __SREG__,__zero_reg__"); // SREG
    asm("ldi r28,0xDF"); // frame pointer
    asm("ldi r29,0");
    asm("out __SP_L__,r28"); // no SP_H
    // REVIEW: r29:r28 reserved for frame pointer (wasteful)

    // lame - zero init all SRAM
    byte* pb = (byte*)0x60;
    byte count = 128;
    while (count--)
        *pb++ = 0;

    ioinit();

    PrintEOL();
    PrintString("SapAvr " VERSION_STRING "\r\n");
    // PrintString(": (c) 2004 RoboSapienPet\r\n");
    PrintEOL();

    if (flagsreg_1 & FLAGS1_behaviormode)
        ExecuteOps_Indirect(E2_proc_startup);

    while (1)
    {
#if CAMERA_SUPPORT
        ReportCameraReply();
#endif

        if (flagsreg_1 & FLAGS1_echomode)
	        SimpleEchoMode();

        if (flagsreg_1 & FLAGS1_behaviormode)
		    BehaviorMode1();

        byte ch = GetChar_UART2();
        if (ch != 0)
            HandleRxChar(ch);
    }
}


///////////////////////////////////////////////////////////////
// simple echo mode

void SimpleEchoMode()
{
    byte outd = PORTD & ~(_BV(PORTD_LOUT) | _BV(PORTD_ROUT) | _BV(PORTD_IROUT));
    // either L1IN or L2IN low => LOUT high

    if (!PIN_B(PORTB_L1IN))
        outd |= _BV(PORTD_LOUT);
    if (!PIN_B(PORTB_L2IN))
        outd |= _BV(PORTD_LOUT);
    if (!PIN_B(PORTB_R1IN))
        outd |= _BV(PORTD_ROUT);
    if (!PIN_B(PORTB_R2IN))
        outd |= _BV(PORTD_ROUT);

    if (PIND & _BV(PORTD_IRIN))
        outd |= _BV(PORTD_IROUT);
    PORTD = outd;
}

///////////////////////////////////////////////////////////////

void Whoops()
{
    PrintString("WHOOPS!\n\r");
    SendIROut(IR_OOPS);
}

///////////////////////////////////////////////////////////////
// recording sequences with remote

byte record_index; // 0 when not recording

bool Record1(byte bAdd)
{
    if (record_index < E2_dynamic_base)
        return false;
    if (record_index >= E2_dynamic_end)
        return false;
	Write_E2PROM(record_index, bAdd);
    record_index++;
    return true;
}

void StartRecording(byte proc_entry)
    // reports 'Whoops' on error
{
    if (record_index != 0)
    {
        // already recording
        Whoops();
        return;
    }
	record_index = Read_E2PROM(E2_last_record_index);
	if (record_index == 0xFF)
		record_index = E2_dynamic_base; // init case
    if (!Record1(0xFF))
    {
        // no room to add more
        record_index = 0;
        Whoops();
        return;
    }
    record_index--; // move start pointer back
	Write_E2PROM(proc_entry, record_index);
}

void StopRecording()
{
    if (!Record1(0xFF))
    {
        record_index--;
	    Record1(0xFF); // may not work
        Whoops();
    }
	Write_E2PROM(E2_last_record_index, record_index);
    record_index = 0;   // off
}

bool RecordIr(byte ir)
    // reports 'Whoops' on error
{
    // REVIEW: add timing - 4 second delay for now
    byte time_gap = 4*10;
    if (!Record1(time_gap) || !Record1(ir))
    {
        Whoops();
        StopRecording(); // maybe double whoops
    }
}

///////////////////////////////////////////////////////////////
//  Standard behavior mode
    // IR remote codes get repeated, unless filtered
    // 4 switch sensors trigger E2PROM routines
    // Echo should be turned off

// the 5 main routines use the 5 direction pad
//   (Fwd, Right(leftside), Stop, Left(rightside), Bwd)
#define IRX_MAIN1 IR_WALK_FORWARD
#define IRX_MAIN2 IR_TURN_RIGHT
#define IRX_MAIN3 IR_STOP
#define IRX_MAIN4 IR_TURN_LEFT
#define IRX_MAIN5 IR_WALK_BACKWARD

static void HandleSpecialIR(byte ir)
{
    // 5 main execute routines
    if (ir == IRX_MAIN1)
    {
        ExecuteOps_Indirect(E2_proc_main1);
    }
    else if (ir == IRX_MAIN2)
    {
        ExecuteOps_Indirect(E2_proc_main2);
    }
    else if (ir == IRX_MAIN3)
    {
        ExecuteOps_Indirect(E2_proc_main3);
    }
    else if (ir == IRX_MAIN4)
    {
        ExecuteOps_Indirect(E2_proc_main4);
    }
    else if (ir == IRX_MAIN5)
    {
        ExecuteOps_Indirect(E2_proc_main5);
    }
    else if (ir == IRX_MAIN1 + GREEN_SHIFT)
    {
        StartRecording(E2_proc_main1);
    }
    else if (ir == IRX_MAIN2 + GREEN_SHIFT)
    {
        StartRecording(E2_proc_main2);
    }
    else if (ir == IRX_MAIN3 + GREEN_SHIFT)
    {
        StartRecording(E2_proc_main3);
    }
    else if (ir == IRX_MAIN4 + GREEN_SHIFT)
    {
        StartRecording(E2_proc_main4);
    }
    else if (ir == IRX_MAIN5 + GREEN_SHIFT)
    {
        StartRecording(E2_proc_main5);
    }
    else if (ir == IR_PROGRAM_PLAY)
    {
        if (record_index != 0)
        {
            StopRecording();
        }
        else
        {
            Whoops();
        }
    }
    else if (ir == IR_RIGHT_ARM_UP || ir == IR_RIGHT_ARM_OUT ||
		ir == IR_RIGHT_ARM_DOWN || ir == IR_RIGHT_ARM_IN)
    {
	    // mirror left and right
		SendIROut(ir);
		SendIROut(ir | 8);
    }
    else
    {
		SendIROut(ir);
    }
}

byte gLastPinsPolled;

void BehaviorMode1()
{
    byte now = PINB; // low => switch pressed
    byte changed = (~now & gLastPinsPolled);
    gLastPinsPolled = now;

    if (changed & _BV(PORTB_L1IN))
        ExecuteOps_Indirect(E2_proc_leftfoot);
    if (changed & _BV(PORTB_R1IN))
        ExecuteOps_Indirect(E2_proc_rightfoot);
    if (changed & _BV(PORTB_L2IN))
        ExecuteOps_Indirect(E2_proc_leftarm);
    if (changed & _BV(PORTB_R2IN))
        ExecuteOps_Indirect(E2_proc_rightarm);

    // echo IR signals
	byte ir = gLastIR;
    if (ir >= 0x80 && ir < 0xE0)
    {
        // only process regular range
        gLastIR = 0; // clear it
        // regular range
	    if (record_index != 0)
	    {
            // in recording mode
            RecordIr(ir);
	    }
        else if (flagsreg_2 & FLAGS2_special_shift)
        {
            // handle special shifts
			flagsreg_2 &= ~FLAGS2_special_shift;
            HandleSpecialIR(ir);
        }
        else if (ir == 0x94)
        {
            // "S>>" button - start shift process
			flagsreg_2 |= FLAGS2_special_shift;
        }
        else
        {
	        SendIROut(ir);
        }
    }
}


/////////////////////////////////////////////////////////////////
// main timer handler

// Timer0 overflow
    // 9600 Hz (more or less) handler
    // used for IR input (8x oversample bit rate of 1200 Hz),
    // IR output (1200Hz bit rate, 8X)
    //   pulse output feature
    //   software UART (Uart2, 8x 1200 baud)
    //   other timers
SIGNAL(SIG_OVERFLOW0)
{
    //NOTE: saves a ton of registers...

#define SIGNAL_OVERHEAD (40)  /* approx CPU cycles */
    TCNT0 = 256-52 + (SIGNAL_OVERHEAD/8) ;  // reload
	//REVIEW: use timer1 for more precision
    
    PollIRIn_TimerRoutine();
    PulseIROut_TimerRoutine();

    Uart2In_TimerRoutine();
    Uart2Out_TimerRoutine();

#if FULL_CMDS
    PulsePins_TimerRoutine();
#endif
    if (gTicker != 0)
        gTicker--;
}


/////////////////////////////////////////////////////////////////
