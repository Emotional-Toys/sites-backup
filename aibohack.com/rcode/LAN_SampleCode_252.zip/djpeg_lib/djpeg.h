// djpeg_lib.lib
// 
// JPEG decompression library, designed just for AIBO
// adapted from IJG release 6b
//  IJG = "the Independent JPEG Group", http://www.ijg.org 
// email me if you really want source

typedef unsigned char byte;

#define CB_AIBO_BMP (176*144*3)

extern "C" bool do_djpeg_aibo(const byte* pbJpg, int cbJpg, byte pbBmpData[CB_AIBO_BMP]);

