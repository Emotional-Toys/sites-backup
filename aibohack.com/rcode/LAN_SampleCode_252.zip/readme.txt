RCodePlus/LifePlus LAN Sample Programs
    Visual C++, Visual Basic, Desktop and PDA versions

Requires:
    ERS-210, ERS-220, ERS-210A, ERS-220A AIBO
    AIBO WiFi LAN card in the AIBO

    For Windows Programs:
	    Windows PC WiFi LAN card
	    Windows PC to run these programs
    For PDA versions
        CLIE NX/NZ with WL100 WiFi LAN card
        Windows CE PDA with WiFi LAN card

    Visual C++ to build C++ samples (version 6 recommended)
    Visual Basic to build VB samples (version 6 recommended)
    other tools for CLIE/WinCE PDA versions

For most programs, AIBO must be running RCodePlus 2.52 or later

For AiboScope, AIBO must be running "Life Plus" 2.52 or later

For AiboCam, AIBO must be running version 2.52 or later of RCodePlus or LifePlus

=================================================================
Windows:
--------

Common files:
	telem.h - low level telemetry interface
    aiboh25.h, aiboh25.cpp, aiboh_*.c_
        - helper classes for doing AIBO socket interface

Primitive samples: (command line tools) - compile with Visual C++
    AiboCap\aibocap.cpp - low level image capture
    AiboCap\aibomic.cpp - low level audio capture
    AiboPlayR\*.* - upload performance data from PC to AIBO. Perform on AIBO
    GetArray\*.* - download array contents from AIBO to PC

Visual C++ GUI Samples: - compile with Visual C++
    AiboRemote\*.* - full blown remote control, with 3 different user interfaces
            Works with RCodePlus sticks only

    AiboScope\*.* - AiboScope - works with LifePlus sticks only

    AiboCam\*.* - AiboCam capture (works with RCodePlus and LifePlus sticks)

    djpeg_lib\*.* - interface to JPG decode library (obsolete)

Visual Basic Samples:
    AiboRemoteVB\*.* - Visual Basic Sample - trivial AiboRemote

    VBAIBO\*.* - source (in C++) for VBAIBO.DLL
            - use in conjunction with AiboRemoteVB or other Visual Basic code

-----------------------------------------------------------------
PDAs:
-----

PDA source code coming later

CLIE Samples (PalmOS)
    ClieAiboCam - simple camera viewer
    ClieAiboRemoteScope - AiboRemote + AiboScope for CLIEs
	    TO BUILD: requires CodeWarrior (not free)

PDA Samples: (Windows CE/PocketPC 2002)
    WpdaAiboCam - simple camera viewer
    WpdaAiboRemoteScope - AiboRemote + AiboScope for WinCE devices
	    TO BUILD: requires Embedded Visual C++ and Pocket PC 2002 SDK (free)


-----------------------------------------------------------------
OTHER/OBSOLETE SAMPLES: (email me if you want them)
    apping\*.* - OLD - LAN test program
    PidWalker\*.* - OLD - tool for playing with servo "PID"s
    CVV\*.* - OLD - interface to CVV image processing library
    djpeg_lib\*.c - actual source to JPG library

=================================================================
