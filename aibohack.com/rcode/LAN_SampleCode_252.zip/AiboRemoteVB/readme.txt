Note for AiboRemoteVB:

"Update All" will get the latest data from AIBO and fill in a Visual Basic form.

NOTE: the photo and color matrix data returns the last captured one.
Press the "Update All" button twice to get a more current photo.

NOTE: you may need to copy VBAIBO.DLL to your c:\WINDOWS\SYSTEM32 folder


