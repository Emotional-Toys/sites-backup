// Helper classes for LifePlus and RCodePlus versions 2.5x and later
// version 2.52 (.03 + CLIE)

// Current versions supported:
//      default = Windows (command line tools or GUI)
//      BUILD_CLIE = PalmOS with WiFi card (CLIE NX or NZ)
//      BUILD_WINCE - NOT WORKING YET

#pragma once


#ifndef BUILD_CLIE
#ifndef BUILD_WINCE
#ifndef BUILD_WINDOWS
#define BUILD_WINDOWS
#endif
#endif
#endif

////////////////////////////////////////////////////////////
// Basic types

typedef unsigned char       byte;
typedef unsigned short      word;
typedef signed short rcword; // RCODE signed 16-bit value

#include "telem.h"   // telemetry codes

////////////////////////////////////////////////////////////
// image data sizes

#define CX_FULLIMAGE    176
#define CY_FULLIMAGE    144     /* last line is not perfect */
#define CB_FULLIMAGE (CY_FULLIMAGE*CX_FULLIMAGE*3)
#define CW_FULLIMAGE16 (CY_FULLIMAGE*CX_FULLIMAGE)

// color detection byte (CDT)
#define CX_COLORIMAGE	88
#define CY_COLORIMAGE	72
#define CB_COLORIMAGE (CY_COLORIMAGE*CX_COLORIMAGE*1)

#define CB_JPGMAX   32000

////////////////////////////////////////////////////////////
// Abstract AIBO socket connection (either Telemetry or RCODE)

class AIBOH_CONNECTION
{
protected:

#ifdef BUILD_CLIE
    Int16 m_hSocket; // NetSocketRef
#else
    unsigned int m_hSocket; // SOCKET
#endif

    bool SimpleConnect(const byte ipAddr[4], int port, char* szErr);
public:
    static bool ParseIPAddrString(byte ipAddr[4], const char* szIPAddr);

	void Disconnect();
    AIBOH_CONNECTION() { m_hSocket = (unsigned int)~0; } // invalid socket
    ~AIBOH_CONNECTION() { Disconnect(); }

public:
	void PurgeReply();
	bool SendCommandBytes(const byte* pb, int cb);
	bool ReceiveReply(byte* pbReply, int cbReply);

	bool IsConnected() { return m_hSocket != 0xFFFFFFFF; }
		bool IsOpen() { return IsConnected(); } // old name
};

////////////////////////////////////////////////////////////
// Telemetry port is used for getting images, color info, audio
//   and Life+ semantic data from AIBO
        // RCodePlus and LifePlus

class AIBOH_TELEMETRY : public AIBOH_CONNECTION
{
public:
    bool Connect(const byte ipAddr[4], char* szErr = 0);
    bool Connect(const char* szIPAddr, char* szErr = 0);

	bool GetVersionRaw(TELEMVER& tver);
	int GetVersion();	// from TELEMREQ_GETVER

    ////////////////////////////////////////////////////
    // high level access to image data

	bool GetImageYUV10(PACKED_YUV10_DATA& packedData);
	bool GetColorData(byte cdtBuffer[CB_COLORIMAGE]);

#ifndef BUILD_CLIE
    static void ConvertToRgb(byte bmpData[CB_FULLIMAGE],
				PACKED_YUV10_DATA const& packedData);

#else
    static void ConvertToRgb16(word bmpData[CW_FULLIMAGE16],
				PACKED_YUV10_DATA const& packedData);
#endif

#ifdef BUILD_WINDOWS
	int GetImageJpeg(byte buffer[CB_JPGMAX]);
        // soon to be obsolete
#endif

    // telemetry array (use in conjunction with AIBOH_RCODE)
    bool GetTelemetryVarArray(int iArray, void* values, int sizeof_values);
#ifdef LATER_MAYBE
    bool GetTelemetryRawArray(int iArray, void* values, int sizeof_values);
#endif


    ////////////////////////////////////////////////////
    // low level access

	bool SendCommandByte(byte bCmd)
        { return SendCommandBytes(&bCmd, 1); }
	int GetStdPacket(byte bReq, byte* pbReply,
		    int cbExpectedMin, int cbExpectedMax);
        // returns actual number of data bytes (or -1)
	int GetStdDataArray(byte bCmd, byte* pbReply,
        int cbPerElement, int cElemMax);
        // returns number of full elements (or -1)
	bool GetStdPacketFixedRetry(byte bReq, byte* pbReply, int cbExpected);
};

////////////////////////////////////////////////////////////
// RCODE port for sending RCODE commands
        // RCodePlus only

class AIBOH_RCODE : public AIBOH_CONNECTION
{
public:
    bool Connect(byte const ipAddr[4], char* szErr = 0);
    bool Connect(const char* szIPAddr, char* szErr = 0);

	bool SendCommandString(const char* szCmd);
	bool ReceiveTextReply(char* szReply, int cbReply);

	// high level RCODE commands
	rcword GetIntValue(const char* szVariable);
		// slow way to get a single value

    // for faster data access, set up a telemetry array

    bool InitTelemetryVarArray(int iArray,
            const char* szVars, int sizeof_values);
            // separate variable names with ';'
            // get telemetry array using the telemetry connection
};

////////////////////////////////////////////////////////////
