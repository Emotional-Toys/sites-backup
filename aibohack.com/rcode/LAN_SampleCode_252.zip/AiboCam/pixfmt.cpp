#include "stdafx.h"
#include "AiboCam.h"

#include "aibolan.h"
#include "pixfmt.h"

#include "wravi.h"


////////////////////////////////////////////////////////

////////////////////////////////////////////////////////
// called back in time critical read thread

////////////////////////////////////////////////////////

#define COLOR_RED RGB(255, 0, 0)
#define COLOR_PINK RGB(255, 81, 146)
#define COLOR_BLACK RGB(0, 0, 0)
#define COLOR_BLUE RGB(135, 114, 255)
#define COLOR_GREEN RGB(151, 255, 54)
#define COLOR_FLESH RGB(180, 121, 88)


COLORREF s_colorDT[8] =
{
	COLOR_RED,
	COLOR_PINK,
	COLOR_BLACK,
	COLOR_BLACK,
	COLOR_BLUE,
	COLOR_GREEN,
	COLOR_FLESH,
	COLOR_BLACK,
};

// colorize 
void Colorize(const BYTE* pbCDT, int iColor, int xBase, int yBase,
	BYTE* rgbVideoFrame, int cxVideo, int cyFrame, bool bErase /*= true*/)
{
    ASSERT(iColor >= 0 && iColor < 8);
    BYTE bMask = (1 << iColor);
    COLORREF color = s_colorDT[iColor];

	BYTE rgbOn[3];
	rgbOn[0] = GetBValue(color);
	rgbOn[1] = GetGValue(color);
	rgbOn[2] = GetRValue(color);

	int yBase2 = cyFrame - 1 - yBase;	// bottom line
	BYTE* pbBase = &rgbVideoFrame[3*(xBase + cxVideo * yBase2)];
	int yLine = 0;
	for (int y = 0; y < CY_COLORIMAGE; y++)
	{
		BYTE* pbOut = &pbBase[(cxVideo*3)*yLine--];	// bottom up
	    if (bErase)
	        memset(pbOut, GRAYBGCOLOR, CX_COLORIMAGE*3);
		for (int x = 0; x < CX_COLORIMAGE; x++)
		{
			if (*pbCDT++ & bMask)
				memcpy(pbOut, rgbOn, 3);		// 3 byte BGR
			pbOut += 3;
		}
	}
}

////////////////////////////////////////////////////////


