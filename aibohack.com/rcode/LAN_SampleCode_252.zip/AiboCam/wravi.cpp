
#include "stdafx.h"

#include <vfw.h>

#pragma comment(lib, "vfw32.lib")

#include "wravi.h"

// only one AVI at a time
static PAVIFILE g_pfile = NULL;  
static PAVISTREAM g_pstreamNaked = NULL;
static PAVISTREAM g_pstreamComp = NULL;
static PAVISTREAM g_pstreamAudio = NULL;
static int g_iFrame = 0;
static int g_iAudFrame = 0;
static BITMAPINFOHEADER g_bi;

bool CreateAVI(const char* szFile, int fps_times_100, int cxImage, int cyImage, bool bAudio)
{
    HRESULT hr;
    g_iFrame = 0;

    // init BITMAPINFOHEADER
    memset(&g_bi, 0, sizeof(g_bi));
    g_bi.biSize = sizeof(g_bi);
    g_bi.biWidth = cxImage;
    g_bi.biHeight = cyImage;
    g_bi.biPlanes = 1;
    g_bi.biBitCount = 24;
    g_bi.biCompression = BI_RGB;
    g_bi.biSizeImage = cxImage*cyImage*3;   // uncompressed size

    // create file
    AVIFileInit();          // opens AVIFile library  
    hr = AVIFileOpen(&g_pfile, szFile, OF_CREATE|OF_WRITE, NULL); 
    if (hr != 0)
		return false;

    // create stream
	AVISTREAMINFO strhdr;
	memset(&strhdr, 0, sizeof(strhdr));
	strhdr.fccType = streamtypeVIDEO;
    /// strhdr.fccHandler = ??; // filled in by dialog
	strhdr.dwRate = fps_times_100;
	strhdr.dwScale = 100;
	strhdr.dwSuggestedBufferSize  = cxImage*cyImage*3;  // uncompressed
	SetRect(&strhdr.rcFrame, 0, 0, cxImage, cyImage);

	// And create the stream;
	hr = AVIFileCreateStream(g_pfile, &g_pstreamNaked, &strhdr);
    if (hr != 0)
		return false;

	AVICOMPRESSOPTIONS opts;
	memset(&opts, 0, sizeof(opts));

    // ask user for options
	AVICOMPRESSOPTIONS* rgpopts[1];
    rgpopts[0] = &opts;

	if (!AVISaveOptions(NULL, 0, 1, &g_pstreamNaked, rgpopts))
		return false;

	hr = AVIMakeCompressedStream(&g_pstreamComp, g_pstreamNaked, &opts, NULL);
    if (hr != 0)
		return false;

	hr = AVIStreamSetFormat(g_pstreamComp, 0, &g_bi, sizeof(g_bi));
        // this sets the format

    if (hr != 0)
		return false;

	if (bAudio)
	{
		memset(&strhdr, 0, sizeof(strhdr));
		strhdr.fccType = streamtypeAUDIO;
		strhdr.dwScale = 4;		// nBlockAlign
		strhdr.dwRate = 16000*2*2;
		strhdr.dwSampleSize = 4;
		// strhdr.dwLength = ?;

		hr = AVIFileCreateStream(g_pfile, &g_pstreamAudio, &strhdr);
		if (hr != 0)
			return false;

		WAVEFORMATEX wfmt;
		memset(&wfmt, 0, sizeof(wfmt));
		wfmt.wFormatTag = WAVE_FORMAT_PCM;
		wfmt.nChannels = 2;
		wfmt.nSamplesPerSec = 16000;
		wfmt.nAvgBytesPerSec = 16000*2*2;
		wfmt.wBitsPerSample = 16;
		wfmt.nBlockAlign = 4;
		hr = AVIStreamSetFormat(g_pstreamAudio, 0, &wfmt, sizeof(wfmt));
		if (hr != 0)
			return false;
	}

	g_iFrame = 0;
	g_iAudFrame = 0;

	return true;
}

void CloseAVI()
{
	AVIStreamClose(g_pstreamNaked); // close this first
	g_pstreamNaked = NULL;
	AVIStreamClose(g_pstreamComp);  // then compressed one
	g_pstreamComp = NULL;

	if (g_pstreamAudio != NULL)
		AVIStreamClose(g_pstreamAudio);
	g_pstreamAudio = NULL;
    
	AVIFileClose(g_pfile);  // finally close the AVI file
	g_pfile = NULL;
    
	AVIFileExit();          // releases AVIFile library
}

bool AddToAVI_RGB(BYTE* pbData)
{
    HRESULT hr = AVIStreamWrite(g_pstreamComp, g_iFrame, 1,
			pbData, g_bi.biSizeImage,
			AVIIF_KEYFRAME,			 // flags....
			NULL, NULL);

	if (hr != 0)
	{
		TRACE("AddToAVI_AUD error");
		return false;
	}
	g_iFrame++;
	return true;
}

bool AddToAVI_AUD(BYTE* pbData)
{
	HRESULT hr = AVIStreamWrite(g_pstreamAudio, g_iAudFrame, 1,
			pbData, 512*2*2, 0, NULL, NULL);
	if (hr != 0)
	{
		TRACE("AddToAVI_AUD error");
		return false;
	}
	g_iAudFrame++;
	return true;
}
