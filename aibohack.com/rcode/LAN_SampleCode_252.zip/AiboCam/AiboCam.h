// AiboCam.h : main header file for the AIBOCAM application
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CAiboCamApp:
// See AiboCam.cpp for the implementation of this class
//

class CAiboCamApp : public CWinApp
{
public:
	CAiboCamApp();

	void DoAbout();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAiboCamApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CAiboCamApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


extern CAiboCamApp theApp;

/////////////////////////////////////////////////////////////////////////////

