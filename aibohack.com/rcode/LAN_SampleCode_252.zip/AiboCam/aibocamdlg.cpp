// AiboCamDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AiboCam.h"
#include "AiboCamDlg.h"

#include "audio.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAiboCamDlg dialog

CAiboCamDlg::CAiboCamDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAiboCamDlg::IDD, pParent)
{
	// good defaults
	m_iFmtCDT = 0;
	m_strAviPath = "C:\\AIBOCAM.AVI";
	m_bKeepAspectRatio = TRUE;

	// BLOCK: get initial (default) IP address (set by AiboScope Live)
	{
		m_b1 = 10;
		m_b2 = 0;
		m_b3 = 1;
		m_b4 = 100;
		CString strIP = AfxGetApp()->GetProfileString("Settings", "IPADDR", "");
		int a1, a2, a3, a4;
		if (sscanf(strIP, "%d.%d.%d.%d", &a1, &a2, &a3, &a4) == 4)
		{
			m_b1 = (BYTE)a1;
			m_b2 = (BYTE)a2;
			m_b3 = (BYTE)a3;
			m_b4 = (BYTE)a4;
		}
	}

	//{{AFX_DATA_INIT(CAiboCamDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_iCaptureType = 1; // YUV default
	m_bCapAudio = TRUE;
}

void CAiboCamDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAiboCamDlg)
	DDX_Radio(pDX, IDC_RADIO4, m_iFmtCDT);
	DDX_Text(pDX, IDC_AVIPATH, m_strAviPath);
	DDX_Text(pDX, IDC_EDIT3, m_b3);
	DDV_MinMaxByte(pDX, m_b3, 0, 255);
	DDX_Text(pDX, IDC_EDIT1, m_b1);
	DDV_MinMaxByte(pDX, m_b1, 0, 255);
	DDX_Text(pDX, IDC_EDIT2, m_b2);
	DDV_MinMaxByte(pDX, m_b2, 0, 255);
	DDX_Text(pDX, IDC_EDIT4, m_b4);
	DDV_MinMaxByte(pDX, m_b4, 0, 255);
	DDX_Check(pDX, IDC_ASPECTRATIO, m_bKeepAspectRatio);
	DDX_Radio(pDX, IDC_RADIO1, m_iCaptureType);
	DDX_Check(pDX, IDC_CAP_AUDIO, m_bCapAudio);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAiboCamDlg, CDialog)
	//{{AFX_MSG_MAP(CAiboCamDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_STARTCAPTURE, OnStartCapture)
	ON_BN_CLICKED(IDC_TESTLAN, OnTestLan)
	ON_BN_CLICKED(IDC_PREVIEW, OnStartPreview)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAiboCamDlg message handlers

BOOL CAiboCamDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CAiboCamDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		theApp.DoAbout();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAiboCamDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CAiboCamDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////
// pump the AIBOLAN

#include "aibolan.h"

AIBOLAN g_aiboLan;


#include "pixfmt.h"
#include "statusdlg.h"


//////////////////////////////////////////////////////////////////////////////////////////////////////////

struct VIDINFO
{
	VIDINFO() { memset(this, 0, sizeof(*this)); }
	~VIDINFO();
	// filled in by ValidateConnectInfo

	bool bJpg;	// JPG capture (else YUV10 capture)
	int cxImage, cyImage;
	int cbImage;
	BYTE* pbImage;	// points inside of pbFrame buffer

	int iFmtCDT;
	bool bCDT;	
	int cxFrame, cyFrame;
	int cbFrame;
	BITMAPINFO bmiFrame;

    bool bAudio;

	int nFPS;	// estimate (fps*100)

	BYTE* pbFrame;
};

VIDINFO::~VIDINFO()
{
	delete [] pbFrame;
}


bool CAiboCamDlg::ValidateConnectInfo(VIDINFO& vi, BYTE ipAddr[4])
{
	TRY
	{
		CDataExchange dx(this, TRUE);;	// save and validate
	    DoDataExchange(&dx);
	}
	CATCH_ALL(e)
	{
		return false;
	}
	END_CATCH_ALL

	ipAddr[0] = m_b1;
	ipAddr[1] = m_b2;
	ipAddr[2] = m_b3;
	ipAddr[3] = m_b4;

	vi.cxImage = CX_FULLIMAGE;
    vi.cyImage = CY_FULLIMAGE;
	vi.cbImage = CY_FULLIMAGE*CX_FULLIMAGE*3;

	ASSERT(m_iFmtCDT >= 0 && m_iFmtCDT <= 2);
	vi.iFmtCDT = m_iFmtCDT;
	vi.bCDT = m_iFmtCDT != 0;
	vi.bJpg = (m_iCaptureType == 0);
    vi.bAudio = (m_bCapAudio != 0);

	// nFPS is frames per second * 100
	if (vi.bJpg)
	{
		vi.nFPS = (vi.bAudio) ? 470 : 480;
	}
	else
	{
		vi.nFPS = (vi.bAudio) ? 610 : 850;
	}

	vi.cxFrame = vi.cxImage;
    vi.cyFrame = vi.cyImage;	// just the image
	int xImageStart = 0;
	int yImageStart = 0;	// upper left usually

	if (vi.iFmtCDT == 1)
	{
		// large + 8
		vi.cxFrame = vi.cxImage + CX_GAP + CX_COLORIMAGE;
		vi.cyFrame = CY_COLORIMAGE + CY_GAP + vi.cyImage + CY_GAP + CY_GAP + CY_COLORIMAGE;	// extra mid-gap
		yImageStart = CY_COLORIMAGE + CY_GAP + CY_GAP/2;	// down a bit
	}
	else if (vi.iFmtCDT == 2)
	{
		// single CDT matrix to the right
		vi.cxFrame = vi.cxImage + CX_GAP + CX_COLORIMAGE;
	}

	// do any row math with DWORD aligned width
    while (vi.cxFrame & 3)
		vi.cxFrame++;

	vi.cbFrame = vi.cyFrame * vi.cxFrame * 3;
	vi.pbFrame = new BYTE[vi.cbFrame];
    memset(vi.pbFrame, BLACKBGCOLOR, vi.cbFrame);
	vi.pbImage = vi.pbFrame + (yImageStart * vi.cxFrame + xImageStart)*3;

	memset(&vi.bmiFrame, 0, sizeof(vi.bmiFrame));
	vi.bmiFrame.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	vi.bmiFrame.bmiHeader.biWidth = vi.cxFrame;
	vi.bmiFrame.bmiHeader.biHeight = vi.cyFrame;
	vi.bmiFrame.bmiHeader.biPlanes = 1;
	vi.bmiFrame.bmiHeader.biBitCount = 24;
	vi.bmiFrame.bmiHeader.biCompression = BI_RGB;
	return true;
}


////////////////////////////////////////////////////////////////////////////////////////////////////

struct STATS
{
	long timeStart, timeRate;
	int nFrames;
	int nErrors;
	char szLastReport[128];		// avoid flicker
};
static STATS g_stats;

static void InitStatistics()
{
	g_aiboLan.ResetReadStats();
	g_stats.nFrames = 0;
	g_stats.nErrors = 0;
	g_stats.szLastReport[0] = '\0';

	// faster time calculation
	LARGE_INTEGER li;
	QueryPerformanceFrequency(&li);
	g_stats.timeRate = li.LowPart;
	QueryPerformanceCounter(&li);
	g_stats.timeStart = li.LowPart;
}

static void ReportStatistics(StatusDlg& dlg, bool bGotAFrame)
{
	if (bGotAFrame)
		g_stats.nFrames++;

	char szReport[256];
	sprintf(szReport, "captured %d frames\n(%d errors)\n", g_stats.nFrames, g_stats.nErrors);

	double secsOverall, secsPeak;
	int cbOverall, cbPeak;
	g_aiboLan.GetLastReadStats(secsOverall, cbOverall, secsPeak, cbPeak);
	ASSERT(cbOverall == cbPeak);
	g_aiboLan.ResetReadStats();

	if (secsOverall > 0.0)
	{
		int cbPerSec = (int)(cbOverall / secsOverall);
		sprintf(szReport + strlen(szReport), "\nOverall: %d KB/s\n    (%.3f Mbps)", cbPerSec / 1000, (double)cbPerSec * 8 / 1.0e6);	// not 1024
	}
	if (secsPeak > 0.0)
	{
		int cbPerSec = (int)(cbPeak / secsPeak);
		sprintf(szReport + strlen(szReport), "\nPeak: %d KB/s\n    (%.3f Mbps)", cbPerSec / 1000, (double)cbPerSec * 8 / 1.0e6);	// not 1024
	}

	if (g_stats.nFrames > 10)
	{
		LARGE_INTEGER li;
		QueryPerformanceCounter(&li);
		long dtime = li.LowPart - g_stats.timeStart;
		if (dtime > 0)
        {
		    float flFPS = (float)(g_stats.nFrames) / ((float)dtime / g_stats.timeRate);
			sprintf(szReport + strlen(szReport), "\n%.2f frames per sec\n", flFPS);
        }
	}

	if (strcmp(szReport, g_stats.szLastReport) != 0)
	{
		dlg.SetText(szReport);
		strcpy(g_stats.szLastReport, szReport);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////


void ALC_Error(const char* szReason)
{
	TRACE("AIBOLAN error: %s\n", szReason);
	g_stats.nErrors++;
}


// single buffer - assumes main thread is fast enough
int g_cbImageData = 0;
bool g_bGotImageData = false;
BYTE g_rgbImage[CB_FULLIMAGE];

BYTE g_rgbCDT[CB_COLORIMAGE];

void ALC_GotImageData(BYTE* pbImage, BYTE* pbCDT)
{
    if (g_bGotImageData)
    {
        // already processing - could be paused or just slow
        // REVIEW: could allocate a buffer

        TRACE("warning: main thread not ready - frame lost\n");
	        // REVIEW: status display
        return;
    }
	ASSERT(g_cbImageData != 0);
    memcpy(g_rgbImage, pbImage, g_cbImageData);
    if (pbCDT != NULL)
	    memcpy(g_rgbCDT, pbCDT, CB_COLORIMAGE);
    g_bGotImageData = true;
}

void CAiboCamDlg::DoColorize(VIDINFO const& vi)
{
	ASSERT(vi.iFmtCDT == 1 || vi.iFmtCDT == 2);

#define COLORIZE(iColor, xCell, yCell) \
	Colorize(g_rgbCDT, iColor, xCell*(CX_GAP+CX_COLORIMAGE), yCell*(CY_GAP+CY_COLORIMAGE), pbBase, vi.cxFrame, vi.cyFrame)
	BYTE* pbBase = vi.pbFrame;
	if (vi.iFmtCDT == 1)
	{
		// colorize 8 around it
		COLORIZE(0, 0, 0);
		COLORIZE(1, 1, 0);
		COLORIZE(2, 2, 0);
		COLORIZE(3, 2, 1);
		COLORIZE(6, 2, 2);
		COLORIZE(4, 0, 3);
		COLORIZE(5, 1, 3);
		COLORIZE(7, 2, 3);
    }
	else if (vi.iFmtCDT == 2)
	{
		int x = CX_COLORIMAGE + CX_GAP;
		int y = 0;
		x = vi.cxImage + CX_GAP;
		y = vi.cyFrame / 4;	// down a bit

        bool bErase = true;
        for (int iColor = 8-1; iColor >= 0; iColor--) // higher #s first
        {
			Colorize(g_rgbCDT, iColor, x, y, pbBase, vi.cxFrame, vi.cyFrame, bErase);
            bErase = false; // merge rest
        }
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////

bool CAiboCamDlg::Connect(VIDINFO const& vi, BYTE const ipAddr[4])
{
    if (!g_aiboLan.Init(ALC_Error))
    {
        TRACE("AIBOLAN initialization error\n");
        return false;
    }

    TRACE("Connecting to AIBO...");

	int version;
    if (!g_aiboLan.Connect(ipAddr, version))
    {
        TRACE("FAILED\n");
        return false;
	}
    TRACE("Connected\n");
	// if success - save IP address for later use
	char szIP[64];
	wsprintf(szIP, "%d.%d.%d.%d", ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3]);
	AfxGetApp()->WriteProfileString("Settings", "IPADDR", szIP);

	if (version < 252 || version > 299)
	{
		AfxMessageBox("Old RCode/LifePlus version is not supported\nPlease upgrade stick");
		Disconnect();
		return false;
	}

	if (!vi.bJpg && version == 250)
	{
		AfxMessageBox("YUV10 capture not supported, please try JPG");
		Disconnect();
		return false;
	}
	
	// start polling at proper rate
    g_cbImageData = vi.cbImage;
	g_aiboLan.SetImageProc(ALC_GotImageData, vi.bJpg, vi.bCDT);

	return true;
}

void CAiboCamDlg::Disconnect()
{
    g_aiboLan.Run(false);
    Sleep(500); // wait for helper thread to die
    g_aiboLan.Disconnect();
}

/////////////////////////////////////////////////////////////////////////////

static void FlushInput()
{
	MSG msg;
	while (PeekMessage(&msg, NULL, WM_KEYFIRST, WM_KEYLAST, PM_REMOVE))
		;
	while (PeekMessage(&msg, NULL, WM_MOUSEFIRST, WM_MOUSELAST, PM_REMOVE))
		;
}
static bool CheckAbort()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 0x8000)
		return true;
	if (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
		return true;
	if (GetAsyncKeyState(VK_RBUTTON) & 0x8000)
		return true;
	return false;
}


void CAiboCamDlg::OnStartPreview() 
{
	// TODO: Add your control notification handler code here
	VIDINFO vi;
	BYTE ipAddr[4];
	if (!ValidateConnectInfo(vi, ipAddr))
	{
		AfxMessageBox("Invalid data entered");
		return;
	}

	bool bSquare = (m_bKeepAspectRatio != FALSE);

    if (vi.bAudio && !OpenAudio())
    {
		AfxMessageBox("No audio device\nTurn off audio and try again");
		return;
    }

	if (!Connect(vi, ipAddr))
	{
		AfxMessageBox("Failed to connect");
        CloseAudio();
		return;
	}

	// fill the screen
	int xDest = 0;
	int yDest = 0;
	int cxDest = GetSystemMetrics(SM_CXSCREEN);
	int cyDest = GetSystemMetrics(SM_CYSCREEN);

	if (bSquare)
	{
		// keep aspect ratio
		int cy2 = (cxDest * vi.cyFrame) / vi.cxFrame;
		if (cyDest > cy2)
		{
			yDest = (cyDest - cy2) / 2;
			cyDest = cy2;
		}
		else
		{
			int cx2 = (cyDest * vi.cxFrame) / vi.cyFrame;
			xDest = (cxDest - cx2) / 2;
			cxDest = cx2;
		}
	}

	HWND hwnd = ::CreateWindowEx(WS_EX_TOPMOST, "STATIC", "Aibo Cam Preview", WS_POPUP | WS_VISIBLE, xDest, yDest, cxDest, cyDest,
		this->m_hWnd, NULL, AfxGetInstanceHandle(), NULL);

	if (hwnd == NULL)
	{
		Disconnect();
        CloseAudio();
		AfxMessageBox("window creation error");
		return;
	}

	HDC hdc = ::GetDC(hwnd);
	ASSERT(hdc != NULL);	// just party directly on the window

    g_aiboLan.Run(true);
	if (IsAudioOpen())
		g_aiboLan.m_telem.SendCommandByte(TELEMOP_FLUSHAUDIO);

	while (!CheckAbort())
	{
		g_aiboLan.Poll();
		
		if (g_bGotImageData)	// review: use an event or PostMessage?
        {
		    CopyRGB(vi.pbImage, g_rgbImage,
                vi.cxImage, vi.cyImage, vi.cxFrame);
			if (vi.iFmtCDT != 0)
				DoColorize(vi);

            g_bGotImageData = false;	// free buffer

			// blt to screen
			StretchDIBits(hdc, 0, 0, cxDest, cyDest,	// to upper left of window always
				0, 0, vi.cxFrame, vi.cyFrame, vi.pbFrame,
				&vi.bmiFrame, DIB_RGB_COLORS, SRCCOPY);
		}

        if (IsAudioOpen())
        {
			AUDIO_BUFF buffers[MAX_AUDIO_BUFF];
			int cbReplyData = g_aiboLan.m_telem.GetStdPacket(TELEMREQ_GETAUDIO,
                (byte*)buffers,
			    sizeof(AUDIO_BUFF)*1,
			    sizeof(AUDIO_BUFF)*MAX_AUDIO_BUFF);

	        int nBuff = cbReplyData / sizeof(AUDIO_BUFF);
			if (nBuff > 0 && nBuff <= MAX_AUDIO_BUFF &&
		            nBuff * (int)sizeof(AUDIO_BUFF) == cbReplyData)
            {
                // valid audio
                for (int iB = 0; iB < nBuff; iB++)
                    WriteAudio(buffers[iB]);
            }
        }
	}
	CloseAudio();
	FlushInput();

	::ReleaseDC(hwnd, hdc);
	::DestroyWindow(hwnd);

	Disconnect();

}

void CAiboCamDlg::OnTestLan() 
{
	VIDINFO vi;
	BYTE ipAddr[4];
	if (!ValidateConnectInfo(vi, ipAddr))
	{
		AfxMessageBox("Invalid data entered");
		return;
	}

	if (!Connect(vi, ipAddr))
	{
		AfxMessageBox("Failed to connect");
		return;
	}

	StatusDlg dlg(this, "LAN Test");

    g_aiboLan.Run(true);
	InitStatistics();
	while (!CheckAbort())
	{
		g_aiboLan.Poll();

	    if (g_bGotImageData)	// review: use an event or PostMessage?
		{
			g_bGotImageData = false;
			ReportStatistics(dlg, true);
		}
		else
		{
			Sleep(10);
			ReportStatistics(dlg, false);
		}
	}
	dlg.DestroyWindow();
	FlushInput();

	Disconnect();
}

#include "wravi.h"

void CAiboCamDlg::OnStartCapture() 
{
	// TODO: Add your control notification handler code here
	VIDINFO vi;
	BYTE ipAddr[4];
	if (!ValidateConnectInfo(vi, ipAddr))
	{
		AfxMessageBox("Invalid data entered");
		return;
	}

	FILE* pfT = fopen(m_strAviPath, "rb");
	if (pfT != NULL)
	{
		fclose(pfT);
		if (AfxMessageBox("File exists, replace ?", MB_YESNO) != IDYES)
			return;
	}

	StatusDlg dlg(this, "Creating AVI file");

    if (!CreateAVI(m_strAviPath, vi.nFPS, vi.cxFrame, vi.cyFrame, vi.bAudio))
    {
		Disconnect();
		char szErr[256];
		sprintf(szErr, "Can't create AVI file '%s'", (const char*)m_strAviPath);
		AfxMessageBox(szErr);
        return;
    }

	dlg.SetTitle("Connecting");

	if (!Connect(vi, ipAddr))
	{
		AfxMessageBox("Failed to connect");
	    CloseAVI();
		return;
	}

	dlg.SetTitle("Capturing");

    g_aiboLan.Run(true);
	InitStatistics();
	bool bErr = false;

    long timeStart = time(NULL);
	while (!CheckAbort() && !bErr)
	{
		g_aiboLan.Poll(); // REVIEW: remove old polling and double buffering

	    if (g_bGotImageData)	// REVIEW: clean this up
        {
		    CopyRGB(vi.pbImage, g_rgbImage,
                vi.cxImage, vi.cyImage, vi.cxFrame);
			if (vi.iFmtCDT != 0)
				DoColorize(vi);
            g_bGotImageData = false;	// free buffer
			ReportStatistics(dlg, true);

			if (!AddToAVI_RGB(vi.pbFrame))
				bErr = true;
		}

		if (vi.bAudio)
		{
			AUDIO_BUFF buffers[MAX_AUDIO_BUFF];
			int cbReplyData = g_aiboLan.m_telem.GetStdPacket(TELEMREQ_GETAUDIO,
                (byte*)buffers,
			    sizeof(AUDIO_BUFF)*1,
			    sizeof(AUDIO_BUFF)*MAX_AUDIO_BUFF);

	        int nBuff = cbReplyData / sizeof(AUDIO_BUFF);
			if (nBuff > 0 && nBuff <= MAX_AUDIO_BUFF &&
		            nBuff * (int)sizeof(AUDIO_BUFF) == cbReplyData)
            {
                // valid audio
                for (int iB = 0; iB < nBuff; iB++)
                    AddToAVI_AUD(buffers[iB].wavdata);
            }
		}

	}
	dlg.SetTitle("Closing");

    CloseAVI();

	if (bErr)
		AfxMessageBox("Error saving AVI file - disk may be full");
	dlg.DestroyWindow();
	FlushInput();

	Disconnect();

}
