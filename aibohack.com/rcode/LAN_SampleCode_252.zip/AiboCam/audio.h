
#include "../aiboh25.h"

bool OpenAudio();
void CloseAudio();
bool IsAudioOpen();

bool WriteAudio(AUDIO_BUFF const& buff);

