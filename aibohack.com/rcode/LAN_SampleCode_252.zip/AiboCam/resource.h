//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AiboCam.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_AIBOCAM_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDD_CAPTURESTATUS               133
#define IDC_ASPECTRATIO                 1000
#define IDC_CAP_AUDIO                   1001
#define IDC_EDIT1                       1014
#define IDC_EDIT2                       1015
#define IDC_EDIT3                       1016
#define IDC_EDIT4                       1017
#define IDC_AVIPATH                     1018
#define IDC_RADIO4                      1021
#define IDC_RADIO5                      1022
#define IDC_RADIO1                      1023
#define IDC_RADIO2                      1024
#define IDC_RADIO3                      1025
#define IDC_RADIO6                      1026
#define IDC_PREVIEW                     1028
#define IDC_STARTCAPTURE                1030
#define IDC_STATUS1                     1032
#define IDC_STATUS2                     1033
#define IDC_TESTLAN                     1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
