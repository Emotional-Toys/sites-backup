/////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "aibolan.h"

/////////////////////////////////////////////////////////////////////
// Work Thread


#include "..\djpeg_lib\djpeg.h"

void AIBOLAN::Poll()
{
	ASSERT(!m_bPaused);
    ASSERT(m_pfnImage != NULL);	// otherwise we should be paused

    bool bDidSomething = false;
	BYTE rgbFull[CB_FULLIMAGE]; // max size
	BYTE rgbCDT[CB_COLORIMAGE];

	LARGE_INTEGER timeStart;
	QueryPerformanceCounter(&timeStart);

	if (m_bJpg)
	{
		// get JPG image
		BYTE rgbJpg[CB_JPGMAX]; // max size
		int cbJpg = m_telem.GetImageJpeg(rgbJpg);
		if (cbJpg <= 0)
		{
			(m_pfnError)("GetImageJpeg failed");
			return;
		}
		// decompress
		if (!do_djpeg_aibo(rgbJpg, cbJpg, rgbFull))
		{
			(m_pfnError)("Jpg decompress failed");
			return;
		}
    }
	else
	{
		// YUV10 format
		PACKED_YUV10_DATA packedData;
		if (!m_telem.GetImageYUV10(packedData))
		{
			(m_pfnError)("GetImageYUV10 failed");
			return;
		}
		// decompress
		AIBOH_TELEMETRY::ConvertToRgb(rgbFull, packedData);
	}

	if (m_bCDT && !m_telem.GetColorData(rgbCDT))
	{
		    (m_pfnError)("GetColorData failed");
			return;
    }

	(m_pfnImage)(rgbFull, m_bCDT ? rgbCDT : NULL);	// notification

#ifdef LATER_STATS
		LARGE_INTEGER timeEnd;
		QueryPerformanceCounter(&timeEnd);
		m_ticksOverallStats += timeEnd.LowPart - timeStart.LowPart;
		m_cbOverallStats += cbJpgData;
????
		LARGE_INTEGER timeEnd;
		QueryPerformanceCounter(&timeEnd);
		m_ticksOverallStats += timeEnd.LowPart - timeStart.LowPart;
		m_cbOverallStats += cbJpgData + CB_COLORIMAGE;

#endif

}

void AIBOLAN::ResetReadStats()
{
	m_ticksReadStats = 0;
	m_cbReadStats = 0;
	m_ticksOverallStats = 0;
	m_cbOverallStats = 0;
}

void AIBOLAN::GetLastReadStats(double& secsOverall, int& cbOverall,
							   double& secsPeak, int& cbPeak)
{
	LARGE_INTEGER timeFreq;
	QueryPerformanceFrequency(&timeFreq);
	// TRACE("Freq %d\n", timeFreq.LowPart);
	secsOverall = (double)(m_ticksOverallStats) / (double)timeFreq.LowPart;
	cbOverall = m_cbOverallStats;
	secsPeak = (double)(m_ticksReadStats) / (double)timeFreq.LowPart;
	cbPeak = m_cbReadStats;
}



/////////////////////////////////////////////////////////////////////
// Helper for fast image BLT

void CopyRGB(BYTE* rgbOut, const BYTE* rgbIn, int cx, int cy, int cxOut)
{
    // copy rows
	const BYTE* pb1 = rgbIn;
	for (int y = 0; y < cy; y++)
    {
		BYTE* pbRow = rgbOut + 3 * cxOut * y; // y already reversed
		memcpy(pbRow, pb1, cx*3);
		pb1 += 3*cx;
	}
}

/////////////////////////////////////////////////////////////////////
// high level connection

AIBOLAN::AIBOLAN()
{
    m_pfnError = NULL;
    m_pfnImage = NULL;
}


AIBOLAN::~AIBOLAN()
{
    Disconnect();
}


bool AIBOLAN::Init(ERROR_PROC proc)
{
    m_bPaused = true;
    ASSERT(proc != NULL);
    m_pfnError = proc;

    return true;
}

bool AIBOLAN::Connect(BYTE const ipAddr[4], int& versionRet)
{
	ASSERT(!m_telem.IsOpen());
	if (!m_telem.Connect(ipAddr))
		return false;
	versionRet = m_telem.GetVersion();
    return true;
}

void AIBOLAN::Disconnect()
{
	if (m_telem.IsOpen())
		m_telem.Disconnect();
}

void AIBOLAN::SetImageProc(IMAGE_PROC proc, bool bJpg, bool bCDT)
{
    ASSERT(proc != NULL);
    ASSERT(m_bPaused);
	m_bJpg = bJpg;
    m_bCDT = bCDT;
    m_pfnImage = proc;
	TRACE("Capture using %s\n", (m_bJpg) ? "JPEG" : "YUV10");
}

void AIBOLAN::Run(bool bRun)
{
    m_bPaused = !bRun;
}

/////////////////////////////////////////////////////////////////////
