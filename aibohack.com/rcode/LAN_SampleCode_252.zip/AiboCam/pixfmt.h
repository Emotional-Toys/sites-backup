
#define CX_GAP 2
#define CY_GAP 2

// for formatting

#define BLACKBGCOLOR	0
#define GRAYBGCOLOR 192


void Colorize(const BYTE* pbCDT, int iColor, int xBase, int yBase,
	BYTE* rgbVideoFrame, int cxVideo, int cyFrame, bool bErase = true);
