#if !defined(AFX_STATUSDLG_H__14851ED6_0832_4679_9169_4029BA69F3DC__INCLUDED_)
#define AFX_STATUSDLG_H__14851ED6_0832_4679_9169_4029BA69F3DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StatusDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// StatusDlg dialog

class StatusDlg : public CDialog
{
// Construction
public:
	StatusDlg(CWnd* pParent, const char* sz1);
	void SetTitle(const char* sz1);
	void SetText(const char* sz2);


// Dialog Data
	//{{AFX_DATA(StatusDlg)
	CStatic	m_text2;
	CStatic	m_text1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(StatusDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(StatusDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATUSDLG_H__14851ED6_0832_4679_9169_4029BA69F3DC__INCLUDED_)
