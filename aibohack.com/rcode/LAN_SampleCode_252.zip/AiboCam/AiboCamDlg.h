// AiboCamDlg.h : header file
//
#pragma once

/////////////////////////////////////////////////////////////////////////////
// CAiboCamDlg dialog

struct VIDINFO;

class CAiboCamDlg : public CDialog
{
// Construction
public:
	CAiboCamDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CAiboCamDlg)
	enum { IDD = IDD_AIBOCAM_DIALOG };
	int		m_iFmtCDT;
	CString	m_strAviPath;
	BYTE	m_b3;
	BYTE	m_b1;
	BYTE	m_b2;
	BYTE	m_b4;
	BOOL	m_bKeepAspectRatio;
	int		m_iCaptureType;
	BOOL	m_bCapAudio;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAiboCamDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CAiboCamDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStartCapture();
	afx_msg void OnTestLan();
	afx_msg void OnStartPreview();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void DoColorize(VIDINFO const& vi);	// color CDT matrices
	bool ValidateConnectInfo(VIDINFO& vi, BYTE ipAddr[4]);
	bool Connect(VIDINFO const& vi, BYTE const ipAddr[4]);
	void Disconnect();
};

