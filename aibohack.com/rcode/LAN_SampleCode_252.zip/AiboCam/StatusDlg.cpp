// StatusDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AiboCam.h"
#include "StatusDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// StatusDlg dialog



StatusDlg::StatusDlg(CWnd* pParent, const char* sz1)
{
	if (!Create(IDD_CAPTURESTATUS, pParent))
	{
		AfxMessageBox("internal error");
		return;
	}
	ShowWindow(SW_SHOW);
	m_text1.SetWindowText(sz1);
	UpdateWindow();
}

void StatusDlg::SetTitle(const char* sz1)
{
	m_text1.SetWindowText(sz1);
	UpdateWindow();
}

void StatusDlg::SetText(const char* sz2)
{
	m_text2.SetWindowText(sz2);
	UpdateWindow();
}



void StatusDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(StatusDlg)
	DDX_Control(pDX, IDC_STATUS2, m_text2);
	DDX_Control(pDX, IDC_STATUS1, m_text1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(StatusDlg, CDialog)
	//{{AFX_MSG_MAP(StatusDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// StatusDlg message handlers
