
// single threaded version using AIBOH

#include "../aiboh25.h"

/////////////////////////////////////////////////////////////////////////////

typedef void (*ERROR_PROC)(const char* szReason);
typedef void (*IMAGE_PROC)(BYTE* pbImage, BYTE* pbCDT);


class AIBOLAN
{
public:
	// public interface to polling interface

    AIBOLAN();
    ~AIBOLAN();

    bool Init(ERROR_PROC proc); // start thread going

    bool Connect(BYTE const ipAddr[4], int& version);
    void Disconnect();

    void SetImageProc(IMAGE_PROC proc, bool bJpg, bool bCDT);
	void Run(bool bRun);
	void YieldToWorkerThread();

	void ResetReadStats();
	void GetLastReadStats(double& secsOverall, int& cbOverall,
							   double& secsPeak, int& cbPeak);

public: // semi-protected
	AIBOH_TELEMETRY m_telem;	// telemetry socket

protected: // implementation
    bool m_bPaused;

    // callbacks
    ERROR_PROC m_pfnError;
    IMAGE_PROC m_pfnImage;
	bool m_bJpg, m_bCDT;

	// read stats
	long m_ticksReadStats;
	int m_cbReadStats;
	long m_ticksOverallStats;
	int m_cbOverallStats;

public:
	void Poll();
};

// other helper

void CopyRGB(BYTE* rgbOut, const BYTE* rgbIn, int cx, int cy, int cxOut);




