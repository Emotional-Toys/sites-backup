// APTELEM protocol
// standard stream socket

#define TELEMETRY_PORT              21001   /* LifePlus or RCodePlus */
#define RCODE_PORT                  21002   /* RCodePlus only */

//////////////////////////////////////////////////////////
// send byte command [optional data] to AIBO, reply with binary data

// supported by all
#define TELEMREQ_GETVER             0x20 // cb=12 (version struct)
#define TELEMREQ_GETAUDIO           0x21 // cb=0, or multiple of AUDIO_BUFF
#define TELEMREQ_GETJPEG            0x22 // cb=0 or variable, auto recapture
#define TELEMREQ_GETCOLORIMAGE      0x23 // cb=0 or 6336 (88x72) bytes
                                            // auto recapture
#define TELEMREQ_GETYUV10           0x24 // cb=0 or
                                            // multiple of PACKED_YUV10_DATA,
                                            // auto recapture
                                            // VERSION 2.51 and later

#define TELEMOP_SETPROPERTY         0x40 // 2 bytes data: iProp, bVal
#define TELEMOP_FLUSHAUDIO          0x41 // purge buffers

// For LifePlus (AL1+, AL2+, Exp+)
#define TELEMREQ_GETSEMANTICEVENT   0x30 // cb=0 or multiple of 44
#define TELEMREQ_GETVOICEDATA       0x31 // cb=0 or 40
#define TELEMOP_INJECTSEMANTICEVENT 0x33 // 40 bytes of data to follow

// For RCodePlus
#define TELEMOP_RPUT                0x32 // more complicated protocol
#define TELEMOP_GETARRAYRAW         0x35 // 1 byte data: iarray
#define TELEMOP_GETARRAYVARS        0x36 // 1 byte data: iarray
#ifdef LATER_MAYBE
#define TELEMOP_PUTARRAYRAW         0x37 // 3 byte data: iarray, byte count.W
#endif

#define TELEMREQ_GETXPRINT          0x38 // AP_PRINT buffer, long cb + chars

// Experimental builds only
#define TELEMREQ_PING               0x34 // 2 bytes data: cbReply

//////////////////////////////////////////////////////////
// for TELEMREQ_GETVER

struct TELEMVER
{
    char name[8];       // "AiboPet\0"
    unsigned char bMaj, bMin;    // version
    unsigned char bType;
    unsigned char bLang;    // 2=JPN, 3=ENG, 4=GER, 5=FRN
                            // 1=unmarked (usually ENG)
                        // Life+ only (and buggy in version 2.50)
};

enum TELEMVERTYPE
{
    TELEMVERTYPE_RCODE,     // RCode Plus
    TELEMVERTYPE_AL1,       // AiboLife 1 Plus
    TELEMVERTYPE_AL2,       // AiboLife 2 Plus
    TELEMVERTYPE_EXP,       // Explorer Plus
    TELEMVERTYPE_REC        // Recognition Plus
};

//////////////////////////////////////////////////////////
// for TELEMOP_RPUT

#define MAX_RPUT_SEND_SIZE   32768

//////////////////////////////////////////////////////////
// for TELEMREQ_GETSEMANTICEVENT and TELEMOP_INJECTSEMANTICEVENT

#define CL_SEMANTICEVENT    10      /* actual data */

// for TELEMREQ_
#define CL_SEMANTICEVENTSEQ (1+10)  /* sequence number + actual data */
#define MAX_SEMDATAARRAY    100     /* max in a single reply */

//////////////////////////////////////////////////////////
// for TELEMREQ_GETVOICEDATA

#define CL_VOICEDATA    20          /* actual data */

//////////////////////////////////////////////////////////
// for TELEMREQ_GETYUV10 (2.51 and later)

#define PACKED_FIVEBITS	15840	/* 176*144*5/8 */

struct PACKED_YUV10_DATA
{
    long sig; // first 4 bytes are 0x10 0x00 0x01 0x05
    byte tagData[16];

    //YUV format 4:2:2, 5 bits each
    byte compressedY[PACKED_FIVEBITS];
    byte compressedU[PACKED_FIVEBITS/2];
    byte compressedV[PACKED_FIVEBITS/2];
};

#define SIG_YUV10_DATA  0x05010010  // lsByte order

//////////////////////////////////////////////////////////
// for TELEMREQ_GETAUDIO (2.51 and later get multiple)

#define MAX_AUDIO_BUFF       10

struct AUDIO_BUFF
{
    long seq;
    long sensor;     // AP_SensorData 0,1
    byte wavdata[512*2*2]; // 512 16bit stereo samples
};

//////////////////////////////////////////////////////////
// conventions for array numbers
//  for TELEMOP_GETARRAYRAW, TELEMOP_GETARRAYVARS

#define ARRAY_NORMAL_FIRST 1 /* 1->20 are normal arrays */
#define ARRAY_NORMAL_LAST 20

#define ARRAY_TELEM_FIRST 21 /* 21->25 are telemetry arrays */
#define ARRAY_TELEM_LAST 25

//////////////////////////////////////////////////////////
