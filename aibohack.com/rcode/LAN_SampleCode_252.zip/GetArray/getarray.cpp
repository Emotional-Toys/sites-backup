// Use telemetry to get array data
//
// for all arrays, save the raw data if the array is dimensioned
//  in addition for arrays 21->25, array may be variable array
//   in that case the raw data is bogus,
//    and the current variable values are savede

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "../aiboh25.h" // helper classes

////////////////////////////////////////////////////////

bool SaveFile(const char* pathName, byte* data, int size);

int main(int argc, char* argv[])
{
    // default arguments
    int iSpecial = -1;
    const char* ipAddress = "10.0.1.100";

    // user provided values
    if (argc > 1)
        ipAddress = argv[1];

    AIBOH_TELEMETRY telem;
    printf("Connecting to AIBO...");
    if (!telem.Connect(ipAddress))
    {
        printf("FAILED\n");
        return -1;
    }
    printf("Success\n");

    // get all of them
    assert(ARRAY_NORMAL_LAST + 1 == ARRAY_TELEM_FIRST);
    for (int iArray = ARRAY_NORMAL_FIRST; iArray <= ARRAY_TELEM_LAST; iArray++)
    {
        byte rgb2[2];
        rgb2[0] = TELEMOP_GETARRAYRAW;
        rgb2[1] = (byte)iArray; // 1 based

        printf("Array %d: ", iArray);
        // telem.PurgeReply(); // just in case

		if (!telem.SendCommandBytes(rgb2, 2))
        {
            printf("Send error\n");
            return -1;
        }
        long cbData = -1;
        if (!telem.ReceiveReply((byte*)&cbData, 4) || cbData < 0)
        {
            printf("Receive size error (%d)\n", cbData);
            return -1;
        }
        if (cbData == 0)
        {
            printf("not used\n");
            continue;
        }

	    printf("%d raw bytes", cbData); // 1 if error
        byte* pbData = new byte[cbData];

	    if (!telem.ReceiveReply(pbData, cbData))
        {
	        printf("Receive data error\n");
	        return -1;
        }

        char pathName[64];
        sprintf(pathName, "ARRAY%d.DAT", iArray);
		if (!SaveFile(pathName, pbData, cbData))
		{
		    printf("Could not save file %s - disk may be full\n",
                pathName);
            return -1;
	    }
        delete [] pbData;
		printf(", saved to %s\n", pathName);

        if (iArray < ARRAY_TELEM_FIRST)
            continue;   // normal arrays don't usually contain variables

        if ((cbData & 3) != 0)
            continue;       // not the rights size for var address array

        // now see if a variable array
        int nPossibleVars = cbData / 4;

        rgb2[0] = TELEMOP_GETARRAYVARS;
        rgb2[1] = (byte)iArray; // 1 based
		if (!telem.SendCommandBytes(rgb2, 2))
        {
            printf("Send error\n");
            return -1;
        }

        long cbActual;
		if (!telem.ReceiveReply((byte*)&cbActual, 4) || cbActual < 0)
        {
            printf("Receive size error (%d)\n", cbData);
            return -1;
        }
        if (cbActual == 1)
        {
            // not proper format for VAR array
            byte bIgnore;
			telem.ReceiveReply(&bIgnore, 1); // tells us which field failed
            continue;
        }

        if (cbActual != nPossibleVars * 2)
        {
            printf("\t not a var array - but strange size (%d %d)\n",
                cbActual, cbData);
            telem.PurgeReply();
            continue;
        }
        byte* pbVars = new byte[cbActual];

		if (!telem.ReceiveReply(pbVars, cbActual))
        {
	        printf("Receive vars data error\n");
	        return -1;
        }

        sprintf(pathName, "VARS%d.DAT", iArray);
		if (!SaveFile(pathName, pbVars, cbActual))
		{
		    printf("Could not save file %s - disk may be full\n",
                pathName);
            return -1;
	    }
        delete [] pbVars;
		printf("\tVARARRAY saved %d variables to %s\n",
                nPossibleVars, pathName);
    }


    telem.Disconnect();

    return 0;
}

///////////////////////////////////////////////////////////////


bool SaveFile(const char* pathName, byte* data, int size)
{
    FILE* file = fopen(pathName, "wb");
    if (file == NULL)
		return false;

    if (fwrite(data, size, 1, file) != 1)
	{
		fclose(file);
        return false;
    }
	fclose(file);
    return true;
}

///////////////////////////////////////////////////////////////
