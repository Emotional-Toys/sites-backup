// Standard includes
#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmsystem.h>

#define MAX_STRING  256

#include <winsock.h>

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
