// updated with RCodePlus 2.52 release to use AiboH helper classes

#include "std.h"

#include <time.h>

#include "../aiboh25.h"

static void PrUsage()
{
    printf("aiboplayr - play MTN LED WAV [MID]\n");
    printf("RAM version\n");
    printf("Usage:\n");
    printf("\taiboplayr ip_address mtn_file le2_file wav_file [mid_file]\n");
    printf("\tuse - for files that aren't needed\n");
    printf("\tLED must be in 'LE2' format\n");
}

////////////////////////////////////////

void DoPurge(AIBOH_TELEMETRY& telem, AIBOH_RCODE& rcode, const char* szTag)
{
    telem.PurgeReply();
    rcode.PurgeReply();
}

BYTE WaitForTelemAck(AIBOH_TELEMETRY& telem)
{
    BYTE b;
    if (!telem.ReceiveReply(&b, 1))
        return 0xFF;
    return b;
}

bool CopyToAIBO_R(AIBOH_TELEMETRY& telem, const char* szSrc)
{
    // copy from AIBO
    FILE* pfLocal = fopen(szSrc, "rb");
    if (pfLocal == NULL)
    {
        printf("Can't open local source file '%s'\n", szSrc);
        return false;
	}
    fseek(pfLocal, 0, SEEK_END);
    long cbFile = ftell(pfLocal);
    fseek(pfLocal, 0, SEEK_SET);

    BYTE rgbRput[1+4];
    rgbRput[0] = TELEMOP_RPUT;
    memcpy(&rgbRput[1], &cbFile, 4); // size
	if (!telem.SendCommandBytes(rgbRput, 1+4))
    {
        printf("Error sending RPUT command\n");
        fclose(pfLocal);
        return false;
    }

    BYTE* pbFile = new BYTE[cbFile];
    assert(pbFile != NULL);
    if (fread(pbFile, cbFile, 1, pfLocal) != 1)
    {
        printf("local file read error\n");
        fclose(pfLocal);
        return false;
    }
	fclose(pfLocal); // file no longer used

    int cbTodo = cbFile;
    const BYTE* pbTodo = pbFile;
    while (cbTodo > 0)
    {
        int cbChunk = cbTodo;
        if (cbChunk > MAX_RPUT_SEND_SIZE)
            cbChunk = MAX_RPUT_SEND_SIZE;

        BYTE bAck = WaitForTelemAck(telem);
        if (bAck != 1)
        {
	        printf("Error ack is bad $%x\n", bAck);
	        return false;
        }


		if (!telem.SendCommandBytes(pbTodo, cbChunk))
	    {
	        printf("Error sending data (%d byte chunk %d / %d)\n",
                    cbChunk, pbTodo - pbFile, cbFile);
	        return false;
	    }


        pbTodo += cbChunk;
        cbTodo -= cbChunk;
    }
    assert(pbTodo == pbFile + cbFile);

    delete [] pbFile; // not always cleaned up

    printf("file '%s' written to ram (through telemetry pipe)\n", szSrc);
    return true;
}

bool Expect(AIBOH_RCODE& rcode, const char* szExpect)
{
    char szReply[512];
    memset(szReply, '?', 512);
    if (!rcode.ReceiveTextReply(szReply, strlen(szExpect)+1))
    {
        printf("Error waiting for result '%s'\n", szReply);
        return false;
    }
    if (strncmp(szExpect, (char*)szReply, strlen(szExpect) != 0))
    {
        printf("Error result %s\n", szReply);
        return false;
    }
    return true;
}


bool ExpectSuccess(AIBOH_RCODE& rcode)
{
    return Expect(rcode, "MTN_MSG_SUCCESS");
}

bool SendCommandStringEcho(AIBOH_RCODE& rcode, const char* szCmd)
{
    printf("sending '%s' to RCODE pipe\n", szCmd);
    if (!rcode.SendCommandBytes((const BYTE*)szCmd, strlen(szCmd)+1))
        return false;

    // expect echo
    BYTE szReply[512];
    if (!rcode.ReceiveReply(szReply, strlen(szCmd)+2+1))
    {
        printf("Error sending '%s' (reply)\n", szCmd);
        return false;
    }
    if (strncmp(szCmd, (char*)szReply, strlen(szCmd)) != 0)
    {
        printf("Error sending '%s' (echo)\n", szCmd);
        for (int i = 0; i < strlen(szCmd); i++)
            printf("\texpected $%x got $%x\n", szCmd[i], szReply[i]);
		printf("\tfinal bytes $%x $%x $%x\n",
             szReply[i], szReply[i+1], szReply[i+2]);
        return false;
    }
    return true;
}

bool SendCommand2(AIBOH_RCODE& rcode, const char* szCmdFmt, const char* szArg)
{
    char szT[256];
    sprintf(szT, szCmdFmt, szArg);
    return SendCommandStringEcho(rcode, szT);
}

bool LoadPerfFile(AIBOH_RCODE& rcode, const char* szType, bool bMidi = false)
{
    char szT[256];
    sprintf(szT, "LOAD:%s:%s", szType, bMidi ? "ram.MID" : "ram");
    if (!SendCommandStringEcho(rcode, szT)) // and echo
        return false;
    if (!ExpectSuccess(rcode))
    {
        printf("command %s failed\n", szT);
        return false;
    }
    return true;
}
    

int main(int argc, char* argv[])
{
    if (argc != 5 && argc != 6)
    {
        PrUsage();
        return -1;
    }
    const char* szIP = argv[1];
    const char* szMtn = argv[2];
    const char* szLed = argv[3];
    const char* szWav = argv[4];
    const char* szMid = argv[5];

    if (strcmp(szMtn, "-") == 0)
        szMtn = NULL;
    if (strcmp(szLed, "-") == 0)
        szLed = NULL;
    if (strcmp(szWav, "-") == 0)
        szWav = NULL;
    if (szMid != NULL && strcmp(szMid, "-") == 0)
        szMid = NULL;

    if (szWav != NULL && szMid != NULL)
    {
        printf("ERROR: can't have both .MID and .WAV\n");
        return -1;
    }
    if (szMtn == NULL && szLed == NULL && szWav == NULL && szMid == NULL)
    {
        PrUsage();
        return -1;
    }

    // need both the telemetry and RCODE ports

    AIBOH_TELEMETRY telem;
    printf("Connecting to AIBO...");
    if (!telem.Connect(szIP))
    {
        printf("FAILED\n");
        return -1;
    }
    printf("Success\n");

    TELEMVER tver;
    if (!telem.GetVersionRaw(tver))
    {
        printf("Telemetry connection flakey\n");
        return -1;
    }
        
    if (tver.bType != TELEMVERTYPE_RCODE)
    {
        printf("Not RcodePlus stick\n");
        return -1;
    }

    Sleep(500); // bogus, but it may help

    AIBOH_RCODE rcode;
	if (!rcode.Connect(szIP))
    {
        printf("RCODE telnet pipe did not open (but telemetry did)\n");
        return -1;
	}

    const char* szMtnRemote = "/MS/OPEN-R/APP/PC/AMS/AMS.MTN";
    const char* szLedRemote = "/MS/OPEN-R/APP/PC/AMS/AMS.LED";
    const char* szWavRemote = "/MS/OPEN-R/APP/PC/AMS/AMS.WAV";
    const char* szMidRemote = "/MS/OPEN-R/APP/PC/AMS/AMS.MID";

    bool bOK = true;

    Sleep(500);
    DoPurge(telem, rcode, "start");
    SendCommandStringEcho(rcode, "INIT:MTN");
    if (!ExpectSuccess(rcode))
    {
        printf("INIT:MTN failed\n");
        bOK = false;
    }
        
    DoPurge(telem, rcode, "pre load MTN");
    if (bOK && szMtn)
    {
        if (!CopyToAIBO_R(telem, szMtn) || !LoadPerfFile(rcode, "MTN"))
	        bOK = false;
    }
    DoPurge(telem, rcode, "pre load LED");
    if (bOK && szLed)
    {
        if (!CopyToAIBO_R(telem, szLed) || !LoadPerfFile(rcode, "LED"))
	        bOK = false;
    }
    DoPurge(telem, rcode, "pre load WAV");
    if (bOK && szWav)
    {
        if (!CopyToAIBO_R(telem, szWav) || !LoadPerfFile(rcode, "SND"))
	        bOK = false;
    }
    DoPurge(telem, rcode, "pre load MID");
    if (bOK && szMid)
    {
        if (!CopyToAIBO_R(telem, szMid) || !LoadPerfFile(rcode, "SND", true))
	        bOK = false;
    }

    if (!bOK)
    {
        printf("ERROR: problem initing performance files\n");
        return -1;
    }

    DoPurge(telem, rcode, "pre-play");
    SendCommandStringEcho(rcode, "PLAY:MTN");

    printf("Playing");
    // poll until "Wait" is done
    while (rcode.GetIntValue("Wait") > 0)
    {
        printf(".");
        Sleep(100);
    }
    printf("\n");

    DoPurge(telem, rcode, "final");

    rcode.Disconnect();
    telem.Disconnect();

    return bOK ? 0 : 1;
}
