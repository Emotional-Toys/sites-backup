//////////////////////////////////////
// Visual Basic interface


#define VBAIBO_API(ret) extern "C" __declspec(dllexport) ret _stdcall
typedef signed short VB_BOOL;
#define VB_TRUE -1
#define VB_FALSE 0


#include "../aiboh25.h"
