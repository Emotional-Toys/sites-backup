// VBAIBO.cpp : Defines the entry point for the DLL application.
//


#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <assert.h>
#include <time.h>
#include <winsock.h>


#include "VBAIBO.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  reason, 
                       LPVOID lpReserved
					 )
{
    switch (reason)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


/////////////////////////////////////////////////////////////////////
// Using the AIBOH library

AIBOH_TELEMETRY theTelemetrySocket;
AIBOH_RCODE theRcodeSocket;

/////////////////////////////////////////////////////////////////////
// other helpers  for AIBO

VBAIBO_API(VB_BOOL) AIBO_SendCommandString(const char* szCmd)
{
	if (theRcodeSocket.IsOpen() && theRcodeSocket.SendCommandString(szCmd))
		return VB_TRUE;
	else
		return VB_FALSE;
}

VBAIBO_API(void) AIBO_PurgeReply()
{
	// purge one or both
	if (theTelemetrySocket.IsOpen())
		theTelemetrySocket.PurgeReply();
	if (theRcodeSocket.IsOpen())
		theRcodeSocket.PurgeReply();
}

VBAIBO_API(VB_BOOL) AIBO_ReceiveRcodeReply(byte* pbReply, int cbReply)
{
	if (theRcodeSocket.ReceiveReply(pbReply, cbReply))
		return VB_TRUE;
	else
		return VB_FALSE;
}

#if 0
VBAIBO_API(VB_BOOL) AIBO_ReceiveTextReply(char* szReply)
{
    int cbReply = 255;  // max buffer size
	while (cbReply > 1)x
	{
		byte b;
		if (!AIBO_ReceiveReply(aiboHandle, &b, 1))
			return VB_FALSE;
		if (b == 0)
			break;	// end of string
		*szReply++ = (char)b;
		cbReply--;
	}
	*szReply++ = '\0';	// force termination
	return VB_TRUE;
}

#endif

static bool _GetString(char* szReply)
{
    int cbReply = 255;  // max buffer size
	while (cbReply > 1)
	{
		byte b;
		if (!AIBO_ReceiveRcodeReply(&b, 1))
			return false;
		if (b == 0)
			break;	// end of string
		*szReply++ = (char)b;
		cbReply--;
	}
	*szReply++ = '\0';	// force termination
	return true;
}

VBAIBO_API(VB_BOOL) AIBO_GetValue(const char* szVariable, char* szReply)
{
	AIBO_PurgeReply();
	char szCmd[256];
	wsprintf(szCmd, "PRINT:%%d:%s", szVariable);

	if (!AIBO_SendCommandString(szCmd))
		return VB_FALSE;
	char szIgnore[256];	// echo reply
	if (!_GetString(szIgnore))
		return VB_FALSE;
	if (!_GetString(szReply))
		return VB_FALSE;

	char* pch = strchr(szReply, 13);
	if (pch == NULL)
		pch = szReply + strlen(szReply);
	// pad with blanks from pch to szReply+255
	memset(pch, ' ', szReply+256-pch);
	return VB_TRUE;
}


/////////////////////////////////////////////////////////////////////
// high level connection


VBAIBO_API(VB_BOOL) AIBO_Connect(byte ipAddr[4], VB_BOOL bNeedRcode)
{

#if 0
	char szT[256];
	wsprintf(szT, "IP: %d %d %d %d (%d)", ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3], ipAddr[4]);
	MessageBox(NULL, szT, "vbaibo.dll", MB_OK | MB_SYSTEMMODAL);

#endif
	assert(!theTelemetrySocket.IsOpen());
	assert(!theRcodeSocket.IsOpen());
    if (!theTelemetrySocket.Connect(ipAddr))
		return VB_FALSE;
	if (bNeedRcode && !theRcodeSocket.Connect(ipAddr))
		return VB_FALSE;

    return VB_TRUE;
}

VBAIBO_API(void) AIBO_Disconnect()
{
	if (theTelemetrySocket.IsOpen())
		theTelemetrySocket.Disconnect();
	if (theRcodeSocket.IsOpen())
		theRcodeSocket.Disconnect();
	assert(!theTelemetrySocket.IsOpen());
	assert(!theRcodeSocket.IsOpen());
}


/////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
// high level picture access

static void _CopyToPicture(HDC hdcPict, int cx, int cy, const byte* rgbBuffer)
{
	BITMAPINFO bmi;
	memset(&bmi, 0, sizeof(bmi));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = cx;
	bmi.bmiHeader.biHeight = cy;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;
	
	SetDIBitsToDevice(hdcPict, 0, 0, cx, cy,
			0, 0, 0, cy, rgbBuffer, &bmi, DIB_RGB_COLORS);
}

VBAIBO_API(VB_BOOL) AIBO_GetLargeImage(HDC hdcPict)
{
	// YUV10 only (no JPEG anymore)
	PACKED_YUV10_DATA packedData;
	if (!theTelemetrySocket.GetImageYUV10(packedData))
		return VB_FALSE;

	byte rgbBmpData[CB_FULLIMAGE];
	AIBOH_TELEMETRY::ConvertToRgb(rgbBmpData, packedData);
    _CopyToPicture(hdcPict, CX_FULLIMAGE, CY_FULLIMAGE, rgbBmpData);
    return VB_TRUE;
}

////////////////////////////////////////////////////////////////////////////////
// for color detection matrix

VBAIBO_API(VB_BOOL) AIBO_GetColorData(byte* pbImage)
{
	if (!theTelemetrySocket.GetColorData(pbImage))
        return VB_FALSE;

    return VB_TRUE;
}

#define BLACKBGCOLOR	0
#define GRAYBGCOLOR 192

#define COLOR_RED RGB(255, 0, 0)
#define COLOR_PINK RGB(255, 81, 146)
#define COLOR_BLACK RGB(0, 0, 0)
#define COLOR_BLUE RGB(135, 114, 255)
#define COLOR_GREEN RGB(151, 255, 54)
#define COLOR_FLESH RGB(180, 121, 88)


static COLORREF s_colorDT[8] =
{
	COLOR_RED,
	COLOR_PINK,
	COLOR_BLACK,
	COLOR_BLACK,
	COLOR_BLUE,
	COLOR_GREEN,
	COLOR_FLESH,
	COLOR_BLACK,
};

static void Colorize(const BYTE* pbCDT, int iColor, int xBase, int yBase,
	BYTE* rgbVideoFrame, int cxVideo, int cyFrame, bool bErase /*= true*/)
{
    assert(iColor >= 0 && iColor < 8);
    BYTE bMask = (1 << iColor);
    COLORREF color = s_colorDT[iColor];

	BYTE rgbOn[3];
	rgbOn[0] = GetBValue(color);
	rgbOn[1] = GetGValue(color);
	rgbOn[2] = GetRValue(color);

	int yBase2 = cyFrame - 1 - yBase;	// bottom line
	BYTE* pbBase = &rgbVideoFrame[3*(xBase + cxVideo * yBase2)];
	int yLine = 0;
	for (int y = 0; y < CY_COLORIMAGE; y++)
	{
		BYTE* pbOut = &pbBase[(cxVideo*3)*yLine--];	// bottom up
	    if (bErase)
	        memset(pbOut, GRAYBGCOLOR, CX_COLORIMAGE*3);
		for (int x = 0; x < CX_COLORIMAGE; x++)
		{
			if (*pbCDT++ & bMask)
				memcpy(pbOut, rgbOn, 3);		// 3 byte BGR
			pbOut += 3;
		}
	}
}


VBAIBO_API(VB_BOOL) AIBO_RenderMergedColorDetect(const byte* pbImage, HDC hdcPict)
{
	byte rgbBuffer[CY_COLORIMAGE * CX_COLORIMAGE * 3];

    bool bErase = true;
    for (int iColor = 8-1; iColor >= 0; iColor--) // higher #s first
    {
		Colorize(pbImage, iColor, 0, 0, rgbBuffer, CX_COLORIMAGE, CY_COLORIMAGE, bErase);
        bErase = false; // merge rest
	}
    _CopyToPicture(hdcPict, CX_COLORIMAGE, CY_COLORIMAGE, rgbBuffer);
	return VB_TRUE;
}
