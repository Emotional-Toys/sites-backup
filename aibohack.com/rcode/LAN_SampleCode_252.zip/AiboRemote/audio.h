
bool OpenAudio();
void CloseAudio();
bool IsAudioOpen();
void BeginPumpAudio();
void PumpAudio();
