// helper dialogs for AIBO URL and connection

////////////////////////////////////////////////////////////
// CUrlDlg dialog

class CUrlDlg : public CDialog
{
// Construction
public:
	CUrlDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	BYTE	m_ipAddr[4];
	BOOL	m_bCapAudio;

// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	DECLARE_MESSAGE_MAP()
	afx_msg void OnSimple();
	afx_msg void OnSoccer();
	afx_msg void OnComplex();
};

////////////////////////////////////////////////////////////
// CConnectingStatusDlg dialog

class CConnectingStatusDlg : public CDialog
{
public:
	CConnectingStatusDlg(CWnd* pParent = NULL);
	void Begin();
	void End();
};

////////////////////////////////////////////////////////////
