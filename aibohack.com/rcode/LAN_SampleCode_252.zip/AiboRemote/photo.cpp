// photo.cpp - CPhotoCtrl

#include "AiboRemote.h"
#include "photo.h"

////////////////////////////////////////////////////////////

static void ResizeControl(CWnd* pWnd, int cx, int cy)
{
	CRect rcWindow, rcClient;
	pWnd->GetWindowRect(rcWindow);
	pWnd->GetClientRect(rcClient);
	int dx = cx - rcClient.Width();
	int dy = cy - rcClient.Height();
	pWnd->SetWindowPos(NULL, 0, 0,
		rcWindow.Width() + dx, rcWindow.Height() + dy,
		SWP_NOMOVE | SWP_NOZORDER);

}

////////////////////////////////////////////////////////////
// Photo Control

BEGIN_MESSAGE_MAP(CPhotoCtrl, CWnd)
	//{{AFX_MSG_MAP(CPhotoCtrl)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CPhotoCtrl::Init(CDialog* pParent, int nIDC)
{
	VERIFY(SubclassWindow(::GetDlgItem(pParent->m_hWnd, nIDC)));
	ResizeControl(this, CX_FULLIMAGE, CY_FULLIMAGE);

	m_rgbImage = new BYTE[CB_FULLIMAGE];
	m_bImageValid = false;
}

void CPhotoCtrl::OnPaint()
{
	PAINTSTRUCT ps;
	CDC* pdc = BeginPaint(&ps);
	CRect rc;
	GetClientRect(&rc);

	int cx = CX_FULLIMAGE;
	int cy = CY_FULLIMAGE;

	// photo paint
	rc.left = (rc.Width() - cx) / 2;
	rc.top = (rc.Height() - cy) / 2;
	rc.right = rc.left + cx;
	rc.bottom = rc.top + cy;

	if (!m_bImageValid)
	{
		CBrush br2(RGB(0,0,128));
		pdc->FillRect(&rc, &br2);
	}
	else
	{
		BITMAPINFO bmi;
		memset(&bmi, 0, sizeof(bmi));
		bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmi.bmiHeader.biWidth = cx;
		bmi.bmiHeader.biHeight = cy;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 24;
		bmi.bmiHeader.biCompression = BI_RGB;
		
		SetDIBitsToDevice(pdc->m_hDC, rc.left, rc.top, cx, cy,
			0, 0, 0, cy, m_rgbImage,
			&bmi, DIB_RGB_COLORS);
	}

	EndPaint(&ps);

}

bool CPhotoCtrl::GetAndUpdateImage(byte* pbTagData)
{
	Invalidate(FALSE);	// don't bother erasing background
	m_bImageValid = false;

	PACKED_YUV10_DATA packedData;
	if (!theTelemetryConnection.GetImageYUV10(packedData))
	{
		TRACE("GetImageYUV10 failed\n");
		return false;
	}

	if (pbTagData != NULL)
		memcpy(pbTagData, packedData.tagData, 16);


	// convert from packed to raw BMP info
	ASSERT(m_rgbImage != NULL);
	AIBOH_TELEMETRY::ConvertToRgb(m_rgbImage, packedData);

#ifdef LATER
	// keep 8 color levels from the tagData
#endif
	m_bImageValid = true;
	return true;
}

// 1 pixel wide/high - so you can see image as well
void CPhotoCtrl::DrawCrossHair(int x, int y, COLORREF color)
{
	byte* pbColor = (byte*)&color;
	byte rgb3[3];	// in easy to memcpy order
	rgb3[0] = pbColor[2];
	rgb3[1] = pbColor[1];
	rgb3[2] = pbColor[0];

	// horizontal line
	byte* pb = m_rgbImage + (CY_FULLIMAGE - y - 1) * CX_FULLIMAGE * 3;
	for (int x2 = 0; x2 < CX_FULLIMAGE; x2++)
	{
		memcpy(pb, rgb3, 3);
		pb += 3;
	}

	// vertical line
	pb = m_rgbImage + x * 3;
	for (int y2 = 0; y2 < CY_FULLIMAGE; y2++)
	{
		memcpy(pb, rgb3, 3);
		pb += CX_FULLIMAGE*3;
	}
}


////////////////////////////////////////////////////////////
// Color Detection Images

BEGIN_MESSAGE_MAP(CColorCtrl, CWnd)
	//{{AFX_MSG_MAP(CColorCtrl)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CColorCtrl::Init(CDialog* pParent, int nIDC)
{
	VERIFY(SubclassWindow(::GetDlgItem(pParent->m_hWnd, nIDC)));
	ResizeControl(this, CX_COLORIMAGE, CY_COLORIMAGE);

	m_rgbImage = new BYTE[CY_COLORIMAGE * CX_COLORIMAGE * 3];
}


void CColorCtrl::OnPaint()
{
	PAINTSTRUCT ps;
	CDC* pdc = BeginPaint(&ps);
	CRect rc;
	GetClientRect(&rc);

	int cx = CX_COLORIMAGE;
	int cy = CY_COLORIMAGE;

	// photo paint
	rc.left = (rc.Width() - cx) / 2;
	rc.top = (rc.Height() - cy) / 2;
	rc.right = rc.left + cx;
	rc.bottom = rc.top + cy;

	if (m_rgbImage == NULL)
	{
		CBrush br2(RGB(0,0,128));
		pdc->FillRect(&rc, &br2);
	}
	else
	{
		BITMAPINFO bmi;
		memset(&bmi, 0, sizeof(bmi));
		bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmi.bmiHeader.biWidth = cx;
		bmi.bmiHeader.biHeight = cy;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 24;
		bmi.bmiHeader.biCompression = BI_RGB;
		
		SetDIBitsToDevice(pdc->m_hDC, rc.left, rc.top, cx, cy,
			0, 0, 0, cy, m_rgbImage,
			&bmi, DIB_RGB_COLORS);
	}

	EndPaint(&ps);

}


void CColorCtrl::Erase()
{
	memset(GetBuffer(), 0xc0, CY_COLORIMAGE * CX_COLORIMAGE * 3);	// gray background
}

void CColorCtrl::Colorize(byte cdtBuffer[CB_COLORIMAGE], int iColor, COLORREF color)
{
	byte* rgbFrame = GetBuffer();
	const int cxFrame = CX_COLORIMAGE;
	const int cyFrame = CY_COLORIMAGE;
	const int xBase = 0;
	const int yBase = 0;

    ASSERT(iColor >= 0 && iColor < 8);
    byte bMask = (1 << iColor);
	byte* pbCDT = cdtBuffer;

	byte rgbOn[3];
	rgbOn[0] = GetBValue(color);
	rgbOn[1] = GetGValue(color);
	rgbOn[2] = GetRValue(color);

	int yBase2 = cyFrame - 1 - yBase;	// bottom line
	byte* pbBase = &rgbFrame[3*(xBase + cxFrame * yBase2)];
	int yLine = 0;
	for (int y = 0; y < CY_COLORIMAGE; y++)
	{
		byte* pbOut = &pbBase[(cxFrame*3)*yLine--];	// bottom up
		for (int x = 0; x < CX_COLORIMAGE; x++)
		{
			if (*pbCDT++ & bMask)
				memcpy(pbOut, rgbOn, 3);		// 3 byte BGR
			pbOut += 3;
		}
	}
}


////////////////////////////////////////////////////////
// Color Level Bar Graph

BEGIN_MESSAGE_MAP(CBarGraphCtrl, CWnd)
	//{{AFX_MSG_MAP(CBarGraphCtrl)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

#define WIDTH_BAR		5
#define WIDTH_GAP		2
#define HEIGHT_BAR		32
#define BACKCOLOR_BAR	RGB(192, 192, 192)

void CBarGraphCtrl::Init(CDialog* pParent, int nIDC)
{
	VERIFY(SubclassWindow(::GetDlgItem(pParent->m_hWnd, nIDC)));
	ResizeControl(this, WIDTH_BAR * NUM_BAR + WIDTH_GAP * (NUM_BAR - 1), HEIGHT_BAR);
	memset(m_values, 0, sizeof(m_values));
}

static COLORREF s_barColors[NUM_BAR] =
{
	RGB(255, 0, 0), // red
	RGB(255, 81, 146), // pink
	RGB(0, 0, 0), // black
    // 3 skipped
	RGB(135, 114, 255), // blue
	RGB(151, 255, 54), // green
	RGB(180, 121, 88), // flesh ??
    // 7 skipped
};


void CBarGraphCtrl::OnPaint()
{
	PAINTSTRUCT ps;
	CDC* pdc = BeginPaint(&ps);
	CRect rc;
	GetClientRect(&rc);

	CBrush brBack(BACKCOLOR_BAR);
	pdc->FillRect(&rc, &brBack);

	for (int iBar = 0; iBar < NUM_BAR; iBar++)
	{
		// photo paint
		byte bVal = m_values[iBar];
		if (bVal > 0)
		{
			int height = (bVal * HEIGHT_BAR) / 255;

			CBrush brBar(s_barColors[iBar]);
			rc.left = iBar * (WIDTH_BAR + WIDTH_GAP);
			rc.right = rc.left + WIDTH_BAR;
			rc.top = HEIGHT_BAR - height;
			rc.bottom = HEIGHT_BAR;
			pdc->FillRect(&rc, &brBar);
		}

	}
	EndPaint(&ps);
}

void CBarGraphCtrl::SetValues(byte const tagData[16])
{
    ASSERT(NUM_BAR == 6);

	memcpy(&m_values[0], &tagData[8], 3);
	memcpy(&m_values[3], &tagData[4], 3);
	Invalidate(FALSE);
}



////////////////////////////////////////////////////////


