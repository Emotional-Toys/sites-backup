// AiboRemote.cpp
//

#include "AiboRemote.h"
#include "urldlg.h"		// url helper dialog

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// Globals

CMainApp theApp;

AIBOH_TELEMETRY theTelemetryConnection;
AIBOH_RCODE theRcodeConnection;

////////////////////////////////////////////////////////////
// CMainDlg dialog

BOOL CMainApp::InitInstance()
{
	SetRegistryKey("AiboPet Example");

    int idcUIType; // IDC_SIMPLE, IDC_COMPLEX, IDC_SOCCER

	byte ipAddr[4];
	//BLOCK: find ip address	
	{
		// Get last saved IP address
		CString strIP = AfxGetApp()->GetProfileString("Settings", "IPADDR", "");
		if (!AIBOH_CONNECTION::ParseIPAddrString(ipAddr, strIP))
		{
			// default
			ipAddr[0] = 10;
			ipAddr[1] = 0;
			ipAddr[2] = 1;
			ipAddr[3] = 100;
		}

		CUrlDlg askUrlDlg;
		memcpy(askUrlDlg.m_ipAddr, ipAddr, sizeof(ipAddr)); // initial value
        
	    idcUIType = askUrlDlg.DoModal();
        if (idcUIType != IDC_SIMPLE && idcUIType != IDC_COMPLEX &&
	        idcUIType != IDC_SOCCER)
        {
			return FALSE;
        }

		memcpy(ipAddr, askUrlDlg.m_ipAddr, sizeof(ipAddr));	// use this ip address
		// open audio connection for all versions
	    if (askUrlDlg.m_bCapAudio && !OpenAudio())
			AfxMessageBox("No audio device found\nAIBO audio disabled");
	}	

	//BLOCK: attempt connection
	{
		CConnectingStatusDlg statusDlg;
		statusDlg.Begin();

		if (!theTelemetryConnection.Connect(ipAddr))
		{
			statusDlg.End();
			AfxMessageBox("Failed to connect to AIBO (telemetry)");
			return FALSE;
		}
		TRACE("TELEMETRY socket connected\n");

		TELEMVER tver;
		if (!theTelemetryConnection.GetVersionRaw(tver))
		{
			statusDlg.End();
			AfxMessageBox("Telemetry connection flakey");
			return FALSE;
		}
			
		if (tver.bType != TELEMVERTYPE_RCODE)
		{
			statusDlg.End();
			AfxMessageBox("This is a LifePlus stick\nPlease use AiboScope instead");
			return FALSE;
		}
		if (!theRcodeConnection.Connect(ipAddr))
		{
			statusDlg.End();
			AfxMessageBox("Failed to connect to AIBO (r-code)\n"
				"Probably not an RCODE/PMS stick\n");
			return FALSE;
		}
		TRACE("RCODE socket connected\n");

		// Connecting to RCODE socket will stop any running R-CODE program

		TRACE("RCode version = %d\n", theRcodeConnection.GetIntValue("AP_Version"));
		statusDlg.End();
	}

	//BLOCK: success - save IP address for later use
	{
		char szIP[64];
		wsprintf(szIP, "%d.%d.%d.%d", ipAddr[0], ipAddr[1], ipAddr[2], ipAddr[3]);
		WriteProfileString("Settings", "IPADDR", szIP);
	}

    // pick one of three UI dialogs
	CDialog* pDlg = NULL;
	if (idcUIType == IDC_SIMPLE)
        pDlg = NewSimpleDialog();
	else if (idcUIType == IDC_COMPLEX)
        pDlg = NewComplexDialog();
	else if (idcUIType == IDC_SOCCER)
        pDlg = NewSoccerDialog();
    ASSERT(pDlg != NULL);
	m_pMainWnd = pDlg;

	pDlg->DoModal();	// runs the main user interface
    delete pDlg;

	// cleanup
	theTelemetryConnection.Disconnect();
	theRcodeConnection.Disconnect();
	CloseAudio();

	return FALSE;	// done
}

////////////////////////////////////////////////////////////

void SendRcodeCommand(const char* szCmd)
{
	TRACE("RCODE: %s\n", szCmd);
	if (!theRcodeConnection.SendCommandString(szCmd))
		AfxMessageBox("Failed to send command to AIBO\nAIBO may be disconnected");
}

////////////////////////////////////////////////////////////
