
#include "AiboRemote.h"

// common implementation of AIBO helper socket classes
#define BUILD_WINDOWS

#include "../aiboh25.cpp"


