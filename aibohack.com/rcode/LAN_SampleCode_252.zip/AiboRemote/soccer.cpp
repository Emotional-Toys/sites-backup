// Soccer.cpp - Soccer User Interface
//  designed for playing soccer
//

#include "AiboRemote.h"
#include "photo.h"		// photo control
#include "urldlg.h"		// url helper dialog

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// CSoccerDlg dialog

class CSoccerDlg : public CDialog
{
// Construction
public:
	CSoccerDlg(CWnd* pParent = NULL);	// standard constructor

	// helpers
	void Walk(int angle, int duration);
	void Turn(int angle);
	void Look(int hAngle, int vAngle);

// Implementation
protected:
	HICON m_hIcon;	// icon to draw

	// photo controls (3 resolutions)
	CPhotoCtrl m_photoCtrl;
	CColorCtrl m_colorCtrl;

    bool m_bDrawCrosshairs;

	// Generated message map functions
	//{{AFX_MSG(CSoccerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	afx_msg void OnWalkFwd();
	afx_msg void OnWalkBwd();
	afx_msg void OnWalkStop();
	afx_msg void OnTurnLeft();
	afx_msg void OnTurnRight();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnStandup();
	afx_msg void OnSitdown();
	afx_msg void OnLiedown();
	afx_msg void OnWalkFl();
	afx_msg void OnWalkFr();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnWalkBl();
	afx_msg void OnWalkBr();
	afx_msg void OnSpeedHyper();
	afx_msg void OnSpeedFast();
	afx_msg void OnSpeedNorm();
	afx_msg void OnSpeedBandy();
	afx_msg void OnKickHl();
	afx_msg void OnKickHr();
	afx_msg void OnKickHead();
	afx_msg void OnKickPl();
	afx_msg void OnKickPr();
	afx_msg void OnCheckCrosshair();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


CSoccerDlg::CSoccerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_MAIN_SOCCER, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDI_MAIN);
    m_bDrawCrosshairs = true;
}


CDialog* NewSoccerDialog()	// for now
{
    return new CSoccerDlg(NULL);
}


BEGIN_MESSAGE_MAP(CSoccerDlg, CDialog)
	//{{AFX_MSG_MAP(CSoccerDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_WALK_FWD, OnWalkFwd)
	ON_BN_CLICKED(IDC_WALK_BWD, OnWalkBwd)
	ON_BN_CLICKED(IDC_WALK_STOP, OnWalkStop)
	ON_BN_CLICKED(IDC_WALK_LEFT, OnTurnLeft)
	ON_BN_CLICKED(IDC_WALK_RIGHT, OnTurnRight)
	ON_BN_CLICKED(IDC_STANDUP, OnStandup)
	ON_BN_CLICKED(IDC_SITDOWN, OnSitdown)
	ON_BN_CLICKED(IDC_LIEDOWN, OnLiedown)
	ON_BN_CLICKED(IDC_WALK_FL, OnWalkFl)
	ON_BN_CLICKED(IDC_WALK_FR, OnWalkFr)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_WALK_BL, OnWalkBl)
	ON_BN_CLICKED(IDC_WALK_BR, OnWalkBr)
	ON_BN_CLICKED(IDC_SPEED_HYPER, OnSpeedHyper)
	ON_BN_CLICKED(IDC_SPEED_FAST, OnSpeedFast)
	ON_BN_CLICKED(IDC_SPEED_NORM, OnSpeedNorm)
	ON_BN_CLICKED(IDC_SPEED_BANDY, OnSpeedBandy)
	ON_BN_CLICKED(IDC_KICK_HL, OnKickHl)
	ON_BN_CLICKED(IDC_KICK_HR, OnKickHr)
	ON_BN_CLICKED(IDC_KICK_HEAD, OnKickHead)
	ON_BN_CLICKED(IDC_KICK_PL, OnKickPl)
	ON_BN_CLICKED(IDC_KICK_PR, OnKickPr)
	ON_BN_CLICKED(IDC_CHECK_CROSSHAIR, OnCheckCrosshair)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////

// Walking style info
static int theWalkingStyle = 2;	// normal speed


////////////////////////////////////////////////////////////
// CSoccerDlg message handlers


BOOL CSoccerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// User Interface glue

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// hook up photo controls - image and color
	m_photoCtrl.Init(this, IDC_CUSTOM_PHOTO);
	m_colorCtrl.Init(this, IDC_CUSTOM_COLOR);

	CheckDlgButton(IDC_CHECK_CROSSHAIR, m_bDrawCrosshairs ? BST_CHECKED : BST_UNCHECKED);

	SetTimer(1, SET_TIMER_RATE, NULL);
	BeginPumpAudio();

	return TRUE;
}

void CSoccerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CSoccerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


////////////////////////////////////////////////////////////
// Simple graphic primitives

int FindCenterColor(byte const cdtBuffer[CB_COLORIMAGE], byte colormask, int& xRet, int& yRet)
	// find centroid of matching color, return number of matching pixels
{
    long xCent = 0;
    long yCent = 0;
    int n = 0;

    const byte* pbRow = cdtBuffer;
    for (int y = 0; y < CY_COLORIMAGE; y++)
    {
        for (int x = 0; x < CX_COLORIMAGE; x++)
        {
            byte b = *pbRow++;
            if (b & colormask)
            {
                xCent += x;
                yCent += y;
                n++;
            }
        }
    }

    if (n != 0)
    {
	    xRet = (int)(xCent / n);
		yRet = (int)(yCent / n);
	}
	return n;
}


////////////////////////////////////////////////////////////
// User interface Glue

void CSoccerDlg::OnOK() 
{
	// do nothing (make them hit EXIT button)
}

void CSoccerDlg::OnCancel() 
{
	// do nothing (make them hit EXIT button)
}

void CSoccerDlg::OnExit() 
{
	EndDialog(IDOK);
}

void CSoccerDlg::OnCheckCrosshair() 
{
	m_bDrawCrosshairs = !m_bDrawCrosshairs;
	CheckDlgButton(IDC_CHECK_CROSSHAIR, m_bDrawCrosshairs ? BST_CHECKED : BST_UNCHECKED);
}

////////////////////////////////////////////////////////////
// main timer loop

void CSoccerDlg::OnTimer(UINT nIDEvent) 
{	
	// get JPG image last (and auto-snapshot)
    bool bGotImage = m_photoCtrl.GetAndUpdateImage();
	if (!bGotImage)
		TRACE("GetAndUpdateImage failed\n");
	PumpAudio();	// pump audio if enabled

	// color detection
	byte cdtBuffer[CB_COLORIMAGE];
	if (theTelemetryConnection.GetColorData(cdtBuffer))
	{
		m_colorCtrl.Erase();
		m_colorCtrl.Colorize(cdtBuffer, 0 /* red */, RGB(255, 0, 0));
		m_colorCtrl.Colorize(cdtBuffer, 1 /* pink */, RGB(255, 81, 146));
		m_colorCtrl.Invalidate(FALSE);

        if (bGotImage && m_bDrawCrosshairs)
        {
			// draw crosshairs for red, pink, blue and green
			int n, x, y;
			// color detection matrix is 1/2 the photo size (height and width)
			
			const int THRESHOLD = 25;	// at least 100 pixels of a given color

#if 0
			// separate red and pink
			n = FindCenterColor(cdtBuffer, 1, x, y); // red
			if (n > THRESHOLD)
				m_photoCtrl.DrawCrossHair(x*2, y*2, RGB(255, 0, 0));
			n = FindCenterColor(cdtBuffer, 2, x, y); // pink
			if (n > THRESHOLD)
				m_photoCtrl.DrawCrossHair(x*2, y*2, RGB(255, 81, 146));
#else
			n = FindCenterColor(cdtBuffer, 3, x, y); // both
			if (n > THRESHOLD)
				m_photoCtrl.DrawCrossHair(x*2, y*2, RGB(255, 81, 146));
#endif

#if 0
			n = FindCenterColor(cdtBuffer, 0x10, x, y); // blue
			if (n > THRESHOLD)
				m_photoCtrl.DrawCrossHair(x*2, y*2, RGB(135, 114, 255));
			n = FindCenterColor(cdtBuffer, 0x10, x, y); // green/yellow
			if (n > THRESHOLD)
				m_photoCtrl.DrawCrossHair(x*2, y*2, RGB(135, 114, 255));

			//Flesh
			n = FindCenterColor(cdtBuffer, 0x20, x, y);
			if (n > THRESHOLD)
				m_photoCtrl.DrawCrossHair(x*2, y*2, RGB(180, 121, 88));
#endif
		}
	}

	// less frequent polling
	static int s_iTry = 0;
	if (s_iTry++ < 10)
		return;
	s_iTry = 0;


	char statusText[128];
	statusText[0] = '\0';

	// get variables using slow method
		// see complex.cpp for fast method using telemetry arrays

	rcword Batt_Rest = theRcodeConnection.GetIntValue("Batt_Rest");
	sprintf(statusText + strlen(statusText), "Power = %d%% ", Batt_Rest);
	rcword Distance = theRcodeConnection.GetIntValue("Distance");
	sprintf(statusText + strlen(statusText), "Distance = %dmm ", Distance);
	rcword Pink_Ball = theRcodeConnection.GetIntValue("Pink_Ball");
	sprintf(statusText + strlen(statusText), Pink_Ball ? "PINK" : "");
	SetDlgItemText(IDC_STATUS, statusText);
}

////////////////////////////////////////////////////////////
// Helpers for controlling AIBO


// use duration of 10000 to make it walk for a long time (until stopped or a new command)
#define LONG_TIME	10000

void CSoccerDlg::Walk(int angle, int duration)
{
	char cmdString[64];
	sprintf(cmdString, "PLAY:ACTION:WALK.STYLE%d:%d:%d", theWalkingStyle, angle, duration);
	SendRcodeCommand(cmdString);
}

void CSoccerDlg::Turn(int angle)
{
	char cmdString[64];
	sprintf(cmdString, "PLAY:ACTION:TURN.STYLE%d:%d", theWalkingStyle, angle);
	SendRcodeCommand(cmdString);
}

void CSoccerDlg::Look(int hAngle, int vAngle)
{
	// always fast
	char cmdString[64];
	sprintf(cmdString, "PLAY:ACTION:MOVE.HEAD.FAST:%d:%d", hAngle, vAngle);
	SendRcodeCommand(cmdString);
}

////////////////////////////////////////////////////////////
// Here are the actual commands that drive AIBO


void CSoccerDlg::OnSpeedHyper() 
{
	theWalkingStyle = 13; // hyper
}

void CSoccerDlg::OnSpeedFast() 
{
	theWalkingStyle = 3; // fast	
}

void CSoccerDlg::OnSpeedNorm() 
{
	theWalkingStyle = 2; // normal (slow)
}

void CSoccerDlg::OnSpeedBandy() 
{
	theWalkingStyle = 46; // bandy leg (good for defense)
}


void CSoccerDlg::OnWalkFwd() 
{
	Walk(0, LONG_TIME);
}

void CSoccerDlg::OnWalkBwd() 
{
	Walk(-180, LONG_TIME);
}

void CSoccerDlg::OnWalkStop() 
{
	SendRcodeCommand("PLAY:ACTION:STOP_WALK");
}

void CSoccerDlg::OnWalkFl() 
{
	Walk(45, LONG_TIME);	// angle walk
}

void CSoccerDlg::OnWalkFr() 
{
	Walk(-45, LONG_TIME);	// angle walk
}

void CSoccerDlg::OnWalkBl() 
{
	Walk(135, LONG_TIME);	// angle walk
}

void CSoccerDlg::OnWalkBr() 
{
	Walk(-135, LONG_TIME);	// angle walk
}

void CSoccerDlg::OnTurnLeft() 
{
	Turn(10000);	// keep turning until stopped
}

void CSoccerDlg::OnTurnRight() 
{
	Turn(-10000);	// keep turning until stopped
}

////////////////////////////////////////////////////////////
// Posture

void CSoccerDlg::OnStandup() 
{
	SendRcodeCommand("PLAY:ACTION:STAND");
}

void CSoccerDlg::OnSitdown() 
{
	SendRcodeCommand("PLAY:ACTION:SIT");
}

void CSoccerDlg::OnLiedown() 
{
	SendRcodeCommand("PLAY:ACTION:LIE");
}


////////////////////////////////////////////////////////////
// Kicking commands (head or paw)

void CSoccerDlg::OnKickHl() 
{
	SendRcodeCommand("PLAY:ACTION:CONTACT.FRONT.HEADL");
}

void CSoccerDlg::OnKickHr() 
{
	SendRcodeCommand("PLAY:ACTION:CONTACT.FRONT.HEADR");
}

void CSoccerDlg::OnKickHead() 
{
	SendRcodeCommand("PLAY:ACTION:CONTACT.FRONT.HEAD");
}

// assumes ball is in front of paw
void CSoccerDlg::OnKickPl() 
{
	SendRcodeCommand("PLAY:ACTION:KICK:10:300");
}

void CSoccerDlg::OnKickPr() 
{
	SendRcodeCommand("PLAY:ACTION:KICK:-10:300");
}

////////////////////////////////////////////////////////////

