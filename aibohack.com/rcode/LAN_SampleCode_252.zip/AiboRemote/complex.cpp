// Complex.cpp - Complex User Interface
//

#include "AiboRemote.h"
#include "photo.h"		// photo control
#include "urldlg.h"		// url helper dialog

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// CComplexDlg dialog

class CComplexDlg : public CDialog
{
// Construction
public:
	CComplexDlg(CWnd* pParent = NULL);	// standard constructor

	// helpers
	void Walk(int angle, int duration);
	void Turn(int angle);
	void Look(int hAngle, int vAngle);

// Implementation
protected:
	HICON m_hIcon;	// icon to draw

	// photo controls (3 resolutions)
	CPhotoCtrl m_photoCtrl;	// large size image
	CColorCtrl m_colorCtrl;	// medium size image for color matrix
	CBarGraphCtrl m_barGraphCtrl;	// bar graph for color levels

	void FreeListboxStrings();

	// Generated message map functions
	//{{AFX_MSG(CComplexDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	afx_msg void OnWalkFwd();
	afx_msg void OnWalkBwd();
	afx_msg void OnWalkStop();
	afx_msg void OnTurnLeft();
	afx_msg void OnTurnRight();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnStandup();
	afx_msg void OnSitdown();
	afx_msg void OnLiedown();
	afx_msg void OnWalkFl();
	afx_msg void OnWalkFr();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLookUl();
	afx_msg void OnLookUp();
	afx_msg void OnLookUr();
	afx_msg void OnLookL();
	afx_msg void OnLookMid();
	afx_msg void OnLookR();
	afx_msg void OnLookDl();
	afx_msg void OnLookDown();
	afx_msg void OnLookDr();
	afx_msg void OnWalkBl();
	afx_msg void OnWalkBr();
	afx_msg void OnRunit();
	afx_msg void OnStopit();
	afx_msg void OnSelectStyle();
	afx_msg void OnSelectActionList();
	afx_msg void OnRepeatAction();
	afx_msg void OnWhite1();
	afx_msg void OnWhite2();
	afx_msg void OnWhite3();
	afx_msg void OnGain1();
	afx_msg void OnGain2();
	afx_msg void OnGain3();
	afx_msg void OnShutter1();
	afx_msg void OnShutter2();
	afx_msg void OnShutter3();
	afx_msg void OnDestroy();
	afx_msg void OnMicOmni0();
	afx_msg void OnMicOmni1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


CComplexDlg::CComplexDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_MAIN_COMPLEX, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDI_MAIN);
}

CDialog* NewComplexDialog()
{
    return new CComplexDlg(NULL);
}


BEGIN_MESSAGE_MAP(CComplexDlg, CDialog)
	//{{AFX_MSG_MAP(CComplexDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_WALK_FWD, OnWalkFwd)
	ON_BN_CLICKED(IDC_WALK_BWD, OnWalkBwd)
	ON_BN_CLICKED(IDC_WALK_STOP, OnWalkStop)
	ON_BN_CLICKED(IDC_WALK_LEFT, OnTurnLeft)
	ON_BN_CLICKED(IDC_WALK_RIGHT, OnTurnRight)
	ON_BN_CLICKED(IDC_STANDUP, OnStandup)
	ON_BN_CLICKED(IDC_SITDOWN, OnSitdown)
	ON_BN_CLICKED(IDC_LIEDOWN, OnLiedown)
	ON_BN_CLICKED(IDC_WALK_FL, OnWalkFl)
	ON_BN_CLICKED(IDC_WALK_FR, OnWalkFr)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_LOOK_UL, OnLookUl)
	ON_BN_CLICKED(IDC_LOOK_UP, OnLookUp)
	ON_BN_CLICKED(IDC_LOOK_UR, OnLookUr)
	ON_BN_CLICKED(IDC_LOOK_L, OnLookL)
	ON_BN_CLICKED(IDC_LOOK_MID, OnLookMid)
	ON_BN_CLICKED(IDC_LOOK_R, OnLookR)
	ON_BN_CLICKED(IDC_LOOK_DL, OnLookDl)
	ON_BN_CLICKED(IDC_LOOK_DOWN, OnLookDown)
	ON_BN_CLICKED(IDC_LOOK_DR, OnLookDr)
	ON_BN_CLICKED(IDC_WALK_BL, OnWalkBl)
	ON_BN_CLICKED(IDC_WALK_BR, OnWalkBr)
	ON_BN_CLICKED(IDC_RUNIT, OnRunit)
	ON_BN_CLICKED(IDC_STOPIT, OnStopit)
	ON_CBN_SELCHANGE(IDC_WALKINGSTYLELIST, OnSelectStyle)
	ON_CBN_SELCHANGE(IDC_ACTIONLIST, OnSelectActionList)
	ON_BN_CLICKED(IDC_REPEATACTION, OnRepeatAction)
	ON_BN_CLICKED(IDC_WHITE1, OnWhite1)
	ON_BN_CLICKED(IDC_WHITE2, OnWhite2)
	ON_BN_CLICKED(IDC_WHITE3, OnWhite3)
	ON_BN_CLICKED(IDC_GAIN1, OnGain1)
	ON_BN_CLICKED(IDC_GAIN2, OnGain2)
	ON_BN_CLICKED(IDC_GAIN3, OnGain3)
	ON_BN_CLICKED(IDC_SHUTTER1, OnShutter1)
	ON_BN_CLICKED(IDC_SHUTTER2, OnShutter2)
	ON_BN_CLICKED(IDC_SHUTTER3, OnShutter3)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_MIC_OMNI0, OnMicOmni0)
	ON_BN_CLICKED(IDC_MIC_OMNI1, OnMicOmni1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////

// Walking style info
static int theWalkingStyle = 2;	// normal speed
#define MAX_WALKING_STYLE	48

// RCODE 2.5 names are incomplete
const char* namesForWalkingStyles[MAX_WALKING_STYLE] =
{
    // (#) is number of LG table data

    // only a limited number of styles are supported
	"In Place (6)", "Slow (7)", "Normal (8)", "Fast (9)",
    NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL,

    // 16
    NULL, "Slow2", "Normal2", "Fast2",
    NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL,
    NULL, NULL, NULL, NULL,

	// 32
	"Bandy (16)", NULL, NULL, NULL,
	"Small Step (20)", NULL, NULL, NULL,
	"Bandy2 (24)", NULL, NULL, NULL,
	"Bandy3 (28)", NULL, NULL, NULL
};

/////////////////////////////
// ACTIONs - some of the builtin actions

struct ACTION
{
	const char* name;
	const char* rcode;
};

////////////////////////////////////////////////////////////
// we use a telemetry array to get many RCODE variables at once

#define IARRAY_GETCOMPLEXVARS ARRAY_TELEM_LAST
				// there are 5 array numbers reserved for remote telemetry
				// we use the very last one

struct COMPLEX_VARS // note: fields must be 'rcword' and match string names
{
    rcword Wait;
    rcword Batt_Rest;
    rcword Batt_Temp;
    rcword Body_Temp;
    rcword Distance;
    rcword Pink_Ball;
};

#define COMPLEX_VARS_NAMES  "Wait;Batt_Rest;Batt_Temp;Body_Temp;Distance;Pink_Ball"
	// separate with semi-colon (not colon)


////////////////////////////////////////////////////////////
// CComplexDlg message handlers

BOOL CComplexDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// User Interface glue

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// hook up photo controls and resize
	m_photoCtrl.Init(this, IDC_CUSTOM_PHOTO);
	m_colorCtrl.Init(this, IDC_CUSTOM_COLOR);
	m_barGraphCtrl.Init(this, IDC_CUSTOM_GRAPH);

	//BLOCK: fill walking style listbox
	{
		CComboBox& cbox = *(CComboBox*)GetDlgItem(IDC_WALKINGSTYLELIST);
		for (int iStyle = 0; iStyle < MAX_WALKING_STYLE; iStyle++)
		{
			const char* name = namesForWalkingStyles[iStyle];
			if (name != NULL)
			{
				char full_name[64];
				wsprintf(full_name, "Style %02d: %s", iStyle, name);
				cbox.SetItemData(cbox.AddString(full_name), iStyle);
			}
		}
		cbox.SetCurSel(theWalkingStyle);
	}

	int aiboType = theRcodeConnection.GetIntValue("AiboType");
	ASSERT(aiboType == 210 || aiboType == 220);

	//BLOCK: fill in action list
	{
		char szFileName[64];
		sprintf(szFileName, "ACTIONS%d.TXT", aiboType);
		FILE* pf = fopen(szFileName, "rt");
		if (pf != NULL)
		{
			CComboBox& cbox = *(CComboBox*)GetDlgItem(IDC_ACTIONLIST);

			char szLine[256];
			while (fgets(szLine, sizeof(szLine), pf) != NULL)
			{
				char* pchEnd = strchr(szLine, '\n');
				if (pchEnd)
					*pchEnd = '\0';
				if (szLine[0] == ';' || szLine[0] == '\0')
					continue;	// skip comments or blank lines
				char* pchEq = strchr(szLine, '=');
				if (pchEq == NULL)
				{
					AfxMessageBox("Bad line in ACTIONS*.TXT file");
					AfxMessageBox(szLine);
					continue;	// ignore it
				}
				*pchEq = '\0';
				cbox.SetItemData(cbox.AddString(szLine), (DWORD)strdup(pchEq+1));
			}
			fclose(pf);
			cbox.SetCurSel(-1);
			// repeat action is initially disabled
		}
	}

    // allocate and assign value for telemetry array
    if (!theRcodeConnection.InitTelemetryVarArray(
		IARRAY_GETCOMPLEXVARS,
		COMPLEX_VARS_NAMES,
        sizeof(COMPLEX_VARS)))
    {
        AfxMessageBox("Error: failed to initialize telemetry array");
        EndDialog(IDCANCEL);
        return TRUE;
    }

	SetTimer(1, SET_TIMER_RATE, NULL);
	BeginPumpAudio();

	return TRUE;
}

void CComplexDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CComplexDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CComplexDlg::OnDestroy() 
{
	FreeListboxStrings();
	CDialog::OnDestroy();
}

void CComplexDlg::FreeListboxStrings()
{
	// not strictly necessary
	// free 'strdup'd strings to prevent memory leakage reporting
	CComboBox& cbox = *(CComboBox*)GetDlgItem(IDC_ACTIONLIST);
	int nItems = cbox.GetCount();
	for (int i = 0; i < nItems; i++)
		free((char*)cbox.GetItemData(i));
}

////////////////////////////////////////////////////////////
// User interface Glue

void CComplexDlg::OnOK() 
{
	// do nothing (make them hit EXIT button)
}

void CComplexDlg::OnCancel() 
{
	// do nothing (make them hit EXIT button)
}

void CComplexDlg::OnExit() 
{
	EndDialog(IDOK);
}

void CComplexDlg::OnTimer(UINT nIDEvent) 
{	
	// get JPG image last (and auto-snapshot)
	byte tagData[16];

	if (m_photoCtrl.GetAndUpdateImage(tagData))
	{
		m_barGraphCtrl.SetValues(tagData);
	}
	else
	{
		TRACE("m_photoCtrl.GetAndUpdateImage failed\n");
	}

	PumpAudio();	// pump audio if enabled

	// get color image first
	byte cdtBuffer[CB_COLORIMAGE];
	if (theTelemetryConnection.GetColorData(cdtBuffer))
	{
		m_colorCtrl.Erase();

		// use all 8 bits of color (from back to front)
		static COLORREF colors[8] =
		{
			RGB(255, 0, 0), // red
			RGB(255, 81, 146), // pink
			RGB(0, 0, 0), // black
			RGB(0, 0, 0), // black
			RGB(135, 114, 255), // blue
			RGB(151, 255, 54), // green
			RGB(180, 121, 88), // flesh ?
			RGB(0, 0, 0), // black
		};
		for (int iBit = 7; iBit >= 0; iBit--)
		{
			if (iBit == 3 || iBit == 7)
				continue;	// skip them
			m_colorCtrl.Colorize(cdtBuffer, iBit, colors[iBit]);
		}
		m_colorCtrl.Invalidate(FALSE);
	}

    // get a telemetry array of all the interesting globals

    COMPLEX_VARS cv;    // a telemetry array
	if (theTelemetryConnection.GetTelemetryVarArray(IARRAY_GETCOMPLEXVARS,
        &cv, sizeof(cv)))
    {
		SetDlgItemText(IDC_WAITSTATUS, cv.Wait > 0 ? "WAIT" : "");

		CString strStatus;
		strStatus.Format("Power=%d%%, Batt=%dC, Body=%dC",
                 cv.Batt_Rest, cv.Batt_Temp, cv.Body_Temp);
		SetDlgItemText(IDC_STATUS, strStatus);
		SetDlgItemInt(IDC_DISTANCE, cv.Distance);
		SetDlgItemText(IDC_SEEPINK, cv.Pink_Ball ? "PINK" : "");
    }
    else
    {
		TRACE("GetTelemetryVarArray failed\n");
    }
}


////////////////////////////////////////////////////////////
// Helpers for controlling AIBO


// use duration of 10000 to make it walk for a long time (until stopped or a new command)
#define LONG_TIME	10000

void CComplexDlg::Walk(int angle, int duration)
{
	char cmdString[64];
	sprintf(cmdString, "PLAY:ACTION:WALK.STYLE%d:%d:%d", theWalkingStyle, angle, duration);
	SendRcodeCommand(cmdString);
}

void CComplexDlg::Turn(int angle)
{
	char cmdString[64];
	sprintf(cmdString, "PLAY:ACTION:TURN.STYLE%d:%d", theWalkingStyle, angle);
	SendRcodeCommand(cmdString);
}

void CComplexDlg::Look(int hAngle, int vAngle)
{
	// always fast
	char cmdString[64];
	sprintf(cmdString, "PLAY:ACTION:MOVE.HEAD.FAST:%d:%d", hAngle, vAngle);
	SendRcodeCommand(cmdString);
}

////////////////////////////////////////////////////////////
// Here are the actual commands that drive AIBO

void CComplexDlg::OnSelectStyle() 
{
	CComboBox& cbox = *(CComboBox*)GetDlgItem(IDC_WALKINGSTYLELIST);

	int iSel = cbox.GetCurSel();
	if (iSel != -1)
	{
		int iStyle = cbox.GetItemData(iSel);
		if (iStyle >= 0 && iStyle < MAX_WALKING_STYLE)
		{
			theWalkingStyle = iStyle;
			// start walking forward with the new style
			Walk(0, LONG_TIME);

		}
	}
}

void CComplexDlg::OnWalkFwd() 
{
	Walk(0, LONG_TIME);
}

void CComplexDlg::OnWalkBwd() 
{
	Walk(-180, LONG_TIME);
}

void CComplexDlg::OnWalkStop() 
{
	SendRcodeCommand("PLAY:ACTION:STOP_WALK");
}

void CComplexDlg::OnWalkFl() 
{
	Walk(45, LONG_TIME);	// angle walk
}

void CComplexDlg::OnWalkFr() 
{
	Walk(-45, LONG_TIME);	// angle walk
}

void CComplexDlg::OnWalkBl() 
{
	Walk(135, LONG_TIME);	// angle walk
}

void CComplexDlg::OnWalkBr() 
{
	Walk(-135, LONG_TIME);	// angle walk
}

void CComplexDlg::OnTurnLeft() 
{
	Turn(10000);	// keep turning until stopped
}

void CComplexDlg::OnTurnRight() 
{
	Turn(-10000);	// keep turning until stopped
}

void CComplexDlg::OnStandup() 
{
	SendRcodeCommand("PLAY:ACTION:STAND");
}

void CComplexDlg::OnSitdown() 
{
	SendRcodeCommand("PLAY:ACTION:SIT");
}

void CComplexDlg::OnLiedown() 
{
	SendRcodeCommand("PLAY:ACTION:LIE");
}



////////////////////////////////////////////////////////////
// move head (look in direction)

#define HANGLE_LOOK		60
#define VANGLE_LOOK		45

void CComplexDlg::OnLookUl() 
{
	Look(HANGLE_LOOK, VANGLE_LOOK);
}

void CComplexDlg::OnLookUp() 
{
	Look(0, VANGLE_LOOK);
}

void CComplexDlg::OnLookUr() 
{
	Look(-HANGLE_LOOK, VANGLE_LOOK);
}

void CComplexDlg::OnLookL() 
{
	Look(HANGLE_LOOK, 0);
}

void CComplexDlg::OnLookMid() 
{
	Look(0, 0);
}

void CComplexDlg::OnLookR() 
{
	Look(-HANGLE_LOOK, 0);
}

void CComplexDlg::OnLookDl() 
{
	Look(HANGLE_LOOK, -VANGLE_LOOK);
	
}

void CComplexDlg::OnLookDown() 
{
	Look(0, -VANGLE_LOOK);
}

void CComplexDlg::OnLookDr() 
{
	Look(-HANGLE_LOOK, -VANGLE_LOOK);
}

////////////////////////////////////////////////////////////
// when user picks from action list

void CComplexDlg::OnSelectActionList() 
{
	GetDlgItem(IDC_REPEATACTION)->EnableWindow(TRUE);
	OnRepeatAction();
}

void SendMultipleRcodeCommands(const char* szRcode)
{
    char* pch;
    while ((pch = strchr(szRcode, ';')) != NULL)
    {
        char szT[128];
		int cch = pch-szRcode;
        memcpy(szT, szRcode, cch);
		szT[cch] = '\0';
        SendRcodeCommand(szT);
        szRcode = pch+1;
    }
    SendRcodeCommand(szRcode); // send last one
}

void CComplexDlg::OnRepeatAction() 
{
	CComboBox& cbox = *(CComboBox*)GetDlgItem(IDC_ACTIONLIST);

	int iSel = cbox.GetCurSel();
	if (iSel != -1)
	{
		const char* szRcode = (const char*)cbox.GetItemData(iSel);
		ASSERT(szRcode != NULL);
        SendMultipleRcodeCommands(szRcode);
	}
}

////////////////////////////////////////////////////////////
// Camera and other settings

void CComplexDlg::OnWhite1() 
{
	SendRcodeCommand("AP_DEVCTL 1 1");
}

void CComplexDlg::OnWhite2() 
{
	SendRcodeCommand("AP_DEVCTL 1 2");
}

void CComplexDlg::OnWhite3() 
{
	SendRcodeCommand("AP_DEVCTL 1 3");
}

void CComplexDlg::OnGain1() 
{
	SendRcodeCommand("AP_DEVCTL 2 1");
}

void CComplexDlg::OnGain2() 
{
	SendRcodeCommand("AP_DEVCTL 2 2");
}

void CComplexDlg::OnGain3() 
{
	SendRcodeCommand("AP_DEVCTL 2 3");
}

void CComplexDlg::OnShutter1() 
{
	SendRcodeCommand("AP_DEVCTL 3 1");
}

void CComplexDlg::OnShutter2() 
{
	SendRcodeCommand("AP_DEVCTL 3 2");
}

void CComplexDlg::OnShutter3() 
{
	SendRcodeCommand("AP_DEVCTL 3 3");
}


void CComplexDlg::OnMicOmni0() 
{
	SendRcodeCommand("AP_DEVCTL 4 0");
}

void CComplexDlg::OnMicOmni1() 
{
	SendRcodeCommand("AP_DEVCTL 4 1");
}

////////////////////////////////////////////////////////////
// control over R-CODE.R program

void CComplexDlg::OnRunit() 
{
	SendRcodeCommand("RUN");
}

void CComplexDlg::OnStopit() 
{
	SendRcodeCommand("END");	// "END" actually stops it	
}

////////////////////////////////////////////////////////////
