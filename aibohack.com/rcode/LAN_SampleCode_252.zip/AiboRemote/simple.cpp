// Simple.cpp - simple user interface
//

#include "AiboRemote.h"
#include "photo.h"		// photo control

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// CSimpleDlg dialog

class CSimpleDlg : public CDialog
{
// Construction
public:
	CSimpleDlg(CWnd* pParent = NULL);	// standard constructor

// Implementation
protected:
	HICON m_hIcon;	// icon to draw

	CPhotoCtrl m_photoCtrl;	// photo control


	// Generated message map functions
	//{{AFX_MSG(CSimpleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	afx_msg void OnWalkFwd();
	afx_msg void OnWalkBwd();
	afx_msg void OnWalkStop();
	afx_msg void OnTurnLeft();
	afx_msg void OnTurnRight();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnStandup();
	afx_msg void OnSitdown();
	afx_msg void OnLiedown();
	afx_msg void OnWalkFl();
	afx_msg void OnWalkFr();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnWalkBl();
	afx_msg void OnWalkBr();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


CSimpleDlg::CSimpleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_MAIN_SIMPLE, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDI_MAIN);
}

CDialog* NewSimpleDialog()
{
    return new CSimpleDlg(NULL);
}


BEGIN_MESSAGE_MAP(CSimpleDlg, CDialog)
	//{{AFX_MSG_MAP(CSimpleDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_WALK_FWD, OnWalkFwd)
	ON_BN_CLICKED(IDC_WALK_BWD, OnWalkBwd)
	ON_BN_CLICKED(IDC_WALK_STOP, OnWalkStop)
	ON_BN_CLICKED(IDC_WALK_LEFT, OnTurnLeft)
	ON_BN_CLICKED(IDC_WALK_RIGHT, OnTurnRight)
	ON_BN_CLICKED(IDC_STANDUP, OnStandup)
	ON_BN_CLICKED(IDC_SITDOWN, OnSitdown)
	ON_BN_CLICKED(IDC_LIEDOWN, OnLiedown)
	ON_BN_CLICKED(IDC_WALK_FL, OnWalkFl)
	ON_BN_CLICKED(IDC_WALK_FR, OnWalkFr)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_WALK_BL, OnWalkBl)
	ON_BN_CLICKED(IDC_WALK_BR, OnWalkBr)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimpleDlg message handlers


BOOL CSimpleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// User Interface glue

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_photoCtrl.Init(this, IDC_CUSTOM_PHOTO);

	SetTimer(1, SET_TIMER_RATE, NULL);
	BeginPumpAudio();

	return TRUE;
}

void CSimpleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CSimpleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}




/////////////////////////////////////////////////////////////////////////////
// User interface Glue

void CSimpleDlg::OnOK() 
{
	// do nothing (make them hit EXIT button)
}

void CSimpleDlg::OnCancel() 
{
	// do nothing (make them hit EXIT button)
}

void CSimpleDlg::OnExit() 
{
	EndDialog(IDOK);
}

void CSimpleDlg::OnTimer(UINT nIDEvent) 
{
	if (!m_photoCtrl.GetAndUpdateImage())
		TRACE("GetAndUpdateImage failed\n");
	PumpAudio();	// pump audio if enabled

	// less frequent polling for RCODE variables
	static int s_iTry = 0;
	if (s_iTry++ < 10)
		return;
	s_iTry = 0;

	int batt_level = theRcodeConnection.GetIntValue("Batt_Rest");
	if (batt_level != -1)
	{
		char reportString[64];
		sprintf(reportString, "Power = %d%%", batt_level);
		SetDlgItemText(IDC_STATUS, reportString);
	}

}

////////////////////////////////////////////////////////////
// Here are the actual commands that drive AIBO
// use duration of 10000 to make it walk for a long time
//  (until stopped or a new command)

void CSimpleDlg::OnWalkFwd() 
{
	SendRcodeCommand("PLAY:ACTION:WALK:0:10000");
}

void CSimpleDlg::OnWalkBwd() 
{
	SendRcodeCommand("PLAY:ACTION:WALK:-180:10000");
}

void CSimpleDlg::OnWalkStop() 
{
	SendRcodeCommand("PLAY:ACTION:STOP_WALK");
}

void CSimpleDlg::OnWalkFl() 
{
	SendRcodeCommand("PLAY:ACTION:WALK:45:10000"); // angle walk
}

void CSimpleDlg::OnWalkFr() 
{
	SendRcodeCommand("PLAY:ACTION:WALK:-45:10000"); // angle walk
}

void CSimpleDlg::OnWalkBl() 
{
	SendRcodeCommand("PLAY:ACTION:WALK:135:10000"); // angle walk
}

void CSimpleDlg::OnWalkBr() 
{
	SendRcodeCommand("PLAY:ACTION:WALK:-135:10000"); // angle walk
}

void CSimpleDlg::OnTurnLeft() 
{
	SendRcodeCommand("PLAY:ACTION:TURN:10000"); // keep turning until stopped
}

void CSimpleDlg::OnTurnRight() 
{
	SendRcodeCommand("PLAY:ACTION:TURN:-10000"); // keep turning until stopped
}


void CSimpleDlg::OnStandup() 
{
	SendRcodeCommand("PLAY:ACTION:STAND");
}

void CSimpleDlg::OnSitdown() 
{
	SendRcodeCommand("PLAY:ACTION:SIT");
}

void CSimpleDlg::OnLiedown() 
{
	SendRcodeCommand("PLAY:ACTION:LIE");
}

////////////////////////////////////////////////////////////

