////////////////////////////////////////////////////////////
// photo control (using YUV10)

class CPhotoCtrl : public CWnd
{
public:
	CPhotoCtrl() { m_rgbImage = NULL; m_bImageValid = true; }
	~CPhotoCtrl() { delete [] m_rgbImage; }
	
	void Init(CDialog* pParent, int nIDC);

	bool GetAndUpdateImage(byte* pbTagData = NULL);

	// for CDT display
	void Erase();
	void Colorize(byte cdtBuffer[CB_COLORIMAGE], int iColor, COLORREF color);
	void DrawCrossHair(int x, int y, COLORREF color);

protected:
	bool m_bImageValid;
	BYTE* m_rgbImage;

	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
};


class CColorCtrl : public CWnd
{
public:
	CColorCtrl() { m_rgbImage = NULL; }
	~CColorCtrl() { delete [] m_rgbImage; }
	BYTE* GetBuffer() { return m_rgbImage; }

	void Init(CDialog* pParent, int nIDC);

	// for CDT display
	void Erase();
	void Colorize(byte cdtBuffer[CB_COLORIMAGE], int iColor, COLORREF color);

protected:
	BYTE* m_rgbImage;
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()

};

////////////////////////////////////////////////////////////
// simple little bar graph for color levels

#define NUM_BAR 6

class CBarGraphCtrl : public CWnd
{
public:
	CBarGraphCtrl() { }

	void Init(CDialog* pParent, int nIDC);

	void SetValues(byte const tagData[16]);

protected:
	byte m_values[NUM_BAR];

	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()

};

////////////////////////////////////////////////////////////
