// AiboRemote.h : main header file for the AIBOREMOTE application
//

////////////////////////////////////////////////////////////
// MFC (Visual C++) application

#define VC_EXTRALEAN
#include <afxwin.h> // core 
#include "resource.h" // main symbols

#include "..\aiboh25.h"	// AIBOH helper

#include "audio.h" // audio preview/playback helper

////////////////////////////////////////////////////////////
// CMainApp:

class CMainApp : public CWinApp
{
public:
	CMainApp() {}
	virtual BOOL InitInstance();
};

// CMainApp and other globals
// keep state in globals for simplicity

extern CMainApp theApp;

extern AIBOH_TELEMETRY theTelemetryConnection;
extern AIBOH_RCODE theRcodeConnection;

////////////////////////////////////////////////////////////
// construction of type specific dialogs

CDialog* NewSimpleDialog();
CDialog* NewComplexDialog();
CDialog* NewSoccerDialog();

////////////////////////////////////////////////////////////
// Customizable

#define SET_TIMER_RATE 250
	// number of ms between polling
	// 100 => ~10 frames per second is too fast (wedges RCODE personalities)
	// 500 => ~2 frames per second is too slow
	// 250 => ~4 frames per second is just right

////////////////////////////////////////////////////////////
// helpers

void SendRcodeCommand(const char* szCmd);

////////////////////////////////////////////////////////////
