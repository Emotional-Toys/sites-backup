// Helper classes
// don't compile directly
//  include in project specific 'helper.cpp'
//   with project specific includes and defines

#include "aiboh25.h" // helper classes

////////////////////////////////////////////////////////

#ifndef BUILD_WINDOWS
#ifndef BUILD_CLIE
#ifndef BUILD_WINCE
#error - please specify one BUILD_ variant
#endif
#endif
#endif

////////////////////////////////////////////////////////
// Windows/WinCE socket version

#ifdef BUILD_WINCE
#error "wince specific version NYI"
#endif //BUILD_WINCE

#ifdef BUILD_WINDOWS
#include <winsock.h>
#include <assert.h>

#pragma comment(lib, "wsock32.lib")

#include "aiboh25_win.c_"
#endif //!BUILD_CLIE

////////////////////////////////////////////////////////
// CLIE PalmOS version

#ifdef BUILD_CLIE

UInt16 g_libNet = 0;

#define INVALID_SOCKET ((NetSocketRef)~0)
#define SOCKET NetSocketRef
#define Sleep(n)    { }

#include "aiboh25_palm.c_"

#endif //BUILD_CLIE


//////////////////////////////////////////////////////////////
// Platform independent routines

////////////////////////////////////////////////
// AIBOH_TELEMETRY low level

bool AIBOH_TELEMETRY::Connect(const byte ipAddr[4],
    char* szErr)
{
	if (!SimpleConnect(ipAddr, TELEMETRY_PORT, szErr))
        return false;

    // get version info
    PurgeReply();
    if (!SendCommandByte(TELEMREQ_GETVER))
    {
        Disconnect();
        return false;
    }

    TELEMVER verinfo;
	if (!ReceiveReply((byte*)&verinfo, sizeof(verinfo)))
    {
        Disconnect();
        return false;
    }

    if (memcmp(verinfo.name, "AiboPet", 8) != 0)
    {
        Disconnect();
        return false;
    }

    if (verinfo.bMaj != 2 || verinfo.bMin < 51)
    {
        Disconnect();
        return false;
    }
    return true;
}

bool AIBOH_TELEMETRY::Connect(const char* szIPAddr,
    char* szErr)
{
    byte ipAddr[4];
    return ParseIPAddrString(ipAddr, szIPAddr) &&
        Connect(ipAddr, szErr);
}

bool AIBOH_TELEMETRY::GetVersionRaw(TELEMVER& tver)
{
	PurgeReply();
	if (!SendCommandByte(TELEMREQ_GETVER))
		return false;
	if (!ReceiveReply((byte*)&tver, sizeof(tver)))
		return false;
	if (memcmp(tver.name, "AiboPet", 8) != 0)
		return false;
	return true;
}

int AIBOH_TELEMETRY::GetVersion()
{
	TELEMVER tver;
    if (!GetVersionRaw(tver))
		return -1;
	return tver.bMaj * 100 + tver.bMin;
}


int AIBOH_TELEMETRY::GetStdPacket(byte bReq, byte* pbReply,
    int cbExpectedMin, int cbExpectedMax)
    // return cbActual (may be zero if not ready)
    // return -1 if error
{
	PurgeReply();
	if (!SendCommandByte(bReq))
		return -1;
    long cbStdData;
	if (!ReceiveReply((byte*)&cbStdData, 4))
		return -1;

    if (cbStdData == 0)
        return 0;       // not ready
	if (cbStdData < cbExpectedMin && cbStdData > cbExpectedMax)
        return -1;      // probably bad data
	if (!ReceiveReply(pbReply, (int)cbStdData))
		return -1;
	return (int)cbStdData;
}

bool AIBOH_TELEMETRY::GetStdPacketFixedRetry(byte bReq, byte* pbReply,
    int cbExpected)
{
    for (int iRetry = 0; iRetry <= 10; iRetry++)
    {
		int cb = GetStdPacket(bReq, pbReply, cbExpected, cbExpected);
	    if (cb == -1)
        {
            // printf("GetStdPacket returned %d\n", cb);
            return false;
        }
        if (cb == 0)
        {
            // printf(".");
			Sleep(10); // before polling again
            continue;
        }
        assert(cb == cbExpected);
        // printf("Got standard packed of %d bytes\n", cb);
        return true;
    }
    return false;  // timeout error
}

int AIBOH_TELEMETRY::GetStdDataArray(byte bCmd,
    byte* pbReply, int cbPerElement, int cElemMax)
{
	int cbTotal = GetStdPacket(bCmd, pbReply,
            cbPerElement * 1, cbPerElement * cElemMax);
    if (cbTotal < 0)
        return -1;
    if (cbTotal % cbPerElement != 0)
        return -1; // bad size
    return cbTotal / cbPerElement;
}

//////////////////////////////////////////////////////////////
// AIBOH_TELEMETRY high level

bool AIBOH_TELEMETRY::GetImageYUV10(PACKED_YUV10_DATA& packedData)
{
    if (!GetStdPacketFixedRetry(TELEMREQ_GETYUV10,
      (byte*)&packedData, sizeof(packedData)))
    {
        // printf("GetYUV10: get packet retry failed\n");
        return false;
    }
    if (packedData.sig != SIG_YUV10_DATA)
    {
        // printf("GetYUV10: bad sig $%x\n", packedData.sig);
        return false;
    }
    return true;
}

bool AIBOH_TELEMETRY::GetColorData(byte cdtBuffer[CB_COLORIMAGE])
{
    if (!GetStdPacketFixedRetry(TELEMREQ_GETCOLORIMAGE,
      cdtBuffer, CB_COLORIMAGE))
        return false;

    // erase first 16 pixels of last row (because of tag data)
	memset(cdtBuffer + CB_COLORIMAGE - CX_COLORIMAGE, 0, 16);
    return true;
}

#ifdef BUILD_WINDOWS
int AIBOH_TELEMETRY::GetImageJpeg(byte buffer[CB_JPGMAX])
    // return cbJpg or -1 if error (never return 0)
{
    for (int iRetry = 0; iRetry <= 10; iRetry++)
    {
		int cbJ = GetStdPacket(TELEMREQ_GETJPEG, buffer,
	            16, CB_JPGMAX);
	    if (cbJ == 0)
        {
			Sleep(10); // before polling again
            continue;
        }
		return cbJ; // ok or error
    }
    return -1;  // timeout error
}
#endif //BUILD_WINDOWS


#ifdef LATER
// audio helper
#endif

//////////////////////////////////////////////////////////////
// AIBOH_TELEMETRY image support

static inline byte limit(int v)
{
    if (v < 0)
        return 0;
    else if (v > 255)
        return 255;
	else
		return (byte)v;
}

#define EMIT(_b) \
    assert(_b < 64); \
    *pbOut++ = (byte)((_b) << 3); \
    if (bDouble) \
        *pbOut++ = (byte)((_b) << 3);

static void expand5(byte* pbOut, const byte* pbIn, bool bDouble)
{
    // expand 5 bits to 8
    byte* pbOutExpected = pbOut + CX_FULLIMAGE*CY_FULLIMAGE;

    int cbIn = 15840;
    if (bDouble)
        cbIn = cbIn / 2;    // half as many input bytes, same output
    assert(cbIn % 5 == 0);
    while (cbIn > 0)
    {
        byte b, bIn;

        bIn = *pbIn++;

        b = (byte)((bIn) & 0x1F);
        EMIT(b);
        b = (byte)((bIn >> 5));
        bIn = *pbIn++;
        b = (byte)(((bIn << 3) | b) & 0x1F);
        EMIT(b);

        b = (byte)((bIn >> 2) & 0x1F);
        EMIT(b);

        b = (byte)((bIn >> 7));
        bIn = *pbIn++;
        b = (byte)(((bIn << 1) | b) & 0x1F);
        EMIT(b);

        b = (byte)(bIn >> 4);
        bIn = *pbIn++;
        b = (byte)(((bIn << 4) | b) & 0x1F);
        EMIT(b);

        b = (byte)((bIn >> 1) & 0x1F);
        EMIT(b);

        b = (byte)((bIn >> 6));
        bIn = *pbIn++;
        b = (byte)(((bIn << 2) | b) & 0x1F);
        EMIT(b);

        b = (byte)((bIn >> 3) & 0x1F);
        EMIT(b);

        cbIn -= 5;
    }
    assert(pbOut == pbOutExpected);
}

#ifndef BUILD_CLIE
// 24 bit color
static void ConvertRGBFull(byte* rgbOut,
    const byte* pbY, const byte* pbV, const byte* pbU)
{
    //BLOCK: convert from YVU to RGB
    for (int y = 0; y < CY_FULLIMAGE; y++)
    {
		byte* pbRow = rgbOut + 3 * CX_FULLIMAGE * (CY_FULLIMAGE-1-y);
            	// reverse Y origin for bitmap and SetDIBits
	    for (int x = 0; x < CX_FULLIMAGE; x++)
        {
            int Y = *pbY++;
            int vS = (*pbV++) - 128;
            int uS = (*pbU++) - 128;
#if 1
			// old YUV interpretation - I think it looks better that way
			int r = (int)(Y + 1.4075 * vS);
			int g = (int)(Y - 0.3455 * uS - 0.7169 * vS);
			int b = (int)(Y + 1.7790 * uS);
#else
			// OpenR SDK says it is YCrCb - but I don't believe it
			int r = (int)(Y + vS);
			int g = (int)(Y - 0.19 * uS - 0.51 * vS);
			int b = (int)(Y + uS);
#endif
            *pbRow++ = limit(b);
            *pbRow++ = limit(g);
            *pbRow++ = limit(r);
        }
    }
}

/*static*/ void AIBOH_TELEMETRY::ConvertToRgb(byte bmpData[CB_FULLIMAGE],
				PACKED_YUV10_DATA const& packedData)
{
    // expand 10 bits per pixel into 24 bits per pixel (YVU order actually)
    byte rgbY[176*144];
    byte rgbV[176*144];
    byte rgbU[176*144];

    expand5(rgbY, packedData.compressedY, false);    //  not double
    expand5(rgbU, packedData.compressedU, true);
    expand5(rgbV, packedData.compressedV, true);

    // finally convert to RGB format [reverse Y format]
	ConvertRGBFull(bmpData, rgbY, rgbV, rgbU);

    // erase first 16 pixels of last row (because of tag data)
        // since bitmap is reversed, it is now the first row
	memset(bmpData, 0, 16*3);
}

#endif //!BUILD_CLIE

/////////////////////////////////////////////////////////
// 16 bit color (CLIE, maybe WinCE?)

#ifdef BUILD_CLIE
static void ConvertRGB16(word* rgwOut,
    const byte* pbY, const byte* pbV, const byte* pbU)
{
    //BLOCK: convert from YVU to RGB, save 16 bit version
    for (int y = 0; y < CY_FULLIMAGE; y++)
    {
//REVIEW: orientation?
		word* pwRow = rgwOut + CX_FULLIMAGE * (CY_FULLIMAGE-1-y);
	    for (int x = 0; x < CX_FULLIMAGE; x++)
        {
            int Y = *pbY++;
            int vS = (*pbV++) - 128;
            int uS = (*pbU++) - 128;

#if 1
			// old YUV interpretation
			int r = (int)(Y + 1.4075 * vS);
			int g = (int)(Y - 0.3455 * uS - 0.7169 * vS);
			int b = (int)(Y + 1.7790 * uS);
#else
        // optimize?
            // YUV (not YCrCb)
	        int r = Y + MyMul(1.4075, vS);
	        int g = Y - MyMul(0.3455, uS) - MyMul(0.7169, vS);
	        int b = Y + MyMul(1.7790, uS);
#endif
            // pack into 16 bits
            *pwRow++ = (word)(
                    (((limit(r) >> 3) & 31) << 11) |
                    (((limit(g) >> 2) & 63) << 5) |
                    ((limit(b) >> 3) & 31));
        }
    }
}

#ifndef BIG_LOCAL_VARIABLE
#define BIG_LOCAL_VARIABLE static
#endif

/*static*/ void AIBOH_TELEMETRY::ConvertToRgb16(
    word bmpData[CW_FULLIMAGE16],
	PACKED_YUV10_DATA const& packedData)
{
    // expand 10 bits per pixel into 16 bits per pixel
    BIG_LOCAL_VARIABLE byte rgbY[176*144];
    BIG_LOCAL_VARIABLE byte rgbV[176*144];
    BIG_LOCAL_VARIABLE byte rgbU[176*144];

    expand5(rgbY, packedData.compressedY, false);    //  not double
    expand5(rgbU, packedData.compressedU, true);
    expand5(rgbV, packedData.compressedV, true);

    // finally convert to RGB format [reverse Y format]
	ConvertRGB16(bmpData, rgbY, rgbV, rgbU);

    // erase first 16 pixels of last row (because of tag data)
        // since bitmap is reversed, it is now the first row
	memset(bmpData, 0, 16*sizeof(word));

//REVIEW: orientation?

}
#endif // BUILD_CLIE



////////////////////////////////////////////////
// AIBOH_RCODE

bool AIBOH_RCODE::Connect(const byte ipAddr[4], char* szErr)
{
	if (!SimpleConnect(ipAddr, RCODE_PORT, szErr))
        return false;

    Sleep(500); // give time for RCODE engine to restart
    PurgeReply();

    int version = GetIntValue("AP_Version");
    if (version < 251)
    {
        Disconnect();
        return false;
    }
    return true;
}

bool AIBOH_RCODE::Connect(const char* szIPAddr, char* szErr)
{
    byte ipAddr[4];
    return ParseIPAddrString(ipAddr, szIPAddr) &&
        Connect(ipAddr, szErr);
}


bool AIBOH_RCODE::SendCommandString(const char* szCmd)
{
    // send including terminating '\0'
	return SendCommandBytes((const byte*)szCmd, (int)strlen(szCmd)+1);
}

bool AIBOH_RCODE::ReceiveTextReply(char* szReply, int cbReply)
{
	while (cbReply > 1)
	{
		byte b;
		if (!ReceiveReply(&b, 1))
			return false;
		if (b == 0)
			break;	// end of string
		*szReply++ = (char)b;
		cbReply--;
	}
	*szReply++ = '\0';	// force termination
	return true;
}

rcword AIBOH_RCODE::GetIntValue(const char* szVariable)
{
	PurgeReply();	// just in case

	char cmdText[64];
	sprintf(cmdText, "PRINT:%%d:%s", szVariable);
	if (!SendCommandString(cmdText))
		return -1;

	// get first reply - echo of command
	char echoText[128];
	if (!ReceiveTextReply(echoText, sizeof(echoText)) ||
      strncmp(cmdText, echoText, strlen(cmdText)) != 0)
		return -1;

	char replyText[128];
	if (!ReceiveTextReply(replyText, (int)sizeof(replyText)))
		return -1;
	return (rcword)atoi(replyText);
}


///////////////////////////////////////////////////////////
// Telemetry array support

// initialization goes to RCODE socket
bool AIBOH_RCODE::InitTelemetryVarArray(int iArray,
            const char* szVars, int sizeof_values)
{
    assert(sizeof_values % sizeof(rcword) == 0);
    int nValues = sizeof_values / (int)sizeof(rcword);
    assert(iArray >= ARRAY_TELEM_FIRST && iArray <= ARRAY_TELEM_LAST);

    // we need to dimension the array and then fill in values
    char szArray[64];
    sprintf(szArray, "_telem_array%d", iArray); // need a name
    char szR[64];

    sprintf(szR, "SET %s %d", szArray, iArray);
    if (!SendCommandString(szR))
        return false;

    sprintf(szR, "AP_DIM %s %d", szArray, sizeof_values / sizeof(rcword) * 2);
            // need two 'rcwords' for each variable address/pointer
    if (!SendCommandString(szR))
        return false;
 
    for (int iVar = 0; iVar < nValues; iVar++)
    {
        if (szVars == NULL || *szVars == '\0')
            return false;
        char* pchSep = strchr(szVars, ';');
        char szName[32];
        if (pchSep == NULL)
        {
	        strcpy(szName, szVars); // last one I hope
            szVars = NULL;
        }
        else
        {
			int cch = (int)(pchSep-szVars);
	        memcpy(szName, szVars, cch);
			szName[cch] = '\0';
            szVars = pchSep+1;
        }
	    sprintf(szR, "AP_SETVARADDR %s %d %s", szArray, iVar, szName);
	    if (!SendCommandString(szR))
	        return false;
	    PurgeReply(); // if echo
    }
    Sleep(10); // ignore echo
    PurgeReply();
    return true;
}

// data comes from the telemetry socket
bool AIBOH_TELEMETRY::GetTelemetryVarArray(int iArray,
    void* values, int sizeof_values)
{
    assert(iArray >= ARRAY_TELEM_FIRST && iArray <= ARRAY_TELEM_LAST);
    byte rgb2[2];

	PurgeReply();	// just in case

    rgb2[0] = TELEMOP_GETARRAYVARS;
    rgb2[1] = (byte)iArray; // 1 based
	if (!SendCommandBytes(rgb2, 2))
        return false;

	long cbActual;
	if (!ReceiveReply((byte*)&cbActual, 4))
    {
        Sleep(10);
        PurgeReply();
        return false;
    }
	if (cbActual != sizeof_values)
    {
        Sleep(10);
        PurgeReply();
        return false;
    }
	if (!ReceiveReply((byte*)values, (int)cbActual))
        return false;

    return true;
}


/////////////////////////////////////////////////////////

