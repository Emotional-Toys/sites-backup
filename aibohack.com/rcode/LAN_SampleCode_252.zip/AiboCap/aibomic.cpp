// example program for getting AUDIO data from AIBO
// and saving as .WAV

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <windows.h> // for Sleep

#include "../aiboh25.h" // helper classes

#define VERBOSE

typedef unsigned char byte;
typedef unsigned short word;

////////////////////////////////////////////////////////
// cheesy WAV header


struct MY_WAVEHDR
{
    char rgchRIFF[4];
    long cbRiff;
    char rgchWAVE[4];
    char rgchfmt_[4];
    long cbFmt;
    // 16 bytes of format
    word pcm_type, channels;
    long samples_per_sec, bytes_per_sec;
    word bytes_per_sample, bits_per_sample;
    char rgchdata[4];
    long cbData;
};

MY_WAVEHDR whDefault = 
{
    { 'R', 'I', 'F', 'F' },
    0,  // patch with real length
    { 'W', 'A', 'V', 'E' },
    { 'f', 'm', 't', ' ' },
    16,
    1, 2,
    16000, 16000*4,
    4, 16,
    { 'd', 'a', 't', 'a' },
    0, // patch with data length
};


////////////////////////////////////////////////////////

int main(int argc, char* argv[])
{
    // default arguments
    const char* szFile = "out.wav";
    int secondsToCapture = 10;
    const char* ipAddress = "10.0.1.100";

    bool bOmni = true; // a good default
    bool bAlc = false; // I don't think this works

    // user provided values
    if (argc > 1)
        szFile = argv[1];
    if (argc > 2)
        secondsToCapture = atoi(argv[2]);
    if (argc > 3)
        ipAddress = argv[3];
    if (argc > 4)
        bOmni = atoi(argv[4]) != 0;
    if (argc > 5)
        bAlc = atoi(argv[5]) != 0;

    printf("Connecting to AIBO...");

    AIBOH_TELEMETRY telem;
    printf("Connecting to AIBO...");
    if (!telem.Connect(ipAddress))
    {
        printf("FAILED\n");
        return -1;
    }
    printf("Success\n");

    FILE* pf = fopen(szFile, "wb");
    if (pf == NULL)
    {
        printf("ERROR: failed to create output file '%s'\n", szFile);
	    telem.Disconnect();
        return -1;
    }

    // Data is recorded in chunks 
    // each chunk has 512 samples (32 ms)
    // each sample is 32 bits (stereo 16 bit sample)
    int chunksToCapture = (secondsToCapture * 1000) / 32;
    int samplesToCapture = 512*chunksToCapture;
    const int bytesPerSample = 4;
    int bytesToCapture = samplesToCapture * bytesPerSample;

    // write the WAV header
    {
        // we are doing it the RAW way (so we don't need Windows headers)
        MY_WAVEHDR wh;
        memcpy(&wh, &whDefault, sizeof(MY_WAVEHDR));

	    wh.cbData = bytesToCapture;
	    wh.cbRiff = 0x24 + wh.cbData;

	    int n = fwrite(&wh, sizeof(wh), 1, pf);
        if (n != 1)
        {
            printf("ERROR: can't write .WAV header, disk may be full\n");
            fclose(pf);
		    telem.Disconnect();
	        return -1;
        }
    }

    //BLOCK: set dev properties
    {
	    printf("Mic device properies: omni = %s, alc = %s\n",
	        bOmni ? "on" : "off", bAlc ? "on" : "off");

        byte rgb[3];
        rgb[0] = TELEMOP_SETPROPERTY;
        rgb[1] = 4;
        rgb[2] = bOmni;
        telem.SendCommandBytes(rgb, sizeof(rgb));
        rgb[0] = TELEMOP_SETPROPERTY;
        rgb[1] = 5;
        rgb[2] = bAlc;
        telem.SendCommandBytes(rgb, sizeof(rgb));
    }


#ifdef VERBOSE
    printf("Recording (%d chunks)...\n", chunksToCapture);
#else
    printf("Recording...\n");
#endif

    telem.SendCommandByte(TELEMOP_FLUSHAUDIO);

    int sequenceGaps = 0;
    int nextSequence = -1;
    int iChunk = 0;

    while (iChunk < chunksToCapture)
    {
        Sleep(100); // don't poll too quickly
		telem.PurgeReply(); // just in case

		AUDIO_BUFF buffers[MAX_AUDIO_BUFF];
		int cbReplyData = telem.GetStdPacket(TELEMREQ_GETAUDIO, (byte*)buffers,
		    sizeof(AUDIO_BUFF)*1,
		    sizeof(AUDIO_BUFF)*MAX_AUDIO_BUFF);

        if (cbReplyData == 0)
        {
#ifdef VERBOSE
            printf("-");
#endif
            // data not ready yet
            continue;
        }
        int nBuff = cbReplyData / sizeof(AUDIO_BUFF);
        if (nBuff < 0 || nBuff > MAX_AUDIO_BUFF ||
            nBuff * sizeof(AUDIO_BUFF) != cbReplyData)
        {
            printf("Warning: GETAUDIO returned bad length (%d) - retrying\n",
                cbReplyData);
            continue;
        }

        // now save out the buffers
        for (int iB = 0; iB < nBuff && iChunk < chunksToCapture; iB++)
        {
			AUDIO_BUFF const& buffer = buffers[iB];
	        if (buffer.seq != nextSequence && nextSequence != -1)
	        {
#ifdef VERBOSE
				printf(" !ERR! %d %d\n", buffer.seq, nextSequence);
#endif
	            sequenceGaps++;
            }
	        nextSequence = buffer.seq + 1;

	        // ignore sensor data

	        int n = fwrite(buffer.wavdata, sizeof(buffer.wavdata), 1, pf);
	        if (n != 1)
	        {
	            printf("ERROR: can't save data to file, disk may be full\n");
	            fclose(pf);
			    telem.Disconnect();
		        return -1;
	        }
	
#ifdef VERBOSE
            printf(".");
#endif
	        iChunk++;
        }
    }
    fclose(pf);
    telem.Disconnect();
    printf("Saved %d seconds of audio to %s\n", secondsToCapture, szFile);
    if (sequenceGaps > 0)
        printf("WARNING: %d gaps, some audio lost\n", sequenceGaps);
    return 0;
}

