// example program for getting data from Aibo
// using helper classes
// YUV10 version

#include <stdio.h>
#include <stdlib.h>

#include "../aiboh25.h" // helper classes

////////////////////////////////////////////////////////

bool SaveFile(const char* pathName, byte* data, int size);
bool SaveBitmap176x144(const char* pathName, byte* frameBufferRGB);

int main(int argc, char* argv[])
{
    // default arguments
    int numToCapture = 1;
    const char* ipAddress = "10.0.1.100";

    // user provided values
    if (argc > 1)
        numToCapture = atoi(argv[1]);
    if (argc > 2)
        ipAddress = argv[2];

    bool bCaptureJpeg = false;
    if (numToCapture < 0)
    {
	    numToCapture = -numToCapture;
        bCaptureJpeg = true;
    }

    AIBOH_TELEMETRY telem;
    printf("Connecting to AIBO...");
    if (!telem.Connect(ipAddress))
    {
        printf("FAILED\n");
        return -1;
    }
    printf("Success\n");

    // capture a number of frames
    int frameNum = 1;
    while (frameNum <= numToCapture)
    {
#if 0
        printf("Capturing frame %d of %d\n", frameNum, numToCapture);
#endif

        if (bCaptureJpeg)
        {
			byte rgbJpg[CB_JPGMAX];
	        int cbJpg;
	        while ((cbJpg = telem.GetImageJpeg(rgbJpg)) == 0)
	            ;

	        // for this example, we will save it as a standard Windows .JPG
	        char pathName[_MAX_PATH];
	        sprintf(pathName, "CAP%05d.JPG", frameNum);   // 1 based
	        if (!SaveFile(pathName, rgbJpg, cbJpg))
	        {
	            printf("Could not save file %s - disk may be full\n", pathName);
	            break;
            }
	        printf("Saved file %s\n", pathName);
        }
        else
        {
            // capture using newer video codec,
            //  then convert and save as a .BMP

            PACKED_YUV10_DATA packedData;
	        while (!telem.GetImageYUV10(packedData))
	            ;

            // convert compressed to full blown .BMP
            byte rgbBmpData[CB_FULLIMAGE];
            telem.ConvertToRgb(rgbBmpData, packedData);

#if 0
            printf("Pink level: %d+%d\n",
                    packedData.tagData[8],
                    packedData.tagData[9]);
#endif
	        char pathName[_MAX_PATH];
	        sprintf(pathName, "CAP%05d.BMP", frameNum);   // 1 based
	        if (!SaveBitmap176x144(pathName, rgbBmpData))
	        {
	            printf("Could not save file %s - disk may be full\n", pathName);
	            break;
            }
	        printf("Saved file %s\n", pathName);
	    }

        frameNum++;
	}

    telem.Disconnect();

    printf("Capture complete\n");
    return 0;
}

///////////////////////////////////////////////////////////////


bool SaveFile(const char* pathName, byte* data, int size)
{
    FILE* file = fopen(pathName, "wb");
    if (file == NULL)
		return false;

    if (fwrite(data, size, 1, file) != 1)
	{
		fclose(file);
        return false;
    }
	fclose(file);
    return true;
}

// first part of .BMP file (hard coded to APH image size)
byte bmpHdr176x144[] =
{
	0x42, 0x4d, 0x36, 0x29, 0x01, 0, 0, 0,
	0, 0, 0x36, 0, 0, 0, 0x28, 0,
	0, 0, 0xb0, 0, 0, 0, 0x90, 0,
	0, 0, 0x01, 0, 0x18, 0, 0, 0,
	0, 0, 0, 0x29, 0x01, 0, 0xc4, 0x0e,
	0, 0, 0xc4, 0x0e, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0
};

bool SaveBitmap176x144(const char* pathName, byte* frameBufferRGB)
{
    FILE* file = fopen(pathName, "wb");
    if (file == NULL)
		return false;

    if (fwrite(bmpHdr176x144, sizeof(bmpHdr176x144), 1, file) != 1 ||
			fwrite(frameBufferRGB, CB_FULLIMAGE, 1, file) != 1)
	{
		fclose(file);
        return false;
    }
	fclose(file);
    return true;
}



///////////////////////////////////////////////////////////////
