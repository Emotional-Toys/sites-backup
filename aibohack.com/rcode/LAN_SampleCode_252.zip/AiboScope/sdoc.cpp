// sdoc.cpp : implementation of the CScopeDoc class
//

#include "stdafx.h"
#include "ScopeLive.h"

#include "sdoc.h"
#include "audio.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// CScopeDoc

IMPLEMENT_DYNCREATE(CScopeDoc, CDocument)

BEGIN_MESSAGE_MAP(CScopeDoc, CDocument)
	//{{AFX_MSG_MAP(CScopeDoc)
	ON_COMMAND(ID_CONNECT, OnConnect)
	ON_COMMAND(ID_TOOL_VIDCAM, OnToolVidcam)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


CScopeDoc::CScopeDoc()
{
	theApp.m_pDocActive = this;
        	// for disabling during sub-dialogs

	m_ipAddr[0] = 10;
	m_ipAddr[1] = 0;
	m_ipAddr[2] = 1;
	m_ipAddr[3] = 100;
	m_bAudioCapture = FALSE;
	m_videoType = 0;	// YUV10 faster
	m_pollingDelay = 200;

	// BLOCK: get initial (default) IP address
	{
		CString strIP = AfxGetApp()->GetProfileString("Settings", "IPADDR", "");
		int a1, a2, a3, a4;
		if (sscanf(strIP, "%d.%d.%d.%d", &a1, &a2, &a3, &a4) == 4)
		{
			m_ipAddr[0] = a1;
			m_ipAddr[1] = a2;
			m_ipAddr[2] = a3;
			m_ipAddr[3] = a4;
		}
	}

	m_szLang[0] = '\0';
	
	memset(m_emotions, 0, sizeof(m_emotions));
	memset(m_instincts, 0, sizeof(m_instincts));
}

CScopeDoc::~CScopeDoc()
{
}

void CScopeDoc::Serialize(CArchive& ar)
{
	ASSERT(FALSE);	// not used
}

////////////////////////////////////////////////////////////

#include "urldlg.h"

BOOL CScopeDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	CUrlDlg dlg;
	dlg.m_b1 = m_ipAddr[0];
	dlg.m_b2 = m_ipAddr[1];
	dlg.m_b3 = m_ipAddr[2];
	dlg.m_b4 = m_ipAddr[3];
	dlg.m_bAudioCapture = m_bAudioCapture;
	dlg.m_videoType = m_videoType;
	dlg.m_pollingDelay = m_pollingDelay;

	if (dlg.DoModal() != IDOK)
		return FALSE;

	m_ipAddr[0] = dlg.m_b1;
	m_ipAddr[1] = dlg.m_b2;
	m_ipAddr[2] = dlg.m_b3;
	m_ipAddr[3] = dlg.m_b4;
	m_bAudioCapture = (dlg.m_bAudioCapture != FALSE);
	m_pollingDelay = dlg.m_pollingDelay;

	m_videoType = dlg.m_videoType;

    CloseAudio(); // just in case
    if (m_bAudioCapture)
    {
	    if (!OpenAudio())
        {
			AfxMessageBox("No audio device found\nAIBO audio disabled");
            m_bAudioCapture = true;
        }
    }

	return TRUE;
}

void CScopeDoc::OnConnect() 
{
	Disconnect();
	if (OnNewDocument())
	{
		AttemptConnection();
		UpdateAllViews(NULL, 1);	// reconnected
	}
}

void CScopeDoc::AttemptConnection()
{
	if (m_telem.IsConnected())
		return;

	CConnectingStatusDlg dlg;
	dlg.Create(IDD_CONNECTING);
	dlg.ShowWindow(SW_SHOW);
	dlg.UpdateWindow();

	// serial connection
	TRACE("opening telemetry pipe\n");

	if (!m_telem.Connect(m_ipAddr))
	{
		AfxMessageBox("AIBO not found");
		dlg.DestroyWindow();
		return;
	}
	dlg.DestroyWindow();

	if (!CheckAiboConnection())
	{
		AfxMessageBox("AIBO is not running correct AiboWare");
		m_telem.Disconnect();
        return;
	}

	// if success - save IP address for later use
	char szIP[64];
	wsprintf(szIP, "%d.%d.%d.%d", m_ipAddr[0], m_ipAddr[1], m_ipAddr[2], m_ipAddr[3]);
	AfxGetApp()->WriteProfileString("Settings", "IPADDR", szIP);
}


void CScopeDoc::Disconnect()
{
	if (!m_telem.IsConnected())
		return;

	m_telem.Disconnect();

	UpdateAllViews(NULL, 1);	// change in connection status (stop timers)
}


const char* CScopeDoc::GetConnectedName()
{
	static char szReply[32];	// return string
	if (!m_telem.IsConnected())
		return "not connected";
	sprintf(szReply, "%d.%d.%d.%d",
		m_ipAddr[0], m_ipAddr[1],
		m_ipAddr[2], m_ipAddr[3]);
	return szReply;
}

////////////////////////////////////////////////////////////

static char GetLangChar(BYTE bLang)
{
	switch (bLang)
	{
	case 0: // REVIEW ?? - default to english
	case 1: return 'E';	// unmarked, usually english
	case 2: return 'J'; // japanese
	case 3: return 'E'; // english
	case 4: return 'G'; // german
	case 5: return 'F'; // french
	}
	return '?';
}

bool CScopeDoc::CheckAiboConnection()
{
	// do high level communication to see if working
	if (!m_telem.SendCommandByte(TELEMREQ_GETVER))
		return false;
	Sleep(10);

	TELEMVER vi;
	if (!m_telem.ReceiveReply((BYTE*)&vi, sizeof(vi)))
		return false;
	
	if (vi.name[7] != '\0' || strcmp(vi.name, "AiboPet") != 0)
		return false;

	if (vi.bMaj != 2)
	{
		AfxMessageBox("AiboWare and AiboScope versions mismatch");
		return false;
	}

	if (vi.bType == TELEMVERTYPE_RCODE)
    {
        AfxMessageBox("RCodePlus stick detected\n"
            "Please use AiboRemote instead");
        return false;
    }

	if (vi.bMin < 52)	// 2.52 needed for new codec and audio capture
	{
		AfxMessageBox("Old AiboWare version detected\nPlease upgrade to Life Plus 2.52");
		return false;
	}

    if (vi.bType == TELEMVERTYPE_AL1)
    {
        m_bNewFmt = false;
		sprintf(m_szLang, "210AW01%c", GetLangChar(vi.bLang));
    }
    else if (vi.bType == TELEMVERTYPE_AL2)
	{
		sprintf(m_szLang, "220AW01%c", GetLangChar(vi.bLang));
        m_bNewFmt = true;
	}
	else if (vi.bType == TELEMVERTYPE_EXP)
    {
		sprintf(m_szLang, "220AW02%c", GetLangChar(vi.bLang));
        m_bNewFmt = true;
    }
	else if (vi.bType == TELEMVERTYPE_REC)
    {
		sprintf(m_szLang, "210AW06%c", GetLangChar(vi.bLang));
        m_bNewFmt = true;
    }
    else
    {
        AfxMessageBox("unknown stick type detected");
        return false;
    }

	return true;
}


void CScopeDoc::OnToolVidcam() 
{
	Disconnect();
#ifdef _DEBUG
	const char* szPath = "aibocam\\debug\\AiboCam.exe";
#else
	const char* szPath = "AiboCam";
#endif
	WinExec(szPath, SW_SHOW);
}


////////////////////////////////////////////////////////////
// AIBO SOCKET connection using AIBOH helper class
//  all other uses just use m_telem directly

#include "..\djpeg_lib\djpeg.h" // JPEG decompression

bool CScopeDoc::GetImage(BYTE* rgbImage)
{
	if (m_videoType == 0)
	{
		// YUV10
		PACKED_YUV10_DATA packedData;
		if (!m_telem.GetImageYUV10(packedData))
		{
			TRACE("GetImageYUV10 failed\n");
			return false;
		}
		// currently 16 byte 'tag' data is ignored

		// convert from packed to raw BMP info
		AIBOH_TELEMETRY::ConvertToRgb(rgbImage, packedData);
	}
	else
	{
		// JPEG
		BYTE rgbJpg[CB_JPGMAX];
		int cbJpg = m_telem.GetImageJpeg(rgbJpg);
		if (cbJpg <= 0)
		{
			TRACE("GetImageJpg failed\n");
			return false;
		}

		// convert from JPG to raw BMP info
		ASSERT(rgbImage != NULL);
		if (!do_djpeg_aibo(rgbJpg, cbJpg, rgbImage))
		{
			TRACE("do_djpeg_aibo() failed\n");
			return false;
		}
	}
	return true;
}

////////////////////////////////////////////////////////////
