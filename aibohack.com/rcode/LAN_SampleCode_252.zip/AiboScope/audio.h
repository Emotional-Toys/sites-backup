
bool OpenAudio();
void CloseAudio();
bool IsAudioOpen();
void BeginPumpAudio(AIBOH_TELEMETRY& telem);
void PumpAudio(AIBOH_TELEMETRY& telem);
