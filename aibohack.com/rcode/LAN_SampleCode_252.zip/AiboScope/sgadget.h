////////////////////////////////////////////////////////////
// special controls
// (derived from CText for convenient dialog editing)


////////////////////////////////////////////////////////////

class CPhotoCtrl : public CWnd
{
public:
	CPhotoCtrl() { m_rgbImage = NULL; }
	~CPhotoCtrl() { delete [] m_rgbImage; }
	BYTE* GetBuffer();	// allocate if necessary

protected:
	BYTE* m_rgbImage;
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////

class CColorDetCtrl : public CWnd	// full size only
{
public:
	CColorDetCtrl() { m_rgbImage = NULL; }
	~CColorDetCtrl() { delete [] m_rgbImage; }
	
	void Init(BYTE bMask, COLORREF color)
		{ m_bMask = bMask; m_color = color; }

	void Colorize(const BYTE* rgbCDT);

protected:
	BYTE* m_rgbImage;
	BYTE m_bMask;
	COLORREF m_color;
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
};
#define NUM_COLOR_DETECT	8	/* not all used */

////////////////////////////////////////////////////////////

struct RADAR_DISPINFO
{
	const char* sz;
	COLORREF color;
};

struct RADAR_DOT
{
	bool bOn;
	int x;
	int y;
	RADAR_DISPINFO const* pdi;
};

#define NUM_RADAR_DOT		12		/* six per side */

class CRadarCtrl : public CWnd
{
public:
	CRadarCtrl() {  m_hbm = NULL; }
	~CRadarCtrl() { }
	
	void Init(RADAR_DISPINFO const* rgdi, HBITMAP hbm);
	void EnableDot(int iDot, int x, int y);
	void DisableDot(int iDot);

protected:
	RADAR_DOT m_dots[NUM_RADAR_DOT];
	HBITMAP m_hbm;

	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
};


////////////////////////////////////////////////////////////
