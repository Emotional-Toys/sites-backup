// UrlDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ScopeLive.h"
#include "UrlDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// CUrlDlg dialog


CUrlDlg::CUrlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUrlDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUrlDlg)
	m_b1 = 0;
	m_b2 = 0;
	m_b3 = 0;
	m_b4 = 0;
	m_bAudioCapture = FALSE;
	m_videoType = -1;
	m_pollingDelay = 0;
	//}}AFX_DATA_INIT
}


void CUrlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUrlDlg)
	DDX_Text(pDX, IDC_EDIT1, m_b1);
	DDV_MinMaxByte(pDX, m_b1, 0, 255);
	DDX_Text(pDX, IDC_EDIT2, m_b2);
	DDV_MinMaxByte(pDX, m_b2, 0, 255);
	DDX_Text(pDX, IDC_EDIT3, m_b3);
	DDV_MinMaxByte(pDX, m_b3, 0, 255);
	DDX_Text(pDX, IDC_EDIT4, m_b4);
	DDV_MinMaxByte(pDX, m_b4, 0, 255);
	DDX_Check(pDX, IDC_AUDIO_CAP, m_bAudioCapture);
	DDX_Radio(pDX, IDC_RADIO1, m_videoType);
	DDX_Text(pDX, IDC_POLLING_RATE, m_pollingDelay);
	DDV_MinMaxInt(pDX, m_pollingDelay, 100, 10000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUrlDlg, CDialog)
	//{{AFX_MSG_MAP(CUrlDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////
// CConnectingStatusDlg dialog

CConnectingStatusDlg::CConnectingStatusDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConnectingStatusDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConnectingStatusDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CConnectingStatusDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConnectingStatusDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConnectingStatusDlg, CDialog)
	//{{AFX_MSG_MAP(CConnectingStatusDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////
