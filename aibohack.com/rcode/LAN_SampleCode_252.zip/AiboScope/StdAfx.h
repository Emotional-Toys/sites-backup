// stdafx.h : include file for standard system include files,

#pragma once

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>
#include <afxext.h>

#include <winsock.h>

