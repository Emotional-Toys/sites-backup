////////////////////////////////////////////////////////////
// somewhat out of date semantic input info

//REVIEW: which are needed ?
enum
{
	SHOW_LEVELBIN = 1,		// 0 or 1
#if 0
    SHOW_SIZE = 2,		// size instead of level
#else
    SHOW_SIZE = 0,		// size instead of level
#endif
    // 

	SHOW_SUB_MASK = 0xF00,
	SHOW_SUB_AUDIO = 0x100,
	SHOW_SUB_PARTS = 0x200,
	SHOW_SUB_BOOT = 0x300,
	SHOW_SUB_BC = 0x400,
	SHOW_SUB_SPOS = 0x500,
	SHOW_SUB_EMG = 0x600

	// rest are automatic
	// SHOW_STAT
	// SHOW_LEVEL
    // SHOW_PITCH
	// SHOW_POS
};

// act id dump ?
// able info ?

static LUD g_ludSemid[] =
{
 { 0x60101, "BALL", SHOW_SIZE },
 { 0x60102, "FAV", SHOW_SIZE },
 { 0x60103, "UNFAV", SHOW_SIZE },
 { 0x60104, "FLESH", SHOW_SIZE },
 { 0x60105, "NEWCOL", SHOW_SIZE },
 
 // new SEMIDs
 { 0x20101, "BALL", SHOW_SIZE },
 { 0x20102, "FAV", SHOW_SIZE },
 { 0x20103, "UNFAV", SHOW_SIZE },
 { 0x20104, "FLESH", SHOW_SIZE },
 { 0x20105, "NEWCOL", SHOW_SIZE },
 
 { 0x20106, "DANGER", SHOW_SIZE },
 { 0x20107, "EDGE", SHOW_SIZE },

 { 0x20201, "OBJECT" },
 { 0x20202, "OBSTACLE", SHOW_SIZE },
 { 0x20203, "HAND", SHOW_SIZE },
 { 0x60203, "HAND", SHOW_SIZE },

 { 0x20204, "WALL", SHOW_SIZE },
 { 0x20205, "CLIFF", SHOW_SIZE },
 { 0x20206, "BORDER", SHOW_SIZE },
 { 0x20207, "MOVE_OBJ", SHOW_SIZE },

 { 0x10301, "VOICE", SHOW_SUB_AUDIO },
 { 0x10401, "TONE" },
 { 0x10501, "BITONE" },
 { 0x10601, "AIBO_SOUND" },
 { 0x10701, "LOUD" },
 { 0x20702, "NOISY", SHOW_LEVELBIN },
 { 0x20703, "LOUD2" },
 { 0x10704, "RHYTHM" },

 { 0x20801, "EXTENSION" },
 { 0x10802, "EXTEMP" },
 { 0x10803, "INTEMP" },
 { 0x10804, "BATTERY" },
 //{ 0x10805, "FATIGUE#1" },
 { 0x20805, "FATIGUE" },	// ??

 { 0x10806, "HIT", SHOW_SUB_PARTS },
 { 0x10807, "PAT", SHOW_SUB_PARTS },
 { 0x10808, "CLICK", SHOW_SUB_PARTS },
 { 0x10809, "LONGPAT", SHOW_SUB_PARTS },
 { 0x1080a, "TOUCH_ON", SHOW_SUB_PARTS },
 { 0x1080b, "TOUCH_OFF", SHOW_SUB_PARTS },

 { 0x1080c, "MASTER_TOUCH" },
 { 0x1080d, "MODE1 (autonomous mode)" },
 { 0x1080e, "MODE2 (rest mode)" },
 { 0x1080f, "MODE3 (station transfer)" },
 { 0x10810, "MODE4 (sleep mode)" },
 { 0x20811, "RESTRAINT" },

 { 0x110901, "BOOT", SHOW_SUB_BOOT },
 { 0x110902, "SYS_POSTURE", SHOW_SUB_EMG },
 { 0x110903, "TZ_CHANGE" },
 { 0x110904, "EMERGENCY", SHOW_SUB_EMG },

 { 0x20a01, "JOY" },
 { 0x20a02, "ANGRY" },
 { 0x20a03, "SAD" },
 { 0x20a04, "FEAR" },
 { 0x20a05, "DISGUST" },
 { 0x20a06, "SURPRISE" },
 { 0x20a07, "APPETITE" },
 { 0x20a08, "EXERCISE" },
 { 0x20a09, "AFFECTION" },
 { 0x20a0a, "CURIOSITY" },
 { 0x20b01, "AWAKENING" },

 { 0x10c01, "TIME_EVENT" },
 { 0x20c02, "RISE_POSE", SHOW_SUB_SPOS },
 { 0x10d01, "GAL_SEM" },
 { 0x20e01, "BM_TIMEUP" },
 { 0x20e02, "BM_COMPLETE" },
 { 0x20e03, "BM_INCOMPLETE" },
 { 0x20e04, "BM_ANYCOMPLETE" },
 { 0x20e05, "BM_UNKNOWN" },
 { 0x20e06, "BM_ANYRESULT" },
 { 0x20e07, "BM_ACT_SUCCESS" },
 { 0x20e08, "BM_ACT_FAIL" },
 { 0x20e09, "BM_ACT_UNKNOWN" },
 { 0x20e0a, "BM_STTA_STOP" },
 { 0x20e0b, "BM_STTB_STOP" },
 { 0x20e0c, "BM_FIRST_IN_STAGE" },

//RECOG
 { 0x22001, "HFD" },
 { 0x12101, "HFI" },


};

static LUD g_ludLevel[] =
{
 { 0x1, "level=Very Low" },
 { 0x2, "level=Low" },
 { 0x3, "level=Mid" },
 { 0x4, "level=High" },
 { 0x5, "level=Very High" },
};

// size instead of level (reverse)
static LUD g_ludSize[] =
{
 { 0x1, "size=Very Large" },
 { 0x2, "size=Large" },
 { 0x3, "size=Medium" },
 { 0x4, "size=Small" },
 { 0x5, "size=Very Small" },
};

static LUD g_ludPitch[] =
{
 { 0x1, "pitch=Very Low" },
 { 0x2, "pitch=Low" },
 { 0x3, "pitch=Mid" },
 { 0x4, "pitch=High" },
 { 0x5, "pitch=Very High" },
};

static LUD g_ludPosDist[] =
{
 { 0x0, "-" },
 { 0x1, "Far" },
 { 0x2, "Mid" },
 { 0x4, "Near" },
};
#define MASK_POS_DIST   0xF

static LUD g_ludPosHAng[] =
{
 { 0x0, "-" },
 { 0x100, "Forward" },
 { 0x200, "R Front" },
 { 0x400, "Right" },
 { 0x800, "R Back" },
 { 0x1000, "Back" },
 { 0x2000, "L Back" },
 { 0x4000, "Left" },
 { 0x8000, "L Front" },
};

#define MASK_POS_HANG   0xFF00

static LUD g_ludPosVAng[] =
{
 { 0x0, "-" },
 { 0x100000, "High Above" },
 { 0x200000, "Above" },
 { 0x400000, "Level" },
 { 0x800000, "Below" },
 { 0x1000000, "Low Below" },
};

#define MASK_POS_VANG   0xFF00000


/////////////////////////

static LUD g_ludSubParts[] =
{
 { 0x1, "UNKNOWN" },
 { 0x2, "DONTCARE" },
 { 0x20, "BODY" },
 { 0x40, "HEAD" },
 { 0x80, "TAIL" },
 { 0xa0, "LEGS" },
 { 0xff, "ALL" },
 { 0x21, "BACK" },
 { 0x22, "HIP" },
 { 0x23, "SHOULDER" },
 { 0x41, "CHIN" },
 { 0x42, "NECK" },
 { 0x43, "TOP" },
 { 0xa1, "RF_LEG" },
 { 0xa3, "RF_PAW" },
 { 0xa9, "LF_LEG" },
 { 0xab, "LF_PAW" },
 { 0xb1, "RR_LEG" },
 { 0xb3, "RR_PAW" },
 { 0xb9, "LR_LEG" },
 { 0xbb, "LR_PAW" },
};

static LUD g_ludBitwiseSubBoot[] =
{
 { 0x100, "NORMAL" },
 { 0x200, "FLDOWN" },
 { 0x400, "AC" },
 { 0x800, "STATION" },
};

static LUD g_ludBitwiseSubBC[] =
{
 { 0x1, "TIMER" },
 { 0x2, "VIB" },
 { 0x4, "P_SW" },
 { 0x8, "STTN_CN" },
 { 0x10, "STTN_DC" },
 { 0x20, "BT_FULL" },
 { 0x40, "RQ_STTN" },
 { 0x7f, "ALL" },
};

static LUD g_ludSubSPos[] =
{
 { 0x1, "STTN_ON" },
 { 0x2, "STTNOFF" },
 { 0x3, "HOLDUP" },
 { 0x4, "HOLDDWN" },
 { 0x5, "JAM" },
 { 0x6, "JAMQUIT" },
 { 0x7, "FALLDWN" },
 { 0x8, "GET_UP" },
};

static LUD g_ludBitwiseSubEmg[] =
{
 { 0x1, "P_SW" },
 { 0x2, "EX_P_CN" },
 { 0x4, "EX_P_DC" },
 { 0x8, "CLK_GEN" },
 { 0x10, "BT_LOW" },
 { 0x20, "OVR_CUR" },
 { 0x40, "OVR_T_D" },
 { 0x80, "OVR_T_C" },
 { 0x100, "CHG_ERR" },
 { 0x200, "PLG_ERR" },
 { 0x400, "FAN_ERR" },
 { 0x800, "RTC_ERR" },
 { 0x1000, "P_NG" },
 { 0x2000, "BRK_WR" },
 { 0x4000, "CN_ANY" },
};


#ifdef LATER
debug_able: ???
 { 0x1, "FAR" },
 { 0x2, "NEAR" },
 { 0x3, "JUST" },
 { 0x4, "TOOCLOSE" },
 { 0xffffffff, "-" },
#endif // LATER

////////////////////////////////////////////////////////////
