// audio.cpp - audio preview/playback
//

#include "stdafx.h"
#include "ScopeLive.h"
#include "sdoc.h"

#include "audio.h"

#include <mmsystem.h>

#pragma comment(lib, "winmm.lib")

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

static HWAVEOUT g_hwo = NULL;
static int g_nPending = 0;

static void CALLBACK MyWaveOutProc(HWAVEOUT hwo, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
{
	ASSERT(dwInstance == 0);	// not used

	if (uMsg == WOM_DONE)
	{
		ASSERT(hwo == g_hwo);
	    WAVEHDR* phdr = (WAVEHDR*)dwParam1;
		waveOutUnprepareHeader(hwo, phdr, sizeof(WAVEHDR));
        delete [] phdr->lpData;
        delete [] phdr;
		g_nPending--;
	}
}


bool OpenAudio()
{
    CloseAudio();   // just in case

    int deviceID = 0;   // first WaveOut device - may not always work

	WAVEFORMATEX wfmt;
	memset(&wfmt, 0, sizeof(wfmt));
	wfmt.wFormatTag = WAVE_FORMAT_PCM;
	wfmt.nChannels = 2;
	wfmt.nSamplesPerSec = 16000;
	wfmt.nAvgBytesPerSec = 16000*2*2;
	wfmt.wBitsPerSample = 16;
	wfmt.nBlockAlign = 4;

	if (waveOutOpen(&g_hwo, deviceID, &wfmt, (DWORD)MyWaveOutProc, 0,
                CALLBACK_FUNCTION) != 0)
    {
        g_hwo = NULL;
        return false;
    }
    return true;
}

bool IsAudioOpen()
{
    return (g_hwo != NULL);
}

void CloseAudio()
{
    if (IsAudioOpen())
    {
		while (g_nPending > 0)
		{
			Sleep(100); // finish saying what is coming in
		}
		waveOutClose(g_hwo);
        g_hwo = NULL;
    }
}

static bool WriteAudio(AUDIO_BUFF const& buff)
{
	if (g_nPending > 32)
	{
		// over 1 second behind - ignore it
		TRACE("nPending = %d\n", g_nPending);
		return false;
	}

    // we need to make a copy of it
    WAVEHDR* phdr = new WAVEHDR;
    memset(phdr, 0, sizeof(WAVEHDR));
    int cbPlayback = 512*2*2; // 512 16-bit stereo samples

    phdr->lpData = new char[cbPlayback];
    phdr->dwBufferLength = cbPlayback;

    ASSERT(cbPlayback <= sizeof(buff.wavdata));
    memcpy(phdr->lpData, buff.wavdata, cbPlayback);

    if (waveOutPrepareHeader(g_hwo, phdr, sizeof(WAVEHDR)) != 0 ||
	    waveOutWrite(g_hwo, phdr, sizeof(WAVEHDR)) != 0)
    {
        delete [] phdr->lpData;
        delete [] phdr;
        return false;
    }
    // data will be freed in callback
	g_nPending++;

    return true;
}

void BeginPumpAudio(AIBOH_TELEMETRY& telem)
{
	if (IsAudioOpen())
    {
		telem.SendCommandByte(TELEMOP_FLUSHAUDIO);
	}
}


void PumpAudio(AIBOH_TELEMETRY& telem)
{
	if (IsAudioOpen())
    {
		AUDIO_BUFF buffers[MAX_AUDIO_BUFF];
		int cbReplyData = telem.GetStdPacket(TELEMREQ_GETAUDIO,
            (byte*)buffers,
			sizeof(AUDIO_BUFF)*1,
			sizeof(AUDIO_BUFF)*MAX_AUDIO_BUFF);

	    int nBuff = cbReplyData / sizeof(AUDIO_BUFF);
		if (nBuff > 0 && nBuff <= MAX_AUDIO_BUFF &&
		        nBuff * (int)sizeof(AUDIO_BUFF) == cbReplyData)
        {
			TRACE("%d - %d\n", nBuff, g_nPending);
            // valid audio
            for (int iB = 0; iB < nBuff; iB++)
                WriteAudio(buffers[iB]);
        }
    }
}

