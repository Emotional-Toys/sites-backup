// sdoc.h : interface of the CScopeDoc class
//

#pragma once


////////////////////////////////////////////////////////////
// now using the AIBOH_TELEMETRY helper class

#include "../aiboh25.h"

////////////////////////////////////////////////////////////


#define NUM_EMOTION	6
#define NUM_INSTINCT	5

class CScopeDoc : public CDocument
{
protected:
	CScopeDoc();
	DECLARE_DYNCREATE(CScopeDoc)

// Public Low Level connection info
public:
    // CScopeView uses telemetry pipe directly
	AIBOH_TELEMETRY m_telem;
		// connection to AIBO's telemetry socket

	bool m_bAudioCapture; // true if audio should be played
	int m_pollingDelay;	// ms

protected:
    // these are under control of CScopeDoc
	BYTE m_ipAddr[4];
	int m_videoType;	// 0 YUV10, 1 JPEG

// Public High Level Attributes
public:
	const char* GetConnectedName();

	int m_emotions[NUM_EMOTION];
	int m_instincts[NUM_INSTINCT];

	bool m_bNewFmt; // true if AL2+ or EXP+
	char m_szLang[16];	// 2?0AW0??

// Operations
public:
	void AttemptConnection();
	bool CheckAiboConnection();
	void Disconnect();
    
    // image data
	bool GetImage(BYTE* rgbImage);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScopeDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CScopeDoc();


// Generated message map functions
protected:
	//{{AFX_MSG(CScopeDoc)
	afx_msg void OnConnect();
	afx_msg void OnToolVidcam();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////

