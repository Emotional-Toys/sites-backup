// ScopeLive.h : main header file for the SCOPELIVE application
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

class CScopeDoc;

////////////////////////////////////////////////////////////
// CScopeApp:
// See ScopeLive.cpp for the implementation of this class
//

class CScopeApp : public CWinApp
{
public:
	CScopeApp();

	CScopeDoc* m_pDocActive;

	bool ForceDisconnect();	// disconnect
	void DoReconnect();	// reconnect

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScopeApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CScopeApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern CScopeApp theApp;

////////////////////////////////////////////////////////////
// global settings

// #define LOGIT

////////////////////////////////////////////////////////////
