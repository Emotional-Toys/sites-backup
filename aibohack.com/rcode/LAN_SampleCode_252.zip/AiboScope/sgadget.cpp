// Radar, photo and other controls
//

#include "stdafx.h"
#include "ScopeLive.h"

#include "sdoc.h" // for telemetry info

#include "sgadget.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// Photo Control

BEGIN_MESSAGE_MAP(CPhotoCtrl, CWnd)
	//{{AFX_MSG_MAP(CPhotoCtrl)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BYTE* CPhotoCtrl::GetBuffer()
{
	if (m_rgbImage == NULL)
		m_rgbImage = new BYTE[CB_FULLIMAGE];
	return m_rgbImage;
}

void CPhotoCtrl::OnPaint()
{
	PAINTSTRUCT ps;
	CDC* pdc = BeginPaint(&ps);
	CRect rc;
	GetClientRect(&rc);
	ASSERT(rc.top == 0 && rc.left == 0);
	ASSERT(rc.right == CX_FULLIMAGE);
	ASSERT(rc.bottom == CY_FULLIMAGE);

	int cx = CX_FULLIMAGE;
	int cy = CY_FULLIMAGE;

	// photo paint
	rc.left = (rc.Width() - cx) / 2;
	rc.top = (rc.Height() - cy) / 2;
	rc.right = rc.left + cx;
	rc.bottom = rc.top + cy;

	if (m_rgbImage == NULL)
	{
		CBrush br2(RGB(0,0,128));
		pdc->FillRect(&rc, &br2);
	}
	else
	{
		BITMAPINFO bmi;
		memset(&bmi, 0, sizeof(bmi));
		bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmi.bmiHeader.biWidth = cx;
		bmi.bmiHeader.biHeight = cy;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 24;
		bmi.bmiHeader.biCompression = BI_RGB;
		
#ifdef SCALE
		StretchDIBits(pdc->m_hDC, rc.left, rc.top,
			CX_FULLIMAGE*SCALE, CY_FULLIMAGE*SCALE,
			0, 0, cx, cy, m_rgbImage, &bmi,
			DIB_RGB_COLORS, SRCCOPY);
#else
		SetDIBitsToDevice(pdc->m_hDC, rc.left, rc.top, cx, cy,
			0, 0, 0, cy, m_rgbImage,
			&bmi, DIB_RGB_COLORS);
#endif
	}

	EndPaint(&ps);

}


////////////////////////////////////////////////////////////
// ColorDet Control

BEGIN_MESSAGE_MAP(CColorDetCtrl, CWnd)
	//{{AFX_MSG_MAP(CColorDetCtrl)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CColorDetCtrl::Colorize(const BYTE* pbCDT)
{
	if (m_rgbImage == NULL)
		m_rgbImage = new BYTE[CB_COLORIMAGE*3];	// image is stored in RGB format

	BYTE rgbBkgnd[3];
	memset(rgbBkgnd, 192, 3);	// darkish grey
	BYTE rgbOn[3];
	rgbOn[0] = GetBValue(m_color);
	rgbOn[1] = GetGValue(m_color);
	rgbOn[2] = GetRValue(m_color);

	COLORREF crBlack = RGB(0,0,0);
	for (int y = 0; y < CY_COLORIMAGE; y++)
	{
		BYTE* pbOut = &m_rgbImage[(CX_COLORIMAGE*3)*(CY_COLORIMAGE-1-y)];	// bottom up
		for (int x = 0; x < CX_COLORIMAGE; x++)
		{
			if (*pbCDT++ & m_bMask)
				memcpy(pbOut, rgbOn, 3);		// 3 byte BGR
			else
				memcpy(pbOut, rgbBkgnd, 3);
			pbOut += 3;
		}
	}
}


void CColorDetCtrl::OnPaint()
{
	PAINTSTRUCT ps;
	CDC* pdc = BeginPaint(&ps);
	CRect rc;
	GetClientRect(&rc);
	ASSERT(rc.top == 0 && rc.left == 0);
	ASSERT(rc.right == CX_COLORIMAGE);
	ASSERT(rc.bottom == CY_COLORIMAGE);

	// ColorDet paint

	if (m_rgbImage == NULL)
	{
		CBrush br2(RGB(0,0,128));
		pdc->FillRect(&rc, &br2);
	}
	else
	{
		int cx = CX_COLORIMAGE;
		int cy = CY_COLORIMAGE;

		BITMAPINFO bmi;
		memset(&bmi, 0, sizeof(bmi));
		bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bmi.bmiHeader.biWidth = cx;
		bmi.bmiHeader.biHeight = cy;
		bmi.bmiHeader.biPlanes = 1;
		bmi.bmiHeader.biBitCount = 24;
		bmi.bmiHeader.biCompression = BI_RGB;

		SetDIBitsToDevice(pdc->m_hDC, rc.left, rc.top, cx, cy,
			0, 0, 0, cy, m_rgbImage,
			&bmi, DIB_RGB_COLORS);
	}

	EndPaint(&ps);

}

////////////////////////////////////////////////////////////
// Radar Control

BEGIN_MESSAGE_MAP(CRadarCtrl, CWnd)
	//{{AFX_MSG_MAP(CRadarCtrl)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static void DrawBitmap(CDC* pdc, int x, int y, HBITMAP hbm, int cx, int cy, int cz)
{
	CDC dcMem;
	dcMem.CreateCompatibleDC(pdc);

	HGDIOBJ hbmOld = SelectObject(dcMem.m_hDC, hbm);
	ASSERT(hbmOld != NULL);

	
	pdc->BitBlt(x, y, cx, cy, &dcMem, 0, 0, SRCCOPY);
	SelectObject(dcMem.m_hDC, hbmOld);
	dcMem.DeleteDC();
}


void CRadarCtrl::OnPaint()
{
	PAINTSTRUCT ps;
	CDC* pdc = BeginPaint(&ps);
	CRect rc;
	GetClientRect(&rc);

	// fill background
	CBrush brOffWhite(RGB(200, 200, 200));	// off-white
	pdc->FillRect(&rc, &brOffWhite);

	int dRadar = rc.bottom;
	int xRadar = (rc.right - dRadar) / 2;
	int cyText = dRadar / (NUM_RADAR_DOT/2);

	int iDot;

	// draw the titles
	pdc->SetBkMode(TRANSPARENT);
	pdc->SetTextAlign(TA_RIGHT | TA_BASELINE);
	bool bLeft = true;
	for (iDot = 0; iDot < NUM_RADAR_DOT; iDot++)
	{
		RADAR_DOT& dot = m_dots[iDot];
		if (iDot == NUM_RADAR_DOT/2)
		{
			// draw on right side
			pdc->SetTextAlign(TA_LEFT | TA_BASELINE);
			bLeft = false;
		}

		if (!dot.bOn)
			continue;

		int x = (bLeft) ? xRadar : xRadar + dRadar;
		int y = cyText + (iDot % (NUM_RADAR_DOT/2)) * cyText;
		pdc->SetTextColor(dot.pdi->color);
		pdc->TextOut(x, y, dot.pdi->sz);
	}

	// radar part
	CBrush brWhite(RGB(255,255,255));
	rc.right = (rc.left = xRadar) + dRadar;
	rc.bottom = (rc.top = 0) + dRadar;
	pdc->FillRect(&rc, &brWhite);

	// draw bitmap in middle
	if (m_hbm != NULL)
	{
		BITMAP bm;
		GetObject(m_hbm, sizeof(bm), (LPVOID)&bm);
		int xB = rc.left + (rc.Width() - bm.bmWidth) / 2;
		int yB = rc.top + (rc.Height() - bm.bmHeight) / 2;
		DrawBitmap(pdc, xB, yB, m_hbm, bm.bmWidth, bm.bmHeight, bm.bmBitsPixel);
	}
	
	// draw the items
	int xMid = xRadar + dRadar/2;
	int dx = dRadar / 5;
	int yMid = dRadar/2;
	int dy = rc.Height() / 5;

	for (iDot = 0; iDot < NUM_RADAR_DOT; iDot++)
	{
		RADAR_DOT& dot = m_dots[iDot];
		if (!dot.bOn)
			continue;

		int x1 = xMid + dot.x * dx;
		int y1 = yMid + dot.y * dy;
		CBrush br(dot.pdi->color);
		CRect spot;
		const int SPOT_SIZE = 4;
		spot.right = (spot.left = x1 - SPOT_SIZE/2) + SPOT_SIZE;
		spot.bottom = (spot.top = y1 - SPOT_SIZE/2) + SPOT_SIZE;
		pdc->FillRect(&spot, &br);

		int x2 = (iDot < NUM_RADAR_DOT/2) ? xRadar : xRadar + dRadar;
		int y2 = cyText + (iDot % (NUM_RADAR_DOT/2)) * cyText;

		// draw a line to text item legends
		CPen pen(PS_DOT, 1, dot.pdi->color);
		CPen* pOld = pdc->SelectObject(&pen);
		pdc->MoveTo(x1, y1);
		pdc->LineTo(x2, y2);
		pdc->SelectObject(pOld);
	}

	EndPaint(&ps);
}


	
void CRadarCtrl::Init(RADAR_DISPINFO const* rgdi, HBITMAP hbm)
{
	for (int iDot = 0; iDot < NUM_RADAR_DOT; iDot++)
	{
		RADAR_DOT& dot = m_dots[iDot];
		dot.pdi = &rgdi[iDot];
		dot.bOn = false;
	}
	m_hbm = hbm;
}

void CRadarCtrl::EnableDot(int iDot, int x, int y)
{
	ASSERT(iDot >= 0 && iDot < NUM_RADAR_DOT);
	RADAR_DOT& dot = m_dots[iDot];
	dot.bOn = true;
	dot.x = x;
	dot.y = y;
	Invalidate(FALSE);
}

void CRadarCtrl::DisableDot(int iDot)
{
	ASSERT(iDot >= 0 && iDot < NUM_RADAR_DOT);
	RADAR_DOT& dot = m_dots[iDot];
	dot.bOn = false;
	Invalidate(FALSE);
}


////////////////////////////////////////////////////////////
