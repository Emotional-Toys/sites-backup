// sview.cpp : implementation of the CScopeView class
//

#include "stdafx.h"
#include "ScopeLive.h"

#include "sdoc.h"
#include "sview.h"
#include "audio.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////
// Semantic Input Event

struct SEMIN
{
	long l0;
	WORD w_4;
	WORD stat_val;
	long l2;
	long l3;
	long l4;
	long l5;
	long semid;
	long subinfo;
	WORD level;
	WORD pitch;
	long pos;
};

enum STAT_VAL
{
	STAT_VAL_ON = 1,
	STAT_VAL_OFF = 2,
	STAT_VAL_DCARE = 3,
};

static const char g_szScopeDataFile[] = ".\\SCOPEDAT.INI";

////////////////////////////////////////////////////////////
// CScopeView

IMPLEMENT_DYNCREATE(CScopeView, CFormView)

BEGIN_MESSAGE_MAP(CScopeView, CFormView)
	//{{AFX_MSG_MAP(CScopeView)
	ON_BN_CLICKED(IDC_CLEAR_LOG, OnClearLog)
	ON_BN_CLICKED(IDC_CLEAR_VCMD_LIST, OnClearVcmdList)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CLEAR_RADAR, OnClearRadar)
	ON_BN_CLICKED(IDC_WHITE1, OnWhite1)
	ON_BN_CLICKED(IDC_WHITE2, OnWhite2)
	ON_BN_CLICKED(IDC_WHITE3, OnWhite3)
	ON_BN_CLICKED(IDC_GAIN1, OnGain1)
	ON_BN_CLICKED(IDC_GAIN2, OnGain2)
	ON_BN_CLICKED(IDC_GAIN3, OnGain3)
	ON_BN_CLICKED(IDC_SHUTTER3, OnShutter3)
	ON_BN_CLICKED(IDC_SHUTTER2, OnShutter2)
	ON_BN_CLICKED(IDC_SHUTTER1, OnShutter1)
	ON_BN_CLICKED(IDC_MIC_OMNI0, OnMicOmni0)
	ON_BN_CLICKED(IDC_MIC_OMNI1, OnMicOmni1)
	ON_BN_CLICKED(IDC_PAT, OnPat)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

////////////////////////////////////////////////////////////
// CScopeView construction/destruction

static const RADAR_DISPINFO g_rgRadarDispInfo[] =
{
	{ "BALL", RGB(255, 0, 0) },
	{ "FAV",  RGB(0, 0, 255) },
	{ "UNFAV", RGB(0, 255, 0) },
	//	"FLESH",
	// "NEWCOL",
	{ "DANG", RGB(255, 255, 0) },
	{ "OBJ", RGB(0, 0, 0) },
	{ "OBST", RGB(0, 0, 0) },
	{ "HAND", RGB(240, 100, 100) },
	// { "WALL", RGB(128, 0, 0) },
	// { "EDGE", RGB(128, 0, 0) },
	// { "CLIFF", RGB(0, 0, 0) },
	{ "FACE", RGB(0, 128, 128) },
	{ "OWNER", RGB(0, 128, 128) },
	{ "MOVE", RGB(128, 128, 0) },
	{ "VOICE", RGB(128, 128, 128) },
};

enum
{
	RADAR_BALL,
	RADAR_FAV,
	RADAR_UNFAV,
	// RADAR_FLESH,
	// RADAR_NEWCOL,
	RADAR_DANGER,
	RADAR_OBJECT,
	RADAR_OBSTACLE,
	RADAR_HAND,
//	RADAR_WALL,
//	RADAR_EDGE,
//	RADAR_CLIFF,
	RADAR_FACE,	// HFD
	RADAR_OWNERFACE, // HFI
	RADAR_MOVE_OBJ,
	RADAR_VOICE		// until replaced
};


CScopeView::CScopeView()
	: CFormView(CScopeView::IDD)
{
	//{{AFX_DATA_INIT(CScopeView)
	//}}AFX_DATA_INIT

	// both dimensions report same values
	m_radarCtl1.Init(g_rgRadarDispInfo,
        LoadBitmap(AfxGetInstanceHandle(),
        MAKEINTRESOURCE(IDB_DOGHEAD)));
	m_radarCtl2.Init(g_rgRadarDispInfo,
        LoadBitmap(AfxGetInstanceHandle(),
        MAKEINTRESOURCE(IDB_DOGBODY)));
	m_nSeqLastSem = -1;
}

CScopeView::~CScopeView()
{
}


void CScopeView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CScopeView)
	DDX_Control(pDX, IDC_VCMDLIST, m_vcmdList);
	DDX_Control(pDX, IDC_IE_LIST, m_ieList);
	DDX_Control(pDX, IDC_VOICELIST, m_voiceList);
	DDX_Control(pDX, IDC_LOGLIST, m_logList);
	//}}AFX_DATA_MAP
	if (!pDX->m_bSaveAndValidate)
	{
		m_photoCtl.SubclassWindow(
            ::GetDlgItem(m_hWnd, IDC_CUSTOM_PHOTO));
		// IDs must be in order
		for (int i = 0; i < NUM_COLOR_DETECT; i++)
			m_rgcdCtl[i].SubclassWindow(
              ::GetDlgItem(m_hWnd, IDC_CUSTOM_COLOR1 + i));
		m_radarCtl1.SubclassWindow(
            ::GetDlgItem(m_hWnd, IDC_CUSTOM_RADAR1));
		m_radarCtl2.SubclassWindow(
            ::GetDlgItem(m_hWnd, IDC_CUSTOM_RADAR2));
	}
}

BOOL CScopeView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CFormView::PreCreateWindow(cs);
}


static void ResizeControl(CWnd& wnd, int cx, int cy)
{
	CRect rcWindow, rcClient;
	wnd.GetWindowRect(rcWindow);
	wnd.GetClientRect(rcClient);
	int dx = cx - rcClient.Width();
	int dy = cy - rcClient.Height();
	wnd.SetWindowPos(NULL, 0, 0,
		rcWindow.Width() + dx, rcWindow.Height() + dy,
		SWP_NOMOVE | SWP_NOZORDER);
}

////////////////////////////////////////////////////////////

// in bit mask order - reorganized on the screen layout
static COLORREF s_rgcolorCD[NUM_COLOR_DETECT] =
{
	RGB(255, 0, 0),		// red
	RGB(255, 81, 146), // pink
	RGB(0, 0, 0),
	RGB(0, 0, 0),

	RGB(135, 114, 255), // blue/FAV
	RGB(151, 255, 54), // green/UNFAV
	RGB(180, 121, 88), // fleshy
	RGB(0, 0, 0),
};

		
void CScopeView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	//BLOCK: UI init
	{
		ResizeParentToFit();

		m_ieList.SetTabStops(40);
		ResizeControl(m_photoCtl, CX_FULLIMAGE, CY_FULLIMAGE);
		for (int i = 0; i < NUM_COLOR_DETECT; i++)
		{
			ResizeControl(m_rgcdCtl[i], CX_COLORIMAGE, CY_COLORIMAGE);
			m_rgcdCtl[i].Init((BYTE)(1 << i), s_rgcolorCD[i]);
		}
	}
	// REVIEW: perhaps make this more general for reconnect

	m_logList.ResetContent();
	m_logList.AddString("connecting");
	m_logList.ResetContent();
	m_voiceList.AddString("---------");

	CScopeDoc* pDoc = GetDocument();
	pDoc->AttemptConnection();
	OnUpdate(NULL, 1, NULL);	// connection status changed
}
	

void CScopeView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	CFormView::OnUpdate(pSender, lHint, pHint);
	UpdateIEDisplay();

	if (lHint == 1)
	{
		// connection status changed
		CScopeDoc* pDoc = GetDocument();
		m_logList.ResetContent();

		if (pDoc->m_telem.IsConnected())
		{
			CString str;
			str.Format("Connected to '%s'", pDoc->GetConnectedName());
			m_logList.AddString(str);
			str.Format(" memory stick ERF-%s", pDoc->m_szLang);
			m_logList.AddString(str);

#ifdef LOGIT
			m_logList.AddString("DEBUG: low level trace saved");
#endif
			char szLang[32];
			wsprintf(szLang, "VCMD_%s", pDoc->m_szLang);
			char szDisp[64];
			::GetPrivateProfileString(szLang, "TITLE", "Unknown Lang", szDisp, sizeof(szDisp), g_szScopeDataFile);
			m_logList.AddString(szDisp);

			SetTimer(1, pDoc->m_pollingDelay, NULL);
			BeginPumpAudio(pDoc->m_telem);
		}
		else
		{
			m_logList.AddString("disconnected");
			KillTimer(1);
		}
	}
}

////////////////////////////////////////////////////////////
// CScopeView message handlers

void CScopeView::OnClearLog() 
{
	m_logList.ResetContent();
}

void CScopeView::OnClearVcmdList() 
{
	m_vcmdList.ResetContent();	
}


static void FormatIE(char* szOut, const char* szTag, int val)
{
	const char* szVal = "?";
	switch (val)
	{
	case 1: szVal = "Very Low"; break;
	case 2: szVal = "Low"; break;
	case 3: szVal = "Med"; break;
	case 4: szVal = "High"; break;
	case 5: szVal = "Very High"; break;
	}
	sprintf(szOut, "%s\t%s\t", szTag, szVal);
}

void CScopeView::UpdateIEDisplay()
{
	static const char* rgszE[] = { "Joy", "Anger", "Sadness", "Fear", "Disgust", "Surprise" };
	static const char* rgszI[] = { "Appetite", "Exercise", "Affection", "Curiosity", "Awakening" };
	CScopeDoc* pDoc = GetDocument();

	m_ieList.ResetContent();
	ASSERT(NUM_EMOTION > NUM_INSTINCT);
	for (int iIE = 0; iIE < NUM_EMOTION; iIE++)
	{
		char szT[64];
		FormatIE(szT, rgszE[iIE], pDoc->m_emotions[iIE]);
		if (iIE < NUM_INSTINCT)
			FormatIE(szT + strlen(szT), rgszI[iIE], pDoc->m_instincts[iIE]);
		m_ieList.AddString(szT);
	}
}

void CScopeView::ProcessIE(SEMIN const& semin)
{
	CScopeDoc* pDoc = GetDocument();
	if (semin.semid >= 0x20a01 && semin.semid <= 0x20a06)
	{
		pDoc->m_emotions[semin.semid - 0x20a01] = semin.level;
		UpdateIEDisplay();	// REVIEW: single doc only
	}
	else if (semin.semid >= 0x20a07 && semin.semid <= 0x20a0a)
	{
		pDoc->m_instincts[semin.semid - 0x20a07] = semin.level;
		UpdateIEDisplay();	// REVIEW: single doc only
	}
	else if (semin.semid == 0x20b01)
	{
		pDoc->m_instincts[4] = semin.level;
		UpdateIEDisplay();	// REVIEW: single doc only
	}
}



////////////////////////////////////////////////////////////
// Input semantics

struct LUD
{
	long value;
	const char* szName;
	long lExtra;	// options
};

static long Lookup(char* szOut, int valFind, LUD const* rglud, int clud)
{
	for (int i = 0; i < clud; i++)
	{
		if (rglud[i].value == valFind)
		{
			strcpy(szOut, rglud[i].szName);
			return rglud[i].lExtra;
		}
	}
	return 0;
}

static void LookupBitwise(char* szOut, int valFind, LUD const* rglud, int clud)
{
	szOut[0] = '\0';
	int nTerm = 0;
	for (int i = 0; i < clud; i++)
	{
		if (valFind & rglud[i].value)
		{
			if (nTerm > 0)
				strcat(szOut, "|");
			strcat(szOut, rglud[i].szName);
			nTerm++;
		}
	}
}

#include "seminfo.h"	// from debug version of BM

static void FormatInputSemantic(SEMIN const& semin, CString& strRet)
{
	char szVerb[64];
	sprintf(szVerb, "code=$%x", semin.semid);
	long show = Lookup(szVerb, semin.semid, g_ludSemid, sizeof(g_ludSemid) / sizeof(LUD));

	if (semin.stat_val == STAT_VAL_OFF)
		strcat(szVerb, "_LOST");

	char szLvl[32];
	szLvl[0] = '\0';
	if (semin.level != 0)
	{
		if (show & SHOW_SIZE)
		{
			sprintf(szLvl, "size=%d", semin.level);
			Lookup(szLvl, semin.level, g_ludSize, sizeof(g_ludSize) / sizeof(LUD));
		}
		else
		{
			sprintf(szLvl, "level=%d", semin.level);
			Lookup(szLvl, semin.level, g_ludLevel, sizeof(g_ludLevel) / sizeof(LUD));
		}
	}
	
	char szPit[32];
	szPit[0] = '\0';
	if (semin.pitch != 0)
	{
		sprintf(szPit, "pitch=%d", semin.pitch);
		Lookup(szPit, semin.pitch, g_ludPitch, sizeof(g_ludPitch) / sizeof(LUD));
	}

	char szPos[64];
	szPos[0] = '\0';
	if (semin.pos != 0)
	{
		sprintf(szPos, "position=[ ", semin.pos);
		bool bStart = false;
		Lookup(szPos + strlen(szPos), semin.pos & MASK_POS_DIST, g_ludPosDist, sizeof(g_ludPosDist) / sizeof(LUD));
		strcat(szPos, ", ");
		Lookup(szPos + strlen(szPos), semin.pos & MASK_POS_HANG, g_ludPosHAng, sizeof(g_ludPosHAng) / sizeof(LUD));
		strcat(szPos, ", ");
		Lookup(szPos + strlen(szPos), semin.pos & MASK_POS_VANG, g_ludPosVAng, sizeof(g_ludPosVAng) / sizeof(LUD));
		strcat(szPos, " ]");
	}

	char szSub[32];
	szSub[0] = '\0';
	if (semin.subinfo != 0)
		sprintf(szSub, "sub=$%x", semin.subinfo);

	switch (show & SHOW_SUB_MASK)
	{
	case SHOW_SUB_AUDIO:
		{
			const char* szType = "??";
			switch (HIWORD(semin.subinfo))
			{
			case 1: szType = "FAV"; break;
			case 2: szType = "UNFAV"; break;
			}
			sprintf(szSub, "sub=%s:%d", szType, LOWORD(semin.subinfo));
		}
		break;
	case SHOW_SUB_PARTS:
		Lookup(szSub, (semin.subinfo & 0xFF), g_ludSubParts, sizeof(g_ludSubParts) / sizeof(LUD));
		break;
	case SHOW_SUB_BOOT:
		LookupBitwise(szSub, semin.subinfo, g_ludBitwiseSubBoot, sizeof(g_ludBitwiseSubBoot) / sizeof(LUD));
		break;
	case SHOW_SUB_BC:
		LookupBitwise(szSub, semin.subinfo, g_ludBitwiseSubBC, sizeof(g_ludBitwiseSubBC) / sizeof(LUD));
		break;
	case SHOW_SUB_SPOS:
		Lookup(szSub, semin.subinfo, g_ludSubSPos, sizeof(g_ludSubSPos) / sizeof(LUD));
		break;
	case SHOW_SUB_EMG:
		LookupBitwise(szSub, semin.subinfo, g_ludBitwiseSubEmg, sizeof(g_ludBitwiseSubEmg) / sizeof(LUD));
		break;
	}

	strRet.Format("%s %s %s %s %s", szVerb, szLvl, szPit, szPos, szSub);
}

void CScopeView::ProcessVCmd(SEMIN const& semin)
{
	if (semin.semid == 0x10301)
	{
		// voice
		WORD nVcmd = LOWORD(semin.subinfo);
		char szNum[16];
		sprintf(szNum, "%d", nVcmd);

		char szLang[32];
		wsprintf(szLang, "VCMD_%s", GetDocument()->m_szLang);
		char szDisp[64];
		if (::GetPrivateProfileString(szLang, szNum, "", szDisp, sizeof(szDisp), g_szScopeDataFile) == 0)
				sprintf(szDisp, "?? %d ??", nVcmd);

		if (HIWORD(semin.subinfo) == 2)
			strcat(szDisp, " - SCOLD");

		char szT[128];
		sprintf(szT, "VCmd#%d %s", nVcmd, szDisp);
		m_vcmdList.SetCurSel(m_vcmdList.AddString(szT));
	}
}


void CScopeView::ProcessRadar(SEMIN const& semin)
{
	int iDot = -1;
	switch (semin.semid)
	{
	case 0x20101: case 0x60101: iDot = RADAR_BALL; break;
	case 0x20102: case 0x60102: iDot = RADAR_FAV; break;
	case 0x20103: case 0x60103: iDot = RADAR_UNFAV; break;
	
	// case 0x20104: case 0x60104: iDot = RADAR_FLESH; break;
	// case 0x20105: case 0x60105: iDot = RADAR_NEWCOL; break;

	case 0x20106: iDot = RADAR_DANGER; break;
	case 0x20201: iDot = RADAR_OBJECT; break;
	case 0x20202: iDot = RADAR_OBSTACLE; break;
	case 0x20203: case 0x60203: iDot = RADAR_HAND; break;

		//	case 0x20204: iDot = RADAR_WALL; break;
//	case 0x20107: iDot = RADAR_EDGE; break;	// ???
//	case 0x20205: iDot = RADAR_CLIFF; break;
// 	case 0x20206: iDot = RADAR_BORDER; break;
	case 0x20207: iDot = RADAR_MOVE_OBJ; break;
	case 0x10301: iDot = RADAR_VOICE; break;
	case 0x22001: iDot = RADAR_FACE; break;
	case 0x12101: iDot = RADAR_OWNERFACE; break;
	default:
		return;
	}
	ASSERT(iDot != -1);

	if (semin.stat_val == STAT_VAL_OFF)
	{
		m_radarCtl1.DisableDot(iDot);
		m_radarCtl2.DisableDot(iDot);
	}
	else
	{
		// Figure position as
		long posDist = (semin.pos & MASK_POS_DIST);
		long posHAngle = (semin.pos & MASK_POS_HANG) >> 8;
		long posVAngle = (semin.pos & MASK_POS_VANG) >> 20;

#ifdef LATER
		Distance should go into size of font / object on radar
#endif
		// AIBO eye view
		int x = 0;
		int y = 0;
		int z = 0;
		if (posHAngle & 0xE)
			x = +2;
		else if (posHAngle & 0xE0)
			x = -2;

		if (posHAngle & 0x83)
			y = -2;
		else if (posHAngle & 0x38)
			y = +2;

		switch (posVAngle)
		{
		case 1: z = -2; break;
		case 2: z = -1; break;
		case 3: z = 0; break;
		case 4: z = +1; break;
		case 5: z = +2; break;
		}

		m_radarCtl1.EnableDot(iDot, x, z);
		m_radarCtl2.EnableDot(iDot, x, y);
	}

}

void CScopeView::ProcessVoiceData(long rgl[20])
{
	m_voiceList.ResetContent();
	const long* pl = rgl;
	int confBase = 0;
	for (int iMatch = 0; iMatch < 10; iMatch++)
	{
		int dicid = *pl++;
		int conf = *pl++;

		if (iMatch == 0)
			confBase = conf;

		char szLang[32];
		wsprintf(szLang, "VDIC_%s", GetDocument()->m_szLang);

		char szNum[16];
		sprintf(szNum, "%d", dicid);
		char szTag[64];
		if (::GetPrivateProfileString(szLang, szNum, "", szTag, sizeof(szTag), g_szScopeDataFile) == 0)
			sprintf(szTag, "?? %d ??", dicid);
		CString str;
		str.Format("%s %d (%d)", szTag, dicid, (conf - confBase)/100);
		m_voiceList.AddString(str);
	}
}

////////////////////////////////////////////////////////////
// Experimental Inject feature

static SEMIN seminSend = 
{ 0xcf40, 0x3, 0x3, 0xffffffff, 0xffffffff, 0x0, 0x10000,
	0x10701, 0x3, 0x5, 0x4, 0x8000 }; // "AIBO"

void CScopeView::OnPat() 
{
	CScopeDoc* pDoc = GetDocument();

    BYTE rgb[1+CL_SEMANTICEVENT*4];
	rgb[0] = TELEMOP_INJECTSEMANTICEVENT;
    memcpy(rgb+1, &seminSend, CL_SEMANTICEVENT*4);
	if (!pDoc->m_telem.SendCommandBytes(rgb, sizeof(rgb)))
		AfxMessageBox("Send error");
	else
		TRACE("INJECTED!\n");
}


////////////////////////////////////////////////////////////
// Other commands

void CScopeView::OnClearRadar() 
{
	for (int iDot = 0; iDot < NUM_RADAR_DOT; iDot++)
	{
		m_radarCtl1.DisableDot(iDot);
		m_radarCtl2.DisableDot(iDot);
	}	
}

void CScopeView::SendDeviceControl(byte prop, byte val)
{
    byte rgb[3];
    rgb[0] = TELEMOP_SETPROPERTY;
    rgb[1] = prop;
    rgb[2] = val;

	CScopeDoc* pDoc = GetDocument();
	if (!pDoc->m_telem.SendCommandBytes(rgb, sizeof(rgb)))
		AfxMessageBox("Send error (devctrl)");
}

void CScopeView::OnWhite1() 
{
    SendDeviceControl(1, 1);
}

void CScopeView::OnWhite2() 
{
    SendDeviceControl(1, 2);
}

void CScopeView::OnWhite3() 
{
    SendDeviceControl(1, 3);
}

void CScopeView::OnGain1() 
{
	SendDeviceControl(2, 1);
}

void CScopeView::OnGain2() 
{
	SendDeviceControl(2, 2);
}

void CScopeView::OnGain3() 
{
	SendDeviceControl(2, 3);
}

void CScopeView::OnShutter3() 
{
	SendDeviceControl(3, 3);
}

void CScopeView::OnShutter2() 
{
	SendDeviceControl(3, 2);
}

void CScopeView::OnShutter1() 
{
	SendDeviceControl(3, 1);
}

void CScopeView::OnMicOmni0() 
{
	SendDeviceControl(4, 0);
}

void CScopeView::OnMicOmni1() 
{
	SendDeviceControl(4, 1);
}

// 5 is AGC - doesn't appear to change anything
// 6 is HFD experimental (RCodePlus only)

////////////////////////////////////////////////////////////
// idle update

void CScopeView::OnTimer(UINT nIDEvent) 
{
	CFormView::OnTimer(nIDEvent);

	CScopeDoc* pDoc = GetDocument();
	ASSERT(pDoc->m_telem.IsConnected());

	// TRACE("TICK\n");
	if (pDoc->GetImage(m_photoCtl.GetBuffer()))
		m_photoCtl.Invalidate(FALSE);	// don't bother erasing background
	else
		TRACE("GetImage failed\n");

	BYTE cdtBuffer[CB_COLORIMAGE];
	if (pDoc->m_telem.GetColorData(cdtBuffer))
	{
		for (int i = 0; i < NUM_COLOR_DETECT; i++)
		{
			CColorDetCtrl& cdCtl = m_rgcdCtl[i];
			cdCtl.Colorize(cdtBuffer);
			cdCtl.Invalidate(FALSE);
		}
	}
	else
	{
		TRACE("GetColorData failed\n");
	}


    //BLOCK: SEMVOICE
	{
		long rglSem[CL_SEMANTICEVENTSEQ*MAX_SEMDATAARRAY];

		int nElem;
		if ((nElem = pDoc->m_telem.GetStdDataArray(
            TELEMREQ_GETSEMANTICEVENT,
			(byte*)rglSem, CL_SEMANTICEVENTSEQ*sizeof(long),
            MAX_SEMDATAARRAY)) > 0)
		{
			long* plSem = rglSem;
			for (int iElem = 0; iElem < nElem; iElem++)
			{
				ASSERT(CL_SEMANTICEVENTSEQ == CL_SEMANTICEVENT + 1);
				int nSeq = plSem[0];
				plSem++;
				SEMIN* psi = (SEMIN*)plSem;
				plSem += CL_SEMANTICEVENT;

				// TRACE("SEMDATA[%d/%d] #%d\n", iElem+1, nElem, nSeq);
				if (m_nSeqLastSem != -1 && nSeq != m_nSeqLastSem+1)
				{
					int nLost = nSeq - m_nSeqLastSem - 1;
					TRACE("LOST %d SEMDATA\n", nLost);
					CString str;
					str.Format(" { lost %d SEMDATA records }", nLost);
					m_logList.AddString(str);
				}
				m_nSeqLastSem = nSeq;

				CString strT;
				FormatInputSemantic(*psi, strT);
				m_logList.SetCurSel(m_logList.AddString(strT));
				// LATER: UpdateRadarList(strT); ???
				
				ProcessIE(*psi);
				ProcessVCmd(*psi);
				ProcessRadar(*psi);
#ifdef LOGIT
                FILE* pf = fopen("log.out", "at");
                fprintf(pf, " { 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x,\n",
                    psi->l0, psi->w_4, psi->stat_val, psi->l2, psi->l3,
					psi->l4, psi->l5);
                fprintf(pf, "\t0x%x, 0x%x, 0x%x, 0x%x, 0x%x },\n",
					psi->semid, psi->subinfo, psi->level, psi->pitch, psi->pos);
				fclose(pf);
#endif
			}
			ASSERT(plSem == rglSem + nElem*11);
		}
		
		long rglVoice[20];
		if (pDoc->m_telem.GetStdPacket(TELEMREQ_GETVOICEDATA,
            (byte*)rglVoice, sizeof(rglVoice), sizeof(rglVoice)))
		{
			// TRACE("VOICEDATA\n");
			ProcessVoiceData(rglVoice);
		}
	}

	PumpAudio(pDoc->m_telem);	// pump audio if enabled
}

////////////////////////////////////////////////////////////

