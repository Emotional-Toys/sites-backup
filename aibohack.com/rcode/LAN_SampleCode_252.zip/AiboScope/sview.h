// sview.h : interface of the CScopeView class
//

#pragma once

#include "sgadget.h"

struct SEMIN;

class CScopeView : public CFormView
{
protected: // create from serialization only
	CScopeView();
	DECLARE_DYNCREATE(CScopeView)

public:
	//{{AFX_DATA(CScopeView)
	enum { IDD = IDD_SCOPELIVE_FORM };
	CListBox	m_vcmdList;
	CListBox	m_ieList;
	CListBox	m_voiceList;
	CListBox	m_ttyList;
	CListBox	m_logList;
	//}}AFX_DATA

	CPhotoCtrl m_photoCtl;
	CColorDetCtrl m_rgcdCtl[NUM_COLOR_DETECT];
	CRadarCtrl m_radarCtl1;
	CRadarCtrl m_radarCtl2;

// Attributes
public:
	CScopeDoc* GetDocument() { return (CScopeDoc*)m_pDocument; }

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScopeView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CScopeView();

protected:
	void UpdateIEDisplay();

	void ProcessVCmd(SEMIN const& semin);
	void ProcessIE(SEMIN const& semin);
	void ProcessRadar(SEMIN const& semin);
	void ProcessVoiceData(long rgl[20]);

	int m_nSeqLastSem;

	void SendDeviceControl(byte prop, byte val);

// Generated message map functions
protected:
	//{{AFX_MSG(CScopeView)
	afx_msg void OnClearLog();
	afx_msg void OnClearVcmdList();
	afx_msg void OnMoodalter();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnClearRadar();
	afx_msg void OnWhite1();
	afx_msg void OnWhite2();
	afx_msg void OnWhite3();
	afx_msg void OnGain1();
	afx_msg void OnGain2();
	afx_msg void OnGain3();
	afx_msg void OnShutter3();
	afx_msg void OnShutter2();
	afx_msg void OnShutter1();
	afx_msg void OnMicOmni0();
	afx_msg void OnMicOmni1();
	afx_msg void OnPat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////
