//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ScopeLive.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_SCOPELIVE_FORM              101
#define IDR_MAINFRAME                   128
#define IDR_SCOPELTYPE                  129
#define IDD_NEWURL                      130
#define IDD_CONNECTING                  131
#define IDB_DOGHEAD                     132
#define IDB_DOGBODY                     133
#define IDC_CLEAR_LOG                   1001
#define IDC_CLEAR_VCMD_LIST             1002
#define IDC_CUSTOM_COLOR1               1003
#define IDC_CUSTOM_COLOR2               1004
#define IDC_CUSTOM_COLOR3               1005
#define IDC_CUSTOM_COLOR4               1006
#define IDC_CUSTOM_COLOR5               1007
#define IDC_CUSTOM_COLOR6               1008
#define IDC_CUSTOM_COLOR7               1009
#define IDC_CUSTOM_COLOR8               1010
#define IDC_CUSTOM_PHOTO                1011
#define IDC_CUSTOM_RADAR1               1012
#define IDC_CUSTOM_RADAR2               1013
#define IDC_EDIT1                       1014
#define IDC_CLEAR_RADAR                 1014
#define IDC_EDIT2                       1015
#define IDC_EDIT3                       1016
#define IDC_EDIT4                       1017
#define IDC_IE_LIST                     1019
#define IDC_LOGLIST                     1021
#define IDC_RADIO1                      1023
#define IDC_RADIO2                      1024
#define IDC_VCMDLIST                    1026
#define IDC_VOICELIST                   1027
#define IDC_WHITE1                      1036
#define IDC_WHITE2                      1037
#define IDC_AUDIO_CAP                   1037
#define IDC_WHITE3                      1038
#define IDC_GAIN1                       1039
#define IDC_POLLING_RATE                1039
#define IDC_GAIN2                       1040
#define IDC_GAIN3                       1041
#define IDC_SHUTTER1                    1042
#define IDC_SHUTTER2                    1043
#define IDC_SHUTTER3                    1044
#define IDC_MIC_OMNI1                   1045
#define IDC_MIC_OMNI0                   1046
#define IDC_PAT                         1047
#define ID_TOOL_VIDCAM                  32774
#define ID_TOOLS_SPEEDTEST              32775
#define ID_CONNECT                      32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
