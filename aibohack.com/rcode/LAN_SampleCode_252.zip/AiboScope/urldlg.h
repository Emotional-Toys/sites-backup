// UrlDlg.h : header file

#pragma once

////////////////////////////////////////////////////////////
// CUrlDlg dialog

class CUrlDlg : public CDialog
{
// Construction
public:
	CUrlDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUrlDlg)
	enum { IDD = IDD_NEWURL };
	BYTE	m_b1;
	BYTE	m_b2;
	BYTE	m_b3;
	BYTE	m_b4;
	BOOL	m_bAudioCapture;
	int		m_videoType;
	int		m_pollingDelay;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUrlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUrlDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////
// CConnectingStatusDlg dialog

class CConnectingStatusDlg : public CDialog
{
// Construction
public:
	CConnectingStatusDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CConnectingStatusDlg)
	enum { IDD = IDD_CONNECTING };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConnectingStatusDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CConnectingStatusDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

////////////////////////////////////////////////////////////
