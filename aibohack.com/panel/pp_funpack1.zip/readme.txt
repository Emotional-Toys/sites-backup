PanelPet Fun Pack 1

Should be installed to the root of the WinCE file system
"\" on the Panel
"\\tsclient\files" from the PC

Programs get placed in "\Programs" on the panel for easy
launching using the PanelShell mini-launcher

--------- --------- --------- ---------

DESKTOP TOOLS:
	gExplore.exe - Grundle Explorer
        Good for browsing files in local WinCE filesystem
        Free version won't copy files or run programs
        SHAREWARE - register for full features

	gRegEdit.exe - Grundle RegEdit
        Good for browsing registry, or importing .RCE files
        Free version won't edit registry entries
        SHAREWARE - register for full features

	pnotepad.exe - Pocket Notepad
        Great for taking notes.
        FREEWARE

    registry.exe - Another registry editor
		WinCE 2 SDK 'monkey' sample
        Use Grundle RegEdit for more features

GAMES:
	mspacman - small game
        SHAREWARE - register if you like it

    reversi - another classic
        WinCE 2 SDK sample

--------- --------- --------- ---------
If you find other useful shareware or freeware
WinCE programs that run on the Panel, please email me
  panelpet@aibohack.com

--------- --------- --------- ---------
