Custom ERS-11x AiboWare by AiboPet
For the ERS-110 and ERS-111

Disco AIBO 4.x
Non-Rcode version

http://aibohack.com/111
http://aibohack.com/disco

------------------------------------------
Disclaimer:

This AiboPet AiboWare contains parts that are my creation,
as well as parts that are owned by Sony (the main AiboWare).

Here are the rules that apply to all versions of ERS-11x AiboPet AiboWare:

Sony is not involved with this version of AiboWare.
Sony does not warrant this version.
I do not warrant this version.

Use this version AT YOUR OWN RISK !

You can use this version for your own amusement.
You can not modify, reverse engineer, disassemble or decompile this version.
You can not sell this version of AiboWare, or anything derived from it.

------------------------------------------

The software is copyrighted.

Please do not post copies of this software on the Internet.

This is not allowed by the copyright (you don't own the work, and I can't give
you the right to post Sony's copyrighted material)

More importantly, personalities like Disco AIBO change from time to time.
Having old copies floating around is a pain to deal with.

Instead, please point to the official site:

	http://aibohack.com/111
or:
	http://aibohack.com/disco

------------------------------------------

