Notes for AIBO custom personality: Disco AIBO 4.5 (11x part)

Contents of the "custom" directory are for documentation only
(these files are not needed to run the AIBO personality)

Also included in this directory:
    readme.txt = this file
    comments.ini = state descriptions
    disco4.sbl = Simplified Behavior Language source file
    *.sbh = files included by "disco4.sbl"

Credits:
    Behavior and tools - AiboPet (that's me)
    Dance choreography - many people

    See http://aibohack.com/disco
        for songs, instructions and full credits

--------------------------------------
Technical notes:

The "disco4.sbl" file includes the source for the state machine.

The Stage/Personality of the dog is marked as "Adult #1".
This is meaningless since Disco AIBO does not evolve and has none
of the standard AIBO personality traits.

Website: http://aibohack.com
Suggestions/Comments: aibopet@aibohack.com

--------------------------------------

A future version will use the newly announced/released RCODE for the 110/111
and include part selection (like the 2x0/31x version)

--------------------------------------

