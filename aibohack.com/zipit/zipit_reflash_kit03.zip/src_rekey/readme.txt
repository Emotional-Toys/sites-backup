ENCZ and DECZ are programs to encrypt and decrypt 2MB raw ROM images
You can ignore them.

Provided here for general education

usage:
    encz keyfile.key infile.raw outfile.bin
    decz keyfile.key infile.bin outfile.raw

.BIN files are 2MB + 16 bytes in length. Encrypted. Can be uploaded with "ZRS"
.RAW files are exactly 2MB in length. Not encrypted. Can be reflashed with "zflash" or otherwise decompiled.

----

NOTE: the keyfile is directly tied to the MD5 sum of the unencrypted .RAW file
[so this is not very useful if you change the data]

Here are the few command lines that are interesting:

#1) Decrypt the BURN3.BIN upgrade to a RAW file

    decz burn3.key burn3.bin burn3.raw
    
#2) Decrypt the 1.21 version ROM from the Zipit Website

	decz zipit3_1_21.key bootrom.4KD8G8NA.bin ROM21.RAW

Here is a much less interesting command line:
#3) Encrypt the BURN2.RAW upgrade to a BIN file
    (not interesting since you can't change the .RAW file contents without
    invalidating the .KEY file)

    encz burn3.key burn3.raw burn3_again.bin

