
// Standard includes

#include <stdio.h>
#include <assert.h>
#define verify assert
 // assert() used for sleazy runtime checks

#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock.h>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "wsock32.lib")
#pragma comment(lib, "advapi32.lib")

#define byte BYTE
#define uint8 BYTE
#define uint16 WORD
#define uint32 DWORD

#define ushort WORD
#define ulong DWORD
