// Zipit Reflash Server
// Minimal Server services for Zipit reflashing
//  DNS Server for redirection www.zipitwireless.net/com to our server
//  HTTP Server for hosting .txt and .bin file
//    NOTE: remove need to know exact ????????.txt filename
//  TODO??: NFS Server (version 3 UDP) for file upload/share

//  REMOVED/DEPRECATED: DHCP Server


// Design contraints:
//  everything in this one .exe
//  no Windows services or other installation
//  roll your own implementation
//  restricted to the lamest version of each protocol, just for Zipit
//  rely on standard Windows services (WINSOCK)
//  should run on practically every version of Windows
//   may adapt for Linux socket variations later

#include "std.h"

#include <process.h>
#include <conio.h>
#include <time.h>
#include <stdlib.h>

#include "sock.c_"

// #include "dhcp.h"
#include "dns.h"


/////////////////////////////////////////////////////////////
// over-wire data reversed from i386

ulong Swap32(ulong l)
{
    union { ulong l; byte b[4]; } u1, u2;
    u1.l = l;
    u2.b[0] = u1.b[3];
    u2.b[1] = u1.b[2];
    u2.b[2] = u1.b[1];
    u2.b[3] = u1.b[0];
    return u2.l;
}

ushort Swap16(ushort w)
{
    union { ushort w; byte b[2]; } u1, u2;
    u1.w = w;
    u2.b[0] = u1.b[1];
    u2.b[1] = u1.b[0];
    return u2.w;
}
/////////////////////////////////////////////////////////////

WSADATA g_wsaData;

//REVIEW: clean this up
byte g_ipaddrFake[4];

// hard coded !! -- REVIEW: put in INI or remove
byte g_ipaddrYahoo[4] = { 66, 218, 75, 184 };

struct THREADINFO
{
    int portListen;
};

#define ROMIMAGE_SIZE (2*1024*1024+16)
byte g_image[ROMIMAGE_SIZE];
char g_szVer[16];
char g_szMD5[64];

/////////////////////////////////////////////////////////////
// Very very simple DNS server

void cdecl DNS_Thread(void* pv)
{
    THREADINFO& ti = *(THREADINFO*)pv;

	printf("ZRS INFO: DNS server thread running (port %d)\n", ti.portListen);
	SOCKET hGet = OpenDatagram(ti.portListen, false);
	if (hGet == INVALID_SOCKET)
	{
		printf("ZRS FATAL: Can't create udp socket (%d)\n", ti.portListen);
		return;
	}

    while (1)
    {
        byte buffer[1000];
		SOCKADDR_IN sinFrom;
		int cbSinFrom = sizeof(sinFrom);

	    int cbIn = recvfrom(hGet, (char*)buffer, sizeof(buffer), 0,
             (struct sockaddr *)&sinFrom, &cbSinFrom);

        if (cbIn <= 0)
        {
            printf("."); // shouldn't happen - should be blocking
            continue;
        }
        printf("ZRS INFO: Got DNS request %d bytes\n", cbIn);

		if (cbIn < sizeof(MIN_DNS))
        {
			printf("ZRS WARNING: DNS request too small\n");
            continue;
        }
        MIN_DNS& dns = *(MIN_DNS*)buffer;
        if (dns.flags != Swap16(FLAGS_STDQUERY) ||
            dns.qdcount != Swap16(1) ||
            dns.ancount != 0 ||
            dns.nscount != 0 ||
            dns.arcount != 0)
        {
            printf("ZRS WARNING: DNS request not supported\n");
            continue;
        }
        char szString[256];
        char* pchOut = szString;
        byte* pbIn = (byte*)(&dns+1);
        while (*pbIn != 0)
        {
            byte cch = *pbIn++;
            memcpy(pchOut, pbIn, cch);
            pchOut += cch;
            pbIn += cch;
            if (*pbIn != '\0')
                *pchOut++ = '.';
        }
        pbIn++;
        *pchOut = '\0';
        printf("ZRS INFO: nslookup request '%s'\n", szString);

        byte ipaddrNew[4];
        if (strcmp(szString, "www.zipitwireless.net") == 0 ||
           strcmp(szString, "www.zipitwireless.com") == 0 ||
           strcmp(szString, "www.aibohack.com") == 0)
        {
            memcpy(ipaddrNew, g_ipaddrFake, 4);
        }
        else if (strcmp(szString, "login.yahoo.com") == 0)
        {
            // don't rely on this
            memcpy(ipaddrNew, g_ipaddrYahoo, 4);
        }
        else
        {
            printf("ZRS WARNING: DNS request unexpected URL\n");
            continue;
        }
	    END_DNSQUERY const& end = *(END_DNSQUERY*)pbIn;
        pbIn += sizeof(END_DNSQUERY);
        if (end.type != Swap16(1) || end.cls != Swap16(1))
        {
            printf("ZRS WARNING: DNS request not supported (end)\n");
            continue;
        }
        
        if (pbIn - buffer != cbIn)
        {
            printf("ZRS WARNING: DNS request not supported (bad len)\n");
            continue;
        }

        printf("ZRS INFO: Fake DNS redirecting '%s' to %d.%d.%d.%d\n",
            szString, 
            ipaddrNew[0], ipaddrNew[1],
            ipaddrNew[2], ipaddrNew[3]);

        // return dns record already in buffer (extend it for reply)
        dns = *(MIN_DNS*)buffer;
        dns.flags = Swap16(FLAGS_STDREPLY);
        dns.ancount = Swap16(1);

        byte* pbOut = pbIn; // at end of original packet
        MID_DNSANSWER& answer = *(MID_DNSANSWER*)pbOut;
        pbOut += sizeof(MID_DNSANSWER);
        answer.short_name = Swap16(0xC00C); // assumes location in std record
        answer.type = Swap16(1);
        answer.cls = Swap16(1);
        answer.ttl = Swap32(60*60);
        answer.rdlength = Swap16(4);
        memcpy(answer.rdata, g_ipaddrFake, 4);

        int cbOut = pbOut - buffer;

        // reply back to sender
		int cbSend = sendto(hGet, (char*)buffer, cbOut, 0,
             (struct sockaddr *)&sinFrom, cbSinFrom);
		if (cbSend != cbOut)
        {
			printf("ZRS ERROR: Fake DNS send error! (%d %d)\n", cbSend, cbOut);
            printf("err = %d\n", WSAGetLastError());
        }
    }
}

/////////////////////////////////////////////////////////////
// Very very simple HTTP server

static void FmtReplyText(char* reply, const char* szContent, bool bHead)
{
	// format simple mini-webpage
	sprintf(reply, "HTTP/1.0 200 OK\r\n"
		"Content-Type: text/html\r\n"
		"Content-Length: %d\r\n"
		"\r\n", strlen(szContent));
    if (!bHead)
    {
        // include data
		strcat(reply, szContent);
		strcat(reply, "\r\n");
    }
}

void cdecl HTTP_Thread(void* pv)
{
    THREADINFO& ti = *(THREADINFO*)pv;

//REVIEW: should be true IP of our computer (on WiFi adapter)
	printf("ZRS INFO: HTTP server thread running (port %d)\n", ti.portListen);

	SOCKET hListen = OpenListen(g_ipaddrFake, ti.portListen);
	if (hListen == INVALID_SOCKET)
	{
		printf("ZRS FATAL: Can't create listen socket (%d)\n", ti.portListen);
		return;
    }

    while (1)
    {
		SOCKET hIn = Accept(hListen); // wait for connect
        if (hIn == INVALID_SOCKET)
        {
            printf("ZRS FATAL: Can't accept connection (%d)\n", ti.portListen);
            return;
        }

        printf("ZRS INFO: HTTPD connect\n");

        while (1)
        {
	        byte buffer[1000];
		    int cbIn = recv(hIn, (char*)buffer, sizeof(buffer), 0);
            int err = WSAGetLastError();

            // don't rely on 'keep-alive' hints
            if (cbIn == 0)
            {
                // connection closed properly, go back and wait for next accept
                printf("\tZRS INFO: connection closed (kept alive too long)\n");
                break;
            }
	        else if (cbIn == -1 && err == WSAECONNRESET)
            {
                // connection reset, go back and wait for next accept
                printf("\tZRS INFO: connection reset (kept alive too long)\n");
                break;
            }
	        else if (cbIn == -1 && err == WSAEWOULDBLOCK)
            {
                // not ready yet
                Sleep(10);
                continue;
            }
	        else if (cbIn == -1)
	        {
                // nothing ready
                printf("\tZRS WARNING: recv err (%d)\n", err);
                Sleep(10);
                continue; // continue or break ?
	        }

            char szURL[128];
            szURL[0] = '\0';

            bool bHead = false;
            bool bKeepAlive = false;
                // can't rely on hints - so do it ourselves

            if (cbIn > 10 && memcmp(buffer, "GET ", 4) == 0)
            {
                char* pchStart = (char*)&buffer[4];
                char* pchEnd = strchr(pchStart, ' ');
                if (pchEnd != NULL)
                {
                    int cch = pchEnd-pchStart;
                    memcpy(szURL, pchStart, cch);
                    szURL[cch] = '\0';
	                printf("\tZRS INFO: HTTPD client request GET file '%s'\n", szURL);
                }
            }
            else if (cbIn > 10 && memcmp(buffer, "HEAD ", 5) == 0)
            {
                char* pchStart = (char*)&buffer[5];
                char* pchEnd = strchr(pchStart, ' ');
                if (pchEnd != NULL)
                {
                    int cch = pchEnd-pchStart;
                    memcpy(szURL, pchStart, cch);
                    szURL[cch] = '\0';
	                printf("\tZRS INFO: HTTPD client request HEAD file '%s'\n", szURL);
                    bHead = true;
                }
            }

            if (szURL[0] == '\0')
            {
                printf("\tZRS WARNING: Got an unsupported HTTP request (%d) - %d bytes\n", ti.portListen, cbIn);
				if (cbIn > 0)
				{
					FILE* pf = fopen("in.bin", "wb");
					assert(pf);
					assert(fwrite(buffer, cbIn, 1, pf) == 1);
					fclose(pf);
				}
                continue; // ignore it (danger ?)
            }

            long cbDataToSend = 0;
            byte* pbDataToSend = NULL;
            bool bSendLastData = false;

			char reply[1000];
			int cbReply = 0;

            if (strncmp(szURL, "/~zippy/", 8) == 0 &&
                strstr(szURL, ".txt") != NULL)
            {
                printf("\tZRS INFO: HTTPD sending version text info\n");

                // use LF-only for files
                char szT[256];
                sprintf(szT, "%s\n"
                    "http://www.zipitwireless.net/~zippy/current.bin\n"
                    "%32s\n", g_szVer, g_szMD5);
                FmtReplyText(reply, szT, bHead);
	            cbReply = strlen(reply);

                if (bHead)
		            bKeepAlive = true;  // keep open for GET
            }
            else if (strncmp(szURL, "/~zippy/", 8) == 0 &&
				strstr(szURL, ".bin") != NULL)
            {
                printf("\tZRS INFO: HTTPD sending ROM BINARY\n");
				sprintf(reply, "HTTP/1.0 200 OK\r\n"
					"Content-Type: application/octet-stream\r\n"
					"Content-Length: %ld\r\n"
					"\r\n", ROMIMAGE_SIZE); // no data this packet
	            cbReply = strlen(reply);

                if (bHead)
                {
		            bKeepAlive = true;  // keep open for GET
                }
                else
                {
                    // GET: look for Range: bytes=?-?\r\n
                    char *pchRange = strstr((char*)buffer, "Range: bytes=");
                    if (pchRange != NULL)
                    {
                        // sleazy parsing
                        pchRange += 13;
                        long ibStartRange = atol(pchRange);
                        pchRange = strchr(pchRange, '-');
                        assert(pchRange != NULL);
                        long ibEndRange = atol(pchRange+1);
            
                        assert(ibStartRange >= 0 && ibStartRange < ROMIMAGE_SIZE);
                        assert(ibEndRange > ibStartRange && ibEndRange < ROMIMAGE_SIZE);
		                cbDataToSend = ibEndRange + 1 - ibStartRange;
		                pbDataToSend = g_image + ibStartRange;
		                printf("\tZRS INFO: Partial ROM BINARY %ld-%ld\n",
                            ibStartRange, ibEndRange);
			            if (ibEndRange + 1 == ROMIMAGE_SIZE)
							bSendLastData = true;
                        else
                            bKeepAlive = true; // multiple GETs
                    }
                    else
                    {
                        // send all data
		                cbDataToSend = ROMIMAGE_SIZE;
		                pbDataToSend = g_image;
						bSendLastData = true;
                    }
                }
            }
            else
            {
                printf("\tZRS INFO: replying fake generic page\n");
                FmtReplyText(reply,
                    "<HTML>\r\n"
                    "<HEAD>Fake Webpage</HEAD>\r\n"
                    "<BODY>\r\n"
                    "Minimal 'ZRS' Webserver supports:<BR>\r\n"
                    "*.txt = return current.txt file from ZRS program<BR>\r\n"
                    "   <A HREF=/~zippy/test.txt>EXAMPLE.TXT</A><BR>\r\n"
                    "*.bin = return current.bin file from ZRS program<BR>\r\n"
                    "   <A HREF=/~zippy/test.bin>EXAMPLE.BIN</A><BR>\r\n"
                    "all other URLs return this lame page\r\n"
                    "</BODY></HTML>\r\n", bHead);
	            cbReply = strlen(reply);
            }

            if (cbReply <= 0)
            {
                printf("\tZRS INFO: NO-OP, RETRY\n");   // danger
                continue; // danger ?
            }

            // send reply (or header for binary)
			int cbSent = send(hIn, reply, cbReply, 0);
            if (cbSent != cbReply)
                printf("\tZRS ERROR: HTTPD send reply failed!\n");

#define CHUNK_MAX   1460

            while (cbDataToSend > 0)
            {
                // send continuation records
                int cbChunk = CHUNK_MAX;
                if (cbChunk > cbDataToSend)
                    cbChunk = cbDataToSend;
				int cbSent = send(hIn, (char*)pbDataToSend, cbChunk, 0);
                if (cbSent == -1)
                {
                    int err = WSAGetLastError();
                    if (err == WSAEWOULDBLOCK)
	                    printf("_");
                    else
	                    printf("_wait(%d)", err);

                    // let the socket catch up
                    Sleep(100);
                    continue;
                }
                if (cbSent != cbChunk)
                {
                    printf("\n\tZRS ERROR: HTTPD send binary data error! (%ld)\n", cbDataToSend);
                    break;
                }
                printf(".");
                pbDataToSend += cbChunk;
                cbDataToSend -= cbChunk;
                if (cbDataToSend == 0)
                {
                    // chunk sent (not yet received)
                    if (!bSendLastData)
                        printf("! -- data chunk sent\n");
                    else
                        printf("! -- add data sent\n\tZRS INFO: all data sent!\n");
                }
            }

            // keep alive logic is very weird
            if (bKeepAlive)
            {
				printf("\tZRS INFO: keep alive\n");
            }
            else
            {
				printf("\tZRS INFO: not keep alive\n");
                break;
            }
	    }

        printf("ZRS INFO: HTTPD disconnect\n");
		closesocket(hIn);
	}
	closesocket(hListen);
}
	

bool ParseIPAddrString(byte ipAddr[4], const char* szIPAddr)
{
    int b1, b2, b3, b4;
    if (sscanf(szIPAddr, "%d.%d.%d.%d", &b1, &b2, &b3, &b4) != 4)
        return false;
    ipAddr[0] = b1;
    ipAddr[1] = b2;
    ipAddr[2] = b3;
    ipAddr[3] = b4;
    return true;
}

static bool GetTrimLine(FILE* pf, char* szOut, int cbMax)
    // cbMax must be larger than max strlen()
{
    if (fgets(szOut, cbMax-1, pf) == NULL)
        return false;
    szOut[cbMax-1] = '\0';
    char* pch = strchr(szOut, '\n');
    if (pch == NULL)
    {
        // printf("(OOPS! line too long %d) '%s'\n", cbMax, szOut);
        return false;   // line too long
    }
    *pch = '\0';
    return strlen(szOut) > 0;
}

static bool ReadVersionFile(const char* szFile)
{
    FILE* pf = fopen(szFile, "rt");
    if (pf == NULL)
        return false;
    char szURL[256]; // ignored
    if (!GetTrimLine(pf, g_szVer, sizeof(g_szVer)) ||
      !GetTrimLine(pf, szURL, sizeof(szURL)) ||
      !GetTrimLine(pf, g_szMD5, sizeof(g_szMD5)))
    {
        fclose(pf);
        return false;
    }
    // assume the rest are ok
    if (strchr(g_szVer, '.') == NULL)
        return false;
    if (strlen(g_szMD5) != 32)
        return false; // very strict

    printf("\tVERSION: %s\n", g_szVer);
    printf("\tMD5SUM: %s\n", g_szMD5);
    return true;
}

static bool ReadImageFile(const char* szFile)
{
    FILE* pf = fopen(szFile, "rb");
    if (pf == NULL)
        return false;
    byte bEnd;
    if (fread(g_image, ROMIMAGE_SIZE, 1, pf) != 1 ||
        fread(&bEnd, 1, 1, pf) != 0)
    {
        fclose(pf);
        return false;
    }
	fclose(pf);
    return true;
}

int main(int argc, char* argv[])
{
    printf("Zipit Reflashing Server 0.01 (ZRS)\n");
    printf("  (c) 2004-2005 - ZipItPet\n");
    printf("  http://aibohack.com/zipit\n");
    printf("\n");

    if (argc != 3)
    {
	    printf("usage: zrs base_name this_ip_address\n");
        return -1;
    }
        
    const char* szBase = argv[1];
    const char* szIPForward = argv[2];

    printf("ZRS INFO: exporting version %s.txt and %s.bin\n", szBase, szBase);
    // read in 'current.txt' and 'current.bin'
    char szFile[MAX_PATH];
    sprintf(szFile, "%s.txt", szBase);
    if (!ReadVersionFile(szFile))
    {
        printf("ZRS FATAL: Bad version file (%s)\n", szFile);
        return -1;
    }
    sprintf(szFile, "%s.bin", szBase);
    if (!ReadImageFile(szFile))
    {
        printf("ZRS FATAL: Bad ROM image file (%s)\n", szFile);
        return -1;
    }

    if (!ParseIPAddrString(g_ipaddrFake, szIPForward))
    {
        printf("ZRS FATAL: Bad IP address\n");
        return -1;
    }

    printf("ZRS INFO: Using IP %d.%d.%d.%d for DNS and HTTP servers\n",
        g_ipaddrFake[0],
        g_ipaddrFake[1],
        g_ipaddrFake[2],
        g_ipaddrFake[3]);

    if (WSAStartup(MAKEWORD(1,1), &g_wsaData) != 0)
    {
        printf("ZRS FATAL: winsock init error\n");
        return -1;
    }

    // DNS mapping
	THREADINFO ti0;
    ti0.portListen = DNS_UDP_REQUEST_PORT;
	unsigned long t0 = _beginthread(DNS_Thread, 0, &ti0);

    // HTTP server -- one thread
	THREADINFO ti1;
    ti1.portListen = 80;
	unsigned long t1 = _beginthread(HTTP_Thread, 0, &ti1);

#ifdef LATER
    // NFS server ? - or split into another
#endif

    Sleep(100);
    printf("ZRS INFO: Mini DNS and HTTP server running (hit Ctrl-C to stop)\n");
    while (1)
    {
        Sleep(60*1000); // lame
    }

	WSACleanup();

    return 0;
}


