// limited DNS request

#define DNS_UDP_REQUEST_PORT 53

#include <pshpack2.h>   // uint16 alignment

struct MIN_DNS
{
    // uint16 need swapping
    uint16 xid;
    uint16 flags;
        // expect 0x0100 = standard query

    uint16 qdcount, ancount, nscount, arcount;
        // expect: 1, 0, 0, 0
        // reply: 1, 1, 0, 0
};

#define FLAGS_STDQUERY 0x0100
#define FLAGS_STDREPLY 0x8180

// followed by name parts (usually 3) or special reuse labels
// followed by
struct END_DNSQUERY
{
    uint16 type, cls;
        // both 1
};

struct MID_DNSANSWER
{
    uint16 short_name; // $C00C for standard query
    uint16 type, cls; // both 1
    uint32 ttl; // seconds
    uint16 rdlength;    // 4 for IP address
    uint8 rdata[4];
};


#include <poppack.h>   // default alignment
